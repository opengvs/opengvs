#pragma once
#include <windows.h>
//#include <fstream>
//#include <sstream>
//#include <iostream>
//#include "TraceMsg.h"

#ifdef _MSC_VER
#pragma optimize( "g", off )
#endif

#include "glad.h"
#include <string>
#include "glm/glm.hpp"
#include "glm/gtc/type_ptr.hpp"
#include "Shader.hpp"

class GLMaterial
{
public:
    std::string    Name;

    //��������ʲ���            Ĭ��ֵΪGL_ambient
    glm::vec3 ambient = glm::vec3(0.2f, 0.2f, 0.2f);//��ʾ���ʶԻ����ⷴ���RGBAֵ��ǰ������ȱʡֵ���� (0.2, 0.2, 0.2, 1.0)��
    
    //�������ʲ���         Ĭ��ֵΪGL_diffuse��GL_ambient_AND_diffuse
    glm::vec3 diffuse = glm::vec3(0.8f, 0.8f, 0.8f);//��ʾ���ʶ������ķ���RGBAֵ��ǰ������ȱʡֵ���� (0.8, 0.8, 0.8, 1.0)��
    
    //���淴����ʲ���     Ĭ��ֵΪGL_specular 
    glm::vec3 specular = glm::vec3(0.0f, 0.0f, 0.0f);//��ʾ���ʶԾ����ķ���RGBAֵ��ǰ������ȱʡֵ���� (0.0, 0.0, 0.0, 1.0)��
    
    //����ָ���ⷴ��������������
    float  shininess = 0.0f;//��ʾ���ʵľ���ָ����ȡֵ��Χ��[0,128]����ȡֵΪ128ʱ�����ʾ�ò�����һ��ȫ���档ȱʡֵΪ0��

    //�������Է�������
    glm::vec3 emissive = glm::vec3(0.0f, 0.0f, 0.0f); //��ʾ���ʷ����RGBAֵ��ǰ������ȱʡֵ���� (0.0, 0.0, 0.0, 1.0)��

    glm::vec3 reflective = glm::vec3(0.0f, 0.0f, 0.0f);//���䣬��Ӱ,

    glm::vec3 transparent = glm::vec3(1.0f, 1.0f, 1.0f);//͸���Ȳ���

    GLMaterial()
    {

    }
    virtual ~GLMaterial()
    {

    }
    void SendAmbientData(const Shader* pShader, const std::string& _AmbientName)
    {
        pShader->SetVec3(_AmbientName, ambient);
    }
    void SendDiffuseData(const Shader* pShader, const std::string& _DiffuseName )
    {
        pShader->SetVec3(_DiffuseName, diffuse);
    }
    void SendSpecularData(const Shader* pShader, const std::string& _SpecularName, const std::string& _ShininessName)
    {
        pShader->SetVec3(_SpecularName, specular);
        pShader->setFloat(_ShininessName, shininess);
    }

    void SendEmissiveData(const Shader* pShader, const std::string& _EmissiveName)
    {
        pShader->SetVec3(_EmissiveName, emissive);
    }

    void SendReflectiveData(const Shader* pShader, const std::string& _ReflectiveName)
    {
        pShader->SetVec3(_ReflectiveName, reflective);
    }

    void SendTransparentData(const Shader* pShader, const std::string& _TransparentName)
    {
        pShader->SetVec3(_TransparentName, transparent);
    }

};

class GLMaterials
{
public:
    static GLMaterial GetEmeraldMaterial()
    {
        GLMaterial material;
        material.Name = "Emerald";//���
        material.ambient.r = 0.0215f;
        material.ambient.g = 0.1745f;
        material.ambient.b = 0.0215f;
        material.diffuse.r = 0.07568f;
        material.diffuse.g = 0.61424f;
        material.diffuse.b = 0.07568f;
        material.specular.r = 0.07568f;
        material.specular.g = 0.61424f;
        material.specular.b = 0.07568f;
        material.shininess = 0.6f;
        return material;
    }

    static GLMaterial GetJadeMaterial()
    {
        GLMaterial material;
        material.Name = "Jade";//��
        material.ambient.r = 0.135f;
        material.ambient.g = 0.2225f;
        material.ambient.b = 0.1575f;
        material.diffuse.r = 0.54f;
        material.diffuse.g = 0.89f;
        material.diffuse.b = 0.63f;
        material.specular.r = 0.316228f;
        material.specular.g = 0.316228f;
        material.specular.b = 0.316228f;
        material.shininess = 0.1f;
        return material;
    }

    static GLMaterial GetObsidianMaterial()
    {
        GLMaterial material;
        material.Name = "Obsidian";//����ʯ
        material.ambient.r = 0.05375f;
        material.ambient.g = 0.05f;
        material.ambient.b = 0.06f;
        material.diffuse.r = 0.18275f;
        material.diffuse.g = 0.17f;
        material.diffuse.b = 0.22525f;
        material.specular.r = 0.332741f;
        material.specular.g = 0.328634f;
        material.specular.b = 0.346435f;
        material.shininess = 0.3f;
        return material;
    }
    static GLMaterial GetPearlMaterial()
    {
        GLMaterial material;
        material.Name = "Pearl";//����
        material.ambient.r = 0.25f;
        material.ambient.g = 0.20725f;
        material.ambient.b = 0.20725f;
        material.diffuse.r = 1.0f;
        material.diffuse.g = 0.829f;
        material.diffuse.b = 0.829f;
        material.specular.r = 0.296648f;
        material.specular.g = 0.296648f;
        material.specular.b = 0.296648f;
        material.shininess = 0.088f;
        return material;
    }
    static GLMaterial GetRubyMaterial()
    {
        GLMaterial material;
        material.Name = "Ruby";//�챦ʯ
        material.ambient.r = 0.1745f;
        material.ambient.g = 0.01175f;
        material.ambient.b = 0.01175f;
        material.diffuse.r = 0.61424f;
        material.diffuse.g = 0.04136f;
        material.diffuse.b = 0.04136f;
        material.specular.r = 0.727811f;
        material.specular.g = 0.626959f;
        material.specular.b = 0.626959f;
        material.shininess = 0.6f;
        return material;
    }
    static GLMaterial GetTurquoiseMaterial()
    {
        GLMaterial material;
        material.Name = "Turquoise";//����ʯ
        material.ambient.r = 0.1f;
        material.ambient.g = 0.18725f;
        material.ambient.b = 0.1745f;
        material.diffuse.r = 0.396f;
        material.diffuse.g = 0.74151f;
        material.diffuse.b = 0.69102f;
        material.specular.r = 0.297254f;
        material.specular.g = 0.30829f;
        material.specular.b = 0.306678f;
        material.shininess = 0.1f;
        return material;
    }
    static GLMaterial GetBrassMaterial()
    {
        GLMaterial material;
        material.Name = "Brass";//��ͭ
        material.ambient.r = 0.329412f;
        material.ambient.g = 0.223529f;
        material.ambient.b = 0.027451f;
        material.diffuse.r = 0.780392f;
        material.diffuse.g = 0.568627f;
        material.diffuse.b = 0.113725f;
        material.specular.r = 0.992157f;
        material.specular.g = 0.941176f;
        material.specular.b = 0.807843f;
        material.shininess = 0.21794872f;
        return material;
    }
    static GLMaterial GetBronzeMaterial()
    {
        GLMaterial material;
        material.Name = "Bronze";//��ͭ
        material.ambient.r = 0.2125f;
        material.ambient.g = 0.1275f;
        material.ambient.b = 0.054f;
        material.diffuse.r = 0.714f;
        material.diffuse.g = 0.4284f;
        material.diffuse.b = 0.18144f;
        material.specular.r = 0.393548f;
        material.specular.g = 0.271906f;
        material.specular.b = 0.166721f;
        material.shininess = 0.2f;
        return material;
    }
    static GLMaterial GetChromeMaterial()
    {
        GLMaterial material;
        material.Name = "Chrome";//��
        material.ambient.r = 0.25f;
        material.ambient.g = 0.25f;
        material.ambient.b = 0.25f;
        material.diffuse.r = 0.4f;
        material.diffuse.g = 0.4f;
        material.diffuse.b = 0.4f;
        material.specular.r = 0.774597f;
        material.specular.g = 0.774597f;
        material.specular.b = 0.774597f;
        material.shininess = 0.6f;
        return material;
    }
    static GLMaterial GetCopperMaterial()
    {
        GLMaterial material;
        material.Name = "Copper";//ͭ
        material.ambient.r = 0.19125f;
        material.ambient.g = 0.0735f;
        material.ambient.b = 0.0225f;
        material.diffuse.r = 0.7038f;
        material.diffuse.g = 0.27048f;
        material.diffuse.b = 0.0828f;
        material.specular.r = 0.256777f;
        material.specular.g = 0.137622f;
        material.specular.b = 0.086014f;
        material.shininess = 0.1f;
        return material;
    }
    static GLMaterial GetGoldMaterial()
    {
        GLMaterial material;
        material.Name = "Gold";//�ƽ�
        material.ambient.r = 0.24725f;
        material.ambient.g = 0.1995f;
        material.ambient.b = 0.0745f;
        material.diffuse.r = 0.75164f;
        material.diffuse.g = 0.60648f;
        material.diffuse.b = 0.22648f;
        material.specular.r = 0.638281f;
        material.specular.g = 0.555802f;
        material.specular.b = 0.366065f;
        material.shininess = 0.4f;
        return material;
    }
    static GLMaterial GetSilverMaterial()
    {
        GLMaterial material;
        material.Name = "Silver";//��
        material.ambient.r = 0.19225f;
        material.ambient.g = 0.19225f;
        material.ambient.b = 0.19225f;
        material.diffuse.r = 0.50754f;
        material.diffuse.g = 0.50754f;
        material.diffuse.b = 0.50754f;
        material.specular.r = 0.508273f;
        material.specular.g = 0.508273f;
        material.specular.b = 0.508273f;
        material.shininess = 0.4f;
        return material;
    }
    static GLMaterial GetBlackPlasticMaterial()
    {
        GLMaterial material;
        material.Name = "BlackPlastic";//��ɫ����
        material.ambient.r = 0.0f;
        material.ambient.g = 0.0f;
        material.ambient.b = 0.0f;
        material.diffuse.r = 0.1f;
        material.diffuse.g = 0.1f;
        material.diffuse.b = 0.1f;
        material.specular.r = 0.5f;
        material.specular.g = 0.5f;
        material.specular.b = 0.5f;
        material.shininess = 0.25f;
        return material;
    }
    static GLMaterial GetCyanPlasticMaterial()
    {
        GLMaterial material;
        material.Name="CyanPlastic";//��ɫ����
        material.ambient.r = 0.0f;
        material.ambient.g = 0.0f;
        material.ambient.b = 0.06f;
        material.diffuse.r = 0.0f;
        material.diffuse.g = 0.50980392f;
        material.diffuse.b = 0.50980392f;
        material.specular.r = 0.50196078f;
        material.specular.g = 0.50196078f;
        material.specular.b = 0.50196078f;
        material.shininess = 0.25f;
        return material;
    }
    static GLMaterial GetGreenPlasticMaterial()
    {
        GLMaterial material;
        material.Name = "GreenPlastic";//��ɫ����
        material.ambient.r = 0.0f;
        material.ambient.g = 0.0f;
        material.ambient.b = 0.0f;
        material.diffuse.r = 0.1f;
        material.diffuse.g = 0.35f;
        material.diffuse.b = 0.1f;
        material.specular.r = 0.45f;
        material.specular.g = 0.55f;
        material.specular.b = 0.45f;
        material.shininess = 0.25f;
        return material;
    }
    static GLMaterial GetRedPlasticMaterial()
    {
        GLMaterial material;
        material.Name = "RedPlastic";//��ɫ����
        material.ambient.r = 0.0f;
        material.ambient.g = 0.0f;
        material.ambient.b = 0.0f;
        material.diffuse.r = 0.5f;
        material.diffuse.g = 0.0f;
        material.diffuse.b = 0.0f;
        material.specular.r = 0.7f;
        material.specular.g = 0.6f;
        material.specular.b = 0.6f;
        material.shininess = 0.25f;
        return material;
    }
    static GLMaterial GetWhitePlasticMaterial()
    {
        GLMaterial material;
        material.Name = "WhitePlastic";//��ɫ����
        material.ambient.r = 0.0f;
        material.ambient.g = 0.0f;
        material.ambient.b = 0.0f;
        material.diffuse.r = 0.55f;
        material.diffuse.g = 0.55f;
        material.diffuse.b = 0.55f;
        material.specular.r = 0.7f;
        material.specular.g = 0.7f;
        material.specular.b = 0.7f;
        material.shininess = 0.25f;
        return material;
    }
    static GLMaterial GetYellowPlasticMaterial()
    {
        GLMaterial material;
        material.Name = "YellowPlastic";//��ɫ����
        material.ambient.r = 0.0f;
        material.ambient.g = 0.0f;
        material.ambient.b = 0.0f;
        material.diffuse.r = 0.5f;
        material.diffuse.g = 0.5f;
        material.diffuse.b = 0.0f;
        material.specular.r = 0.6f;
        material.specular.g = 0.6f;
        material.specular.b = 0.5f;
        material.shininess = 0.25f;
        return material;
    }
    static GLMaterial GetBlackRubberMaterial()
    {
        GLMaterial material;
        material.Name = "BlackRubber";//��ɫ��
        material.ambient.r = 0.02f;
        material.ambient.g = 0.02f;
        material.ambient.b = 0.02f;
        material.diffuse.r = 0.01f;
        material.diffuse.g = 0.01f;
        material.diffuse.b = 0.01f;
        material.specular.r = 0.4f;
        material.specular.g = 0.4f;
        material.specular.b = 0.4f;
        material.shininess = 0.78125f;
        return material;
    }
    static GLMaterial GetCyanRubberMaterial()
    {
        GLMaterial material;
        material.Name = "CyanRubber";//��ɫ��
        material.ambient.r = 0.0f;
        material.ambient.g = 0.05f;
        material.ambient.b = 0.05f;
        material.diffuse.r = 0.4f;
        material.diffuse.g = 0.5f;
        material.diffuse.b = 0.5f;
        material.specular.r = 0.04f;
        material.specular.g = 0.7f;
        material.specular.b = 0.7f;
        material.shininess = 0.78125f;
        return material;
    }
    static GLMaterial GetGreenRubberMaterial()
    {
        GLMaterial material;
        material.Name = "GreenRubber";//��ɫ��
        material.ambient.r = 0.0f;
        material.ambient.g = 0.05f;
        material.ambient.b = 0.0f;
        material.diffuse.r = 0.4f;
        material.diffuse.g = 0.5f;
        material.diffuse.b = 0.4f;
        material.specular.r = 0.04f;
        material.specular.g = 0.7f;
        material.specular.b = 0.04f;
        material.shininess = 0.78125f;
        return material;
    }
    static GLMaterial GetRedRubberMaterial()
    {
        GLMaterial material;
        material.Name = "RedRubber";//��ɫ��
        material.ambient.r = 0.05f;
        material.ambient.g = 0.0f;
        material.ambient.b = 0.0f;
        material.diffuse.r = 0.5f;
        material.diffuse.g = 0.4f;
        material.diffuse.b = 0.4f;
        material.specular.r = 0.7f;
        material.specular.g = 0.04f;
        material.specular.b = 0.04f;
        material.shininess = 0.78125f;
        return material;
    }
    static GLMaterial GetWhiteRubberMaterial()
    {
        GLMaterial material;
        material.Name = "WhiteRubber";//��ɫ��
        material.ambient.r = 0.05f;
        material.ambient.g = 0.05f;
        material.ambient.b = 0.05f;
        material.diffuse.r = 0.5f;
        material.diffuse.g = 0.5f;
        material.diffuse.b = 0.5f;
        material.specular.r = 0.7f;
        material.specular.g = 0.7f;
        material.specular.b = 0.7f;
        material.shininess = 0.78125f;
        return material;
    }
    static GLMaterial GetYellowRubberMaterial()
    {
        GLMaterial material;
        material.Name = "YellowRubber";//��ɫ��
        material.ambient.r = 0.05f;
        material.ambient.g = 0.05f;
        material.ambient.b = 0.00f;
        material.diffuse.r = 0.5f;
        material.diffuse.g = 0.5f;
        material.diffuse.b = 0.4f;
        material.specular.r = 0.7f;
        material.specular.g = 0.7f;
        material.specular.b = 0.04f;
        material.shininess = 0.78125f;
        return material;
    }

  

};

