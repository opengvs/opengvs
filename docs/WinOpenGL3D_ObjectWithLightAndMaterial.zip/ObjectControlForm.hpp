#pragma once
#include "framework.h"
#include "WinForm.hpp"
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"
#include "transform.hpp"
#include "Format.h"
#include "SphereUseMaterial.hpp"

extern SphereUseMaterial            g_sphereUseMaterial;

class  ObjetControlTabPage:public Win::TabPage
{
public:
    
  Win::EditBox m_Mat00;
  Win::EditBox m_Mat01;
  Win::EditBox m_Mat02;
  Win::EditBox m_Mat03;

  Win::EditBox m_Mat10;
  Win::EditBox m_Mat11;
  Win::EditBox m_Mat12;
  Win::EditBox m_Mat13;
  Win::EditBox m_Mat20;
  Win::EditBox m_Mat21;
  Win::EditBox m_Mat22;
  Win::EditBox m_Mat23;
  Win::EditBox m_Mat30;
  Win::EditBox m_Mat31;
  Win::EditBox m_Mat32;
  Win::EditBox m_Mat33;

  Win::EditBox m_Rotation_X_Edit;
  Win::EditBox m_Rotation_Y_Edit;
  Win::EditBox m_Rotation_Z_Edit;

  Win::Button  m_RatationButtion;
  Win::RadioButton m_AUTORATATION;
  Win::UpDownBox   m_MOVEX_SPIN;
  Win::UpDownBox   m_MOVEY_SPIN;

  Win::EditBox   m_SCALE_X_EDIT;
  Win::EditBox   m_SCALE_Y_EDIT;
  Win::EditBox   m_SCALE_Z_EDIT;
  Win::Trackbar  m_SCALE_X_SLIDER;
  Win::Trackbar  m_SCALE_Y_SLIDER;
  Win::Trackbar  m_SCALE_Z_SLIDER;

  Win::RadioButton  m_SHOW_ONE_RADIO;
  Win::RadioButton  m_SHOW_ALL_RADIO;


  
    void SetModelMat( Transform& _transform)
    {
        glm::mat4 mat = _transform.GetMat();
        std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][0]);
        m_Mat00.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][1]);
        m_Mat01.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][2]);
        m_Mat02.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][3]);
        m_Mat03.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][0]);
        m_Mat10.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][1]);
        m_Mat11.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][2]);
        m_Mat12.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][3]);
        m_Mat13.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][0]);
        m_Mat20.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][1]);
        m_Mat21.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][2]);
        m_Mat22.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][3]);
        m_Mat23.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][0]);
        m_Mat30.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][1]);
        m_Mat31.setText(tempStr.c_str());
        float tempF = mat[3][2];
        tempStr = StringFormat::wstr_format(L"%.2lf", tempF);
        m_Mat32.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][3]);
        m_Mat33.setText(tempStr.c_str());

        const glm::vec3& rotation = _transform.GetRotation();
        tempStr = StringFormat::wstr_format(L"%.2lf", glm::degrees(rotation.x));
        m_Rotation_X_Edit.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", glm::degrees(rotation.y));
        m_Rotation_Y_Edit.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", glm::degrees(rotation.z));
        m_Rotation_Z_Edit.setText(tempStr.c_str());

        const glm::vec3& scale = _transform.GetScale();
        tempStr = StringFormat::wstr_format(L"%.2lf", scale.x);
        m_SCALE_X_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", scale.y);
        m_SCALE_Y_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", scale.z);
        m_SCALE_Z_EDIT.setText(tempStr.c_str());

    }
    
    virtual void Init_Event(HWND hDlg,WPARAM wParam, LPARAM lParam)
    {
               m_Mat00.set(hDlg, IDC_MAT00);
               m_Mat01.set(hDlg, IDC_MAT01);
               m_Mat02.set(hDlg, IDC_MAT02);
               m_Mat03.set(hDlg, IDC_MAT03);
               m_Mat10.set(hDlg, IDC_MAT10);
               m_Mat11.set(hDlg, IDC_MAT11);
               m_Mat12.set(hDlg, IDC_MAT12);
               m_Mat13.set(hDlg, IDC_MAT13);
               m_Mat20.set(hDlg, IDC_MAT20);
               m_Mat21.set(hDlg, IDC_MAT21);
               m_Mat22.set(hDlg, IDC_MAT22);
               m_Mat23.set(hDlg, IDC_MAT23);
               m_Mat30.set(hDlg, IDC_MAT30);
               m_Mat31.set(hDlg, IDC_MAT31);
               m_Mat32.set(hDlg, IDC_MAT32);
               m_Mat33.set(hDlg, IDC_MAT33);


               m_Rotation_X_Edit.set(hDlg, IDC_ROTATION_X_EDIT);
               m_Rotation_X_Edit.setText(L"0");
               m_Rotation_Y_Edit.set(hDlg, IDC_ROTATION_Y_EDIT);
               m_Rotation_Y_Edit.setText(L"0");
               m_Rotation_Z_Edit.set(hDlg, IDC_ROTATION_Z_EDIT);
               m_Rotation_Z_Edit.setText(L"0");

               m_RatationButtion.set(hDlg, IDC_ROTATIONBUTTON);
               m_AUTORATATION.set(hDlg, IDC_AUTORATATION);
               m_MOVEX_SPIN.set(hDlg, IDC_MOVEX_SPIN);
               m_MOVEX_SPIN.setRange(-100, 100);
               m_MOVEX_SPIN.setPos(0);
               m_MOVEY_SPIN.set(hDlg, IDC_MOVEY_SPIN);
               m_MOVEY_SPIN.setRange(-100, 100);
               m_MOVEY_SPIN.setPos(0);
               m_SCALE_X_EDIT.set(hDlg, IDC_SCALE_X_EDIT);
               m_SCALE_X_EDIT.setText(L"1");
               m_SCALE_Y_EDIT.set(hDlg, IDC_SCALE_Y_EDIT);
               m_SCALE_Y_EDIT.setText(L"1");
               m_SCALE_Z_EDIT.set(hDlg, IDC_SCALE_Z_EDIT);
               m_SCALE_Z_EDIT.setText(L"1");
               m_SCALE_X_SLIDER.set(hDlg, IDC_SCALE_X_SLIDER);
               m_SCALE_X_SLIDER.setRange(1, 100);
               m_SCALE_X_SLIDER.setPos(50);
               m_SCALE_Y_SLIDER.set(hDlg, IDC_SCALE_Y_SLIDER);
               m_SCALE_Y_SLIDER.setRange(1, 100);
               m_SCALE_Y_SLIDER.setPos(50);
               m_SCALE_Z_SLIDER.set(hDlg, IDC_SCALE_Z_SLIDER);
               m_SCALE_Z_SLIDER.setRange(1, 100);
               m_SCALE_Z_SLIDER.setPos(50);

               m_SHOW_ONE_RADIO.set(hDlg, IDC_SHOW_ONE_RADIO);
               m_SHOW_ALL_RADIO.set(hDlg, IDC_SHOW_ALL_RADIO);
               m_SHOW_ALL_RADIO.check();

             /*  m_RADIO1.set(hDlg, IDC_RADIO1);
               m_RADIO2.set(hDlg, IDC_RADIO2);
               m_RADIO1.check();
               */
               Transform  _transform;

               SetModelMat(_transform);
    }
    virtual VOID TabPage_OnCommand(HWND hwnd, INT id, HWND hwndCtl, UINT codeNotify)
    {

      if (id == IDC_ROTATIONBUTTON_X_UP)
      {
          g_sphereUseMaterial.RotateAngleX(glm::radians(5.0f));
          SetModelMat(g_sphereUseMaterial);

      }
      else if (id == IDC_ROTATIONBUTTON_X_DOWN)
      {
          g_sphereUseMaterial.RotateAngleX(glm::radians(-5.0f));
          SetModelMat(g_sphereUseMaterial);

      }
      else if (id == IDC_ROTATIONBUTTON_Y_UP)
      {
          g_sphereUseMaterial.RotateAngleY(glm::radians(5.0f));
          SetModelMat(g_sphereUseMaterial);

      }
      else if (id == IDC_ROTATIONBUTTON_Y_DOWN)
      {
          g_sphereUseMaterial.RotateAngleY(glm::radians(-5.0f));
          SetModelMat(g_sphereUseMaterial);

      }
      else if (id == IDC_ROTATIONBUTTON_Z_UP)
      {
          g_sphereUseMaterial.RotateAngleZ(glm::radians(5.0f));
          SetModelMat(g_sphereUseMaterial);

      }
      else if (id == IDC_ROTATIONBUTTON_Z_DOWN)
      {
          g_sphereUseMaterial.RotateAngleZ(glm::radians(-5.0f));
          SetModelMat(g_sphereUseMaterial);

      }
    }
    virtual VOID TabPage_OnNotify(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
    {
        NMHDR* p = (NMHDR*)(void*)lParam;

        LONG iID = wParam;
        if (iID == IDC_MOVEX_SPIN)
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta > 0)
            {
                g_sphereUseMaterial.MoveAlongVectorDistance(glm::vec3(1.0f, 0, 0), 1.0f);
                SetModelMat(g_sphereUseMaterial);

            }
            else
            {
                g_sphereUseMaterial.MoveAlongVectorDistance(glm::vec3(1.0f, 0, 0), -1.0f);
                SetModelMat(g_sphereUseMaterial);

            }

        }
        else if (iID == IDC_MOVEY_SPIN)
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta > 0)
            {
                g_sphereUseMaterial.MoveAlongVectorDistance(glm::vec3(0.0f, 1.0f, 0), 1.0f);
                SetModelMat(g_sphereUseMaterial);


            }
            else
            {
                g_sphereUseMaterial.MoveAlongVectorDistance(glm::vec3(0.0f, 1.0f, 0), -1.0f);
                SetModelMat(g_sphereUseMaterial);

            }

        }
        else if (iID == IDC_MOVEZ_SPIN)
        {


            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta > 0)
            {
                g_sphereUseMaterial.MoveAlongVectorDistance(glm::vec3(0.0f, 0, 1.0f), 1.0f);
                SetModelMat(g_sphereUseMaterial);

            }
            else
            {
                g_sphereUseMaterial.MoveAlongVectorDistance(glm::vec3(0.0f, 0, 1.0f), -1.0f);
                SetModelMat(g_sphereUseMaterial);

            }

        }
        else if (iID == IDC_SCALE_X_SLIDER)
        {
            int tPos = m_SCALE_X_SLIDER.getPos();
            float tempF = 1.0f;
            std::wstring tempStr;// = std::to_wstring(tPos);
            if (tPos == 50)
                tempStr = L"1";
            else
            {
                if (tPos > 50)
                {
                    tempF = 1.0f - (9.0f / 50.0f) * (50 - tPos);
                    tempStr = std::to_wstring(tempF);
                }
                else
                {
                    tempF = (0.9f / 49.0f) * (tPos - 1) + 0.1f;
                    tempStr = std::to_wstring(tempF);
                }
            }
            m_SCALE_X_EDIT.setText(tempStr.c_str());
            glm::vec3 _scale = g_sphereUseMaterial.GetScale();
            g_sphereUseMaterial.SetScale(glm::vec3(tempF, _scale.y, _scale.z));

        }
        else if (iID == IDC_SCALE_Y_SLIDER)
        {
            int tPos = m_SCALE_Y_SLIDER.getPos();
            float tempF = 1.0f;
            std::wstring tempStr;// = std::to_wstring(tPos);
            if (tPos == 50)
                tempStr = L"1";
            else
            {
                if (tPos > 50)
                {
                    tempF = 1.0f - (9.0f / 50.0f) * (50 - tPos);
                    tempStr = std::to_wstring(tempF);
                }
                else
                {
                    tempF = (0.9f / 49.0f) * (tPos - 1) + 0.1f;
                    tempStr = std::to_wstring(tempF);
                }
            }
            m_SCALE_Y_EDIT.setText(tempStr.c_str());
            glm::vec3 _scale = g_sphereUseMaterial.GetScale();
            g_sphereUseMaterial.SetScale(glm::vec3(_scale.x, tempF,  _scale.z));
 
        }
        else if (iID == IDC_SCALE_Z_SLIDER)
        {
            int tPos = m_SCALE_Z_SLIDER.getPos();
            float tempF = 1.0f;
            std::wstring tempStr;// = std::to_wstring(tPos);
            if (tPos == 50)
                tempStr = L"1";
            else
            {
                if (tPos > 50)
                {
                    tempF = 1.0f - (9.0f / 50.0f) * (50 - tPos);
                    tempStr = std::to_wstring(tempF);
                }
                else
                {
                    tempF = (0.9f / 49.0f) * (tPos - 1) + 0.1f;
                    tempStr = std::to_wstring(tempF);
                }
            }
            m_SCALE_Z_EDIT.setText(tempStr.c_str());
            glm::vec3 _scale = g_sphereUseMaterial.GetScale();
            g_sphereUseMaterial.SetScale(glm::vec3(_scale.x, _scale.z, tempF));  
        }
    }
};
