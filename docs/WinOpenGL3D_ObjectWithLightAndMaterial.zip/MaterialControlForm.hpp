#pragma once

#include "framework.h"
#include "WinForm.hpp"
#include "GLMaterial.hpp"
#include "Format.h"

extern GLMaterial                   g_Material_1;
class  MaterialControlForm :public Win::TabPage
{
public:
    Win::EditBox m_AMBIENT_R_EDIT;
    Win::EditBox m_AMBIENT_G_EDIT;
    Win::EditBox m_AMBIENT_B_EDIT;
    Win::UpDownBox m_AMBIENT_R_SPIN;
    Win::UpDownBox m_AMBIENT_G_SPIN;
    Win::UpDownBox m_AMBIENT_B_SPIN;

    Win::EditBox m_DIFFUSE_R_EDIT;
    Win::EditBox m_DIFFUSE_G_EDIT;
    Win::EditBox m_DIFFUSE_B_EDIT;
    Win::UpDownBox m_DIFFUSE_R_SPIN;
    Win::UpDownBox m_DIFFUSE_G_SPIN;
    Win::UpDownBox m_DIFFUSE_B_SPIN;

    Win::EditBox m_SPECULAR_R_EDIT;
    Win::EditBox m_SPECULAR_G_EDIT;
    Win::EditBox m_SPECULAR_B_EDIT;
    Win::UpDownBox m_SPECULAR_R_SPIN;
    Win::UpDownBox m_SPECULAR_G_SPIN;
    Win::UpDownBox m_SPECULAR_B_SPIN;

    Win::EditBox  m_SPECULAR_OPTIMAL_FACTOR_EDIT;
    Win::Trackbar m_SHININESSSLIDER;

    void  SetMaterial(const GLMaterial& _material)
    {
        std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", _material.ambient.r);
        m_AMBIENT_R_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", _material.ambient.g);
        m_AMBIENT_G_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", _material.ambient.b);
        m_AMBIENT_B_EDIT.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", _material.diffuse.r);
        m_DIFFUSE_R_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", _material.diffuse.g);
        m_DIFFUSE_G_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", _material.diffuse.b);
        m_DIFFUSE_B_EDIT.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", _material.specular.r);
        m_SPECULAR_R_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", _material.specular.g);
        m_SPECULAR_G_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", _material.specular.b);
        m_SPECULAR_B_EDIT.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", _material.shininess);
        m_SPECULAR_OPTIMAL_FACTOR_EDIT.setText(tempStr.c_str());

       // m_SPECULAR_OPTIMAL_FACTOR_SLIDER.setPos(_material.shininess);

        
    }
    virtual void Init_Event(HWND hDlg, WPARAM wParam, LPARAM lParam)
    {
        m_AMBIENT_R_EDIT.set(hDlg, IDC_AMBIENT_R_EDIT);
        m_AMBIENT_G_EDIT.set(hDlg, IDC_AMBIENT_G_EDIT);
        m_AMBIENT_B_EDIT.set(hDlg, IDC_AMBIENT_B_EDIT);
        m_AMBIENT_R_SPIN.set(hDlg, IDC_AMBIENT_R_SPIN);
        m_AMBIENT_G_SPIN.set(hDlg, IDC_AMBIENT_G_SPIN);
        m_AMBIENT_B_SPIN.set(hDlg, IDC_AMBIENT_B_SPIN);

        m_DIFFUSE_R_EDIT.set(hDlg, IDC_DIFFUSE_R_EDIT);
        m_DIFFUSE_G_EDIT.set(hDlg, IDC_DIFFUSE_G_EDIT);
        m_DIFFUSE_B_EDIT.set(hDlg, IDC_DIFFUSE_B_EDIT);
        m_DIFFUSE_R_SPIN.set(hDlg, IDC_DIFFUSE_R_SPIN);
        m_DIFFUSE_G_SPIN.set(hDlg, IDC_DIFFUSE_G_SPIN);
        m_DIFFUSE_B_SPIN.set(hDlg, IDC_DIFFUSE_B_SPIN);

        m_SPECULAR_R_EDIT.set(hDlg, IDC_SPECULAR_R_EDIT);
        m_SPECULAR_G_EDIT.set(hDlg, IDC_SPECULAR_G_EDIT);
        m_SPECULAR_B_EDIT.set(hDlg, IDC_SPECULAR_B_EDIT);
        m_SPECULAR_R_SPIN.set(hDlg, IDC_SPECULAR_R_SPIN);
        m_SPECULAR_G_SPIN.set(hDlg, IDC_SPECULAR_G_SPIN);
        m_SPECULAR_B_SPIN.set(hDlg, IDC_SPECULAR_B_SPIN);

        m_SPECULAR_OPTIMAL_FACTOR_EDIT.set(hDlg, IDC_SPECULAR_OPTIMAL_FACTOR_EDIT);

        m_SHININESSSLIDER.set(hDlg, IDC_SHININESSSLIDER);
        m_SHININESSSLIDER.setRange(0, 128);
        m_SHININESSSLIDER.setPos(0);
        SetMaterial(g_Material_1);
    }
    virtual VOID TabPage_OnCommand(HWND hwnd, INT id, HWND hwndCtl, UINT codeNotify)
    {
        // if (id == CMD_CLICK_1)
        {
            //  ::MessageBox(hwnd, L"CMD_CLICK_1", L"��Ϣ��ʾ", MB_OKCANCEL);
        }
    }
    virtual VOID TabPage_OnNotify(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
    {
        NMHDR* p = (NMHDR*)(void*)lParam;
       
        LONG iID = wParam;
        if (iID == IDC_AMBIENT_R_SPIN)
        {
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                g_Material_1.ambient.r += 0.1;
                if (g_Material_1.ambient.r > 1)
                    g_Material_1.ambient.r = 1;
            }
            else
            {
                g_Material_1.ambient.r -= 0.1;
                if (g_Material_1.ambient.r < 0)
                    g_Material_1.ambient.r = 0;
            }  
        }
        else if (iID == IDC_AMBIENT_G_SPIN)
        {
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                g_Material_1.ambient.g += 0.1;
                if (g_Material_1.ambient.g > 1)
                    g_Material_1.ambient.g = 1;
            }
            else
            {
                g_Material_1.ambient.g -= 0.1;
                if (g_Material_1.ambient.g < 0)
                    g_Material_1.ambient.g = 0;
            }
        }
        else if (iID == IDC_AMBIENT_B_SPIN)
        {
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                g_Material_1.ambient.b += 0.1;
                if (g_Material_1.ambient.b > 1)
                    g_Material_1.ambient.b = 1;
            }
            else
            {
                g_Material_1.ambient.b -= 0.1;
                if (g_Material_1.ambient.b < 0)
                    g_Material_1.ambient.b = 0;
            }
        }
        else if (iID == IDC_DIFFUSE_R_SPIN)
        {
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                g_Material_1.diffuse.r += 0.1;
                if (g_Material_1.diffuse.r > 1)
                    g_Material_1.diffuse.r = 1;
            }
            else
            {
                g_Material_1.diffuse.r -= 0.1;
                if (g_Material_1.diffuse.r < 0)
                    g_Material_1.diffuse.r = 0;
            }
        }
        else if (iID == IDC_DIFFUSE_G_SPIN)
        {
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                g_Material_1.diffuse.g += 0.1;
                if (g_Material_1.diffuse.g > 1)
                    g_Material_1.diffuse.g = 1;
            }
            else
            {
                g_Material_1.diffuse.g -= 0.1;
                if (g_Material_1.diffuse.g < 0)
                    g_Material_1.diffuse.g = 0;
            }
        }
        else if (iID == IDC_DIFFUSE_B_SPIN)
        {
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                g_Material_1.diffuse.b += 0.1;
                if (g_Material_1.diffuse.b > 1)
                    g_Material_1.diffuse.b = 1;
            }
            else
            {
                g_Material_1.diffuse.b -= 0.1;
                if (g_Material_1.diffuse.b < 0)
                    g_Material_1.diffuse.b = 0;
            }
        }
        else if (iID == IDC_SPECULAR_R_SPIN)
        {
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                g_Material_1.specular.r += 0.1;
                if (g_Material_1.specular.r > 1)
                    g_Material_1.specular.r = 1;
            }
            else
            {
                g_Material_1.specular.r -= 0.1;
                if (g_Material_1.specular.r < 0)
                    g_Material_1.specular.r = 0;
            }
        }
        else if (iID == IDC_SPECULAR_G_SPIN)
        {
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                g_Material_1.specular.g += 0.1;
                if (g_Material_1.specular.g > 1)
                    g_Material_1.specular.g = 1;
            }
            else
            {
                g_Material_1.specular.g -= 0.1;
                if (g_Material_1.specular.g < 0)
                    g_Material_1.specular.g = 0;
            }
        }
        else if (iID == IDC_SPECULAR_B_SPIN)
        {
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                g_Material_1.specular.b += 0.1;
                if (g_Material_1.specular.b > 1)
                    g_Material_1.specular.b = 1;
            }
            else
            {
                g_Material_1.specular.b -= 0.1;
                if (g_Material_1.specular.b < 0)
                    g_Material_1.specular.b = 0;
            }
        }
        else if (iID == IDC_SHININESSSLIDER)
        {
           int tPos = m_SHININESSSLIDER.getPos();
            

           g_Material_1.shininess = tPos * 0.1;

           
        }

        SetMaterial(g_Material_1);
       
    }
};