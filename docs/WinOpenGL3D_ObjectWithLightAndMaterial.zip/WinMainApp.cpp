﻿// WinMainApp.cpp : 定义应用程序的入口点。
//

#include "framework.h"
#include "WinMainApp.h"
#include <commctrl.h>
#include "WinForm.hpp"
#include "ObjectControlForm.hpp"
#include "LightControlForm.hpp"
#include "MaterialControlForm.hpp"
#include "GLContext.hpp"
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"
#include <string>
#include "Shader.hpp"
#include "Camera.hpp"
#include "Format.h"

#include "Terrain.hpp"
#include "CubeObjectWithPositionTexture.hpp"
#include "TetrahedronWithTexture.hpp"
#include "SphereUseMaterial.hpp"
#include "GLMaterial.hpp"
#include "GLLight.hpp"

#pragma comment(lib,"ComCtl32.lib")

#define MAX_LOADSTRING 100

// 全局变量:
HINSTANCE hInst;                                // 当前实例
WCHAR szTitle[MAX_LOADSTRING];                  // 标题栏文本
WCHAR szWindowClass[MAX_LOADSTRING];            // 主窗口类名
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

GLMaterial                   g_Material_1;
GLMaterial      g_EmeraldMaterial;//翡翠
GLMaterial      g_JadeMaterial;//玉
GLMaterial      g_ObsidianMaterial;//黑曜石
GLMaterial      g_PearlMaterial;//珍珠
GLMaterial      g_RubyMaterial;//红宝石
GLMaterial      g_TurquoiseMaterial;//绿松石
GLMaterial      g_BrassMaterial;//黄铜
GLMaterial      g_BronzeMaterial;//青铜
GLMaterial      g_ChromeMaterial;//铬
GLMaterial      g_CopperMaterial;//铜
GLMaterial      g_GoldMaterial;//黄金
GLMaterial      g_SilverMaterial;//银
GLMaterial      g_GreenPlastic;//绿色塑料
GLMaterial      g_CyanRubber;//青色橡胶



SphereUseMaterial            g_sphereUseMaterial;

ParallelLight                g_ParallelLight;
DotLight                     g_DotLight;
SpotLight                    g_SpotLight;

Shader                       g_ParallelLightShader;
Shader                       g_DotLightShader;
Shader                       g_SpotLightShader;

class  WindowsForm :public Win::WinForm, public GLContext
{
private:
    //注意: attribute属性修饰在更高版本的GLSL中被弃用，使用in替代
    std::string  m_vertexShader = R"(
        #version 460 core
        layout(location = 0) in  vec3 inPosition;
        layout(location = 1) in  vec3 inColor;
        uniform mat4 ModelMatrix;
        uniform mat4 ViewMatrix;
        uniform mat4 ProjectionMatrix;
        
        out VertexAtrbuteData {
              vec3 color;
        } vs_out;

        void main()
        {
            gl_Position = ProjectionMatrix * ViewMatrix * ModelMatrix *vec4(inPosition,1.0);
            vs_out.color = inColor;
        }
                                )";



    std::string  m_fragmentShader = R"(
    #version 460 core
    in VertexAtrbuteData {
              vec3 color;
        } fs_in;
    out vec4 color;
    void main()
    {
        color = vec4(fs_in.color,1);
    }
  )";

private:
    Win::Button  m_AboutButton;
    Win::Button  m_CloseButton;

 
    Win::TabControl      m_MAINTAB;
    ObjetControlTabPage  m_ObjetControlTabPage;
    LightControlForm     m_LightControlForm;
    MaterialControlForm  m_MaterialControlForm;

    Win::Button m_CAMERAMOVEFORWARD;
    Win::Button m_CAMERAMOVEBACK;
    Win::Button m_CAMERAMOVELEFT;
    Win::Button m_CAMERAMOVERIGHT;
    Win::Button m_CAMERAMOVEUP;
    Win::Button m_CAMERAMOVEDOWN;
    

    Win::TextBox m_VIEWMAT00;
    Win::TextBox m_VIEWMAT01;
    Win::TextBox m_VIEWMAT02;
    Win::TextBox m_VIEWMAT03;

    Win::TextBox m_VIEWMAT10;
    Win::TextBox m_VIEWMAT11;
    Win::TextBox m_VIEWMAT12;
    Win::TextBox m_VIEWMAT13;

    Win::TextBox m_VIEWMAT20;
    Win::TextBox m_VIEWMAT21;
    Win::TextBox m_VIEWMAT22;
    Win::TextBox m_VIEWMAT23;

    Win::TextBox m_VIEWMAT30;
    Win::TextBox m_VIEWMAT31;
    Win::TextBox m_VIEWMAT32;
    Win::TextBox m_VIEWMAT33;

    Win::RadioButton m_AROUNDEYEPOSITION;  
    Win::RadioButton m_AROUNDEYELOOKAT;
    Win::UpDownBox m_AROUND_UP;
    Win::UpDownBox m_AROUNDFRONT;
    Win::UpDownBox m_AROUNDRIGHT;

    Win::EditBox m_CAMERA_FOV_EDIT;
    Win::EditBox m_CAMERA_NEAR_EDIT;
    Win::EditBox m_CAMERA_FAR_EDIT;

    Win::TextBox m_CAMERA_PRJ_MAT_00;
    Win::TextBox m_CAMERA_PRJ_MAT_01;
    Win::TextBox m_CAMERA_PRJ_MAT_02;
    Win::TextBox m_CAMERA_PRJ_MAT_03;

    Win::TextBox m_CAMERA_PRJ_MAT_10;
    Win::TextBox m_CAMERA_PRJ_MAT_11;
    Win::TextBox m_CAMERA_PRJ_MAT_12;
    Win::TextBox m_CAMERA_PRJ_MAT_13;

    Win::TextBox m_CAMERA_PRJ_MAT_20;
    Win::TextBox m_CAMERA_PRJ_MAT_21;
    Win::TextBox m_CAMERA_PRJ_MAT_22;
    Win::TextBox m_CAMERA_PRJ_MAT_23;

    Win::TextBox m_CAMERA_PRJ_MAT_30;
    Win::TextBox m_CAMERA_PRJ_MAT_31;
    Win::TextBox m_CAMERA_PRJ_MAT_32;
    Win::TextBox m_CAMERA_PRJ_MAT_33;

    Win::CheckBox m_CREATEMIPMAPBOOL;
    Win::ComboBox m_TEXTUREWRAPMODECOMBO;
    Win::ComboBox m_TEXTUREMAGFILTERMODECOMBO;
    Win::ComboBox m_TEXTUREMINFILTERMODECOMBO;
    Win::Trackbar m_TEXTUREMIXBLENDINGFACTORSLIDER;

public:
    WindowsForm() :Win::WinForm(), GLContext()
    {

    };
    void SetViewProjectMat(const glm::mat4& mat)
    {
        std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][0]);
        m_CAMERA_PRJ_MAT_00.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][1]);
        m_CAMERA_PRJ_MAT_01.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][2]);
        m_CAMERA_PRJ_MAT_02.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][3]);
        m_CAMERA_PRJ_MAT_03.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][0]);
        m_CAMERA_PRJ_MAT_10.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][1]);
        m_CAMERA_PRJ_MAT_11.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][2]);
        m_CAMERA_PRJ_MAT_12.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][3]);
        m_CAMERA_PRJ_MAT_13.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][0]);
        m_CAMERA_PRJ_MAT_20.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][1]);
        m_CAMERA_PRJ_MAT_21.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][2]);
        m_CAMERA_PRJ_MAT_22.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][3]);
        m_CAMERA_PRJ_MAT_23.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][0]);
        m_CAMERA_PRJ_MAT_30.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][1]);
        m_CAMERA_PRJ_MAT_31.setText(tempStr.c_str());
        float tempF = mat[3][2];
        tempStr = StringFormat::wstr_format(L"%.2lf", tempF);
        m_CAMERA_PRJ_MAT_32.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][3]);
        m_CAMERA_PRJ_MAT_33.setText(tempStr.c_str());
    }
    void SetViewMat(const glm::mat4& mat)
    {
        std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][0]);
        m_VIEWMAT00.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][1]);
        m_VIEWMAT01.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][2]);
        m_VIEWMAT02.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][3]);
        m_VIEWMAT03.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][0]);
        m_VIEWMAT10.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][1]);
        m_VIEWMAT11.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][2]);
        m_VIEWMAT12.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][3]);
        m_VIEWMAT13.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][0]);
        m_VIEWMAT20.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][1]);
        m_VIEWMAT21.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][2]);
        m_VIEWMAT22.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][3]);
        m_VIEWMAT23.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][0]);
        m_VIEWMAT30.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][1]);
        m_VIEWMAT31.setText(tempStr.c_str());
        float tempF = mat[3][2];
        tempStr = StringFormat::wstr_format(L"%.2lf", tempF);
        m_VIEWMAT32.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][3]);
        m_VIEWMAT33.setText(tempStr.c_str());
    }
    
    virtual void Init_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        HWND hWnd = hDlg;// ::GetDlgItem(hDlg, IDC_OPENGLVIEW);
        //::SetWindowPos(hDlg, NULL,0, 0, 680, 650, SWP_NOMOVE);
        m_AboutButton.set(hDlg, IDD_ABOUTBOX);
        m_CloseButton.set(hDlg, IDM_EXIT);
   
        m_MAINTAB.set(hDlg, IDC_MAINTAB, 4);
        m_ObjetControlTabPage.set(&m_MAINTAB, (LPWSTR)L"物体控制", IDD_OBJECTEDITFORM);
        m_LightControlForm.set(&m_MAINTAB, (LPWSTR)L"光源控制", IDD_LIGHTCONTROLFORM);
        m_MaterialControlForm.set(&m_MAINTAB, (LPWSTR)L"材质控制", IDD_MATERIALFORM);

        m_CAMERAMOVEFORWARD.set(hDlg, IDC_CAMERAMOVEFORWARD);
        m_CAMERAMOVEBACK.set(hDlg, IDC_CAMERAMOVEBACK);
        m_CAMERAMOVELEFT.set(hDlg, IDC_CAMERAMOVELEFT);
        m_CAMERAMOVERIGHT.set(hDlg, IDC_CAMERAMOVERIGHT);
        m_CAMERAMOVEUP.set(hDlg, IDC_CAMERAMOVEUP);
        m_CAMERAMOVEDOWN.set(hDlg, IDC_CAMERAMOVEDOWN);
        m_AROUND_UP.set(hDlg, IDC_AROUND_UP);
        m_AROUNDFRONT.set(hDlg, IDC_AROUNDFRONT);
        m_AROUNDRIGHT.set(hDlg, IDC_AROUNDRIGHT);


        m_VIEWMAT00.set(hDlg, IDC_VIEWMAT00);
        m_VIEWMAT01.set(hDlg, IDC_VIEWMAT01);        
        m_VIEWMAT02.set(hDlg, IDC_VIEWMAT02);
        m_VIEWMAT03.set(hDlg, IDC_VIEWMAT03);
        m_VIEWMAT10.set(hDlg, IDC_VIEWMAT10);
        m_VIEWMAT11.set(hDlg, IDC_VIEWMAT11);
        m_VIEWMAT12.set(hDlg, IDC_VIEWMAT12);
        m_VIEWMAT13.set(hDlg, IDC_VIEWMAT13);
       
        m_VIEWMAT20.set(hDlg, IDC_VIEWMAT20);
        m_VIEWMAT21.set(hDlg, IDC_VIEWMAT21);
        m_VIEWMAT22.set(hDlg, IDC_VIEWMAT22);
        m_VIEWMAT23.set(hDlg, IDC_VIEWMAT23);
        m_VIEWMAT30.set(hDlg, IDC_VIEWMAT30);
        m_VIEWMAT31.set(hDlg, IDC_VIEWMAT31);
        m_VIEWMAT32.set(hDlg, IDC_VIEWMAT32);
        m_VIEWMAT33.set(hDlg, IDC_VIEWMAT33);
        m_AROUNDEYEPOSITION.set(hDlg, IDC_AROUNDEYEPOSITION);
        m_AROUNDEYELOOKAT.set(hDlg, IDC_AROUNDEYELOOKAT);
        m_AROUNDEYEPOSITION.check();
        m_CAMERA_FOV_EDIT.set(hDlg, IDC_CAMERA_FOV_EDIT);
        m_CAMERA_FOV_EDIT.setText(L"75");

        m_CAMERA_NEAR_EDIT.set(hDlg, IDC_CAMERA_NEAR_EDIT);
        m_CAMERA_NEAR_EDIT.setText(L"0.1");
        m_CAMERA_FAR_EDIT.set(hDlg, IDC_CAMERA_FAR_EDIT);
        m_CAMERA_FAR_EDIT.setText(L"100");

        m_CAMERA_PRJ_MAT_00.set(hDlg, IDC_CAMERA_PRJ_MAT_00);
        m_CAMERA_PRJ_MAT_01.set(hDlg, IDC_CAMERA_PRJ_MAT_01);
        m_CAMERA_PRJ_MAT_02.set(hDlg, IDC_CAMERA_PRJ_MAT_02);
        m_CAMERA_PRJ_MAT_03.set(hDlg, IDC_CAMERA_PRJ_MAT_03);

        m_CAMERA_PRJ_MAT_10.set(hDlg, IDC_CAMERA_PRJ_MAT_10);
        m_CAMERA_PRJ_MAT_11.set(hDlg, IDC_CAMERA_PRJ_MAT_11);
        m_CAMERA_PRJ_MAT_12.set(hDlg, IDC_CAMERA_PRJ_MAT_12);
        m_CAMERA_PRJ_MAT_13.set(hDlg, IDC_CAMERA_PRJ_MAT_13);

        m_CAMERA_PRJ_MAT_20.set(hDlg, IDC_CAMERA_PRJ_MAT_20);
        m_CAMERA_PRJ_MAT_21.set(hDlg, IDC_CAMERA_PRJ_MAT_21);
        m_CAMERA_PRJ_MAT_22.set(hDlg, IDC_CAMERA_PRJ_MAT_22);
        m_CAMERA_PRJ_MAT_23.set(hDlg, IDC_CAMERA_PRJ_MAT_23);

        m_CAMERA_PRJ_MAT_30.set(hDlg, IDC_CAMERA_PRJ_MAT_30);
        m_CAMERA_PRJ_MAT_31.set(hDlg, IDC_CAMERA_PRJ_MAT_31);
        m_CAMERA_PRJ_MAT_32.set(hDlg, IDC_CAMERA_PRJ_MAT_32);
        m_CAMERA_PRJ_MAT_33.set(hDlg, IDC_CAMERA_PRJ_MAT_33);

        m_CREATEMIPMAPBOOL.set(hDlg, IDC_CREATEMIPMAPBOOL);
        m_CREATEMIPMAPBOOL.check();
        m_CREATEMIPMAPBOOL.disable();

        int itemHeight = 30; // 设置你希望的高度
        SendMessage(m_TEXTUREWRAPMODECOMBO.getHandle(), CB_SETITEMHEIGHT, 0, MAKELPARAM(itemHeight, 0));

        m_TEXTUREWRAPMODECOMBO.set(hDlg, IDC_TEXTUREWRAPMODECOMBO);
        m_TEXTUREWRAPMODECOMBO.addString(L"GL_REPEAT");
        m_TEXTUREWRAPMODECOMBO.addString(L"GL_MIRRORED_REPEAT");
        m_TEXTUREWRAPMODECOMBO.addString(L"GL_CLAMP_TO_EDGE");
        m_TEXTUREWRAPMODECOMBO.addString(L"GL_CLAMP_TO_BORDER");
        m_TEXTUREWRAPMODECOMBO.setCurrentSelection(0);

        m_TEXTUREMAGFILTERMODECOMBO.set(hDlg, IDC_TEXTUREMAGFILTERMODECOMBO);
        m_TEXTUREMAGFILTERMODECOMBO.addString(L"GL_NEAREST");
        m_TEXTUREMAGFILTERMODECOMBO.addString(L"GL_LINEAR");
        m_TEXTUREMAGFILTERMODECOMBO.setCurrentSelection(0);

        m_TEXTUREMINFILTERMODECOMBO.set(hDlg, IDC_TEXTUREMINFILTERMODECOMBO);
        m_TEXTUREMINFILTERMODECOMBO.addString(L"GL_NEAREST");
        m_TEXTUREMINFILTERMODECOMBO.addString(L"GL_LINEAR");
        m_TEXTUREMINFILTERMODECOMBO.addString(L"GL_NEAREST_MIPMAP_NEAREST");
        m_TEXTUREMINFILTERMODECOMBO.addString(L"GL_LINEAR_MIPMAP_NEAREST");
        m_TEXTUREMINFILTERMODECOMBO.addString(L"GL_NEAREST_MIPMAP_LINEAR");
        m_TEXTUREMINFILTERMODECOMBO.addString(L"GL_LINEAR_MIPMAP_LINEAR");
        m_TEXTUREMINFILTERMODECOMBO.setCurrentSelection(0);

        m_TEXTUREMIXBLENDINGFACTORSLIDER.set(hDlg, IDC_TEXTUREMIXBLENDINGFACTORSLIDER);
        m_TEXTUREMIXBLENDINGFACTORSLIDER.setRange(0, 10);
        m_TEXTUREMIXBLENDINGFACTORSLIDER.setPos(8);


        wchar_t  tempWchar[64];

       // m_Mat21.getText(tempWchar,64);
       // tempwstr = tempWchar;
       // float tF = std::stof(tempwstr);

        HWND hOpenGLWnd =  ::GetDlgItem(hDlg, IDC_OPENGLVIEW);

        bool succ = CreateGLContent(hOpenGLWnd, TRUE);
        if (!succ)
        {
            ::MessageBox(hWnd, L"初始化OpenGL窗口发生错误", L"系统信息", MB_OK);
            return;
        }


        return;
    };
    virtual void Resize_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        WindowResize();
    }
    virtual void Destroy_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
         shutdown();
    }
    virtual BOOL  OnIdle(LONG lCount)
    {
        GLContext::swapBuffer();

        return TRUE;
    }

    virtual void Command_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        int wmId = LOWORD(wParam);
        if (wmId == IDD_ABOUTBOX)
        {
            Win::WinForm::ShowModelDialog(IDD_ABOUTBOX, hDlg, About);// Win::WinForm::DialogWindowProc);
        }
            else if (wmId == IDM_EXIT)
        {
            ::SendMessageW(hDlg, WM_DESTROY, 0, 0);
        }
        else if (wmId == IDC_CAMERAMOVEFORWARD)
        {
            m_camera.MoveFront(0.5f);
            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else if (wmId == IDC_CAMERAMOVEBACK)
        {
            m_camera.MoveFront(-0.5f);
            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else if (wmId == IDC_CAMERAMOVEUP)
        {
            m_camera.MoveUp(0.5f);
            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else if (wmId == IDC_CAMERAMOVEDOWN)
        {
            m_camera.MoveUp(-0.5f);
            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
 
        }
        else if (wmId == IDC_CAMERAMOVELEFT)
        {
            m_camera.MoveRight(0.5f);
            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else if (wmId == IDC_CAMERAMOVERIGHT)
        {
            m_camera.MoveRight(-0.5f);
            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }


    }
    virtual void Notify_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        NMHDR* p = (NMHDR*)(void*)lParam;

        LONG iID = wParam;
      
       if ((INT)wParam == IDC_MAINTAB ) //这里也可以用一个NMHDR *nm = (NMHDR *)lParam这个指针来获取 句柄和事件
       {					//读者可自行查找NMHDR结构
           Win::TabControl::TabControl_Notify(hDlg, message, wParam, lParam);
        }
        else if ( iID == IDC_AROUND_UP )
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (m_AROUNDEYEPOSITION.isChecked() == true)
            {
                if (pNMUpDown->iDelta > 0)
                {
                    // m_AROUND_UP
                    m_camera.RotateCenterEyePosAroundVecter(glm::radians(1.0f), m_camera.m_EyeUp);
                }
                else  if (pNMUpDown->iDelta < 0)
                {
                    m_camera.RotateCenterEyePosAroundVecter(glm::radians(-1.0f), m_camera.m_EyeUp);
                }
            }
            else
            {
                if (pNMUpDown->iDelta > 0)
                {
                    // m_AROUND_UP
                    m_camera.RotateCenterLookatAroundVecter(glm::radians(1.0f), m_camera.m_EyeUp);
                }
                else  if (pNMUpDown->iDelta < 0)
                {
                    m_camera.RotateCenterLookatAroundVecter(glm::radians(-1.0f), m_camera.m_EyeUp);
                }
            }

            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else  if (iID == IDC_AROUNDFRONT)
        {  //m_AROUNDFRONT
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (m_AROUNDEYEPOSITION.isChecked() == true)
            {
                if (pNMUpDown->iDelta > 0)
                {
                    m_camera.RotateCenterEyePosAroundVecter(glm::radians(-1.0f), m_camera.GetFront());
                }
                else  if (pNMUpDown->iDelta < 0)
                {
                    m_camera.RotateCenterEyePosAroundVecter(glm::radians(-1.0f), m_camera.GetFront());
                }
            }
            else
            {
                if (pNMUpDown->iDelta > 0)
                {
                    // m_AROUND_UP
                    m_camera.RotateCenterLookatAroundVecter(glm::radians(1.0f), m_camera.GetFront());
                }
                else  if (pNMUpDown->iDelta < 0)
                {
                    m_camera.RotateCenterLookatAroundVecter(glm::radians(-1.0f), m_camera.GetFront());
                }
            }

            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else  if (iID == IDC_AROUNDRIGHT)
        {//m_AROUNDRIGHT
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (m_AROUNDEYEPOSITION.isChecked() == true)
            {
                if (pNMUpDown->iDelta > 0)
                {
                    m_camera.RotateCenterEyePosAroundVecter(glm::radians(1.0f), m_camera.GetRight());
                }
                else  if (pNMUpDown->iDelta < 0)
                {
                    m_camera.RotateCenterEyePosAroundVecter(glm::radians(-1.0f), m_camera.GetRight());
                }
            }
            else
            {
                if (pNMUpDown->iDelta > 0)
                {
                    m_camera.RotateCenterLookatAroundVecter(glm::radians(1.0f), m_camera.GetRight());
                }
                else  if (pNMUpDown->iDelta < 0)
                {
                    m_camera.RotateCenterLookatAroundVecter(glm::radians(-1.0f), m_camera.GetRight());
                }
            }

            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else if (iID == IDC_CAMERA_FOV_SPIN)
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            float tempFovH = m_camera.GetFovY();
            if (pNMUpDown->iDelta > 0)
            {
                tempFovH += 1.0f;
                if (tempFovH > 150.0f)
                    tempFovH = 150.0f;
            }
            else
            {
                tempFovH -= 1.0f;
                if (tempFovH < 1.0f)
                    tempFovH = 1.0f;
            }
            m_camera.SetFovY(tempFovH);
            std::wstring tempStr = std::to_wstring(tempFovH);
            m_CAMERA_FOV_EDIT.setText(tempStr.c_str());

            SetViewProjectMat(m_camera.GetProjectionMat());
        }
        else if (iID == IDC_CAMERA_NEAR_SPIN)
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            float tempNear = m_camera.GetNear();
            if (pNMUpDown->iDelta > 0)
            {
                tempNear += 0.5;
                if (tempNear > m_camera.GetFar())
                    tempNear = m_camera.GetFar() - 1;
            }
            else
            {
                tempNear -= 0.5;
                if (tempNear < 0.1)
                    tempNear = 0.1;
            }
            m_camera.SetNear(tempNear);
            std::wstring tempStr = std::to_wstring(tempNear);
            m_CAMERA_NEAR_EDIT.setText(tempStr.c_str());

            SetViewProjectMat(m_camera.GetProjectionMat());
        }
        else if (iID == IDC_CAMERA_FAR_SPIN)
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            float tempFar = m_camera.GetFar();
            if (pNMUpDown->iDelta > 0)
            {
                tempFar += 0.5;
                if (tempFar > 200 )
                    tempFar = 200;
            }
            else
            {
                tempFar -= 0.5;
                if (tempFar < m_camera.GetNear())
                    tempFar = m_camera.GetNear() + 1;
            }
            m_camera.SetFar(tempFar);
            std::wstring tempStr = std::to_wstring(tempFar);
            m_CAMERA_FAR_EDIT.setText(tempStr.c_str());

            SetViewProjectMat(m_camera.GetProjectionMat());
        }
    }

    Camera                m_camera;
    Shader                m_ShaderWithColor;
    Terrain               m_terrainObject;

    CubeObjectWithPositionTexture  m_cubeObjectWithPositionTexture;
    TetrahedronWithTexture      m_TetrahedronObjectWithPositionTexture;
    float m_TextureMixBlendingFactor=0.8;
    

    virtual void UserInitialize() 
    {
        RECT rect;
        ::GetWindowRect(m_hWnd, &rect);
        int width = rect.right - rect.left;
        int height = rect.bottom - rect.top;

        
        m_ShaderWithColor.InitializeShaderWithString(m_vertexShader.c_str(), m_fragmentShader.c_str());
        g_ParallelLightShader.InitializeShaderWithString(g_sphereUseMaterial.m_vsShader.c_str(), g_sphereUseMaterial.fs_ParallelLightShader.c_str());
        g_DotLightShader.InitializeShaderWithString(g_sphereUseMaterial.m_vsShader.c_str(), g_sphereUseMaterial.fs_PointLightShader.c_str());
        g_SpotLightShader.InitializeShaderWithString(g_sphereUseMaterial.m_vsShader.c_str(), g_sphereUseMaterial.fs_SpotLightShader.c_str());
        

       
        m_camera.InitializeUseLookat(glm::vec3(0.0f, 0.0f, 7), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.));
        m_camera.SetPerspectiveProjection(75, (float)width / (float)height, 0.1f, 100.0f);
       
        glm::mat4 tempMat = m_camera.GetViewMat();
        SetViewMat(tempMat);
        tempMat = m_camera.GetProjectionMat();
        SetViewProjectMat(tempMat);
        



       // m_terrainObject.InitializeData();

       

     //   m_cubeObjectWithPositionTexture.InitializeData();
     //   m_cubeObjectWithPositionTexture.SetPosition(glm::vec3(2.0f, 1.0f, 0.0f));
        
       // m_TetrahedronObjectWithPositionTexture.InitializeData();
       // m_TetrahedronObjectWithPositionTexture.SetPosition(glm::vec3(-2.0f, 0.0f, -1.0f));

        g_Material_1.ambient = glm::vec3(0.0, 0.0, 0.0);
        g_Material_1.diffuse = glm::vec3(0.8, 0.8, 0.8);
        g_Material_1.specular = glm::vec3(0.0, 0.0, 0.0);
        g_Material_1.shininess = 0.0f;

        g_EmeraldMaterial = GLMaterials::GetEmeraldMaterial();//翡翠
        g_JadeMaterial = GLMaterials::GetJadeMaterial();//玉
        g_ObsidianMaterial = GLMaterials::GetObsidianMaterial();//黑曜石
        g_PearlMaterial = GLMaterials::GetPearlMaterial();//珍珠
        g_RubyMaterial = GLMaterials::GetRubyMaterial();//红宝石
        g_TurquoiseMaterial = GLMaterials::GetTurquoiseMaterial();//绿松石
        g_BrassMaterial = GLMaterials::GetBrassMaterial();//黄铜
        g_BronzeMaterial = GLMaterials::GetBronzeMaterial();//青铜
        g_ChromeMaterial = GLMaterials::GetChromeMaterial();//铬
        g_CopperMaterial = GLMaterials::GetCopperMaterial();//铜
        g_GoldMaterial = GLMaterials::GetGoldMaterial();//黄金
        g_SilverMaterial = GLMaterials::GetSilverMaterial();//银
        g_GreenPlastic = GLMaterials::GetGreenPlasticMaterial();//绿色塑料
        g_CyanRubber = GLMaterials::GetCyanRubberMaterial();//青色橡胶
        m_MaterialControlForm.SetMaterial(g_Material_1);



        g_DotLight.m_Position = glm::vec3(0.0, 3.0, 2.0);
        g_DotLight.SetAmbient(glm::vec3(0.4, 0.4, 0.4));
        g_DotLight.SetDiffuse(glm::vec3(1.0, 1.0, 1.0));
        g_DotLight.SetSpecular(glm::vec3(1.0, 1.0, 1.0));

        g_ParallelLight.m_Direction = glm::vec3(0.0, 0.0, -0.1);
        g_ParallelLight.SetAmbient(glm::vec3(0.4, 0.4, 0.4));
        g_ParallelLight.SetDiffuse(glm::vec3(1.0, 1.0, 1.0));
        g_ParallelLight.SetSpecular(glm::vec3(1.0, 1.0, 1.0));

        m_LightControlForm.SetViewFromLight(&g_DotLight);

        g_sphereUseMaterial.InitializeData();

    };

    virtual void PreDrawProcess(GL_Channel& _channel) 
    {
        RECT rect;
        //-----------------------------------------------------------
        ::GetWindowRect(_channel._hWnd, &rect);
        int width = rect.right - rect.left;
        int height = rect.bottom - rect.top;

        glViewport(0, 0, width, height);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        
       // float* p = glm::value_ptr(ProjectionMat);
       // glLoadMatrixf(p);

        glMatrixMode(GL_MODELVIEW);	// 选择模型观察矩阵



    };
    virtual void GLDrawProcess(GL_Channel& _channel) 
    {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // 清理颜色缓存和深度缓存
        glClearColor(0.1, 0.0, 0.5, 0.0);
        glColor3f(1.0, 1.0, 1.0);
       
        
        
        m_ShaderWithColor.Use();

       m_ShaderWithColor.SetMat4("ModelMatrix", glm::mat4(1.0f));
        m_ShaderWithColor.SetMat4("ViewMatrix", m_camera.GetViewMat());
        m_ShaderWithColor.SetMat4("ProjectionMatrix", m_camera.GetProjectionMat());// ProjectionMat);

    
        bool  isUseBLINN = false;
        if (m_LightControlForm.m_USE_BLINN_CHECK.isChecked() == true)
            isUseBLINN = true;

        LightBase* useLight = &g_DotLight;
        Shader* userShader = &g_DotLightShader;
        if (m_LightControlForm.m_PARALLEL_LIGHT_RADIO.isChecked() == true)
        {
            useLight = &g_ParallelLight;
            userShader = &g_ParallelLightShader;
        }
        else if (m_LightControlForm.m_DOT_LIGHT_RADIO.isChecked() == true)
        {
            useLight = &g_DotLight;
            userShader = &g_DotLightShader;
        }
        else if (m_LightControlForm.m_SPOT_LIGHT_RADIO.isChecked() == true)
        {
            useLight = &g_SpotLight;
            userShader = &g_SpotLightShader;
        }
        if (m_ObjetControlTabPage.m_SHOW_ALL_RADIO.isChecked())
        {
            g_sphereUseMaterial.SetPosition(glm::vec3(-6.0f, 3.0f, 0.0f));

            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_Material_1,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(-3.0f, 3.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_EmeraldMaterial,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(0.0f, 3.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_JadeMaterial,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(3.0f, 3.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_ObsidianMaterial,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(6.0f, 3.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_PearlMaterial,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(-6.0f, 0.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_RubyMaterial,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(-3.0f, 0.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_TurquoiseMaterial,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(0.0f, 0.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_BrassMaterial,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(3.0f, 0.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_BronzeMaterial,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(6.0f, 0.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_ChromeMaterial,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(-6.0f, -3.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_CopperMaterial,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(-3.0f, -3.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_GoldMaterial,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(0.0f, -3.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_SilverMaterial,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(3.0f, -3.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_GreenPlastic,
                useLight, isUseBLINN);

            g_sphereUseMaterial.SetPosition(glm::vec3(6.0f, -3.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_CyanRubber,
                useLight, isUseBLINN);
        }
        else
        {
            
            g_sphereUseMaterial.SetPosition(glm::vec3(0.0f, 0.0f, 0.0f));
            g_sphereUseMaterial.Draw(&m_camera, userShader, &g_Material_1,
                useLight, isUseBLINN);
        }
    };

    virtual void UserDestroy() 
    {

    };

   
   
};
WindowsForm  g_WinForm;

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    OutputDebugStringW(L"字符串");

    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 在此处放置代码。

    // 初始化全局字符串
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WINMAINAPP, szWindowClass, MAX_LOADSTRING);

    // Initialize common controls. Also needed for MANIFEST's.
    InitCommonControls();

    // Load Rich Edit control support.
    // TODO: uncomment one of the lines below, if you are using a Rich Edit control.
    // LoadLibrary(_T("riched32.dll"));  // Rich Edit v1.0
    // LoadLibrary(_T("riched20.dll"));  // Rich Edit v2.0, v3.0

    g_WinForm.CreateWindowFromReSource(hInstance, IDD_MAINDIALOG);
    return g_WinForm.Run(); 
}

// “关于”框的消息处理程序。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

