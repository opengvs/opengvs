#pragma once
#include <string>
#include "glm/glm.hpp"
#include "glm/gtc/type_ptr.hpp"
#include "Shader.hpp"

enum  LightType
{
	ParallelLightType = 1,
	DotLightType = 2,
    SpotLightType = 3
};
class  LightBase
{
	LightBase() {};
protected:
	LightBase(const LightType& _LightType)
	{
		m_LightType = _LightType;
	}
private:
	glm::vec3   m_Ambient; //����������ǿ��Intensity                                                                                          \n" +
	glm::vec3   m_Diffuse;//�����������ǿ��                                                                                           \n" +
	glm::vec3   m_Specular;//���������ǿ��
public:
	virtual ~LightBase()
	{

	}
	LightType  m_LightType;

	void SetAmbient(const glm::vec3& _Ambient)
	{
		m_Ambient = _Ambient;
	}
	glm::vec3 GetAmbient()
	{
		return  m_Ambient;
	}
	void SetDiffuse(const glm::vec3& _Diffuse)
	{
		m_Diffuse = _Diffuse;
	}
	glm::vec3 GetDiffuse()
	{
		return  m_Diffuse;
	}
	void SetSpecular(const glm::vec3& _Specular)
	{
		m_Specular = _Specular;
	}
	glm::vec3 GetSpecular()
	{
		return  m_Specular;
	}

	void SendAmbientData(const Shader* pShader, const std::string& _AmbientName)
	{
		pShader->SetVec3(_AmbientName, m_Ambient);
	}
	void SendDiffuseData(const Shader* pShader, const std::string& _DiffuseName)
	{
		pShader->SetVec3(_DiffuseName, m_Diffuse);
	}
	void SendSpecularData(const Shader* pShader, const std::string& _SpecularName)
	{
		pShader->SetVec3(_SpecularName, m_Specular);
	}
};
class ParallelLight : public LightBase
{
public:
   glm::vec3   m_Direction;   //ƽ�й����䷽��                                                                                       \n" +


   ParallelLight():LightBase(LightType::ParallelLightType)
   {

   }
   virtual ~ParallelLight()
   {

   }
   void SendDirectionData(const Shader* pShader, const std::string& _DirectionName)
   {
	   pShader->SetVec3(_DirectionName, m_Direction);
   }


};

class  DotLight : public LightBase
{
public:
	glm::vec3   m_Position;
	//glm::vec3   m_Direction;

	DotLight() :LightBase(LightType::DotLightType)
	{

	}
	virtual ~DotLight()
	{

	}
	void SendPositionData(const Shader* pShader, const std::string& _PositionName)
	{
		pShader->SetVec3(_PositionName, m_Position);
	}



};

class SpotLight : public LightBase
{
public:
	glm::vec3   m_Position;           //��Դλ��
	glm::vec3   m_Direction;          //��ķ��򣬼���ͼ��SpotDir
	float       m_CutOff;             //��Բ׶�н�
	float       m_OuterCutOff;       //��Բ׶�н�

	//һ������������Shader�и���λ��Զ���Զ����е���������Ҫ����Shader
	//public float _constant_attenuation; //����˥��
	//public float _linear_attenuation; //����˥��
	//public float _quadratic_attenuatin;//���η�˥��
	SpotLight():LightBase(LightType::SpotLightType)
	{

	}
	virtual ~SpotLight()
	{

	}
	void SendPositionData(const Shader* pShader, const std::string& _PositionName)
	{
		pShader->SetVec3(_PositionName, m_Position);
	}
	void SendDirectionData(const Shader* pShader, const std::string& _DirectionName)
	{
		pShader->SetVec3(_DirectionName, m_Direction);
	}
	void SendOuterCutOffData(const Shader* pShader, const std::string& _OuterCutOffName)
	{
		pShader->setFloat(_OuterCutOffName, m_CutOff);
	}
	void SendCutOffData(const Shader* pShader, const std::string& _CutOffName)
	{
		pShader->setFloat(_CutOffName, m_OuterCutOff);
	}

};
