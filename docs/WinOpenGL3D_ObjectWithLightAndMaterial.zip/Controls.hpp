///////////////////////////////////////////////////////////////////////////////
// Controls.hpp  ���ڹ���Windows API������ʽ��Ӧ�ó��򿪷���������Դ�ļ���ID�����Ӧ
//               �ؼ��Ĵ�����ϵ
// ��ͷ�ļ���Ҫʵ�ֵ����¿ؼ�����ϵ (button, checkbox, textbox...)
//
// Button       : ��ť
// CheckBox     : ��ѡ��
// RadioButton  : ��ѡ��
// TextBox      : ��̬�ı� ע�ⲻ��ʹ��static����
// EditBox      : �༭��
// ListBox      : �б���
// Trackbar     : trackbar(slider), ��Ҫ comctl32.dll
// ComboBox     : �����б���
// TreeView     : ���б���, ��Ҫ comctl32.dll
// UpDownBox    : Up-Down(Spin) ���µ��ڰ�ť ��Ҫ comctl32.dll
// SysLink      : �����ӵ����ľ�̬�ı�, required comctl32.dll
// Picture      : ͼƬ��̬�ı�, SS_BITMAP
// TabControl   : ���ڴ���TabControl�ؼ�  ----2025��4������
// TabPage      : ��TabControl�ؼ�������TabPageҳ��
//  ��Ȩ����        ������    1997.6 �ȷ�      
//  Ϊ��ѧ2023��12��  ���������ȷ�����ѧԺ�����޸�
///////////////////////////////////////////////////////////////////////////////
#pragma warning(disable : 4996)
#define _CRT_SECURE_NO_WARNINGS
#ifndef _WIN64
#pragma warning(disable : 4244 4312)
#endif

#ifndef CONTROLS_HPP
#define CONTROLS_HPP

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <vector>
#include "WndProcRemapUtil.h"

//BOOL CALLBACK TabPage_DlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
namespace Win
{
    // constants //////////////////////////////////////////////////////////////
    enum { MAX_INDEX = 30000 };
#define CMD_VK_ESCAPE	101
#define CMD_VK_RETURN	102

    ///////////////////////////////////////////////////////////////////////////
    // base class of control object
    ///////////////////////////////////////////////////////////////////////////
    class ControlBase
    {
    public:
        // ctor / dtor
        ControlBase() : handle(0), parent(0), id(0), fontHandle(0) {}
        ControlBase(HWND parent, int id, bool visible = true) : handle(GetDlgItem(parent, id)) { if (!visible) disable(); }
        virtual ~ControlBase() {
            if (fontHandle) DeleteObject(fontHandle);
            fontHandle = 0;
        }

        // return handle
        HWND getHandle() const { return handle; }
        
        HWND getParentHandle() const { return parent; }
        void setParent(HWND _handle)
        {
            parent = _handle;
        }

        // set all members
        void set(HWND parent, int id, bool visible = true) {
            this->parent = parent;
            this->id = id;
            handle = GetDlgItem(parent, id);
            if (!visible) disable();
        }

        // show/hide control
        void show() { ShowWindow(handle, SW_SHOW); }
        void hide() { ShowWindow(handle, SW_HIDE); }

        // set focus to the control
        void setFocus() { SetFocus(handle); }

        // enable/disable control
        void enable() { EnableWindow(handle, true); }
        void disable() { EnableWindow(handle, false); }
        bool isVisible() const { return (IsWindowVisible(handle) != 0); }

        // change font
        void setFont(wchar_t* fontName, int size, bool bold = false, bool italic = false, bool underline = false, unsigned char charSet = DEFAULT_CHARSET)
        {
            HDC hdc = GetDC(handle);
            LOGFONT logFont;
            HFONT oldFont = (HFONT)SendMessage(handle, WM_GETFONT, 0, 0);
            GetObject(oldFont, sizeof(LOGFONT), &logFont);
            wcsncpy(logFont.lfFaceName, fontName, LF_FACESIZE);
            logFont.lfHeight = -MulDiv(size, GetDeviceCaps(hdc, LOGPIXELSY), 72);
            ReleaseDC(handle, hdc);
            if (bold) logFont.lfWeight = FW_BOLD;
            else     logFont.lfWeight = FW_NORMAL;
            logFont.lfItalic = italic;
            logFont.lfUnderline = underline;
            logFont.lfCharSet = charSet;

            if (fontHandle) DeleteObject(fontHandle);
            fontHandle = CreateFontIndirect(&logFont);
            SendMessage(handle, WM_SETFONT, (WPARAM)fontHandle, MAKELPARAM(1, 0));
        }

        // modify styles
        void addStyles(long newStyles)
        {
            long styles = (long)GetWindowLongPtr(handle, GWL_STYLE);
            styles |= newStyles;
            SetWindowLongPtr(handle, GWL_STYLE, styles);
            SetWindowPos(handle, 0, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER);
        }
        void removeStyles(long noStyles)
        {
            long styles = (long)GetWindowLongPtr(handle, GWL_STYLE);
            styles &= ~noStyles;
            SetWindowLongPtr(handle, GWL_STYLE, styles);
            SetWindowPos(handle, 0, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER);
        }

    protected:
        HWND  handle;
        HWND  parent;
        int   id;
        HFONT fontHandle;
    };



    ///////////////////////////////////////////////////////////////////////////
    // button class
    // �¼�������ͨ�� WM_COMMAND ��Ϣ�����У�ͨ����� LOWORD(wParam) ��ֵ��ȷ�����ĸ���ť������ˡ�
    ///////////////////////////////////////////////////////////////////////////
    class Button : public ControlBase
    {
    public:
        // ctor / dtor
        Button() : ControlBase() {}
        Button(HWND parent, int id, bool visible = true) : ControlBase(parent, id, visible) {}
        virtual ~Button() {}

        // change caption
        void setText(const wchar_t* text) { SendMessage(handle, WM_SETTEXT, 0, (LPARAM)text); }

        // add an image/icon
        void setImage(HBITMAP bitmap) { SendMessage(handle, BM_SETIMAGE, (WPARAM)IMAGE_BITMAP, (LPARAM)bitmap); }
        void setImage(HICON icon) { SendMessage(handle, BM_SETIMAGE, (WPARAM)IMAGE_ICON, (LPARAM)icon); }
    };



    ///////////////////////////////////////////////////////////////////////////
    // Checkbox class
    ///////////////////////////////////////////////////////////////////////////
    class CheckBox : public Button
    {
    public:
        CheckBox() : Button() {}
        CheckBox(HWND parent, int id, bool visible = true) : Button(parent, id, visible) {}
        virtual ~CheckBox() {}

        void check() { SendMessage(handle, BM_SETCHECK, (WPARAM)BST_CHECKED, 0); }
        void uncheck() { SendMessage(handle, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0); }
        bool isChecked() const { return (SendMessage(handle, BM_GETCHECK, 0, 0) == BST_CHECKED); }
    };



    ///////////////////////////////////////////////////////////////////////////
    // Radio button class
    ///////////////////////////////////////////////////////////////////////////
    class RadioButton : public Button
    {
    public:
        RadioButton() : Button() {}
        RadioButton(HWND parent, int id, bool visible = true) : Button(parent, id, visible) {}
        virtual ~RadioButton() {}

        void check() { SendMessage(handle, BM_SETCHECK, (WPARAM)BST_CHECKED, 0); }
        void uncheck() { SendMessage(handle, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0); }
        bool isChecked() const { return (SendMessage(handle, BM_GETCHECK, 0, 0) == BST_CHECKED); }
    };



    ///////////////////////////////////////////////////////////////////////////
    // Text box class
    ///////////////////////////////////////////////////////////////////////////
    class TextBox : public ControlBase
    {
    public:
        TextBox() : ControlBase() {}
        TextBox(HWND parent, int id, bool visible = true) : ControlBase(parent, id, visible) {}
        virtual ~TextBox() {}

        void setText(const wchar_t* buf) { SendMessage(handle, WM_SETTEXT, 0, (LPARAM)buf); }
        void getText(wchar_t* buf, int len) const { SendMessage(handle, WM_GETTEXT, (WPARAM)len, (LPARAM)buf); }
        int  getTextLength() const { return (int)SendMessage(handle, WM_GETTEXTLENGTH, 0, 0); } // return number of chars
    };



    ///////////////////////////////////////////////////////////////////////////
    // Edit box class
    ///////////////////////////////////////////////////////////////////////////
    class EditBox : public TextBox
    {
    public:
        EditBox() : TextBox(), maxLength(0) {}
        EditBox(HWND parent, int id, bool visible = true) : TextBox(parent, id, visible), maxLength((int)SendMessage(handle, EM_GETLIMITTEXT, 0, 0)) {}
        virtual ~EditBox() {}

        // set all members
        void set(HWND parent, int id, bool visible = true) {
            ControlBase::set(parent, id, visible);
            maxLength = (int)SendMessage(handle, EM_GETLIMITTEXT, 0, 0);
        }

        void selectText() { SendMessage(handle, EM_SETSEL, 0, -1); }
        void unselectText() { SendMessage(handle, EM_SETSEL, -1, 0); }

        int getLimitText() const { return maxLength; } // return max number of chars

        static bool isChanged(int code) { return (code == EN_CHANGE); } // LOWORD(wParam)==id && HIWORD(wParam)==EN_CHANGE

    protected:
        int maxLength;
    };



    ///////////////////////////////////////////////////////////////////////////
    // List box class
    ///////////////////////////////////////////////////////////////////////////
    class ListBox : public ControlBase
    {
    public:
        ListBox() : ControlBase(), listCount(0) {}
        ListBox(HWND parent, int id, bool visible = true) : ControlBase(parent, id, visible), listCount(0) {}
        virtual ~ListBox() {}

        int getCount() const { return listCount; }

        void resetContent() { SendMessage(handle, LB_RESETCONTENT, 0, 0); listCount = 0; }

        // add a string at the end of the list
        // If list is full, then delete the most front entry first and add new string.
        // Also, make the latest entry is visible with LB_SETTOPINDEX.
        void addString(const wchar_t* str) {
            if (listCount >= MAX_INDEX) deleteString(0);
            int index = (int)SendMessage(handle, LB_ADDSTRING, 0, (LPARAM)str);
            if (index != LB_ERR) ++listCount;
            SendMessage(handle, LB_SETTOPINDEX, index, 0);
        }

        // insert a string at given index into the list
        // If the index is greater than listCount, the string is added to the end of the list.
        // If the list is full, then delete the last entry before inserting new string.
        void insertString(const wchar_t* str, int index) {
            if (listCount >= MAX_INDEX) deleteString(listCount - 1);
            index = (int)SendMessage(handle, LB_INSERTSTRING, index, (LPARAM)str);
            if (index != LB_ERR) ++listCount;
            SendMessage(handle, LB_SETTOPINDEX, index, 0);
        }

        void deleteString(int index) { if (SendMessage(handle, LB_DELETESTRING, index, 0) != LB_ERR) --listCount; }

        int getSelect() { return SendMessage(handle, LB_GETCURSEL, 0, 0); };

        void getSelectItemText(wchar_t* str, int& Length)
        {
            // Get selected index.
            int lbItem = (int)SendMessage(handle, LB_GETCURSEL, 0, 0);

            // display item's text 
            //TCHAR buff[MAX_PATH];
            SendMessage(handle, LB_GETTEXT, lbItem, (LPARAM)str);
           // lstrcpyW(str, buff);
            Length = lstrlenW(str);
        }
        


    private:
        int listCount;
    };



    ///////////////////////////////////////////////////////////////////////////
    // Trackbar class (Slider)
    // It requires loading comctl32.dll. Note that the range values are logical
    // numbers and all integers.For example, if you want the range of 0~1 and
    // 100 increment steps(ticks) between 0 and 1, then you need to call
    // setRange(0, 100), not setRange(0,1). In other words, this class is not
    // responsible to scale the range to actual values.
    ///////////////////////////////////////////////////////////////////////////
    class Trackbar : public ControlBase
    {
    public:
        Trackbar() : ControlBase() {}
        Trackbar(HWND parent, int id, bool visible = true) : ControlBase(parent, id, visible) {}
        virtual ~Trackbar() {}

        // set/get range
        void setRange(int first, int last) { SendMessage(handle, TBM_SETRANGE, (WPARAM)true, (LPARAM)MAKELONG(first, last)); }
        int getRangeMin() const { return (int)SendMessage(handle, TBM_GETRANGEMIN, 0, 0); }
        int getRangeMax() const { return (int)SendMessage(handle, TBM_GETRANGEMAX, 0, 0); }

        // set a tick mark at a specific position
        // Trackbar creates its own first and last tick marks, so do not use it for first and last tick mark.
        void setTic(int pos) {
            if (pos <= getRangeMin()) return;   // skip if it is the first tick
            if (pos >= getRangeMax()) return;   // skip if it is the last tick
            SendMessage(handle, TBM_SETTIC, 0, (LPARAM)pos);
        }

        // set the interval frequency for tick marks.
        void setTicFreq(int freq) { SendMessage(handle, TBM_SETTICFREQ, (WPARAM)freq, 0); }

        // set/get current thumb position
        int  getPos() const { return (int)SendMessage(handle, TBM_GETPOS, 0, 0); }
        void setPos(int pos) { SendMessage(handle, TBM_SETPOS, (WPARAM)true, (LPARAM)pos); }
    };



    ///////////////////////////////////////////////////////////////////////////
    // Combo box class
    ///////////////////////////////////////////////////////////////////////////
    class ComboBox : public ControlBase
    {
    public:
        ComboBox() : ControlBase() {}
        ComboBox(HWND parent, int id, bool visible = true) : ControlBase(parent, id, visible) {}
        virtual ~ComboBox() {}

        int getCount() const { return (int)SendMessage(handle, CB_GETCOUNT, 0, 0); }

        void resetContent() { SendMessage(handle, CB_RESETCONTENT, 0, 0); }

        // add a string at the end of the combo box
        void addString(const wchar_t* str) { SendMessage(handle, CB_ADDSTRING, 0, (LPARAM)str); }

        // insert a string at given index into the list
        void insertString(const wchar_t* str, int index) { SendMessage(handle, CB_INSERTSTRING, index, (LPARAM)str); }

        // delete an entry
        void deleteString(int index) { SendMessage(handle, CB_DELETESTRING, index, 0); }

        // get/set current selection
        int getCurrentSelection() { return (int)SendMessage(handle, CB_GETCURSEL, 0, 0); }
        void setCurrentSelection(int index) { SendMessage(handle, CB_SETCURSEL, index, 0); }
        
    
        void getSelectItemText(wchar_t* str, int& Length)
        {
            // Get selected index.
            int lbItem = (int)SendMessage(handle, CB_GETCURSEL, 0, 0);

            ::SendMessage(handle, CB_GETLBTEXT, lbItem, (LPARAM)str);

            Length = lstrlenW(str);
        }
    };



    ///////////////////////////////////////////////////////////////////////////
    // TreeView class
    // It requires comctl32.dll.
    ///////////////////////////////////////////////////////////////////////////
    class TreeView : public ControlBase
    {
    public:
        TreeView() : ControlBase() {}
        TreeView(HWND parent, int id, bool visible = true) : ControlBase(parent, id, visible) {}
        virtual ~TreeView() {}

        // get the handle to an item, HTREEITEM
        // The possible flags are TVGN_CARET, TVGN_CHILD, TVGN_DROPHILITE, TVGN_FIRSTVISIBLE,
        // TVGN_LASTVISIBLE, TVGN_NEXT, TVGN_NEXTSELECTED, TVGN_NEXTVISIBLE, TVGN_PARENT,
        // TVGN_PREVIOUS, TVGN_PREVIOUSVISIBLE, TVGN_ROOT
        // It returns NULL if failed.
        HTREEITEM getNextItem(HTREEITEM item, unsigned int flag = TVGN_NEXT) const
        {
            return (HTREEITEM)SendMessage(handle, TVM_GETNEXTITEM, (WPARAM)flag, (LPARAM)item);
        }
        // getNextItem() with specific flags
        // It returns NULL if failed
        HTREEITEM getNext(HTREEITEM item) const { return getNextItem(item, TVGN_NEXT); }    // get the next sibling item
        HTREEITEM getPrevious(HTREEITEM item) const { return getNextItem(item, TVGN_PREVIOUS); }// get the previous sibling item
        HTREEITEM getRoot() const { return getNextItem(0, TVGN_ROOT); }       // get the topmost item
        HTREEITEM getParent(HTREEITEM item) const { return getNextItem(item, TVGN_PARENT); }  // get the parent item
        HTREEITEM getChild(HTREEITEM item) const { return getNextItem(item, TVGN_CHILD); }   // get the first child item
        HTREEITEM getSelected() const { return getNextItem(0, TVGN_CARET); }      // get the selected item
        HTREEITEM getDropHilight() const { return getNextItem(0, TVGN_DROPHILITE); } // get the target item of a drag-and-drop operation.

        // set/get pointer to TVITEM struct
        // User must set TVITEM.hItem and TVITEM.mask to retrieve/set information of the item, then pass its pointer to this function.
        void setItem(TVITEM* tvitem) { SendMessage(handle, TVM_SETITEM, 0, (LPARAM)tvitem); }
        void getItem(TVITEM* tvitem) const { SendMessage(handle, TVM_GETITEM, 0, (LPARAM)tvitem); }

        // select a TreeView item
        // Possible flags are TVGN_CARET, TVGN_DROPHILITE, TVGN_FIRSTVISIBLE.
        void selectItem(HTREEITEM item, unsigned int flag = TVGN_CARET) const
        {
            SendMessage(handle, TVM_SELECTITEM, (WPARAM)flag, (LPARAM)item);
        }

        // insert new item. the associated image, parent and insertAfter item are optional. It returns HTREEITEM
        HTREEITEM insertItem(const wchar_t* str, HTREEITEM parent = TVI_ROOT, HTREEITEM insertAfter = TVI_LAST, int imageIndex = 0, int selectedImageIndex = 0) const
        { // build TVINSERTSTRUCT
            TVINSERTSTRUCT insertStruct;
            insertStruct.hParent = parent;
            insertStruct.hInsertAfter = insertAfter;        // handle to item or TVI_FIRST, TVI_LAST, TVI_ROOT
            insertStruct.item.mask = TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE;
            //insertStruct.item.mask = TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_PARAM;
            insertStruct.item.pszText = (LPWSTR)str;
            insertStruct.item.cchTextMax = sizeof(str) / sizeof(str[0]);
            insertStruct.item.iImage = imageIndex;                       // image index of ImageList
            insertStruct.item.iSelectedImage = selectedImageIndex;

            // insert the item
            HTREEITEM hTreeItem = (HTREEITEM)SendMessage(handle, TVM_INSERTITEM, 0, (LPARAM)&insertStruct);

            // expand its parent
            HTREEITEM hParentItem = getParent(hTreeItem);
            if (hParentItem) expand(hParentItem);

            return hTreeItem;
        }

        // remove an item from TreeView. If a parent item is deleted, all the children of it are also deleted.
        // To delete all items in the TreeView, use TVI_ROOT or NULL param.
        void deleteItem(HTREEITEM item) const { SendMessage(handle, TVM_DELETEITEM, 0, (LPARAM)item); }

        void editLabel(HTREEITEM item) const { SendMessage(handle, TVM_EDITLABEL, 0, (LPARAM)item); }

        // return the handle of EditBox control of an item where TVN_BEGINLABELEDIT is notified
        HWND getEditControl() const { return (HWND)SendMessage(handle, TVM_GETEDITCONTROL, 0, 0); }

        // return the number of items
        // The maximum number of items is based on the amount of memory available in the heap.
        int  getCount() const { return (int)SendMessage(handle, TVM_GETCOUNT, 0, 0); }

        // expand/collapse the list
        // Possible flags are TVE_EXPAND(default), TVE_COLLAPSE, TVE_TOGGLE, TVE_EXPANDPARTIAL, TVE_COLLAPSERESET.
        void expand(HTREEITEM item, unsigned int flag = TVE_EXPAND) const
        {
            SendMessage(handle, TVM_EXPAND, (WPARAM)flag, (LPARAM)item);
        }
        void collapse(HTREEITEM item) const { expand(item, TVE_COLLAPSE); }

        // set/get the amount of indentation
        // To set the minimum indent of your system, use 0 as indent value.
        void setIndent(int indent) const { SendMessage(handle, TVM_SETINDENT, (WPARAM)indent, 0); }
        int  getIndent() const { return (int)SendMessage(handle, TVM_GETINDENT, 0, 0); }

        // set/get image list (MODE: TVSIL_NORMAL, TVSIL_STATE)
        void setImageList(HIMAGELIST imageListHandle, int imageListType = TVSIL_NORMAL) const
        {
            SendMessage(handle, TVM_SETIMAGELIST, (WPARAM)imageListType, (LPARAM)imageListHandle);
        }
        HIMAGELIST getImageList(int imageListType) const
        {
            return (HIMAGELIST)SendMessage(handle, TVM_GETIMAGELIST, (WPARAM)imageListType, (LPARAM)0);
        }

        // create the dragging image for you
        HIMAGELIST createDragImage(HTREEITEM item) const
        {
            return (HIMAGELIST)SendMessage(handle, TVM_CREATEDRAGIMAGE, 0, (LPARAM)item);
        }

        // get bounding rectangle of the item being dragged
        void getItemRect(RECT* rect, bool textOnly = true) const
        {
            SendMessage(handle, TVM_GETITEMRECT, (WPARAM)textOnly, (LPARAM)rect);
        }

        // hit test for dragging item
        HTREEITEM hitTest(TVHITTESTINFO* hitTestInfo) const
        {
            return (HTREEITEM)SendMessage(handle, TVM_HITTEST, 0, (LPARAM)hitTestInfo);
        }

    };



    ///////////////////////////////////////////////////////////////////////////
    // UpDownBox class
    // It requires comctl32.dll.
    // Note that UpDownBox sends UDN_DELTAPOS notification when the position of
    // the control is about to change. Return non-zero value to prevent the
    // change.
    ///////////////////////////////////////////////////////////////////////////
    class UpDownBox : public ControlBase
    {
    public:
        UpDownBox() : ControlBase() {}
        UpDownBox(HWND parent, int id, bool visible = true) : ControlBase(parent, id, visible) {}
        virtual ~UpDownBox() {}

        // set/get the buddy window for up-down control
        // UDS_SETBUDDYINT style must be added to make automatic update of buddy window.
        void setBuddy(HWND buddy) { SendMessage(handle, UDM_SETBUDDY, (WPARAM)buddy, 0); }
        HWND getBuddy() { return (HWND)SendMessage(handle, UDM_GETBUDDY, 0, 0); }

        // set/get the base(decimal or hexadecimal) of number in the buddy window
        // 10 for deciaml, 16 for hexadecimal
        void setBase(int base) { SendMessage(handle, UDM_SETBASE, (WPARAM)base, 0); }
        int  getBase() { return (int)SendMessage(handle, UDM_GETBASE, 0, 0); }

        // set/get the range (low and high value) of up-down control
        void setRange(int low, int high) { SendMessage(handle, UDM_SETRANGE32, (WPARAM)low, (LPARAM)high); }
        void getRange(int* low, int* high) { SendMessage(handle, UDM_GETRANGE32, (WPARAM)low, (LPARAM)high); }

        // set/get acceleration (elapsed time and increment) of up-down control
        void setAccel(unsigned int second, unsigned int increment) {
            UDACCEL accels[2];
            accels[0].nSec = 0;      accels[0].nInc = 1;
            accels[1].nSec = second; accels[1].nInc = increment;
            SendMessage(handle, UDM_SETACCEL, (WPARAM)2, (LPARAM)&accels);
        }
        void getAccel(unsigned int* second, unsigned int* increment) {
            UDACCEL accels[2];
            SendMessage(handle, UDM_GETACCEL, (WPARAM)2, (LPARAM)&accels);
            *second = accels[1].nSec; *increment = accels[1].nInc;
        }

        // set/get the current position with 32-bit precision
        void setPos(int position) { SendMessage(handle, UDM_SETPOS32, 0, (LPARAM)position); }
        int  getPos() { return (int)SendMessage(handle, UDM_GETPOS32, 0, 0); }
    };



    ///////////////////////////////////////////////////////////////////////////
    // SysLink class
    // It requires comctl32.dll. include ICC_LINK_CLASS
    // SysLink control is special textbox with 0 or more <a> markups in it.
    // When it is clicked, it notifies NM_CLICK/NM_RETURN message.
    ///////////////////////////////////////////////////////////////////////////
    class SysLink : public TextBox
    {
    public:
        SysLink() : TextBox() {}
        SysLink(HWND parent, int id, bool visible = true) : TextBox(parent, id, visible) {}
        virtual ~SysLink() {}

        // get URL associated with index value
        void getUrl(int index, wchar_t* buf) {
            LITEM item;
            memset((void*)&item, 0, sizeof(LITEM));
            item.mask = LIF_ITEMINDEX | LIF_URL;
            item.iLink = index; // set index before get URL
            SendMessage(handle, LM_GETITEM, 0, (LPARAM)&item);
            wcscpy(buf, item.szUrl);
        }
        // set URL only at index
        void setUrl(int index, wchar_t* buf) {
            LITEM item;
            memset((void*)&item, 0, sizeof(LITEM));
            item.mask = LIF_ITEMINDEX | LIF_URL;
            item.iLink = index;      // set index before get URL
            wcscpy(item.szUrl, buf); // copy to LITEM struct
            SendMessage(handle, LM_SETITEM, 0, (LPARAM)&item);
        }
    };

    ///////////////////////////////////////////////////////////////////////////
    // Picture class for bitmap
    ///////////////////////////////////////////////////////////////////////////
    class Picture : public ControlBase
    {
    public:
        // ctor / dtor
        Picture() : ControlBase() {}
        Picture(HWND parent, int id, bool visible = true) : ControlBase(parent, id, visible) {}
        virtual ~Picture() {}

        // set an image
        HBITMAP getImage() { return bitmap; }
        void setImage(HBITMAP bitmap) {
            this->bitmap = bitmap;
            SendMessage(handle, STM_SETIMAGE, (WPARAM)IMAGE_BITMAP, (LPARAM)bitmap);
        }
        void  setBmpFile(const wchar_t* fileName)
        {
            HBITMAP hBitmap = (HBITMAP)LoadImage(NULL, fileName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
            setImage(hBitmap);
        }
    private:
        HBITMAP bitmap;
    };

    class TabControl;
    class TabPage : public ControlBase
    {

    public:
        TabPage() : ControlBase() {}
        TabPage(HWND parent, int id, bool visible = true) : ControlBase(parent, id, visible)
        {
            // SetGetTabPage(0, nullptr, this);
        }
        virtual ~TabPage();


        void set(TabControl* pTabControl, LPWSTR _tabName, DWORD id);
    protected:
        TabControl* m_pTabControl = nullptr;
        DWORD tabPageResourceID = 0;
    private:
        friend class TabControl;
        // Function pointer to Parent Dialog Proc
        INT_PTR(CALLBACK* TabPageProc)(HWND, UINT, WPARAM, LPARAM) = nullptr;


        INT_PTR CALLBACK DefaultTabPage_DlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
        {
            switch (msg)
            {

                HANDLE_MSG(hwndDlg, WM_INITDIALOG, TabPage_OnInitDialog);
                HANDLE_MSG(hwndDlg, WM_SIZE, TabPage_OnSize);
                HANDLE_MSG(hwndDlg, WM_COMMAND, TabPage_OnCommand);
                HANDLE_MSG(hwndDlg, WM_LBUTTONDOWN, TabPage_OnLButtonDown);

                //// TODO: Add TabPage dialog message crackers here...
                case WM_NOTIFY:
                    TabPage_OnNotify(hwndDlg, msg, wParam, lParam);
    
                break;
            

            default: return UserTabPageMessageProcess(hwndDlg, msg, wParam, lParam);
            }

            return FALSE;
        }
        virtual INT_PTR UserTabPageMessageProcess(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
        {

            return FALSE;
        }
        virtual VOID TabPage_OnCommand(HWND hwnd, INT id, HWND hwndCtl, UINT codeNotify)
        {

        }
        virtual VOID TabPage_OnNotify(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
        {

        }
        virtual void Init_Event(HWND hDlg, WPARAM wParam, LPARAM lParam)
        {

        }
        BOOL TabPage_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam)
        {
            // We handle this message so that it is not sent to the main dlg proc
            // each time a tab page is initialized.
            Init_Event(hwnd, (WPARAM)hwndFocus, lParam);

            return DefWindowProc(hwnd, WM_INITDIALOG, (WPARAM)hwndFocus, lParam);
        }
       


        virtual VOID TabPage_OnSize(HWND hwnd, UINT state, INT cx, INT cy)
        {

        }
       
        virtual VOID TabPage_OnLButtonDown(HWND hwnd, BOOL fDoubleClick, INT x, INT y, UINT keyFlags)
        {

        }
       
        virtual BOOL StretchTabPage(HWND, INT)
        {
            return TRUE;
        }
        virtual BOOL  CenterTabPage(HWND, INT)
        {
            return TRUE;
        }
    };
   
    class TabControl : public ControlBase
    {
    public:
        TabControl() : ControlBase() 
        {
           // ThisParentProc = NewParentProc;
           // 
        }
        TabControl(HWND parent, int id, bool visible = true) : ControlBase(parent, id, visible) 
        {
            SetGetTabControl(handle, this);
        }
        virtual ~TabControl()
        {
            if (hTabPages != nullptr)
            {
                free(hTabPages);
                hTabPages = nullptr;

                hVisiblePage = nullptr;
            }
            if (tabNames != nullptr)
            {
                for (int i = 0; i < m_TabpageCount; i++)
                {
                    if (tabNames[i] != nullptr)
                    {
                        delete[]  tabNames[i];
                        tabNames[i] = 0;
                    }
                }
                free(tabNames);
                tabNames = nullptr;
            }

            if (tabPageResourceID != nullptr)
            {
                          free(tabPageResourceID);
                tabPageResourceID = nullptr;
            }
        }
        
        void set(HWND parent, int id, const int TabpageCount)
        {
            static TCITEM tie;

            this->parent = parent;
            this->id = id;

            m_TabpageCount = TabpageCount;
            handle = GetDlgItem(parent, id);

            SetGetTabControl(handle, this);

           // hTabPages = new HWND[m_TabpageCount];
            hTabPages = (HWND*)malloc(m_TabpageCount*sizeof(HWND));

            m_pTabPageObject = (TabPage**)malloc(m_TabpageCount * sizeof(TabPage*));

            //tabNames = new LPWSTR[m_TabpageCount];
            tabNames = (LPWSTR*)malloc(m_TabpageCount * sizeof(LPWSTR));
            //tabPageResourceNames = new LPWSTR[m_TabpageCount];
            tabPageResourceID = (int*)malloc(m_TabpageCount * sizeof(int));

            for (int i = 0; i < m_TabpageCount; i++)
            {
                hTabPages[i] = nullptr;
                m_pTabPageObject[i] = nullptr;
                tabNames[i] = nullptr;
                tabPageResourceID[i] = 0;
            }

        }
        static BOOL TabControl_Notify(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
        {
            NMHDR* nm = (NMHDR*)lParam;
            TabControl* pTabControl = SetGetTabControl(nm->hwndFrom);
            if (pTabControl != nullptr)
            {
                return pTabControl->InsideNotify(nm);
            }
            return FALSE;
        }
        void TabControl_OnSize(const HWND hwnd, UINT state, int cx, int cy)
        {
           
            for (int i = 0; i < m_TabpageCount; i++)
            {
                if (m_pTabPageObject[i] != nullptr)
                {
                    if (blStretchTabs)
                        m_pTabPageObject[i]->StretchTabPage(handle, i);
                    else
                        m_pTabPageObject[i]->CenterTabPage(handle, i);
                }
            }

        }
    private:
        friend class TabPage;
        HWND       hVisiblePage;

        HWND*      hTabPages=nullptr;
        TabPage**  m_pTabPageObject = nullptr;

        LPWSTR*    tabNames = nullptr;
        int*       tabPageResourceID = nullptr;
        int        m_TabpageCount = 0;
        BOOL       blStretchTabs=TRUE;
    
        static TabControl* SetGetTabControl(const HWND _hwnd = nullptr, TabControl* p = nullptr)
        {
            static std::vector<TabControl*>  sTabControlArray;
            if (p != nullptr)
            {
                std::vector<TabControl*>::iterator pIt = sTabControlArray.begin();
                while (pIt != sTabControlArray.end())
                {
                    if (*pIt == p)
                        break;
                    pIt++;
                }
                if (pIt == sTabControlArray.end())
                {
                    sTabControlArray.push_back(p);
                    return  p;
                }
                else
                    return *pIt;
            }
            else  if (_hwnd != nullptr)
            {
                std::vector<TabControl*>::iterator pIt = sTabControlArray.begin();
                while (pIt != sTabControlArray.end())
                {
                    if ((*pIt)->handle == _hwnd)
                        break;
                    pIt++;
                }
                if (pIt == sTabControlArray.end())
                {
                    return nullptr;
                }
                else
                {
                    return *pIt;
                }
            }
            else
                return nullptr;
        }

        // Function pointer to Tab Page Size Proc


        VOID  TabControl_GetClientRect(HWND hwnd, RECT* prc);

        BOOL InsideNotify(LPNMHDR pnm);
        VOID TabCtrl_OnKeyDown(LPARAM lParam);
        BOOL TabCtrl_OnSelChanged(VOID);
     

        BOOL CenterTabPage(const HWND hTab, INT iPage)
        {
            RECT rect, rclient;

           
            TabControl_GetClientRect(hTab, &rect); // left, top, width, height

            // Get the tab page size
            GetClientRect(hTabPages[iPage], &rclient);
            
            rclient.right = rclient.right - rclient.left;// width
            rclient.bottom = rclient.bottom - rclient.top;// height
            rclient.left = rect.left;
            rclient.top = rect.top;

            // Center the tab page, or cut it off at the edge of the tab control(bad)
            if (rclient.right < rect.right)
                rclient.left += (rect.right - rclient.right) / 2;

            if (rclient.bottom < rect.bottom)
                rclient.top += (rect.bottom - rclient.bottom) / 2;

            // Move the child and put it on top
            BOOL hResult =SetWindowPos(hTabPages[iPage], HWND_TOP,
                rclient.left, rclient.top, rclient.right, rclient.bottom,
                0);
            if (m_pTabPageObject[iPage] != nullptr)
            {
                m_pTabPageObject[iPage]->CenterTabPage(hTabPages[iPage], iPage);
            }
                   
            return hResult;
        }

        
        BOOL StretchTabPage(const HWND hTab, INT iPage)
        {
            RECT rect;
            
                TabControl_GetClientRect(hTab, &rect); // left, top, width, height

                // Move the child and put it on top
                BOOL hResult = SetWindowPos(hTabPages[iPage],
                             HWND_TOP,
                                  rect.left, rect.top, rect.right, rect.bottom,
                             0);
          
                if (m_pTabPageObject[iPage] != nullptr)
                {
                    m_pTabPageObject[iPage]->StretchTabPage(hTabPages[iPage], iPage);
                }
            return hResult;
        }

    };

    inline VOID TabControl::TabControl_GetClientRect(HWND hwnd, RECT* prc)
    {
        RECT rtab_0;
        LONG lStyle = GetWindowLong(hwnd, GWL_STYLE);

        // Calculate the tab control's display area
        GetWindowRect(hwnd, prc);
        ScreenToClient(GetParent(hwnd), (POINT*)&prc->left);
        ScreenToClient(hwnd, (POINT*)&prc->right);
        TabCtrl_GetItemRect(hwnd, 0, &rtab_0); //The tab itself

        if ((lStyle & TCS_BOTTOM) && (lStyle & TCS_VERTICAL)) //Tabs to Right
        {
            prc->top = prc->top + 6; //x coord
            prc->left = prc->left + 4; //y coord
            prc->bottom = prc->bottom - 12; // height
            prc->right = prc->right - (12 + rtab_0.right - rtab_0.left); // width
        }
        else if (lStyle & TCS_VERTICAL) //Tabs to Left
        {
            prc->top = prc->top + 6; //x coord
            prc->left = prc->left + (4 + rtab_0.right - rtab_0.left); //y coord
            prc->bottom = prc->bottom - 12; // height
            prc->right = prc->right - (12 + rtab_0.right - rtab_0.left); // width
        }
        else if (lStyle & TCS_BOTTOM) //Tabs on Bottom
        {
            prc->top = prc->top + 6; //x coord
            prc->left = prc->left + 4; //y coord
            prc->bottom = prc->bottom - (16 + rtab_0.bottom - rtab_0.top); // height
            prc->right = prc->right - 12; // width
        }
        else //Tabs on top
        {
            prc->top = prc->top + (6 + rtab_0.bottom - rtab_0.top); //x coord
            prc->left = prc->left + 4; //y coord
            prc->bottom = prc->bottom - (16 + rtab_0.bottom - rtab_0.top); // height
            prc->right = prc->right - 12; // width
        }
    }
 
    inline BOOL TabControl::InsideNotify(LPNMHDR pnm)
    {
        switch (pnm->code)
        {
        case TCN_KEYDOWN:
            TabCtrl_OnKeyDown((LPARAM)pnm);
            // fall through to call TabCtrl_OnSelChanged() on each keydown

        case TCN_SELCHANGE:
            return TabCtrl_OnSelChanged();
        }
        return FALSE;
    }

/****************************************************************************
*     FUNCTION: TabCtrl_OnKeyDown  PURPOSE:  Handle key presses in the tab control (but not the tab pages).
\****************************************************************************/

     inline  VOID TabControl::TabCtrl_OnKeyDown(LPARAM lParam)
    {
        TC_KEYDOWN* tk = (TC_KEYDOWN*)lParam;
        int itemCount = TabCtrl_GetItemCount(tk->hdr.hwndFrom);
        int currentSel = TabCtrl_GetCurSel(tk->hdr.hwndFrom);

        if (itemCount <= 1) return; // Ignore if only one TabPage

        BOOL verticalTabs = GetWindowLong(handle, GWL_STYLE) & TCS_VERTICAL;

        if (verticalTabs)
        {
            switch (tk->wVKey)
            {
            case VK_PRIOR: //select the previous page
            {
                if (0 == currentSel) return;
                TabCtrl_SetCurSel(tk->hdr.hwndFrom, currentSel - 1);
                TabCtrl_SetCurFocus(tk->hdr.hwndFrom, currentSel - 1);
            }
            break;
            case VK_UP: //select the previous page
            {
                if (0 == currentSel) return;
                TabCtrl_SetCurSel(tk->hdr.hwndFrom, currentSel - 1);
                TabCtrl_SetCurFocus(tk->hdr.hwndFrom, currentSel);
            }
            break;
            case VK_NEXT:  //select the next page
            {
                TabCtrl_SetCurSel(tk->hdr.hwndFrom, currentSel + 1);
                TabCtrl_SetCurFocus(tk->hdr.hwndFrom, currentSel + 1);
            }
            break;
            case VK_DOWN: //select the next page
            {
                TabCtrl_SetCurSel(tk->hdr.hwndFrom, currentSel + 1);
                TabCtrl_SetCurFocus(tk->hdr.hwndFrom, currentSel);
            }
            break;
            case VK_LEFT: //navagate within selected child tab page
            {
                SetFocus(hTabPages[currentSel]); // focus to child tab page
             }
            break;
            case VK_RIGHT: //navagate within selected child tab page
            {
                SetFocus(hTabPages[currentSel]);
            }
            break;
            default: return;
            }
        } // if(verticalTabs)

        else // horizontal Tabs
        {
            switch (tk->wVKey)
            {
            case VK_NEXT: //select the previous page
            {
                if (0 == currentSel) return;
                TabCtrl_SetCurSel(tk->hdr.hwndFrom, currentSel - 1);
                TabCtrl_SetCurFocus(tk->hdr.hwndFrom, currentSel - 1);
            }
            break;
            case VK_LEFT: //select the previous page
            {
                if (0 == currentSel) return;
                TabCtrl_SetCurSel(tk->hdr.hwndFrom, currentSel - 1);
                TabCtrl_SetCurFocus(tk->hdr.hwndFrom, currentSel);
            }
            break;
            case VK_PRIOR: //select the next page
            {
                TabCtrl_SetCurSel(tk->hdr.hwndFrom, currentSel + 1);
                TabCtrl_SetCurFocus(tk->hdr.hwndFrom, currentSel + 1);
            }
            break;
            case VK_RIGHT: //select the next page
            {
                TabCtrl_SetCurSel(tk->hdr.hwndFrom, currentSel + 1);
                TabCtrl_SetCurFocus(tk->hdr.hwndFrom, currentSel);
            }
            break;
            case VK_UP: //navagate within selected child tab page
            {
                SetFocus(hTabPages[currentSel]);
            }
            break;
            case VK_DOWN: //navagate within selected child tab page
            {
                SetFocus(hTabPages[currentSel]);
            }
            break;
            default: return;
            }
        } //else // horizontal Tabs
    }
  
    inline BOOL TabControl::TabCtrl_OnSelChanged(VOID)
    {
        int iSel = TabCtrl_GetCurSel(handle);

        //Hide the current child dialog box, if any.
        ShowWindow(hVisiblePage, FALSE);

        //Show the new child dialog box.
        ShowWindow(hTabPages[iSel], TRUE);

        // Save the current child
        hVisiblePage = hTabPages[iSel];

        return TRUE;
    }

    inline TabPage::~TabPage()
    {
        if (TabPageProc != nullptr)
            FreeObjectInstance(TabPageProc);
    }
   inline void TabPage::set(TabControl* pTabControl, LPWSTR _tabName, DWORD _resouceID)
    {
        static TCITEM tie;
        this->m_pTabControl = pTabControl;
        tabPageResourceID = _resouceID;
        int i = 0;
        for (i = 0; i < pTabControl->m_TabpageCount; i++)
        {
            if (pTabControl->hTabPages[i] == nullptr)
                break;
        }
        if (i >= pTabControl->m_TabpageCount)
            return;
        // Add a tab for each name in tabnames (list ends with 0)
        tie.mask = TCIF_TEXT | TCIF_IMAGE;
        tie.iImage = -1;

        int tStringLen = wcslen(_tabName);

        pTabControl->tabNames[i] = new wchar_t[tStringLen + 2];
        lstrcpyW(pTabControl->tabNames[i], _tabName);
        tie.pszText = pTabControl->tabNames[i];

        if (TabPageProc == nullptr)
        {
            TabPageProc = (DLGPROC)MakeObjectInstance(this, &TabPage::DefaultTabPage_DlgProc);
        }

        handle = CreateDialog(GetModuleHandle(NULL),
            MAKEINTRESOURCE(tabPageResourceID),
            GetParent(pTabControl->getHandle()),
            TabPageProc);
        if (handle == nullptr)
            return;

        // ��ȷ����Դ�ļ�������ʽΪchild ����Ӧ��SetWindowLong�����󣬳���������ȴ�30��Ž����û����룬�����ε���
          /*
           LONG l_WinStyle = GetWindowLong(handle, GWL_STYLE);
           l_WinStyle &= ~WS_POPUP;            // �Ƴ� WS_POPUP ��ʽ
           l_WinStyle &= ~WS_OVERLAPPEDWINDOW;
           l_WinStyle &= ~WS_BORDER;
           l_WinStyle = (l_WinStyle | WS_CHILD | WS_VISIBLE) & ~WS_CAPTION;
           SetWindowLong(handle, GWL_STYLE, l_WinStyle);  */

        TabCtrl_InsertItem(pTabControl->getHandle(), i, &tie);

        pTabControl->tabPageResourceID[i] = tabPageResourceID;
        pTabControl->hTabPages[i] = handle;



        if (pTabControl->blStretchTabs)
            pTabControl->StretchTabPage(pTabControl->getHandle(), i);
        else
            CenterTabPage(pTabControl->getHandle(), i);

        if (i == 0)
        {
            pTabControl->hVisiblePage = pTabControl->hTabPages[i];
            ShowWindow(pTabControl->hTabPages[i], SW_SHOW);
        }

        return;
    }

}

#endif

#ifndef _WIN64
#pragma warning(default : 4244 4312)
#endif