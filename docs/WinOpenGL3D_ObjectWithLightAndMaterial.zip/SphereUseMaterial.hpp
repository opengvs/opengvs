#pragma once
#include <string>
#include "VAOWithVBOandEBO.hpp"
#include "Transform.hpp"
#include "Camera.hpp"
#include "Shader.hpp"
#include "GLMaterial.hpp"
#include "GLLight.hpp"

#include "g_consts.h"
extern ParallelLight                g_ParallelLight;
extern DotLight                     g_DotLight;
extern SpotLight                    g_SpotLight;

class SphereUseMaterial : public Transform
{
    const int Y_SEGMENTS = 50;
    const int X_SEGMENTS = 50;
    float radius = 1.0f;
    std::vector<glm::vec3> m_sphere_vertices;
   // std::vector<glm::vec3> m_sphere_colors;
    std::vector<glm::vec3> m_sphere_mNormals;
    std::vector<glm::vec2> m_sphere_mTexCoords;
    std::vector<unsigned int> m_sphere_indices;

    std::vector<float>    m_sphereData;
    unsigned int sphereVAO = 0, vbo = 0, ebo=0;
    unsigned int indexCount=0;
    unsigned int triangleCount = 0;
   // float radius = 1.0f;
public:

    VAOWithVBOandEBO  m_VaoWithVbo;
    SphereUseMaterial()
    {

    }
    virtual ~SphereUseMaterial()
    {
        if (sphereVAO != 0)
        {
            glDeleteVertexArrays(1,&sphereVAO);
        }
        if (vbo != 0)
        {

            glDeleteBuffers(1, &vbo);
        }
        if (vbo != 0)
        {
            glDeleteBuffers(1, &ebo);
        }
    }
    void InitializeData()
    {   
       
        // ������Ķ���
        for (int j = 0; j <= Y_SEGMENTS; j++)
        {
            for (int i = 0; i <= X_SEGMENTS; i++)
            {

                float iSegment = (float)i / (float)X_SEGMENTS;
                float jSegment = (float)j / (float)Y_SEGMENTS;
                float xPos =
                    (float)(cos(iSegment * 2.0f * G_PI) * sin(jSegment * G_PI) * radius);
                float yPos = (float)cos(jSegment * G_PI) * radius;
                float zPos =
                    (float)(sin(iSegment * 2.0f * G_PI) * sin(jSegment * G_PI) * radius);

                m_sphere_vertices.emplace_back(glm::vec3(xPos, yPos, zPos));


                //����Ӧ��ʹ��һ����ʱ����
                glm::vec3 v3 = glm::vec3(xPos, yPos, zPos);
                //Ȼ���v3����ʸ����һ��
                v3.x = xPos;
                v3.y = yPos;
                v3.z = zPos;
                v3 = glm::normalize(v3);

                m_sphere_mNormals.emplace_back(v3);

                //���λ�û�������3��ʱ�䣬��ʼû�뵽������Ϊ0�����⣬���ǲ���ʾ����
                //���˺ܶ��а취���ڽ��ô����ΪEathSphereobject�����TextureCube���̷��ֻ��ǲ���ʾ��
                //����ʶ������������������Ϊ0
                float tempU = (float)i / (float)X_SEGMENTS;
                float tempV = (float)j / (float)X_SEGMENTS;

                m_sphere_mTexCoords.emplace_back(glm::vec2(tempU, tempV));

            }
        }
     
        // �������Indices
        bool oddRow = false;
        for (unsigned int i = 0; i < Y_SEGMENTS; ++i)
        {
            if (!oddRow) // even rows: y == 0, y == 2; and so on
            {
                for (unsigned int j = 0; j <= X_SEGMENTS; ++j)
                {
                    m_sphere_indices.push_back(i * (X_SEGMENTS + 1) + j);
                    m_sphere_indices.push_back((i + 1) * (X_SEGMENTS + 1) + j);
                }
            }

            // ������ż�ֿ��������е����ģ���ż�ֿ����ӣ�������λ�������Լ������ñʻ�һ��
            else
            {
                for (int j = X_SEGMENTS; j >= 0; --j)
                {
                    m_sphere_indices.push_back((i + 1) * (X_SEGMENTS + 1) + j);
                    m_sphere_indices.push_back(i * (X_SEGMENTS + 1) + j);
                }
            }
            oddRow = !oddRow;
        }
       
        indexCount = m_sphere_indices.size();
      
        for (unsigned int i = 0; i < m_sphere_vertices.size(); ++i)
        {
            m_sphereData.push_back(m_sphere_vertices[i].x);
            m_sphereData.push_back(m_sphere_vertices[i].y);
            m_sphereData.push_back(m_sphere_vertices[i].z);
            if (m_sphere_mTexCoords.size() > 0)
            {
                m_sphereData.push_back(m_sphere_mTexCoords[i].x);
                m_sphereData.push_back(m_sphere_mTexCoords[i].y);
            }
            if (m_sphere_mNormals.size() > 0)
            {
                m_sphereData.push_back(m_sphere_mNormals[i].x);
                m_sphereData.push_back(m_sphere_mNormals[i].y);
                m_sphereData.push_back(m_sphere_mNormals[i].z);
            }
        }  

        m_VaoWithVbo.AddVBOandEBO({ &(m_sphereData[0]) }, { (int)m_sphereData.size() }, BufferUsageHint::StaticDraw,
            { {3,2,3} }, std::vector<GLuint>(&(m_sphere_indices[0]), &(m_sphere_indices[0]) + m_sphere_indices.size()));
    
    }

    void Draw(Camera* _camera,Shader *_shader, GLMaterial*  _material,LightBase* _light,const bool& isBlin)
    {
        _shader->Use();
        _shader->SetVec3("viewPos", _camera->GetEyePosition());
        if (isBlin == true)
        {
            _shader->setInt("blinn", 1);
        }
        else
        {
            _shader->setInt("blinn", 0);
        }
            

        _material->SendAmbientData(_shader, "material.ambient");
        _material->SendDiffuseData(_shader, "material.diffuse");
        _material->SendSpecularData(_shader, "material.specular", "material.shininess");


        
      //  g_DotLight.SendAmbientData(_shader, "pointLight.ambient");
     //   g_DotLight.SendDiffuseData(_shader, "pointLight.diffuse");
      //  g_DotLight.SendSpecularData(_shader, "pointLight.specular");

      //  g_DotLight.SendPositionData(_shader, "pointLight.position");
        
        if (_light->m_LightType == LightType::ParallelLightType)
        {
            ParallelLight* p = reinterpret_cast<ParallelLight*>(_light);
            p->SendAmbientData(_shader, "directLight.ambient");
            p->SendDiffuseData(_shader, "directLight.diffuse");
            p->SendSpecularData(_shader, "directLight.specular");

            p->SendDirectionData(_shader, "directLight.direction");

        }
        else if (_light->m_LightType == LightType::DotLightType)
        {
            DotLight* p = reinterpret_cast<DotLight*>(_light);
            p->SendAmbientData(_shader, "pointLight.ambient");
            p->SendDiffuseData(_shader, "pointLight.diffuse");
            p->SendSpecularData(_shader, "pointLight.specular");

            p->SendPositionData(_shader, "pointLight.position");
           // p->SendDirectionData(_shader, "pointLight.direction");
        }
        else if (_light->m_LightType == LightType::SpotLightType)
        {
            SpotLight* p = reinterpret_cast<SpotLight*>(_light);
            p->SendAmbientData(_shader, "spotLight.ambient");
            p->SendDiffuseData(_shader, "spotLight.diffuse");
            p->SendSpecularData(_shader, "spotLight.specular");


            p->SendPositionData(_shader, "spotLight.position");
            p->SendDirectionData(_shader, "spotLight.direction");

            p->SendOuterCutOffData(_shader, "spotLight.cutOff");
            p->SendCutOffData(_shader, "spotLight.outerCutOff");
        }
        
        

        //this->RotateAngleY(glm::radians(0.05f));

        //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        // note: currently we set the projection matrix each frame, but since the projection matrix rarely changes it's often best practice to set it outside the main loop only once.
        _shader->SetMat4("projection", _camera->GetProjectionMat());
        _shader->SetMat4("model", GetMat());
        _shader->SetMat4("view", _camera->GetViewMat());


 

        m_VaoWithVbo.DrawElements(TriangleStrip, indexCount);

         _shader->UnUse();
       // m_texture1.Unbind();
    }
    public:
    const std::string m_vsShader = R"(
#version 460 core
layout(location = 0) in   vec3 aPos;
layout(location = 1) in   vec2 aTexCoord;
layout(location = 2) in   vec3 aNormal;

out  vec3   FragPos;
out  vec2   TexCoord;
out  vec3   Normal;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(aPos, 1.0f);
    FragPos = vec3(model * vec4(aPos, 1.0));
    TexCoord = vec2(aTexCoord.x, aTexCoord.y);
    Normal = vec3(aNormal.x, aNormal.y,aNormal.z);
}
)";
 /*   std::string  fs_Shader = R"(
    #version 330 core
        out vec4 FragColor;
    in vec2 TexCoord;
    in vec3 Normal;
    void main()
    {
        FragColor = vec4(1.0, 0.5, 0.31, 1.0);
    }
)";*/
    std::string  fs_ParallelLightShader = R"(
        # version 460 core
          struct Material
          {                                                                                                         
            vec3 ambient;                                                                                          
            vec3 diffuse;                                                                                           
            vec3 specular;                                                                                          
            float shininess;                                                                                        
        };                                                                                                          
        struct DirectLight                                                                                          
        {                                                                                                           
            vec3 direction;                                                                                         
            vec3 ambient;                                                                                           
            vec3 diffuse;                                                                                           
            vec3 specular;                                                                                          
        };                                                                                                          
        out vec4 FragColor;                                                                                         

        in  vec3 FragPos;
        in  vec2   TexCoord;                                                                                            
        in  vec3 Normal;                                                                                             
        //�ڹ���ģ�ͼ�������в���Ҫ�����������ɫ����ʵMaterial����ֵ�൱���������ɫ
        //  " uniform vec3 objectColor;      // ���㱾������ɫ                                             
          uniform bool blinn;                                                                                        
          uniform vec3 viewPos;                                                                                      
          uniform Material material;                                                                                 

          uniform DirectLight  directLight;                                                                           
          void main()                                                                                                
          {                                                                                                          
        // ��������--������ļ���ܼ򵥣����ǿ��*����ǿ��*������ɫ(����������ɫĬ��Ϊ1)
             vec3 ambient = directLight.ambient * material.ambient;                                                       

        // ������---
             vec3 norm = normalize(Normal);                                                                         
             vec3 lightDir = normalize(-directLight.direction);                                                   
             float diff = max(dot(norm, lightDir), 0.0);                                                            
             vec3 diffuse = directLight.diffuse * (diff * material.diffuse);                                              

        // �������
             vec3 viewDir = normalize(viewPos - FragPos);                                                           
             float spec = 0;                                                                                        
             if (blinn)                                                                                             
             {                                                                                                      
                  vec3 halfwayDir = normalize(lightDir + viewDir);                                                  
                  spec = pow(max(dot(norm, halfwayDir), 0.0), material.shininess);                                  
             }                                                                                                      
             else                                                                                                   
             {                                                                                                      
                  vec3 reflectDir = reflect(-lightDir, norm);                                                       
                  spec = pow( max( dot(viewDir, reflectDir), 0.0), material.shininess);                             
             }                                                                                                      
             vec3 specular = directLight.specular * (spec * material.specular);                                     
             vec3 result = ambient + diffuse + specular;                                                            
             FragColor = vec4(result, 1.0);                                                                         
        })";

	std::string  fs_PointLightShader = R"(
		# version 460 core                                                 
          struct Material                                                                                           
          {                                                                                                         
            vec3 ambient;                                                                                           
            vec3 diffuse;                                                                                           
            vec3 specular;                                                                                          
            float shininess;                                                                                        
         };                                                                                                          
        struct PointLight                                                                                           
        {                                                                                                           
            vec3 position;
            vec3 ambient;                                                                                           
            vec3 diffuse;                                                                                           
            vec3 specular;                                                                                          
        };                                                                                                          
        out vec4 FragColor;                                                                                         
        
        in vec3    FragPos;
        in  vec2   TexCoord;                                                                                             
        in vec3    Normal;                                                                                             
       //�ڹ���ģ�ͼ�������в���Ҫ�����������ɫ����ʵMaterial����ֵ�൱���������ɫ
       //  " uniform vec3 objectColor;      // ���㱾������ɫ                                             
          uniform int blinn;                                                                                        
          uniform vec3 viewPos;                                                                                      
          uniform Material material;                                                                                 

          uniform PointLight pointLight;                                                                                 
          void main()                                                                                                
          {                                                                                                          
         // ��������--������ļ���ܼ򵥣����ǿ��*����ǿ��*������ɫ(����������ɫĬ��Ϊ1)
              vec3 ambient = pointLight.ambient * material.ambient;                                                   

         // ������---
              vec3 norm = normalize(Normal);                                                                          
              vec3 lightDir = normalize(pointLight.position - FragPos);                                                   
              float diff = max(dot(norm, lightDir), 0.0);                                                            
              vec3 diffuse = pointLight.diffuse * (diff * material.diffuse);                                              

         // �������
              vec3 viewDir = normalize(viewPos - FragPos);                                                           
              float spec = 0;                                                                                        
              if (blinn==1)                                                                                          
              {                                                                                                      
                   vec3 halfwayDir = normalize(lightDir + viewDir);                                                  
                   spec = pow(max(dot(norm, halfwayDir), 0.0), material.shininess);                                  
              }                                                                                                      
              else                                                                                                   
              {                                                                                                      
                   vec3 reflectDir = reflect(-lightDir, norm);                                                       
                   spec = pow( max( dot(viewDir, reflectDir), 0.0), material.shininess);                               
              }                                                                                                      
              vec3 specular = pointLight.specular * (spec * material.specular);                                      
              vec3 result = ambient + diffuse + specular;                                                            
              FragColor = vec4(result, 1.0);
          }
		)";

    std::string fs_SpotLightShader = R"(
           # version 330 core                    
          struct Material                                                      
          {                                                                    
            vec3 ambient;                                                      
            vec3 diffuse;                                                      
            vec3 specular;                                                    
            float shininess;                                                   
          };                                                                  
         struct SpotLight                                                      
         {               
            vec3 position;     
            vec3 direction;                  
            float cutOff;       
            float outerCutOff;  

            vec3 ambient;                                                      
            vec3 diffuse;                                                     
            vec3 specular;                                                    
         };                                                                   
         out vec4 FragColor;                                                                      
         in vec3 FragPos;                                                                        
          in vec3 Normal;                                                                         
        //�ڹ���ģ�ͼ�������в���Ҫ�����������ɫ����ʵMaterial����ֵ�൱���������ɫ
        //  " uniform vec3 objectColor;      // ���㱾������ɫ                                            
          uniform int blinn;                                                                     
          uniform vec3 viewPos;                                                                   
          uniform Material material;                                                               
          uniform SpotLight  spotLight;   
          float constant=1.0; 
          float linear = 0.0; 
          float quadratic = 0.0;  
         void CalculateAttenuation(float distance) 
         {  
            if(distance<7.0)                      
            {                                     
               linear = 0.7;                      
               quadratic = 1.8;                   
            }                                    
            else if(distance<13.0)               
            {                                   
               linear = 0.35;                   
               quadratic=0.44;                  
             }                                   
            else if (distance < 20.0)           
            {                                  
                linear = 0.22;                  
                quadratic = 0.20;              
             }                                 
             else if (distance < 32.0)         
             {                                  
                linear = 0.14;                    
                quadratic = 0.07;                 
             }                                    
             else if (distance < 50.0)            
             {                                    
                linear = 0.09;                    
                quadratic = 0.032;               
             }                                   
             else if (distance < 65.0)             
             {                                    
                linear = 0.07;                    
                quadratic = 0.017;                
             }                                    
             else if (distance < 100.0)           
             {                                    
                 linear = 0.045;                  
                 quadratic = 0.0075;             
             }                                    
             else if (distance < 160.0)          
             {                                    
                 linear = 0.027;                  
                 quadratic = 0.0028;              
             }                                    
             else if (distance < 200.0)           
             {                                    
                  linear = 0.022;                
                  quadratic = 0.0019;            
             }                                    
             else if (distance < 325.0)           
             {                                    
                   linear = 0.014;                
                   quadratic = 0.0007;           
             }                                    
             else if (distance < 600.0)           
             {                                    
                  linear = 0.007;                  
                  quadratic = 0.0002;             
             }                                    
             else if (distance < 3250.0)         
             {                                    
                   linear = 0.0014;              
                   quadratic = 0.000007;          
             }                                    
          }                                      
          void main()                                                                                              
          {                                                                                                       
        // ����������շ�����
            vec3 ambient = spotLight.ambient * material.ambient;   

        // ��������--������ļ���ܼ򵥣����ǿ��*����ǿ��*������ɫ(����������ɫĬ��Ϊ1)
            vec3 lightDir = normalize(spotLight.position - FragPos);                       

        // ����������ϵ��
            float diff = max(dot(Normal, lightDir), 0.0);                              
            vec3 diffuse = spotLight.diffuse * diff * material.diffuse;        

        // ���淴��ϵ��
            vec3 viewDir = normalize(viewPos - FragPos);                       
            vec3 specular;                                                 
            if(blinn==1)                                                        
            {                                                                   
               vec3 halfwayDir = normalize(lightDir + viewDir);                 
               float spec = pow(max(dot(Normal, halfwayDir), 0.0), material.shininess); 
               specular = spotLight.specular * (spec * material.specular);     
            }                                                                  
            else                                                              
            {                                                                  
               vec3 reflectDir = reflect(-lightDir, Normal);                   
               float spec = pow( max( dot(viewDir, reflectDir), 0.0), material.shininess); 
               specular = spotLight.specular * (spec * material.specular);    
            }
        // ����˥��
            float distance = length(spotLight.position - FragPos);                         
            CalculateAttenuation(distance);                           
            float attenuation = 1.0f / (constant + linear * distance + quadratic * (distance * distance)); 

        //������۹��spotDir�н�����ֵ
             float theta = dot(lightDir, normalize(-spotLight.direction));          
             float inCutOff = cos(spotLight.cutOff);        
             float outCutOff = cos(spotLight.outerCutOff);   

             float epsilon = inCutOff - outCutOff;                          
            float intensity = clamp((theta - outCutOff) / epsilon, 0.0, 1.0);   

        // ����۹�ϵ��
        // "    float theta = dot(lightDir, normalize(-spotLight.direction));                   
        //"    float epsilon = spotLight.cutOff - spotLight.outerCutOff;                           
        // "    float intensity = clamp((theta - spotLight.outerCutOff) / epsilon, 0.0, 1.0);   

        //��ÿ�����շ�������˥��ϵ���;۹�ϵ��
       // "    ambient *= attenuation * intensity;                                                   
            diffuse *= attenuation * intensity;                                                   
            specular *= attenuation * intensity;                                                  
            if(theta < inCutOff)                  
            {                                         
                   vec3 result = ambient*attenuation * intensity + diffuse + specular;                                       
                    FragColor = vec4(result, 1.0);                                                                    
            }                                                
            else                                             
            {                                                 
                   FragColor = vec4(ambient, 1.0);            
            }                                                
         }
      )";
        
};


/*   glGenVertexArrays(1, &sphereVAO);
       glBindVertexArray(sphereVAO);
       glGenBuffers(1, &vbo);
       glBindBuffer(GL_ARRAY_BUFFER, vbo);
       glBufferData(GL_ARRAY_BUFFER, m_sphereData.size() * sizeof(float), &m_sphereData[0], GL_STATIC_DRAW);

       glGenBuffers(1, &ebo);//���ɶ�������
       glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);

       glBufferData(GL_ELEMENT_ARRAY_BUFFER, m_sphere_indices.size() * sizeof(unsigned int), &m_sphere_indices[0], GL_STATIC_DRAW);

       float stride = (3 + 2 + 3) * sizeof(float);
       glEnableVertexAttribArray(0);
       glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
       glEnableVertexAttribArray(1);
       glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
       glEnableVertexAttribArray(2);
       glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(5 * sizeof(float)));
       glBindVertexArray(0);//ע��������Ƚ��VAO
       glBindBuffer(GL_ARRAY_BUFFER, 0);
       glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
       */
