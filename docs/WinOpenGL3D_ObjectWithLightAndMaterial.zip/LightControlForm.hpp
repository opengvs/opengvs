#pragma once

#include "framework.h"
#include "WinForm.hpp"
#include "GLLight.hpp"

extern ParallelLight                g_ParallelLight;
extern DotLight                     g_DotLight;
extern SpotLight                    g_SpotLight;
class  LightControlForm :public Win::TabPage
{
public:
    Win::EditBox m_POSITION_X_EDIT;
    Win::EditBox m_POSITION_Y_EDIT;
    Win::EditBox m_POSITION_Z_EDIT;
    Win::UpDownBox m_POSITION_X_SPIN;
    Win::UpDownBox m_POSITION_Y_SPIN;
    Win::UpDownBox m_POSITION_Z_SPIN;

    Win::EditBox m_DIRECTION_X_EDIT;
    Win::EditBox m_DIRECTION_Y_EDIT;
    Win::EditBox m_DIRECTION_Z_EDIT;
    Win::UpDownBox m_DIRECTION_X_SPIN;
    Win::UpDownBox m_DIRECTION_Y_SPIN;
    Win::UpDownBox m_DIRECTION_Z_SPIN;

    Win::EditBox m_AMBIENT_R_EDIT;
    Win::EditBox m_AMBIENT_G_EDIT;
    Win::EditBox m_AMBIENT_B_EDIT;
    Win::UpDownBox m_AMBIENT_R_SPIN;
    Win::UpDownBox m_AMBIENT_G_SPIN;
    Win::UpDownBox m_AMBIENT_B_SPIN;

    Win::EditBox m_DIFFUSE_R_EDIT;
    Win::EditBox m_DIFFUSE_G_EDIT;
    Win::EditBox m_DIFFUSE_B_EDIT;
    Win::UpDownBox m_DIFFUSE_R_SPIN;
    Win::UpDownBox m_DIFFUSE_G_SPIN;
    Win::UpDownBox m_DIFFUSE_B_SPIN;

    Win::EditBox m_SPECULAR_R_EDIT;
    Win::EditBox m_SPECULAR_G_EDIT;
    Win::EditBox m_SPECULAR_B_EDIT;
    Win::UpDownBox m_SPECULAR_R_SPIN;
    Win::UpDownBox m_SPECULAR_G_SPIN;
    Win::UpDownBox m_SPECULAR_B_SPIN;

    Win::EditBox m_CUTOFF_EDIT;
    Win::EditBox m_OUTCUTOFF_EDIT;
    Win::UpDownBox m_CUTOFF_SPIN;
    Win::UpDownBox m_OUTCUTOFF_SPIN;

    Win::CheckBox m_USE_BLINN_CHECK;
    Win::RadioButton m_PARALLEL_LIGHT_RADIO;
    Win::RadioButton m_DOT_LIGHT_RADIO;
    Win::RadioButton m_SPOT_LIGHT_RADIO;

    void SetViewFromLight(LightBase* _pLight)
    {   
        glm::vec3 _Ambient = _pLight->GetAmbient();

        std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", _Ambient.r);
        m_AMBIENT_R_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", _Ambient.g);
        m_AMBIENT_G_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", _Ambient.b);
        m_AMBIENT_B_EDIT.setText(tempStr.c_str());

        glm::vec3 _Diffuse = _pLight->GetDiffuse();

        tempStr = StringFormat::wstr_format(L"%.2lf", _Diffuse.r);
        m_DIFFUSE_R_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", _Diffuse.g);
        m_DIFFUSE_G_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", _Diffuse.b);
        m_DIFFUSE_B_EDIT.setText(tempStr.c_str());

        glm::vec3 _Specular = _pLight->GetSpecular();

        tempStr = StringFormat::wstr_format(L"%.2lf", _Specular.r);
        m_SPECULAR_R_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", _Specular.g);
        m_SPECULAR_G_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", _Specular.b);
        m_SPECULAR_B_EDIT.setText(tempStr.c_str());


        if (_pLight->m_LightType == LightType::ParallelLightType)
        {
            ParallelLight* pLight = reinterpret_cast<ParallelLight*>(_pLight);

            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_Direction.x);
            m_DIRECTION_X_EDIT.setText(tempStr.c_str());
            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_Direction.y);
            m_DIRECTION_Y_EDIT.setText(tempStr.c_str());
            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_Direction.z);
            m_DIRECTION_Z_EDIT.setText(tempStr.c_str());

            m_DIRECTION_X_EDIT.show();
            m_DIRECTION_Y_EDIT.show();
            m_DIRECTION_Z_EDIT.show();
            m_DIRECTION_X_SPIN.show();
            m_DIRECTION_Y_SPIN.show();
            m_DIRECTION_Z_SPIN.show();

            m_POSITION_X_EDIT.hide();
            m_POSITION_Y_EDIT.hide();
            m_POSITION_Z_EDIT.hide();

            m_POSITION_X_SPIN.hide();
            m_POSITION_Y_SPIN.hide();
            m_POSITION_Z_SPIN.hide();

            m_CUTOFF_EDIT.hide();
            m_OUTCUTOFF_EDIT.hide();
            m_CUTOFF_SPIN.hide();
            m_OUTCUTOFF_SPIN.hide();
        }
        else if (_pLight->m_LightType == LightType::DotLightType)
        {
            DotLight* pLight = reinterpret_cast<DotLight*>(_pLight);
            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_Position.x);
            m_POSITION_X_EDIT.setText(tempStr.c_str());
            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_Position.y);
            m_POSITION_Y_EDIT.setText(tempStr.c_str());
            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_Position.z);
            m_POSITION_Z_EDIT.setText(tempStr.c_str());

            
            m_DIRECTION_X_EDIT.hide();
            m_DIRECTION_Y_EDIT.hide();
            m_DIRECTION_Z_EDIT.hide();
            m_DIRECTION_X_SPIN.hide();
            m_DIRECTION_Y_SPIN.hide();
            m_DIRECTION_Z_SPIN.hide();

            m_POSITION_X_EDIT.show();
            m_POSITION_Y_EDIT.show();
            m_POSITION_Z_EDIT.show();
            m_POSITION_X_SPIN.show();
            m_POSITION_Y_SPIN.show();
            m_POSITION_Z_SPIN.show();

            m_CUTOFF_EDIT.hide();
            m_OUTCUTOFF_EDIT.hide();
            m_CUTOFF_SPIN.hide();
            m_OUTCUTOFF_SPIN.hide();
        }
        else if (_pLight->m_LightType == LightType::SpotLightType)
        {
            SpotLight* pLight = reinterpret_cast<SpotLight*>(_pLight);
            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_Position.x);
            m_POSITION_X_EDIT.setText(tempStr.c_str());
            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_Position.y);
            m_POSITION_Y_EDIT.setText(tempStr.c_str());
            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_Position.z);
            m_POSITION_Z_EDIT.setText(tempStr.c_str());

            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_Direction.x);
            m_DIRECTION_X_EDIT.setText(tempStr.c_str());
            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_Direction.y);
            m_DIRECTION_Y_EDIT.setText(tempStr.c_str());
            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_Direction.z);
            m_DIRECTION_Z_EDIT.setText(tempStr.c_str());

            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_CutOff);
            m_CUTOFF_EDIT.setText(tempStr.c_str());

            tempStr = StringFormat::wstr_format(L"%.2lf", pLight->m_OuterCutOff);
            m_OUTCUTOFF_EDIT.setText(tempStr.c_str());

            m_DIRECTION_X_EDIT.show();
            m_DIRECTION_Y_EDIT.show();
            m_DIRECTION_Z_EDIT.show();
            m_DIRECTION_X_SPIN.show();
            m_DIRECTION_Y_SPIN.show();
            m_DIRECTION_Z_SPIN.show();

            m_POSITION_X_EDIT.show();
            m_POSITION_Y_EDIT.show();
            m_POSITION_Z_EDIT.show();
            m_POSITION_X_SPIN.show();
            m_POSITION_Y_SPIN.show();
            m_POSITION_Z_SPIN.show();
            m_CUTOFF_EDIT.show();
            m_OUTCUTOFF_EDIT.show();
            m_CUTOFF_SPIN.show();
            m_OUTCUTOFF_SPIN.show();

        }
    }
    void GetLight(LightBase* _pLight)
    {
       wchar_t  tempWchar[64];

        m_AMBIENT_R_EDIT.getText(tempWchar, 64);
        // std::wstring tempwstr = tempWchar;
        float tF_r = std::stof(tempWchar);
        //_pLight->m_Ambient.r = tF;

        m_AMBIENT_G_EDIT.getText(tempWchar, 64);
        float tF_g = std::stof(tempWchar);
       // _pLight.m_Ambient.g = tF;

        m_AMBIENT_B_EDIT.getText(tempWchar, 64);
        float tF_b = std::stof(tempWchar);
       // _pLight.m_Ambient.b = tF;
        _pLight->SetAmbient(glm::vec3(tF_r, tF_g, tF_b));

        m_DIFFUSE_R_EDIT.getText(tempWchar, 64);
        // std::wstring tempwstr = tempWchar;
        tF_r = std::stof(tempWchar);
        //_pLight.m_Diffuse.r = tF;

        m_DIFFUSE_G_EDIT.getText(tempWchar, 64);
        tF_g = std::stof(tempWchar);
        //_pLight.m_Diffuse.g = tF;

        m_DIFFUSE_B_EDIT.getText(tempWchar, 64);
        tF_b = std::stof(tempWchar);
        //_pLight.m_Diffuse.b = tF;
        _pLight->SetDiffuse(glm::vec3(tF_r, tF_g, tF_b));

        m_SPECULAR_R_EDIT.getText(tempWchar, 64);
        // std::wstring tempwstr = tempWchar;
        tF_r = std::stof(tempWchar);
        //_pLight.m_Specular.r = tF;

        m_SPECULAR_G_EDIT.getText(tempWchar, 64);
        tF_g = std::stof(tempWchar);
        //_pLight.m_Specular.g = tF;

        m_SPECULAR_B_EDIT.getText(tempWchar, 64);
        tF_b = std::stof(tempWchar);
        //_pLight.m_Specular.b = tF;
        _pLight->SetSpecular(glm::vec3(tF_r, tF_g, tF_b));


        if (_pLight->m_LightType == LightType::ParallelLightType)
        {
            ParallelLight* p = reinterpret_cast<ParallelLight*>(_pLight);
           
            m_DIRECTION_X_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            p->m_Direction.x = tF;
            m_DIRECTION_Y_EDIT.getText(tempWchar, 64);
            tF = std::stof(tempWchar);
            p->m_Direction.y = tF;
            m_DIRECTION_Z_EDIT.getText(tempWchar, 64);
            tF = std::stof(tempWchar);
            p->m_Direction.z = tF;
        }
        else if (_pLight->m_LightType == LightType::DotLightType)
        {
            DotLight* p = reinterpret_cast<DotLight*>(_pLight);
           

            m_POSITION_X_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            p->m_Position.x = tF;
            m_POSITION_Y_EDIT.getText(tempWchar, 64);
            tF = std::stof(tempWchar);
            p->m_Position.y = tF;
            m_POSITION_Z_EDIT.getText(tempWchar, 64);
            tF = std::stof(tempWchar);
            p->m_Position.z = tF;
        }
        else if (_pLight->m_LightType == LightType::SpotLightType)
        {
            SpotLight* p = reinterpret_cast<SpotLight*>(_pLight);
          
            m_DIRECTION_X_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            p->m_Direction.x = tF;
            m_DIRECTION_Y_EDIT.getText(tempWchar, 64);
            tF = std::stof(tempWchar);
            p->m_Direction.y = tF;
            m_DIRECTION_Z_EDIT.getText(tempWchar, 64);
            tF = std::stof(tempWchar);
            p->m_Direction.z = tF;

            m_POSITION_X_EDIT.getText(tempWchar, 64);
            tF = std::stof(tempWchar);
            p->m_Position.x = tF;
            m_POSITION_Y_EDIT.getText(tempWchar, 64);
            tF = std::stof(tempWchar);
            p->m_Position.y = tF;
            m_POSITION_Z_EDIT.getText(tempWchar, 64);
            tF = std::stof(tempWchar);
            p->m_Position.z = tF;

            m_CUTOFF_EDIT.getText(tempWchar, 64);
            tF = std::stof(tempWchar);
            p->m_CutOff = tF;
            m_OUTCUTOFF_EDIT.getText(tempWchar, 64);
            tF = std::stof(tempWchar);
            p->m_OuterCutOff = tF;
        }
        
    }
    virtual void Init_Event(HWND hDlg, WPARAM wParam, LPARAM lParam)
    {
        m_POSITION_X_EDIT.set(hDlg, IDC_LIGHTPOS_X_EDIT);
        m_POSITION_Y_EDIT.set(hDlg, IDC_LIGHTPOS_Y_EDIT);
        m_POSITION_Z_EDIT.set(hDlg, IDC_LIGHTPOS_Z_EDIT);
        m_POSITION_X_SPIN.set(hDlg, IDC_LIGHTPOS_X_SPIN);
        m_POSITION_Y_SPIN.set(hDlg, IDC_LIGHTPOS_Y_SPIN);
        m_POSITION_Z_SPIN.set(hDlg, IDC_LIGHTPOS_Z_SPIN);

        m_DIRECTION_X_EDIT.set(hDlg, IDC_LIGHTDIRECTION_X_EDIT);
        m_DIRECTION_Y_EDIT.set(hDlg, IDC_LIGHTDIRECTION_Y_EDIT);
        m_DIRECTION_Z_EDIT.set(hDlg, IDC_LIGHTDIRECTION_Z_EDIT);
        m_DIRECTION_X_SPIN.set(hDlg, IDC_LIGHTDIRECTION_X_SPIN);
        m_DIRECTION_Y_SPIN.set(hDlg, IDC_LIGHTDIRECTION_Y_SPIN);
        m_DIRECTION_Z_SPIN.set(hDlg, IDC_LIGHTDIRECTION_Z_SPIN);

        m_AMBIENT_R_EDIT.set(hDlg, IDC_AMBIENT_R_EDIT);
        m_AMBIENT_G_EDIT.set(hDlg, IDC_AMBIENT_G_EDIT);
        m_AMBIENT_B_EDIT.set(hDlg, IDC_AMBIENT_B_EDIT);
        m_AMBIENT_R_SPIN.set(hDlg, IDC_MBIENT_R_SPIN);
        m_AMBIENT_G_SPIN.set(hDlg, IDC_AMBIENT_G_SPIN);
        m_AMBIENT_B_SPIN.set(hDlg, IDC_AMBIENT_B_SPIN);

        m_DIFFUSE_R_EDIT.set(hDlg, IDC_DIFFUSE_R_EDIT);
        m_DIFFUSE_G_EDIT.set(hDlg, IDC_DIFFUSE_G_EDIT);
        m_DIFFUSE_B_EDIT.set(hDlg, IDC_DIFFUSE_B_EDIT);
        m_DIFFUSE_R_SPIN.set(hDlg, IDC_DIFFUSE_R_SPIN);
        m_DIFFUSE_G_SPIN.set(hDlg, IDC_DIFFUSE_G_SPIN);
        m_DIFFUSE_B_SPIN.set(hDlg, IDC_DIFFUSE_B_SPIN);

        m_SPECULAR_R_EDIT.set(hDlg, IDC_SPECULAR_R_EDIT);
        m_SPECULAR_G_EDIT.set(hDlg, IDC_SPECULAR_G_EDIT);
        m_SPECULAR_B_EDIT.set(hDlg, IDC_SPECULAR_B_EDIT);
        m_SPECULAR_R_SPIN.set(hDlg, IDC_SPECULAR_R_SPIN);
        m_SPECULAR_G_SPIN.set(hDlg, IDC_SPECULAR_G_SPIN);
        m_SPECULAR_B_SPIN.set(hDlg, IDC_SPECULAR_B_SPIN);

        m_CUTOFF_EDIT.set(hDlg, IDC_CUTOFF_EDIT);
        m_OUTCUTOFF_EDIT.set(hDlg, IDC_OUTCUTOFF_EDIT);
        m_CUTOFF_SPIN.set(hDlg, IDC_CUTOFF_SPIN);
        m_OUTCUTOFF_SPIN.set(hDlg, IDC_OUTCUTOFF_SPIN);

        m_USE_BLINN_CHECK.set(hDlg, IDC_USE_BLINN_CHECK);
        m_USE_BLINN_CHECK.check();

        m_PARALLEL_LIGHT_RADIO.set(hDlg, IDC_PARALLEL_LIGHT_RADIO);
        m_DOT_LIGHT_RADIO.set(hDlg, IDC_DOT_LIGHT_RADIO);
        m_SPOT_LIGHT_RADIO.set(hDlg, IDC_SPOT_LIGHT_RADIO);

        m_DOT_LIGHT_RADIO.check();

       // SetLight(&g_DotLight);
    }
    virtual VOID TabPage_OnCommand(HWND hwnd, INT id, HWND hwndCtl, UINT codeNotify)
    {
        
        if (id == IDC_PARALLEL_LIGHT_RADIO)
        {
            if (m_PARALLEL_LIGHT_RADIO.isChecked() == true)
            {
                SetViewFromLight(&g_ParallelLight);
            }

        }
        else if (id == IDC_DOT_LIGHT_RADIO)
        {
            if (m_DOT_LIGHT_RADIO.isChecked() == true)
            {
                SetViewFromLight(&g_DotLight);
            }
        }
        else if (id == IDC_SPOT_LIGHT_RADIO)
        {
            if (m_SPOT_LIGHT_RADIO.isChecked() == true)
            {
                SetViewFromLight(&g_SpotLight);
            }
        }
    }
    virtual VOID TabPage_OnNotify(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
    {
       
        NMHDR* p = (NMHDR*)(void*)lParam;

        wchar_t  tempWchar[64];
        LONG iID = wParam;
        if (iID == IDC_LIGHTDIRECTION_X_SPIN)
        {
            m_DIRECTION_X_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
                if (tF > 1.0)
                    tF = 1.0;
            }
            else
            {
                tF -= 0.1;
                if (tF <-1)
                    tF = -1;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_DIRECTION_X_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_LIGHTDIRECTION_Y_SPIN)
        {
            m_DIRECTION_Y_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
                if (tF > 1.0)
                    tF = 1.0;
            }
            else
            {
                tF -= 0.1;
                if (tF < -1)
                    tF = -1;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_DIRECTION_Y_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_LIGHTDIRECTION_Z_SPIN)
        {
            m_DIRECTION_Z_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
                if (tF > 1.0)
                    tF = 1.0;
            }
            else
            {
                tF -= 0.1;
                if (tF < -1)
                    tF = -1;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_DIRECTION_Z_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_LIGHTPOS_X_SPIN)
        {
            m_POSITION_X_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
              //  if (tF > 1.0)
               //     tF = 1.0;
            }
            else
            {
                tF -= 0.1;
               // if (tF < 0)
               //     tF = 0;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_POSITION_X_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_LIGHTPOS_Y_SPIN)
        {
            m_POSITION_Y_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
               // if (tF > 1.0)
                //    tF = 1.0;
            }
            else
            {
                tF -= 0.1;
                //if (tF < 0)
                //    tF = 0;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_POSITION_Y_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_LIGHTPOS_Z_SPIN)
        {
            m_POSITION_Z_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
               // if (tF > 1.0)
               //     tF = 1.0;
            }
            else
            {
                tF -= 0.1;
               // if (tF < 0)
               //     tF = 0;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_POSITION_Z_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_MBIENT_R_SPIN)
        {
            m_AMBIENT_R_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
                if (tF > 1.0)
                    tF = 1.0;
            }
            else
            {
                tF -= 0.1;
                if (tF < 0)
                    tF = 0;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_AMBIENT_R_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_AMBIENT_G_SPIN)
        {
            m_AMBIENT_G_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
                if (tF > 1)
                    tF = 1;
            }
            else
            {
                tF -= 0.1;
                if (tF < 0)
                    tF = 0;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_AMBIENT_G_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_AMBIENT_B_SPIN)
        {
            m_AMBIENT_B_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF  += 0.1;
                if (tF > 1)
                    tF = 1;
            }
            else
            {
                tF -= 0.1;
                if (tF < 0)
                    tF = 0;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_AMBIENT_B_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_DIFFUSE_R_SPIN)
        {
            m_DIFFUSE_R_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
                if (tF > 1)
                    tF = 1;
            }
            else
            {
                tF -= 0.1;
                if (tF < 0)
                    tF = 0;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_DIFFUSE_R_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_DIFFUSE_G_SPIN)
        {
            m_DIFFUSE_G_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
                if (tF > 1)
                    tF = 1;
            }
            else
            {
                tF -= 0.1;
                if (tF < 0)
                    tF = 0;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_DIFFUSE_G_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_DIFFUSE_B_SPIN)
        {
            m_DIFFUSE_B_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
                if (tF > 1)
                    tF = 1;
            }
            else
            {
                tF -= 0.1;
                if (tF < 0)
                    tF = 0;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_DIFFUSE_B_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_SPECULAR_R_SPIN)
        {
            m_SPECULAR_R_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
                if (tF > 1)
                    tF = 1;
            }
            else
            {
                tF -= 0.1;
                if (tF < 0)
                    tF = 0;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_SPECULAR_R_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_SPECULAR_G_SPIN)
        {
            m_SPECULAR_G_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
                if (tF > 1)
                    tF = 1;
            }
            else
            {
                tF -= 0.1;
                if (tF < 0)
                    tF = 0;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_SPECULAR_G_EDIT.setText(tempStr.c_str());

        }
        else if (iID == IDC_SPECULAR_B_SPIN)
        {
            m_SPECULAR_B_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 0.1;
                if (tF > 1)
                    tF = 1;
            }
            else
            {
                tF -= 0.1;
                if (tF < 0)
                    tF = 0;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_SPECULAR_B_EDIT.setText(tempStr.c_str());

        }
        else if (iID == IDC_CUTOFF_SPIN)
        {
            m_CUTOFF_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 1;
                if (tF > 60)
                    tF = 60;
            }
            else
            {
                tF -= 0.1;
                if (tF < 5)
                    tF = 5;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_CUTOFF_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_OUTCUTOFF_SPIN)
        {
            m_OUTCUTOFF_EDIT.getText(tempWchar, 64);
            float tF = std::stof(tempWchar);
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta < 0)
            {
                tF += 1;
                if (tF > 90)
                    tF = 90;
            }
            else
            {
                tF -= 1;
                if (tF < 10)
                    tF = 10;
            }
            std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", tF);
            m_OUTCUTOFF_EDIT.setText(tempStr.c_str());
            }

            if (m_PARALLEL_LIGHT_RADIO.isChecked() == true)
            {
                GetLight( &g_ParallelLight );
            }
            else if (m_DOT_LIGHT_RADIO.isChecked() == true)
            {
                GetLight(&g_DotLight);
            }
            else if (m_SPOT_LIGHT_RADIO.isChecked() == true)
            {
                GetLight(&g_SpotLight);
            }
           

    }
};
