
/**************************************************************************
* Function:
*	Universal constants header file
*
* Revision History:
*
*	$State$ $Log$
***************************************************************************/
#ifndef G_CONSTANTS_H
#define G_CONSTANTS_H

#ifdef __cplusplus
extern "C" {
#endif              
	               
#define G_PI		 3.14159265358979323846264338327950288419716939937510582097494459230781640628620899
	//(G_PI * 2.0)   6.283185307179586476925286766559
#define G_PI2		 6.283185307179586476925286766559
	    //(G_PI*0.5)
#define G_PIDIV2	1.5707963267948966192313216916398
	              //(G_PI*0.25)
#define G_PIDIV4	0.78539816339744830961566084581988

/* Degrees <--> Radians */ //(G_PI/180.0)
#define  G_DEG_TO_RAD  0.017453292519943295769
	                   //(180.0/G_PI)
#define  G_RAD_TO_DEG  57.295779513082320876846364344191



// 	                     2����Ȼ����ln(2)
//	const double LN_2 = 0.69314718055994530942;
//	const double INVLN_2 = 1.0 / LN_2;

/* Degrees <--> Milliradians */
#define G_DEG_TO_MILLIRAD (G_DEG_TO_RAD * 1000.0)
#define G_MILLIRAD_TO_DEG (1.0/G_DEG_TO_MILLIRAD)

/* Statute miles <--> Feet */
#define G_SM_TO_FEET	5280.0
#define G_FEET_TO_SM	(1.0/G_SM_TO_FEET)

#define G_MILES_TO_FEET	G_SM_TO_FEET
#define G_FEET_TO_MILES	G_FEET_TO_SM

/* Nautical miles <--> Feet */
#define G_NM_TO_FEET	6076.11549
#define G_FEET_TO_NM	(1.0/G_NM_TO_FEET)

/* Statue miles <--> Nautical Miles */
#define G_NM_TO_SM 	(G_NM_TO_FEET/G_SM_TO_FEET)
#define G_SM_TO_NM 	(G_SM_TO_FEET/G_NM_TO_FEET)

/* Feet per second <--> Knots (nautical miles per hour) */
#define G_FPS_TO_KNOTS (3600.0*G_FEET_TO_NM)
#define G_KNOTS_TO_FPS (G_NM_TO_FEET/3600.0)

/* Feet per second <--> Mph (statute miles per hour) */
#define G_FPS_TO_MPH (3600.0*G_FEET_TO_SM)
#define G_MPH_TO_FPS (G_SM_TO_FEET/3600.0)

/* Inches <--> Feet */
#define G_FEET_TO_INCHES 12.0
#define G_INCHES_TO_FEET (1.0/G_FEET_TO_INCHES)

/* Meters <--> Inches */
#define G_METERS_TO_INCH 39.37
#define G_INCH_TO_METERS (1.0/G_METERS_TO_INCH)

/* Meters <--> Feet */
#define G_METERS_TO_FEET (G_METERS_TO_INCH*G_INCHES_TO_FEET)
#define G_FEET_TO_METERS (1.0/G_METERS_TO_FEET)

/* Kilometers <--> Statue Miles */
#define G_KM_TO_SM	0.62137
#define G_SM_TO_KM	(1.0/G_KM_TO_SM)

/* Kilograms <--> Pounds */
#define G_KG_TO_LB	2.2046
#define G_LB_TO_KG	(1.0/G_KG_TO_LB)

/* Grams <--> Ounces */
#define G_GRAMS_TO_OZ	  0.03527
#define G_OZ_TO_GRAMS	(1.0/G_GRAMS_TO_OZ)

/* Useful for calls to G_sys_set_units */
#define G_PICO 		0.000000000001
#define G_NANO 		0.000000001
#define G_MICRO		0.000001
#define G_MILLI		0.001
#define G_CENTI		0.01
#define G_DECI		0.1
#define G_DECA		10.
#define G_KILO		1000.
#define G_MEGA		1000000.
#define G_GIGA		1000000000.
#define G_TERA		1000000000000.

#ifdef __cplusplus
}
#endif

#endif /* G_CONSTANTS_H */
