﻿// WinMainApp.cpp : 定义应用程序的入口点。
//

#include "framework.h"
#include "WinMainApp.h"
#include "WinForm.hpp"
#include "GLContext.hpp"

#define MAX_LOADSTRING 100

// 全局变量:
HINSTANCE hInst;                                // 当前实例
WCHAR szTitle[MAX_LOADSTRING];                  // 标题栏文本
WCHAR szWindowClass[MAX_LOADSTRING];            // 主窗口类名
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

class  WindowsForm :public Win::WinForm, public GLContext
{
private:
    Win::Button  m_AboutButton;
    Win::Button  m_CloseButton;
public:
    WindowsForm() :Win::WinForm(), GLContext()
    {

    };
    virtual void Init_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        HWND hWnd = hDlg;// ::GetDlgItem(hDlg, IDC_OPENGLVIEW);
        m_AboutButton.set(hDlg, IDD_ABOUTBOX);
        m_CloseButton.set(hDlg, IDM_EXIT);
        HWND hOpenGLWnd =  ::GetDlgItem(hDlg, IDC_OPENGLVIEW);

        bool succ = CreateGLContent(hOpenGLWnd, TRUE);
        if (!succ)
        {
            ::MessageBox(hWnd, L"初始化OpenGL窗口发生错误", L"系统信息", MB_OK);
            return;
        }
      

      //  HWND hOpenGLWnd2 = ::GetDlgItem(hDlg, IDC_GLVIEW2);
      //  succ = CreateGLContent(hOpenGLWnd2, TRUE);
      //  if (!succ)
      //  {
      //      ::MessageBox(hWnd, L"初始化OpenGL窗口发生错误", L"系统信息", MB_OK);
      //      return;
      //  }

      
        return;
    };
    virtual void Resize_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        WindowResize();
    }
    virtual void Destroy_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
         shutdown();
    }
    virtual BOOL  OnIdle(LONG lCount)
    {
        GLContext::swapBuffer();

        return TRUE;
    }
    virtual void Command_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        int wmId = LOWORD(wParam);
        if (wmId == IDD_ABOUTBOX)
        {
            Win::WinForm::ShowModelDialog(IDD_ABOUTBOX, hDlg, About);// Win::WinForm::DialogWindowProc);
        }
        else if (wmId == IDM_EXIT)
        {
            ::SendMessageW(hDlg, WM_DESTROY, 0, 0);
        }
    }


    //virtual void  GLDrawProcess();
    // virtual void  GLWndResize();

};
WindowsForm  g_WinForm;

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 在此处放置代码。

    // 初始化全局字符串
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WINMAINAPP, szWindowClass, MAX_LOADSTRING);
   
    g_WinForm.CreateWindowFromReSource(hInstance, IDD_MAINDIALOG);
    return g_WinForm.Run(); 
}

// “关于”框的消息处理程序。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

