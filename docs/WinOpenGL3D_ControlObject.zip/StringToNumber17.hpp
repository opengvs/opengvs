//StringToNumber17.hpp
#ifndef STRING_TO_NUMBER_HPP
#define STRING_TO_NUMBER_HPP

#include <type_traits>
#include <string>

#include <stdexcept>


template<class T>
using primitive_type = std::decay_t<T>;

template<class StringT>
using if_std_string = std::enable_if_t<std::is_same_v<StringT, std::string>, StringT>;

template<class StringT>
using if_std_wstring = std::enable_if_t<std::is_same_v<StringT, std::wstring>, StringT>;

template<class StringT>
using if_std_string_or_wstring = std::enable_if_t<std::disjunction_v<
    std::is_same<StringT, std::string>, std::is_same<StringT, std::wstring>>, StringT>;

template<class T>
using if_signed = std::enable_if_t<std::is_signed_v<T>, T>;

template<class T>
using if_unsigned = std::enable_if_t<std::is_unsigned_v<T>, T>;

template<class NumberT>
using if_interger = std::enable_if_t<std::is_integral_v<NumberT>, NumberT>;

template<class NumberT>
using if_floating_point = std::enable_if_t<std::is_floating_point_v<NumberT>, NumberT>;

template<class NumberT>
using if_signed_interger = std::enable_if_t< std::conjunction_v<
    std::is_integral<NumberT>, std::is_signed<NumberT>>>;

template<class NumberT>
using if_unsigned_interger = std::enable_if_t< std::conjunction_v<
    std::is_integral<NumberT>, std::is_unsigned<NumberT>>>;

template<class StringT, class NumberT, bool Except = true,
    class = if_std_string_or_wstring<StringT>,
    class = if_interger<primitive_type<NumberT>>>
primitive_type<NumberT> stringToNumber(const StringT& str, std::size_t* pos = 0, int base = 0) noexcept(!Except)
{
    try {
        if constexpr (std::is_signed_v<primitive_type<NumberT>>) {
            if constexpr (sizeof(NumberT) <= sizeof(long)) {
                return static_cast<primitive_type<NumberT>>(std::stoi(str, pos, base));
            }
            else if constexpr (sizeof(NumberT) == sizeof(long)) {
                return static_cast<primitive_type<NumberT>>(std::stol(str, pos, base));
            }
            else {
                return static_cast<primitive_type<NumberT>>(std::stoll(str, pos, base));
            }
        }
        else {
            if constexpr (sizeof(NumberT) <= sizeof(unsigned long)) {
                return static_cast<primitive_type<NumberT>>(std::stoul(str));
            }
            else {
                return static_cast<primitive_type<NumberT>>(std::stoull(str));
            }
        }
    }
    catch (...) {
        //if constexpr (Exception) {
        //    throw;
        //}
        //else {
            return primitive_type<NumberT>(0);
       // }
    }
}

template<class StringT, class NumberT, bool Except = true,
    class = if_std_string_or_wstring<StringT>,
    class = if_floating_point<primitive_type<NumberT>>>
primitive_type<NumberT> stringToNumber(const StringT& str, std::size_t* pos = 0) noexcept(!Except)
{
    try {
        if constexpr (std::is_same_v<primitive_type<NumberT>, float>) {
            return std::stof(str, pos);
        }
        else if constexpr (std::is_same_v<primitive_type<NumberT>, double>) {
            return std::stod(str, pos);
        }
        else {
            return std::stold(str, pos);
        }
    }
    catch (...) {
       // if constexpr (Exception) {
       //     throw;
       // }
       // else {
            return primitive_type<NumberT>(0.);
       // }
    }
}

#endif // STRING_TO_NUMBER_HPP
