#ifndef __SHADERTYPE_H__
#define __SHADERTYPE_H__
enum  ShaderType
{
	//
	// ժҪ:
	//     [requires: v2.0] Original was GL_FRAGMENT_SHADER = 0x8B30
	FragmentShader = 35632,
	//
	// ժҪ:
	//     Original was GL_FRAGMENT_SHADER_ARB = 0x8B30
	FragmentShaderArb = 35632,
	//
	// ժҪ:
	//     [requires: v2.0] Original was GL_VERTEX_SHADER = 0x8B31
	VertexShader = 35633,
	//
	// ժҪ:
	//     Original was GL_VERTEX_SHADER_ARB = 0x8B31
	VertexShaderArb = 35633,
	//
	// ժҪ:
	//     [requires: v3.2] Original was GL_GEOMETRY_SHADER = 0x8DD9
	GeometryShader = 36313,
	//
	// ժҪ:
	//     [requires: v4.0 or ARB_tessellation_shader] Original was GL_TESS_EVALUATION_SHADER
	//     = 0x8E87
	TessEvaluationShader = 36487,
	//
	// ժҪ:
	//     [requires: v4.0 or ARB_tessellation_shader] Original was GL_TESS_CONTROL_SHADER
	//     = 0x8E88
	TessControlShader = 36488,
	//
	// ժҪ:
	//     [requires: v4.3 or ARB_compute_shader] Original was GL_COMPUTE_SHADER = 0x91B9
	ComputeShader = 37305
};

#endif
