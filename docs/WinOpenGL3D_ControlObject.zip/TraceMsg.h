///////////////////////////////////////////////////////////////////////////////
//  TraceMsg.h  ������windows�����±��ʱ���������Ϣ
//  ----���ļ���ͬ����־�࣬������Ϣֻ���������ն�
//  ��Ȩ����        ������    2023.11 �ȷ�      
///////////////////////////////////////////////////////////////////////////////
#ifndef __TRACEMSG__
#define __TRACEMSG__
#include <windows.h>
#include <string>
#include <strsafe.h>
#include <codecvt>

inline void TraceMsgW(const wchar_t* lpFormat, ...) {
    if (!lpFormat)
        return;

    wchar_t* pMsgBuffer = NULL;
    unsigned int iMsgBufCount = 0;

    va_list arglist;
    va_start(arglist, lpFormat);
    HRESULT hr = STRSAFE_E_INSUFFICIENT_BUFFER;
    while (hr == STRSAFE_E_INSUFFICIENT_BUFFER) {
        iMsgBufCount += 1024;
        if (pMsgBuffer) {
            free(pMsgBuffer);
            pMsgBuffer = NULL;
        }
        pMsgBuffer = (wchar_t*)malloc(iMsgBufCount * sizeof(wchar_t));
        if (!pMsgBuffer) {
            break;
        }

        hr = StringCchVPrintfW(pMsgBuffer, iMsgBufCount, lpFormat, arglist);
    }
    va_end(arglist);
    if (hr == S_OK) {
        OutputDebugStringW(pMsgBuffer);
    }

    if (pMsgBuffer) {
        free(pMsgBuffer);
        pMsgBuffer = NULL;
    }
}
inline void TraceMsgA(const char* lpFormat, ...) {
    if (!lpFormat)
        return;

    char* pMsgBuffer = NULL;
    unsigned int iMsgBufCount = 0;

    va_list arglist;
    va_start(arglist, lpFormat);
    HRESULT hr = STRSAFE_E_INSUFFICIENT_BUFFER;
    while (hr == STRSAFE_E_INSUFFICIENT_BUFFER) {
        iMsgBufCount += 1024;
        if (pMsgBuffer) {
            free(pMsgBuffer);
            pMsgBuffer = NULL;
        }
        pMsgBuffer = (char*)malloc(iMsgBufCount * sizeof(char));
        if (!pMsgBuffer) {
            break;
        }

        hr = StringCchVPrintfA(pMsgBuffer, iMsgBufCount, lpFormat, arglist);
    }
    va_end(arglist);
    if (hr == S_OK) {
        OutputDebugStringA(pMsgBuffer);
    }

    if (pMsgBuffer) {
        free(pMsgBuffer);
        pMsgBuffer = NULL;
    }
}

#if (defined UNICODE) || (defined _UNICODE)
#define TraceMsg TraceMsgW
#else
#define TraceMsg TraceMsgA
#endif

// wstring=>string
inline std::string WString2String(const std::wstring& ws)
{

    std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
    return converter.to_bytes(ws);
}

// string => wstring
inline std::wstring String2WString(const std::string& s)
{
    std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
    return converter.from_bytes(s);
}

#endif // !__TRACE__
