///////////////////////////////////////////////////////////////////////////////
//  Shader.hpp  ���ڴ�������C++���򿪷�OpenGL������ʹ�õ�GLSL��Shader�����࣬
//  ���ļ��Ķ���ͷ�ļ���
//  ��Ȩ����        ������    2023.11 �ȷ� 
///////////////////////////////////////////////////////////////////////////////

#ifndef SHADER_HPP
#define SHADER_HPP

#include <windows.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include "TraceMsg.h"

#ifdef _MSC_VER
#pragma optimize( "g", off )
#endif

#include "glad.h"
#include <string>
#include "glm/glm.hpp"
#include "glm/gtc/type_ptr.hpp"
#include "ShaderType.h"


class Shader
{
public:
	// ��ɫ������ID
	unsigned int ID=0;

	Shader() { ID = 0; };

	~Shader() 
	{
		if (ID != 0)
		{
			glDeleteProgram(ID);
	   }
	};

	unsigned int getShaderID() { return ID; };
	GLenum  glCheckError_(const char* file, int line);

	void  InitializeShaderWithString(const char* computeCode);
	void  InitializeShaderWithString(const char* vShaderCode, const char* fShaderCode);
	void  InitializeShaderWithString(const char* vShaderCode, const char* fShaderCode,const char* geometryShaderCode);
	void  InitializeShaderFromFile(const char* computePath);
	void  InitializeShaderFromFile(const char* vertexPath, const char* fragmentPath);
	void  InitializeShaderFromFile(const char* vertexPath, const char* fragmentPath,const char* geometryPath);
	//ʹ����ɫ����
	void Use() {
		glUseProgram(ID);
	}
	void UnUse()
	{
		glUseProgram(0);
	}
	// �Ƚ�ʵ�õ�ͳһ����
	// ------------------------------------------------------------------------
	void setBool(const std::string& name, bool value) const
	{
		glUniform1i(glGetUniformLocation(ID, name.c_str()), (int)value);
	}
	// ------------------------------------------------------------------------
	void setInt(const std::string& name, int value) const
	{
		glUniform1i(glGetUniformLocation(ID, name.c_str()), value);
	}
	// ------------------------------------------------------------------------
	void setFloat(const std::string& name, float value) const
	{
		glUniform1f(glGetUniformLocation(ID, name.c_str()), value);
	}

	void SetVec2(const std::string& name, const glm::vec2& value) const
	{
		SetVec2(name, value.x, value.y);
	}
	void SetVec2(const std::string& name, float x, float y) const
	{
		glUniform2f(GetUniform(name), x, y);
	}
	void SetVec3(const std::string& name, const glm::vec3& value) const
	{
		SetVec3(name, value.x, value.y, value.z);
	}
	void SetVec3(const std::string& name, float x, float y, float z) const
	{
		glUniform3f(GetUniform(name), x, y, z);
	}
	void SetVec4(const std::string& name, const glm::vec4& value) const
	{
		SetVec4(name, value.x, value.y, value.z, value.w);
	}
	void SetVec4(const std::string& name, float x, float y, float z, float w) const
	{
		glUniform4f(GetUniform(name), x, y, z, w);
	}
	void SetMat2(const std::string& name, const glm::mat2& value) const
	{
		glUniformMatrix2fv(GetUniform(name), 1, GL_FALSE, &value[0][0]);
	}
	void SetMat3(const std::string& name, const glm::mat3& value) const
	{
		glUniformMatrix3fv(GetUniform(name), 1, GL_FALSE, &value[0][0]);
	}
	void SetMat4(const std::string& name, const glm::mat4& value) const
	{
		glUniformMatrix4fv(GetUniform(name), 1, GL_FALSE, &value[0][0]);
	}

private:
	int GetUniform(const std::string& name) const
	{
		int position = glGetUniformLocation(ID, name.c_str());
		if (position == -1)
		{
			TraceMsgA("uniform ", name, " set failed!");
			//std::cout << "uniform " << name << " set failed!" << std::endl;
		}
		return position;
	}

	int GetShaderFromFile(const GLchar* vertex_shader_path, const GLchar* fragment_shader_path, std::string* vertex_shader_code, std::string* fragment_shader_code);
	int LinkShader(const char* vertex_shader_code, const char* fragment_shader_code);
	// ���ڼ����ɫ������ / ���Ӵ����ʵ�ó�������
	// ------------------------------------------------------------------------
	void checkCompileErrors(unsigned int shader, std::string type);
	void CheckCompileErrors(GLuint shader, std::string type);
};

inline GLenum Shader::glCheckError_(const char* file, int line)
{
	GLenum errorCode;
	while ((errorCode = glGetError()) != GL_NO_ERROR)
	{
		std::string error;
		switch (errorCode)
		{
		case GL_INVALID_ENUM:                  error = "INVALID_ENUM"; break;
		case GL_INVALID_VALUE:                 error = "INVALID_VALUE"; break;
		case GL_INVALID_OPERATION:             error = "INVALID_OPERATION"; break;
		case GL_STACK_OVERFLOW:                error = "STACK_OVERFLOW"; break;
		case GL_STACK_UNDERFLOW:               error = "STACK_UNDERFLOW"; break;
		case GL_OUT_OF_MEMORY:                 error = "OUT_OF_MEMORY"; break;
		case GL_INVALID_FRAMEBUFFER_OPERATION: error = "INVALID_FRAMEBUFFER_OPERATION"; break;
		}
		//std::cout << error << " | " << file << " (" << line << ")" << std::endl;
		TraceMsgA("Error is ", error, file, " set failed!");
	}
	return errorCode;
}

#define glCheckError() glCheckError_(__FILE__, __LINE__)
/*
ֻ��һ�������ĺ��������ڵ�������������ɫ��
*/
inline void  Shader::InitializeShaderWithString(const char* computeCode)
{
	GLuint computeShader = glCreateShader(GL_COMPUTE_SHADER);
	glShaderSource(computeShader, 1, &computeCode, NULL);
	glCompileShader(computeShader);

	GLint success;
	glGetShaderiv(computeShader, GL_COMPILE_STATUS, &success);
	if (!success) {
		GLchar infoLog[512];
		glGetShaderInfoLog(computeShader, 512, NULL, infoLog);
		std::cout << "Compute shader compilation failed:" << infoLog<< std::endl;
		return;
	}

	ID = glCreateProgram();
	glAttachShader(ID, computeShader);
	glLinkProgram(ID);

	glGetProgramiv(ID, GL_LINK_STATUS, &success);
	if (!success) {
		GLchar infoLog[512];
		glGetProgramInfoLog(ID, 512, NULL, infoLog);
		TraceMsgA("Compute shader linking failed: ", infoLog);
		//std::cout << "Compute shader linking failed:" << infoLog << std::endl;
		return;
	}

	glDeleteShader(computeShader);
	return;
}

inline void  Shader::InitializeShaderWithString(const char* vShaderCode, const char* fShaderCode)
{
	// 2. ������ɫ��
	unsigned int vertex, fragment;
	// ����ɫ��
	vertex = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertex, 1, &vShaderCode, NULL);
	glCompileShader(vertex);
	checkCompileErrors(vertex, "VERTEX");
	// Ƭ����ɫ��
	fragment = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragment, 1, &fShaderCode, NULL);
	glCompileShader(fragment);
	checkCompileErrors(fragment, "FRAGMENT");
	// ��ɫ������
	ID = glCreateProgram();
	glAttachShader(ID, vertex);
	glAttachShader(ID, fragment);
	glLinkProgram(ID);
	checkCompileErrors(ID, "PROGRAM");
	// ɾ����ɫ������Ϊ�����Ѿ����ӵ����ǵĳ������ˣ��Ѿ�������Ҫ��
	glDeleteShader(vertex);
	glDeleteShader(fragment);

}

inline void   Shader::InitializeShaderWithString(const char* vShaderCode, const char* fShaderCode, const char* geometryShaderCode)
{
	//const char* vShaderCode = vertexCode.c_str();
	//const char* fShaderCode = fragmentCode.c_str();
	// 2. compile shaders
	unsigned int vertex, fragment;
	// vertex shader
	vertex = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertex, 1, &vShaderCode, NULL);
	glCompileShader(vertex);
	checkCompileErrors(vertex, "VERTEX");
	// fragment Shader
	fragment = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragment, 1, &fShaderCode, NULL);
	glCompileShader(fragment);
	checkCompileErrors(fragment, "FRAGMENT");
	// if geometry shader is given, compile geometry shader
	unsigned int geometry;
	if (geometryShaderCode != nullptr)
	{
		const char* gShaderCode = geometryShaderCode;//geometryCode.c_str();
		geometry = glCreateShader(GL_GEOMETRY_SHADER);
		glShaderSource(geometry, 1, &gShaderCode, NULL);
		glCompileShader(geometry);
		checkCompileErrors(geometry, "GEOMETRY");
	}
	// shader Program
	ID = glCreateProgram();
	glAttachShader(ID, vertex);
	glAttachShader(ID, fragment);
	if (geometryShaderCode != nullptr)
		glAttachShader(ID, geometry);
	glLinkProgram(ID);
	checkCompileErrors(ID, "PROGRAM");
	// delete the shaders as they're linked into our program now and no longer necessary
	glDeleteShader(vertex);
	glDeleteShader(fragment);
	if (geometryShaderCode != nullptr)
		glDeleteShader(geometry);
	
}

inline void  Shader::InitializeShaderFromFile(const char* computePath)
{
	std::string computeCode;
	std::ifstream computeShaderFile;
	computeShaderFile.exceptions(std::ifstream::failbit | std::ifstream::badbit);
	try
	{
		// ���ļ�
		computeShaderFile.open(computePath);

		std::stringstream computeShaderStream;
		// ���ļ����ж��뵽buffer��
		computeShaderStream << computeShaderFile.rdbuf();

		// �ر��ļ���
		computeShaderFile.close();
		// ����ת��string����
		computeCode = computeShaderStream.str();
		//�Լ��ӵģ����ڲ��ԣ���ӡ������̨
		//std::cout << computeCode << std::endl;

	}
	catch (std::ifstream::failure e)
	{
		//std::cout << "����Shader��ȡ�ļ�ʧ��" << std::endl;
		TraceMsgA("����Shader��ȡ�ļ�ʧ��");
	}
	InitializeShaderWithString(computeCode.c_str());
}

inline void  Shader::InitializeShaderFromFile(const char* vertexPath, const char* fragmentPath)
{
	// 1. ���ļ�·�����ļ�
	std::string vertexCode;
	std::string fragmentCode;
	std::ifstream vShaderFile;
	std::ifstream fShaderFile;
	// ȷ��ifstream���ܹ��׳��쳣
	vShaderFile.exceptions(std::ifstream::failbit | std::ifstream::badbit);
	fShaderFile.exceptions(std::ifstream::failbit | std::ifstream::badbit);
	try
	{
		// ���ļ�
		vShaderFile.open(vertexPath);
		fShaderFile.open(fragmentPath);
		std::stringstream vShaderStream, fShaderStream;
		// ���ļ����ж��뵽buffer��
		vShaderStream << vShaderFile.rdbuf();
		fShaderStream << fShaderFile.rdbuf();
		// �ر��ļ���
		vShaderFile.close();
		fShaderFile.close();
		// ����ת��string����
		vertexCode = vShaderStream.str();
		fragmentCode = fShaderStream.str();
		//�Լ��ӵģ����ڲ��ԣ���ӡ������̨
		//std::cout << vertexCode << std::endl;
		//std::cout << fragmentCode << std::endl;
	}
	catch (std::ifstream::failure e)
	{
		//std::cout << "����Shader��ȡ�ļ�ʧ��" << std::endl;
		TraceMsgA("����Shader��ȡ�ļ�ʧ��");
	}

	InitializeShaderWithString(vertexCode.c_str(), fragmentCode.c_str() );
}
inline void  Shader::InitializeShaderFromFile(const char* vertexPath, const char* fragmentPath, const char* geometryPath)
{
	std::string vertexCode;
	std::string fragmentCode;
	std::string geometryCode;
	std::ifstream vShaderFile;
	std::ifstream fShaderFile;
	std::ifstream geometryShaderFile;

	// ȷ��ifstream���ܹ��׳��쳣
	vShaderFile.exceptions(std::ifstream::failbit | std::ifstream::badbit);
	fShaderFile.exceptions(std::ifstream::failbit | std::ifstream::badbit);
	geometryShaderFile.exceptions(std::ifstream::failbit | std::ifstream::badbit);
	try
	{
		// ���ļ�
		vShaderFile.open(vertexPath);
		fShaderFile.open(fragmentPath);
		geometryShaderFile.open(geometryPath);

		std::stringstream vShaderStream, fShaderStream, geometryShaderStream;
		// ���ļ����ж��뵽buffer��
		vShaderStream << vShaderFile.rdbuf();
		fShaderStream << fShaderFile.rdbuf();
		geometryShaderStream << geometryShaderFile.rdbuf();
		// �ر��ļ���
		vShaderFile.close();
		fShaderFile.close();
		geometryShaderFile.close();
		// ����ת��string����
		vertexCode = vShaderStream.str();
		fragmentCode = fShaderStream.str();
		geometryCode = geometryShaderStream.str();

		
		//�Լ��ӵģ����ڲ��ԣ���ӡ������̨
		//std::cout << vertexCode << std::endl;
		//std::cout << fragmentCode << std::endl;
		//std::cout << geometryCode << std::endl;
	}
	catch (std::ifstream::failure e)
	{
		//std::cout << "����Shader��ȡ�ļ�ʧ��" << std::endl;
		TraceMsgA("����Shader��ȡ�ļ�ʧ��");
	}

	InitializeShaderWithString(vertexCode.c_str(), fragmentCode.c_str(), geometryCode.c_str());
}
// ------------------------------------------------------------------------
inline int Shader::GetShaderFromFile(const GLchar* vertex_shader_path, const GLchar* fragment_shader_path, std::string* vertex_shader_code, std::string* fragment_shader_code)
{
	std::ifstream vertex_shader_file;
	std::ifstream fragment_shader_file;
	vertex_shader_file.exceptions(std::ifstream::badbit | std::ifstream::failbit);
	fragment_shader_file.exceptions(std::ifstream::badbit | std::ifstream::failbit);
	try
	{
		vertex_shader_file.open(vertex_shader_path);
		fragment_shader_file.open(fragment_shader_path);
		std::stringstream vertex_shader_stream, fragment_shader_stream;
		vertex_shader_stream << vertex_shader_file.rdbuf();
		fragment_shader_stream << fragment_shader_file.rdbuf();
		vertex_shader_file.close();
		fragment_shader_file.close();
		*vertex_shader_code = vertex_shader_stream.str();
		*fragment_shader_code = fragment_shader_stream.str();
	}
	catch (std::ifstream::failure e)
	{
		//std::cout << "Load Shader File Error!" << std::endl;
		TraceMsgA("Load Shader File Error!");
		return -1;
	}
	return 0;
}

inline int Shader::LinkShader(const char* vertex_shader_code, const char* fragment_shader_code)
{
	int vertex_shader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertex_shader, 1, &vertex_shader_code, NULL);
	glCompileShader(vertex_shader);
	CheckCompileErrors(vertex_shader, "VERTEX");

	int fragment_shader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragment_shader, 1, &fragment_shader_code, NULL);
	glCompileShader(fragment_shader);
	CheckCompileErrors(fragment_shader, "FRAGMENT");

	this->ID = glCreateProgram();
	glAttachShader(ID, vertex_shader);
	glAttachShader(ID, fragment_shader);
	glLinkProgram(ID);
	CheckCompileErrors(ID, "PROGRAM");

	glDeleteShader(vertex_shader);
	glDeleteShader(fragment_shader);
	return 0;
}

// ���ڼ����ɫ������ / ���Ӵ����ʵ�ó�������
// ------------------------------------------------------------------------
inline void Shader::checkCompileErrors(unsigned int shader, std::string type)
{
	int success;
	char infoLog[1024]; //�洢��Ϣ��־
	if (type != "PROGRAM")
	{
		glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
		if (!success)
		{
			glGetShaderInfoLog(shader, 1024, NULL, infoLog);
			//std::cout << "����Shader�������: " << type << "\n" << infoLog << "\n -- --------------------------------------------------- -- " << std::endl;
			TraceMsgA("����Shader�������: ", type, "\n", infoLog,"\n");
		}
	}
	else
	{
		glGetProgramiv(shader, GL_LINK_STATUS, &success);
		if (!success)
		{
			glGetProgramInfoLog(shader, 1024, NULL, infoLog);
			//std::cout << "����Shader���Ӵ���: " << type << "\n" << infoLog << "\n -- --------------------------------------------------- -- " << std::endl;
			TraceMsgA("����Shader���Ӵ���:: ", type, "\n", infoLog, "\n");
		}
	}
}

inline void Shader::CheckCompileErrors(GLuint shader, std::string type)
{
	GLint success;
	GLchar infoLog[512];
	if (type == "PROGRAM")
	{
		glGetProgramiv(shader, GL_LINK_STATUS, &success);
		if (!success)
		{
			glGetProgramInfoLog(shader, 512, NULL, infoLog);
			//std::cout << "ERROR::PROGRAM_LINKING_ERROR!\n" << infoLog << std::endl;
			TraceMsgA("ERROR::PROGRAM_LINKING_ERROR!", infoLog, "\n");
		}
	}
	else
	{
		glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
		if (!success)
		{
			glGetShaderInfoLog(shader, 512, NULL, infoLog);
			//std::cout << "ERROR::SHADER::" << type << "::COMPILATION_FAILED\n" << infoLog << std::endl;
			TraceMsgA("ERROR::PROGRAM_COMPILE_ERROR!", infoLog, "\n");
		}
	}
}


#endif
