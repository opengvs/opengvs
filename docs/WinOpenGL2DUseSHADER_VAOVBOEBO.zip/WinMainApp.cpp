﻿// WinMainApp.cpp : 定义应用程序的入口点。
//

#include "framework.h"
#include "WinMainApp.h"
#include "WinForm.hpp"
#include "GLContext.hpp"
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"
#include <string>
#include "Shader.hpp"
#include "VAOWithVBOandEBO.hpp"

#define MAX_LOADSTRING 100

// 全局变量:
HINSTANCE hInst;                                // 当前实例
WCHAR szTitle[MAX_LOADSTRING];                  // 标题栏文本
WCHAR szWindowClass[MAX_LOADSTRING];            // 主窗口类名
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

GLfloat vertices[] = {
    // 顶点              //颜色
    0.0f,                          100.0f , 0.0f, 1.0f, 0.0f, 0.0f,
    -100.0 * 1.732050807568 * 0.5, -50.0f ,0.0f, 0.0f, 1.0f, 0.0f,
    100.0 * 1.732050807568 * 0.5,  -50.0f,0.0f, 0.0f, 1.0f
};
//准备顶点颜色与数据
GLfloat positions[] = {
    0.0f, 100.0f ,0.0f,
     -100.0 * 1.732050807568 * 0.5, -50.0f ,0.0f,
     100.0 * 1.732050807568 * 0.5,  -50.0f ,0.0f
};

GLfloat colors[] = {
    1.0f ,0.0f,0.0f,
    0.0f,0.0f,1.0f,
    0.0f,1.0f,0.0f
};

GLfloat rect_vertices[] = {
    // Positions         // Colors
    100.0f, 0.0f, 0.0f,   1.0f, 0.0f, 0.0f,  //右
    -100.0f, 0.0f, 0.0f,   0.0f, 1.0f, 0.0f,  //左
    0.0f,  100.0f, 0.0f,   0.0f, 0.0f, 1.0f,  //上
    0.0f, -100.0f, 0.0f,   0.0f, 0.0f, 1.0f   //下, 新加入顶点
};
GLuint rect_indices[] = {  //顶点索引
    0, 1, 2,  // First Triangle
    0, 1, 3   // Second Triangle
};

class  WindowsForm :public Win::WinForm, public GLContext
{
private:
    //注意: attribute属性修饰在更高版本的GLSL中被弃用，使用in替代
   std::string  m_vertexShader = R"(
        #version 460 core
        layout(location = 0) in  vec3 inPosition;
        layout(location = 1) in  vec3 inColor;
        uniform mat4 ModelMatrix;
        uniform mat4 ViewMatrix;
        uniform mat4 ProjectionMatrix;
        
        out VertexAtrbuteData {
              vec3 color;
        } vs_out;

        void main()
        {
            gl_Position = ProjectionMatrix * ViewMatrix * ModelMatrix *vec4(inPosition,1.0);
            vs_out.color = inColor;
        }
                                )";

 

std::string  m_fragmentShader = R"(
    #version 460 core
    in VertexAtrbuteData {
              vec3 color;
        } fs_in;
    out vec4 color;
    void main()
    {
        color = vec4(fs_in.color,1);
    }
  )";
    

    Shader          m_Shader;
    VAOWithVBOandEBO      m_OneBufferTrangle;
    VAOWithVBOandEBO      m_MultiBufferTrangle;
    VAOWithVBOandEBO      m_VAOWithVBO_EBO;
private:
    Win::Button  m_AboutButton;
    Win::Button  m_CloseButton;
    Win::EditBox m_Mat00;
    Win::EditBox m_Mat01;
    Win::EditBox m_Mat02;
    Win::EditBox m_Mat10;
    Win::EditBox m_Mat11;
    Win::EditBox m_Mat12;
    Win::EditBox m_Mat20;
    Win::EditBox m_Mat21;
    Win::EditBox m_Mat22;

    Win::EditBox m_RotationEdit;
    Win::Button  m_RatationButtion;
    Win::RadioButton m_AUTORATATION;
    Win::UpDownBox   m_MOVEX_SPIN;
    Win::UpDownBox   m_MOVEY_SPIN;

    Win::EditBox   m_SCALE_X_EDIT;
    Win::EditBox   m_SCALE_Y_EDIT;
    Win::Trackbar  m_SCALE_X_SLIDER;
    Win::Trackbar  m_SCALE_Y_SLIDER;

    Win::RadioButton m_RADIO1;
    Win::RadioButton m_RADIO2;
    Win::RadioButton m_RADIO3;
public:
    WindowsForm() :Win::WinForm(), GLContext()
    {

    };
    virtual void Init_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        HWND hWnd = hDlg;// ::GetDlgItem(hDlg, IDC_OPENGLVIEW);
        m_AboutButton.set(hDlg, IDD_ABOUTBOX);
        m_CloseButton.set(hDlg, IDM_EXIT);
        m_Mat00.set(hDlg, IDC_MAT00);
        m_Mat01.set(hDlg, IDC_MAT01);
        m_Mat02.set(hDlg, IDC_MAT02);
        m_Mat10.set(hDlg, IDC_MAT10);
        m_Mat11.set(hDlg, IDC_MAT11);
        m_Mat12.set(hDlg, IDC_MAT12);
        m_Mat20.set(hDlg, IDC_MAT20);
        m_Mat21.set(hDlg, IDC_MAT21);
        m_Mat22.set(hDlg, IDC_MAT22);

        m_RotationEdit.set(hDlg, IDC_ROTATIONEDIT);
        m_RotationEdit.setText(L"30");
        m_RatationButtion.set(hDlg, IDC_ROTATIONBUTTON);
        m_AUTORATATION.set(hDlg, IDC_AUTORATATION);
        m_MOVEX_SPIN.set(hDlg, IDC_MOVEX_SPIN);
        m_MOVEX_SPIN.setRange(-100, 100);
        m_MOVEX_SPIN.setPos(0);
        m_MOVEY_SPIN.set(hDlg, IDC_MOVEY_SPIN);
        m_MOVEY_SPIN.setRange(-100, 100);
        m_MOVEY_SPIN.setPos(0);
        m_SCALE_X_EDIT.set(hDlg, IDC_SCALE_X_EDIT);
        m_SCALE_X_EDIT.setText(L"1");
        m_SCALE_Y_EDIT.set(hDlg, IDC_SCALE_Y_EDIT);
        m_SCALE_Y_EDIT.setText(L"1");
        m_SCALE_X_SLIDER.set(hDlg, IDC_SCALE_X_SLIDER);
        m_SCALE_X_SLIDER.setRange(1, 100);
        m_SCALE_X_SLIDER.setPos(50);
        m_SCALE_Y_SLIDER.set(hDlg, IDC_SCALE_Y_SLIDER);
        m_SCALE_Y_SLIDER.setRange(1, 100);
        m_SCALE_Y_SLIDER.setPos(50);

        m_RADIO1.set(hDlg, IDC_RADIO1);
        m_RADIO2.set(hDlg, IDC_RADIO2);
        m_RADIO3.set(hDlg, IDC_RADIO3);
        m_RADIO1.check();

        float* p = glm::value_ptr(mat33);
        std::wstring tempwstr = std::to_wstring(p[0]);
        m_Mat00.setText(tempwstr.c_str());
        tempwstr = std::to_wstring(p[1]);
        m_Mat10.setText(tempwstr.c_str());
        tempwstr = std::to_wstring(p[2]);
        m_Mat20.setText(tempwstr.c_str());
        tempwstr = std::to_wstring(p[3]);
        m_Mat01.setText(tempwstr.c_str());
        tempwstr = std::to_wstring(p[4]);
        m_Mat11.setText(tempwstr.c_str());
        tempwstr = std::to_wstring(p[5]);
        m_Mat21.setText(tempwstr.c_str());
        tempwstr = std::to_wstring(p[6]);
        m_Mat02.setText(tempwstr.c_str());
        tempwstr = std::to_wstring(p[7]);
        m_Mat12.setText(tempwstr.c_str());
        tempwstr = std::to_wstring(p[8]);
        m_Mat22.setText(tempwstr.c_str());



        wchar_t  tempWchar[64];

       // m_Mat21.getText(tempWchar,64);
       // tempwstr = tempWchar;
       // float tF = std::stof(tempwstr);

        HWND hOpenGLWnd =  ::GetDlgItem(hDlg, IDC_OPENGLVIEW);

        bool succ = CreateGLContent(hOpenGLWnd, TRUE);
        if (!succ)
        {
            ::MessageBox(hWnd, L"初始化OpenGL窗口发生错误", L"系统信息", MB_OK);
            return;
        }
        
        m_Shader.InitializeShaderWithString(m_vertexShader.c_str(), m_fragmentShader.c_str());
      
        
       // m_VAOWithVBO.SetData();

        m_OneBufferTrangle.AddVBO({ vertices }, { 3 * 6 }, BufferUsageHint::StaticDraw, { {3,3} });
        m_MultiBufferTrangle.AddVBO({ positions,colors }, { 9,9 }, BufferUsageHint::DynamicDraw, { {3},{3} });
        
        m_VAOWithVBO_EBO.AddVBOandEBO({ rect_vertices }, { 4 * 6 }, BufferUsageHint::StaticDraw, { {3,3} }, std::vector<GLuint>(rect_indices, rect_indices + 6));
        return;
    };
    virtual void Resize_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        WindowResize();
    }
    virtual void Destroy_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
         shutdown();
    }
    virtual BOOL  OnIdle(LONG lCount)
    {
        GLContext::swapBuffer();

        return TRUE;
    }

    virtual void Command_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        int wmId = LOWORD(wParam);
        if (wmId == IDD_ABOUTBOX)
        {
            Win::WinForm::ShowModelDialog(IDD_ABOUTBOX, hDlg, About);// Win::WinForm::DialogWindowProc);
         
        }
        else if (wmId == IDC_ROTATIONBUTTON)
        {
            wchar_t  tempWchar[64];
            m_RotationEdit.getText(tempWchar, 64);
            std::wstring tempwstr = tempWchar;
            float tF = glm::radians(std::stof(tempwstr));
            
            mat33[0][0] = cos( tF );
            m_Mat00.setText( std::to_wstring(mat33[0][0]).c_str() );

            mat33[0][1] = -sin(tF);
            m_Mat01.setText(std::to_wstring(mat33[0][1]).c_str());

            mat33[1][0] = sin(tF);
            m_Mat10.setText(std::to_wstring(mat33[1][0]).c_str());

            mat33[1][1] = cos(tF);
            m_Mat11.setText(std::to_wstring(mat33[1][1]).c_str());
        }
        else if (wmId == IDM_EXIT)
        {
            ::SendMessageW(hDlg, WM_DESTROY, 0, 0);
           // TestBuffer();
        }
    }
    virtual void Notify_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        NMHDR* p = (NMHDR*)(void*)lParam;

        LONG iID = wParam;
        if (iID == IDC_MOVEX_SPIN)
        {
            int tPos = m_MOVEX_SPIN.getPos();

            std::wstring tempStr = std::to_wstring(tPos);
            m_Mat02.setText(tempStr.c_str());

        }
        else if (iID == IDC_MOVEY_SPIN)
        {
            int tPos = m_MOVEY_SPIN.getPos();
            std::wstring tempStr = std::to_wstring(tPos);
            m_Mat12.setText(tempStr.c_str());
        }
        else if (iID == IDC_SCALE_X_SLIDER)
        {
            int tPos = m_SCALE_X_SLIDER.getPos();
            std::wstring tempStr;// = std::to_wstring(tPos);
            if (tPos == 50)
                tempStr = L"1";
            else
            {
                if (tPos > 50)
                {
                    float tempF = 1.0f - (9.0f / 50.0f) * (50- tPos);
                    tempStr = std::to_wstring(tempF);
                }
                else
                {
                    float tempF = (0.9f/49.0f)*(tPos -1)+0.1f;
                    tempStr = std::to_wstring(tempF);
                }
            }
            m_SCALE_X_EDIT.setText(tempStr.c_str());
        }
        else if (iID == IDC_SCALE_Y_SLIDER)
        {
            int tPos = m_SCALE_Y_SLIDER.getPos();
            std::wstring tempStr;// = std::to_wstring(tPos);
            if (tPos == 50)
                tempStr = L"1";
            else
            {
                if (tPos > 50)
                {
                    float tempF = 1.0f - (9.0f / 50.0f) * (50 - tPos);
                    tempStr = std::to_wstring(tempF);
                }
                else
                {
                    float tempF = (0.9f / 49.0f) * (tPos - 1) + 0.1f;
                    tempStr = std::to_wstring(tempF);
                }
            }
            m_SCALE_Y_EDIT.setText(tempStr.c_str());
        }
    }

    //设置世界坐标系的显示范围
    GLfloat xwcMin = -200.0, xwcMax = 200.0;
    GLfloat ywcMin = -200.0f, ywcMax = 200.0f;

    //定义三角形的初始位置----以二维齐次坐标形式定义 
    glm::vec3  verts[3] = { {0.0,100.0,1},
                            {-100.0* 1.732050807568*0.5,-50.0,1},
                            {100.0*1.732050807568 * 0.5,-50.0,1}};
    glm::mat3x3 mat33 = glm::mat3(1.0f,0.0f,0.0f,
                                  0.0f,1.0f,0.0f,
                                  0.0f,0.0f,1.0f);

    glm::mat3x3 _scaleMat = glm::mat3x3(1.0f);

    virtual void UserInitialize() 
    {
 


    };

    virtual void PreDrawProcess(GL_Channel& _channel) 
    {
        RECT rect;
        ::GetWindowRect(_channel._hWnd, &rect);
        int width = rect.right - rect.left;
        int height = rect.bottom - rect.top;

        glViewport(0, 0, width, height);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluOrtho2D(xwcMin, xwcMax, ywcMin, ywcMax);
        glMatrixMode(GL_MODELVIEW);	// 选择模型观察矩阵

    };
    virtual void GLDrawProcess(GL_Channel& _channel) 
    {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // 清理颜色缓存和深度缓存
        glClearColor(0.0, 0.0, 0.0, 0.0);
        glColor3f(1.0, 1.0, 1.0);
        glLoadIdentity();

        glLineWidth(2.0f);
        glBegin(GL_LINES);
        glVertex2f(-195, 0);
        glVertex2f(195, 0);
        glVertex2f(195, 0);
        glVertex2f(190, -5);
        glVertex2f(195, 0);
        glVertex2f(190, 5);

        glVertex2f(195, -5);
        glVertex2f(189, -15);
        glVertex2f(189, -5);
        glVertex2f(195, -15);
        glEnd();

        glBegin(GL_LINES);
        glVertex2f(0, -195);
        glVertex2f(0, 195);

        glVertex2f(0, 195);
        glVertex2f(-3, 188);
        glVertex2f(0, 195);
        glVertex2f(3, 188);

        glVertex2f(5, 195);
        glVertex2f(8, 188);
        glVertex2f(8, 188);
        glVertex2f(11, 195);
        glVertex2f(8, 188);
        glVertex2f(8, 180);

        glEnd();
        if (m_AUTORATATION.isChecked() == true)
        {
            wchar_t  tempWchar[64];
            m_RotationEdit.getText(tempWchar, 64);

            float tF = std::stof(tempWchar);
            tF += 0.1;
            if (tF > 360)
                tF = 0;
            m_RotationEdit.setText(std::to_wstring(tF).c_str());
            tF = glm::radians(tF);

            mat33[0][0] = cos(tF);
            m_Mat00.setText(std::to_wstring(mat33[0][0]).c_str());

            mat33[0][1] = -sin(tF);
            m_Mat01.setText(std::to_wstring(mat33[0][1]).c_str());

            mat33[1][0] = sin(tF);
            m_Mat10.setText(std::to_wstring(mat33[1][0]).c_str());

            mat33[1][1] = cos(tF);
            m_Mat11.setText(std::to_wstring(mat33[1][1]).c_str());

            m_Mat02.getText(tempWchar, 64);
            mat33[0][2] = std::stof(tempWchar);

            m_Mat12.getText(tempWchar, 64);
            mat33[1][2] = std::stof(tempWchar);

            m_Mat20.getText(tempWchar, 64);
            mat33[2][0] = std::stof(tempWchar);

            m_Mat21.getText(tempWchar, 64);
            mat33[2][1] = std::stof(tempWchar);

            m_Mat22.getText(tempWchar, 64);
            mat33[2][2] = std::stof(tempWchar);
        }
        //处理缩放计算
        {
            wchar_t  tempWchar[64];
            m_SCALE_X_EDIT.getText(tempWchar, 64);
            float tScaleX = std::stof(tempWchar);
            m_SCALE_Y_EDIT.getText(tempWchar, 64);
            float tScaleY = std::stof(tempWchar);

            _scaleMat[0][0] = tScaleX;//沿着X轴缩放的比例
            _scaleMat[1][1] = tScaleY;//沿着X轴缩放的比例
        }
        glm::mat4x4 mat44 = glm::mat4(1.0f);
        mat44[0][0] = mat33[0][0];
        mat44[0][1] = mat33[0][1];
        mat44[3][0] = mat33[0][2];

        mat44[1][0] = mat33[1][0];
        mat44[1][1] = mat33[1][1];
        mat44[3][1] = mat33[1][2];

        glm::mat4x4 _scaleMat4x4 = glm::mat4(1);
        _scaleMat4x4[0][0] = _scaleMat[0][0];
        _scaleMat4x4[1][1] = _scaleMat[1][1];
        mat44 = mat44 * _scaleMat4x4;

        m_Shader.Use();
        glm::mat4  ViewMat  = glm::mat4(1.0f);
        glm::mat4  ModelMat = mat44;// glm::mat4(1.0f);
        glm::mat4  ProjectionMat = glm::ortho(-200.0f, 200.0f, -200.0f, 200.0f, 2.0f, -2.0f);
        
        m_Shader.SetMat4("ModelMatrix", ModelMat);
        m_Shader.SetMat4("ViewMatrix", ViewMat);
        m_Shader.SetMat4("ProjectionMatrix", ProjectionMat);

        if(m_RADIO1.isChecked()==true)
            m_OneBufferTrangle.DrawVAO(PrimitiveType::Triangles, 3);
        else if (m_RADIO2.isChecked() == true)
            m_MultiBufferTrangle.DrawVAO(PrimitiveType::Triangles, 3);
        else if (m_RADIO3.isChecked() == true)
            m_VAOWithVBO_EBO.DrawVAO(PrimitiveType::Triangles,6);
        m_Shader.UnUse();
  
    };

    virtual void UserDestroy() 
    {

    };

   
   
};
WindowsForm  g_WinForm;

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    OutputDebugStringW(L"字符串");

    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 在此处放置代码。

    // 初始化全局字符串
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WINMAINAPP, szWindowClass, MAX_LOADSTRING);



    g_WinForm.CreateWindowFromReSource(hInstance, IDD_MAINDIALOG);
    return g_WinForm.Run(); 
}

// “关于”框的消息处理程序。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

