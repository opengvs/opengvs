﻿///////////////////////////////////////////////////////////////////////////////
//  VAOWithVBOandEBO.hpp  用于创建VAO对象，可是单独使用VBO缓冲区，也可以同时使用VBO+EBO，
//  注意：对于VAO对象，只能使用两种模式中的一种形式存储数据：1 VBO缓冲区；2 VBO+EBO缓冲区
//  版权所有        刘文庆    2023.11 廊坊 
///////////////////////////////////////////////////////////////////////////////
#ifndef __VAOWITHVBOANDEBO__
#define __VAOWITHVBOANDEBO__
#include "glad.h"
#include <string>
#include <vector>
#include "BufferUsageHint.h"
#include "glm/glm.hpp"
#include "glm/gtc/type_ptr.hpp"
#include <numeric>
#include "Shader.hpp"
#include "PrimitiveType.h"


class VAOWithVBOandEBO
{
	GLuint VAOID = 0;
    int    m_UseEBO = 0;//表示VAO对象是否使用EBO类型绘制物体 0表示初始阶段还没有设置任何数据对象
                        //                                   1表示设置VBO对象--以后不能设置VBO+EBO了
                        //                                   2表示设置VBO+EBO对象--以后不能设置VBO
public:
    VAOWithVBOandEBO()
	{
        m_UseEBO = 0;
	}
	~VAOWithVBOandEBO()
	{   
		if (VAOID > 0)
		{
			glDeleteVertexArrays(1,&VAOID);
		}

	}

    //为VAO一次性添加一个VBO对象  ItemData为VBO对象的数据，dataSize为数据长度；c_ArrayList为VBO对象内部数据组织的形式：                      
    // 用户可以有两种形式组织数据，
    // 一种形式是将顶点数据与属性数据(color,normal,uv)一同存放：
    // 调用形式为：AddVBO({Data},{6}.{{3,3}});
    // 另一种形式是顶点数据与属性数据(color,normal,uv)分开存放 
    // 调用形式为：AddVBO({Data1,Data2},{3,3}.{{3},{3}}});
    void AddVBO(std::initializer_list<GLfloat*>  ItemData, std::initializer_list<int> dataSize, BufferUsageHint usage, std::initializer_list<std::vector<int>> c_ArrayList)
    {
        if (m_UseEBO == 2)
        {
            TraceMsg(L"VAO对象已经设置为VBO+EBO模式了，不能再添加单独的VBO对象了，请使用AddVBOandEBO函数添加对象");
            return;
        }
        //创建顶点数组对象
        if (VAOID == 0)
            glGenVertexArrays(1, &VAOID);

        // 1.t绑定顶点数据
        glBindVertexArray(VAOID);

        GLuint theVBOID = 0;
        glGenBuffers(1, &theVBOID);
       // m_VBOArray.emplace_back(theVBOID);

        // 2.绑定顶点缓冲区对象
        glBindBuffer(GL_ARRAY_BUFFER, theVBOID);


        int _TotalSize = std::accumulate(dataSize.begin(), dataSize.end(), 0);
        //分配足够多的存储空间
        glBufferData(GL_ARRAY_BUFFER, _TotalSize * sizeof(GLfloat), nullptr, usage);

        typename std::initializer_list<GLfloat*>::iterator pIt = ItemData.begin();
        typename std::initializer_list<int>::iterator pIt1 = dataSize.begin();
        typename std::initializer_list<std::vector<int>>::iterator pIt2 = c_ArrayList.begin();

        long   _AddressOffset = 0;
        int    _ItemIndex = 0;

        while (pIt != ItemData.end())
        {
            GLfloat* p = *pIt;//得到数据指针

            int tSize = *pIt1;//得到数据大小

            //将数据由内存缓冲区传输到GPU缓冲区中
            glBufferSubData(GL_ARRAY_BUFFER,   // target 目标
                _AddressOffset,    // offset 偏移地址
                tSize * sizeof(GLfloat),              // size 大小
                p);   // data 数据

            //接着就需要设置GPU缓冲区中数据的组织形式

            const std::vector<int>& _ItemArray = *pIt2;
            int    _ItemDataSize = std::accumulate(_ItemArray.begin(), _ItemArray.end(), 0);//计算数组中元素的和
            int   _ItemDataAddressOffset = 0;
            for (int i = 0; i < _ItemArray.size(); i++)
            {
                glVertexAttribPointer(_ItemIndex, _ItemArray[i], GL_FLOAT, GL_FALSE, _ItemDataSize * sizeof(GLfloat), (GLvoid*)(_AddressOffset + _ItemDataAddressOffset));

                glEnableVertexAttribArray(_ItemIndex);
                _ItemDataAddressOffset += _ItemArray[i] * sizeof(float);
                _ItemIndex++;
            }

            _AddressOffset += tSize * sizeof(GLfloat);


            pIt++;
            pIt1++;
            pIt2++;
        }
        //作为习惯，用完之后将VBO,VAO解绑，_ItemArray[i]需要的时候可以重新绑定
        glBindVertexArray(0);
        glBindBuffer(GL_ARRAY_BUFFER, 0);
        //解绑VAO后，就可以删除VAO中存储的对象了，以后使用直接用VAO对象就可以了
        glDeleteBuffers(1, &theVBOID);
        m_UseEBO = 1;
    }

    void AddVBOandEBO(std::initializer_list<GLfloat*>  ItemData, std::initializer_list<int> dataSize, BufferUsageHint usage, std::initializer_list<std::vector<int>> c_ArrayList, const std::vector<GLuint>& cIndices)
    {
        if (m_UseEBO == 1)
        {
            TraceMsg(L"VAO对象已经设置为VBO模式了，不能再添加VBO+EBO对象了，请使用AddVBO函数添加对象");
            return;
        }
        //创建顶点数组对象
        if (VAOID == 0)
            glGenVertexArrays(1, &VAOID);

        // 1.t绑定顶点数据
        glBindVertexArray(VAOID);

        GLuint theVBOID = 0;
        glGenBuffers(1, &theVBOID);
      //  m_VBOArray.emplace_back(theVBOID);

        // 2.绑定顶点缓冲区对象
        glBindBuffer(GL_ARRAY_BUFFER, theVBOID);


        int _TotalSize = std::accumulate(dataSize.begin(), dataSize.end(), 0);
        //分配足够多的存储空间
        glBufferData(GL_ARRAY_BUFFER, _TotalSize * sizeof(float), nullptr, usage);

        typename std::initializer_list<float*>::iterator pIt = ItemData.begin();
        typename std::initializer_list<int>::iterator pIt1 = dataSize.begin();
        typename std::initializer_list<std::vector<int>>::iterator pIt2 = c_ArrayList.begin();

        long   _AddressOffset = 0;
        int    _ItemIndex = 0;

        while (pIt != ItemData.end())
        {
            float* p = *pIt;//得到数据指针

            int tSize = *pIt1;//得到数据大小

            //将数据由内存缓冲区传输到GPU缓冲区中
            glBufferSubData(GL_ARRAY_BUFFER,   // target 目标
                _AddressOffset,    // offset 偏移地址
                tSize * sizeof(GLfloat),              // size 大小
                p);   // data 数据

            //接着就需要设置GPU缓冲区中数据的组织形式

            const std::vector<int>& _ItemArray = *pIt2;
            int    _ItemDataSize = std::accumulate(_ItemArray.begin(), _ItemArray.end(), 0);//计算数组中元素的和
            int   _ItemDataAddressOffset = 0;
            for (int i = 0; i < _ItemArray.size(); i++)
            {
                glVertexAttribPointer(_ItemIndex, _ItemArray[i], GL_FLOAT, GL_FALSE, _ItemDataSize * sizeof(GLfloat), (GLvoid*)(_AddressOffset + _ItemDataAddressOffset));

                glEnableVertexAttribArray(_ItemIndex);
                _ItemDataAddressOffset += _ItemArray[i] * sizeof(GLfloat);
                _ItemIndex++;
            }

            _AddressOffset += tSize * sizeof(GLfloat);


            pIt++;
            pIt1++;
            pIt2++;
        }

        GLuint theEBO = 0;
        glGenBuffers(1, &theEBO);//生成顶点索引
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, theEBO);//绑定GL_ELEMENT_ARRAY_BUFFER缓冲
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, cIndices.size()*sizeof(float), cIndices.data(), GL_STATIC_DRAW);//指定索引数组
       


        //作为习惯，用完之后将VBO,VAO解绑，_ItemArray[i]需要的时候可以重新绑定
        glBindVertexArray(0);
        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

        //解绑VAO后，就可以删除VAO中存储的对象了，以后使用直接用VAO对象就可以了
        glDeleteBuffers(1, &theEBO);
        glDeleteBuffers(1, &theVBOID);

        m_UseEBO = 2;
    }

    void  DrawVAO(const PrimitiveType primativeType,int pointsNumber)
    {
        if (m_UseEBO == 0)
            return;

        glBindVertexArray(VAOID);
        if(m_UseEBO==1)
           
           glDrawArrays(primativeType, 0, pointsNumber);
        else if (m_UseEBO == 2)
            glDrawElements(primativeType, pointsNumber, GL_UNSIGNED_INT, 0);
        glBindVertexArray(0);
        
    }
    void  DrawVAO(Shader& shader, const PrimitiveType primativeType, int pointsNumber)
    {
        shader.Use();

        glBindVertexArray(VAOID);
        glDrawArrays(primativeType, 0, pointsNumber);
        glBindVertexArray(0);
    }
};

#endif

//下面这个函数是用于测试特定顶天的VAO_VBO创建的函数
/*	void SetData(void)
    {
        //创建顶点缓冲区对象
        if(VBOID==0)
            glGenBuffers(1, &VBOID);

        //创建顶点数组对象
        if(VAOID==0)
            glGenVertexArrays(1, &VAOID);

        // 1.t绑定顶点数据
        glBindVertexArray(VAOID);
        // 2.绑定顶点缓冲区对象
        glBindBuffer(GL_ARRAY_BUFFER, VBOID);

        //分配足够多的存储空间
        glBufferData(GL_ARRAY_BUFFER, 3*6 * sizeof(GL_FLOAT), nullptr, GL_STATIC_DRAW);

        //将顶点数据传入缓冲区对象中（&传入缓冲区数据的类型&数据量大小以字节为单位&传入的数据&显卡管理传入数据的方式）
        //glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);//
        glBufferSubData(GL_ARRAY_BUFFER,   // target 目标
                        0,    // offset 偏移地址
                        3 * 6 * sizeof(GL_FLOAT),              // size 大小
            vertices);   // data 数据

        // 3.告知管线顶点数据的解析方式
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid*)0);
        //启用顶点属性数据0
        glEnableVertexAttribArray(0);

        //告知管线颜色数据的解析方式
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
        glEnableVertexAttribArray(1);
        //启用属性1.
        //4. Unbind the VAO解除VAO绑定
        glBindVertexArray(0);
        glDisableVertexAttribArray(0);
    }*/
