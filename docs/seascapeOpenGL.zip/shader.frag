//=============================================================================
// Seascape - Fragment Shader
// 基于 Alexander Alekseev (TDM) 的 Shadertoy 原作
// 已适配为 OpenGL 3.3 Core Profile
// License: CC BY-NC-SA 3.0
//=============================================================================
// 此文件由 seascape.cpp 在运行时读取。
// 你可以直接编辑此文件来调整效果参数，重启程序即可看到变化。
//=============================================================================

#version 330 core

// ---- 输出 ----
out vec4 fragColor;

// ---- Uniforms (由 C++ 代码传入) ----
uniform vec2  uResolution;    // 窗口分辨率 (width, height)
uniform float uTime;          // 已运行的时间 (秒)
uniform vec4  uMouse;         // (mouseX, mouseY, buttonDown, 0)

//=============================================================================
// 常量参数 (可自由调整)
//=============================================================================

const int NUM_STEPS     = 32;
const float PI          = 3.141592;
const float EPSILON     = 1e-3;

// 海洋参数
const int ITER_GEOMETRY     = 3;
const int ITER_FRAGMENT     = 5;
const float SEA_HEIGHT      = 0.6;
const float SEA_CHOPPY      = 4.0;
const float SEA_SPEED       = 0.8;
const float SEA_FREQ        = 0.16;
const vec3  SEA_BASE        = vec3(0.0, 0.09, 0.18);
const vec3  SEA_WATER_COLOR = vec3(0.8, 0.9, 0.6) * 0.6;
#define SEA_TIME (1.0 + uTime * SEA_SPEED)
const mat2 octave_m = mat2(1.6, 1.2, -1.2, 1.6);

//=============================================================================
// 数学工具函数
//=============================================================================

// Euler 角转 3x3 旋转矩阵
mat3 fromEuler(vec3 ang) {
    vec2 a1 = vec2(sin(ang.x), cos(ang.x));
    vec2 a2 = vec2(sin(ang.y), cos(ang.y));
    vec2 a3 = vec2(sin(ang.z), cos(ang.z));
    mat3 m;
    m[0] = vec3(a1.y * a3.y + a1.x * a2.x * a3.x, a1.y * a2.x * a3.x + a3.y * a1.x, -a2.y * a3.x);
    m[1] = vec3(-a2.y * a1.x, a1.y * a2.y, a2.x);
    m[2] = vec3(a3.y * a1.x * a2.x + a1.y * a3.x, a1.x * a3.x - a1.y * a3.y * a2.x, a2.y * a3.y);
    return m;
}

// 伪随机哈希
float hash(vec2 p) {
    float h = dot(p, vec2(127.1, 311.7));
    return fract(sin(h) * 43758.5453123);
}

// 2D 值噪声 (Value Noise)
float noise(in vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);  // Smoothstep
    return -1.0 + 2.0 * mix(
        mix(hash(i + vec2(0.0, 0.0)), hash(i + vec2(1.0, 0.0)), u.x),
        mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
        u.y);
}

//=============================================================================
// 光照函数
//=============================================================================

// 漫反射 (Modified Phong)
float diffuse(vec3 n, vec3 l, float p) {
    return pow(dot(n, l) * 0.4 + 0.6, p);
}

// 高光 (Blinn-Phong)
float specular(vec3 n, vec3 l, vec3 e, float s) {
    float nrm = (s + 8.0) / (PI * 8.0);
    return pow(max(dot(reflect(e, n), l), 0.0), s) * nrm;
}

//=============================================================================
// 天空
//=============================================================================

vec3 getSkyColor(vec3 e) {
    e.y = (max(e.y, 0.0) * 0.8 + 0.2) * 0.8;
    return vec3(pow(1.0 - e.y, 2.0), 1.0 - e.y, 0.6 + (1.0 - e.y) * 0.4) * 1.1;
}

//=============================================================================
// 海洋波浪生成
//=============================================================================

// 单层脊状波浪 (Ridge Wave)
float sea_octave(vec2 uv, float choppy) {
    uv += noise(uv);                          // 加噪扰动
    vec2 wv  = 1.0 - abs(sin(uv));           // 脊状波
    vec2 swv = abs(cos(uv));                  // 余弦波
    wv = mix(wv, swv, wv);                    // 混合形成尖锐波峰
    return pow(1.0 - pow(wv.x * wv.y, 0.65), choppy);
}

// 高度场 SDF (粗糙版 - 用于光线步进)
float map(vec3 p) {
    float freq   = SEA_FREQ;
    float amp    = SEA_HEIGHT;
    float choppy = SEA_CHOPPY;
    vec2 uv      = p.xz;
    uv.x *= 0.75;

    float d, h = 0.0;
    for (int i = 0; i < ITER_GEOMETRY; i++) {
        d  = sea_octave((uv + SEA_TIME) * freq, choppy);
        d += sea_octave((uv - SEA_TIME) * freq, choppy);
        h += d * amp;
        uv *= octave_m;
        freq   *= 1.9;
        amp    *= 0.22;
        choppy = mix(choppy, 1.0, 0.2);
    }
    return p.y - h;
}

// 高度场 SDF (精细版 - 用于法线计算)
float map_detailed(vec3 p) {
    float freq   = SEA_FREQ;
    float amp    = SEA_HEIGHT;
    float choppy = SEA_CHOPPY;
    vec2 uv      = p.xz;
    uv.x *= 0.75;

    float d, h = 0.0;
    for (int i = 0; i < ITER_FRAGMENT; i++) {
        d  = sea_octave((uv + SEA_TIME) * freq, choppy);
        d += sea_octave((uv - SEA_TIME) * freq, choppy);
        h += d * amp;
        uv *= octave_m;
        freq   *= 1.9;
        amp    *= 0.22;
        choppy = mix(choppy, 1.0, 0.2);
    }
    return p.y - h;
}

//=============================================================================
// 海洋着色
//=============================================================================

vec3 getSeaColor(vec3 p, vec3 n, vec3 l, vec3 eye, vec3 dist) {
    // 菲涅尔反射
    float fresnel = clamp(1.0 - dot(n, -eye), 0.0, 1.0);
    fresnel = min(fresnel * fresnel * fresnel, 0.5);

    vec3 reflected = getSkyColor(reflect(eye, n));
    vec3 refracted = SEA_BASE + diffuse(n, l, 80.0) * SEA_WATER_COLOR * 0.12;

    vec3 color = mix(refracted, reflected, fresnel);

    // 水体衰减 (波峰处更亮)
    float atten = max(1.0 - dot(dist, dist) * 0.001, 0.0);
    color += SEA_WATER_COLOR * (p.y - SEA_HEIGHT) * 0.18 * atten;

    // 高光 (随距离锐化)
    color += specular(n, l, eye, 600.0 * inversesqrt(dot(dist, dist)));

    return color;
}

//=============================================================================
// 追踪
//=============================================================================

// 法线计算 (前向有限差分)
vec3 getNormal(vec3 p, float eps) {
    vec3 n;
    n.y = map_detailed(p);
    n.x = map_detailed(vec3(p.x + eps, p.y, p.z)) - n.y;
    n.z = map_detailed(vec3(p.x, p.y, p.z + eps)) - n.y;
    n.y = eps;
    return normalize(n);
}

// 高度场光线步进 (二分法变体)
float heightMapTracing(vec3 ori, vec3 dir, out vec3 p) {
    float tm = 0.0;
    float tx = 1000.0;
    float hx = map(ori + dir * tx);

    // 如果远端点在水面之上则未击中
    if (hx > 0.0) {
        p = ori + dir * tx;
        return tx;
    }

    float hm = map(ori);
    for (int i = 0; i < NUM_STEPS; i++) {
        float tmid = mix(tm, tx, hm / (hm - hx));
        p = ori + dir * tmid;
        float hmid = map(p);

        if (hmid < 0.0) {
            tx = tmid;
            hx = hmid;
        } else {
            tm = tmid;
            hm = hmid;
        }

        if (abs(hmid) < EPSILON) break;
    }

    return mix(tm, tx, hm / (hm - hx));
}

//=============================================================================
// 像素着色
//=============================================================================

vec3 getPixel(in vec2 coord, float time) {
    // 屏幕坐标 → NDC → 考虑宽高比
    vec2 uv = coord / uResolution.xy;
    uv = uv * 2.0 - 1.0;
    uv.x *= uResolution.x / uResolution.y;

    // 相机旋转 (受鼠标 X 坐标影响)
    vec3 ang = vec3(sin(time * 3.0) * 0.1, sin(time) * 0.2 + 0.3, time);
    vec3 ori = vec3(0.0, 3.5, time * 5.0);
    vec3 dir = normalize(vec3(uv.xy, -2.0));
    dir.z += length(uv) * 0.14;        // 鱼眼畸变
    dir = normalize(dir) * fromEuler(ang);

    // 光线步进
    vec3 p;
    heightMapTracing(ori, dir, p);
    vec3 dist  = p - ori;
    vec3 n     = getNormal(p, dot(dist, dist) * (0.1 / uResolution.x));
    vec3 light = normalize(vec3(0.0, 1.0, 0.8));

    // 混合天空与海洋
    return mix(
        getSkyColor(dir),
        getSeaColor(p, n, light, dir, dist),
        pow(smoothstep(0.0, -0.02, dir.y), 0.2));
}

//=============================================================================
// 主函数
//=============================================================================

void main() {
    float time = uTime * 0.3 + uMouse.x * 0.01;
    vec3 color = getPixel(gl_FragCoord.xy, time);

    // 后处理: Gamma 校正
    fragColor = vec4(pow(color, vec3(0.65)), 1.0);
}
