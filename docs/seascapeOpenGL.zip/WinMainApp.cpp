﻿// WinMainApp.cpp : Seascape OpenGL 着色器查看器
//  基于 WindowFormGL 框架 + SeascapeRenderer
//

#include "framework.h"
#include "WinMainApp.h"
#include "WinForm.hpp"
#include "GLContext.hpp"
#include "SeascapeRenderer.hpp"

#define MAX_LOADSTRING 100

// 全局变量:
HINSTANCE hInst;                                // 当前实例
WCHAR szTitle[MAX_LOADSTRING];                  // 标题栏文本
WCHAR szWindowClass[MAX_LOADSTRING];            // 主窗口类名
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

//=============================================================================
// WindowsForm - 主窗口类，集成 Seascape 渲染
//=============================================================================
class WindowsForm :public Win::WinForm, public GLContext
{
private:
    Win::Button  m_AboutButton;
    Win::Button  m_CloseButton;

    // ---- Seascape 渲染相关 ----
    SeascapeRenderer  m_seascape;

    LARGE_INTEGER     m_perfFreq;
    LARGE_INTEGER     m_perfLast;
    GLfloat           m_time;

    int               m_mouseX;
    int               m_mouseY;
    bool              m_mouseDown;

    // ---- OpenGL 视图窗口尺寸 ----
    int               m_glViewWidth;
    int               m_glViewHeight;

public:
    WindowsForm()
        : Win::WinForm()
        , GLContext()
        , m_time(0.0f)
        , m_mouseX(0), m_mouseY(0), m_mouseDown(false)
        , m_glViewWidth(0), m_glViewHeight(0)
    {
        // 初始化高精度计时器
        QueryPerformanceFrequency(&m_perfFreq);
        QueryPerformanceCounter(&m_perfLast);
    }

    //=========================================================================
    // 对话框初始化：创建 OpenGL 上下文 -> 初始化 Seascape 渲染器
    //=========================================================================
    virtual void Init_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) override
    {
        m_AboutButton.set(hDlg, IDD_ABOUTBOX);
        m_CloseButton.set(hDlg, IDM_EXIT);
       //HWND hOpenGLWnd = ::GetDlgItem(hDlg, IDC_OPENGLVIEW);

        // 获取 gl 视图区域大小
        RECT rect;
        ::GetWindowRect(hDlg, &rect);
        m_glViewWidth  = rect.right - rect.left;
        m_glViewHeight = rect.bottom - rect.top;

        bool succ = CreateGLContent(hDlg, TRUE);
        if (!succ)
        {
            ::MessageBox(hDlg, L"初始化OpenGL窗口发生错误", L"系统信息", MB_OK);
            return;
        }
    }

    //=========================================================================
    // 用户初始化 (GLContext 回调) - 在此初始化 Seascape 渲染器
    //=========================================================================
    virtual void UserInitialize() override
    {
        if (!m_seascape.init())
        {
            OutputDebugStringA("[Seascape] Renderer init failed!\n");
        }
    }

    //=========================================================================
    // 每帧绘制 (GLContext 回调) - 渲染 Seascape
    //=========================================================================
    virtual void GLDrawProcess(GL_Channel& _channel) override
    {
        // 更新时间
        LARGE_INTEGER now;
        QueryPerformanceCounter(&now);
        GLfloat dt = (GLfloat)(now.QuadPart - m_perfLast.QuadPart)
                     / (GLfloat)m_perfFreq.QuadPart;
        m_perfLast = now;
        m_time += dt;

        // 渲染 Seascape
        m_seascape.render(m_glViewWidth, m_glViewHeight, m_time,
                          m_mouseX, m_mouseY, m_mouseDown);
    }

    //=========================================================================
    // 跳过固定函数管线投影设置
    //=========================================================================
    virtual void PreDrawProcess(GL_Channel& _channel) override
    {
        // Seascape 使用着色器，不需要固定函数投影矩阵
        // 但需要设置视口
        glViewport(0, 0, _channel._windowWidth, _channel._windowHeight);
    }

    //=========================================================================
    // 窗口大小变化
    //=========================================================================
    virtual void Resize_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) override
    {
       // HWND hOpenGLWnd = ::GetDlgItem(hDlg, IDC_OPENGLVIEW);
        RECT rect;
        ::GetWindowRect(hDlg, &rect);
        m_glViewWidth  = rect.right - rect.left;
        m_glViewHeight = rect.bottom - rect.top;

        WindowResize();
    }

    //=========================================================================
    // 清理
    //=========================================================================
    virtual void Destroy_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) override
    {
        m_seascape.shutdown();
        shutdown();
    }

    //=========================================================================
    // Command 事件
    //=========================================================================
    virtual void Command_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) override
    {
        int wmId = LOWORD(wParam);
        if (wmId == IDD_ABOUTBOX)
        {
            Win::WinForm::ShowModelDialog(IDD_ABOUTBOX, hDlg, About);
        }
        else if (wmId == IDM_EXIT)
        {
            ::SendMessageW(hDlg, WM_DESTROY, 0, 0);
        }
    }

    //=========================================================================
    // 鼠标事件
    //=========================================================================
    virtual void MouseMove_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) override
    {
        m_mouseX = LOWORD(lParam);
        m_mouseY = HIWORD(lParam);
    }

    virtual void MouseLButtonDown_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) override
    {
        m_mouseDown = true;
    }

    virtual void MouseLButtonUp_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) override
    {
        m_mouseDown = false;
    }

    //=========================================================================
    // 键盘事件：ESC 退出，F11 全屏
    //=========================================================================
    virtual void KeyDown_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) override
    {
        switch (wParam)
        {
        case VK_ESCAPE:
            ::SendMessageW(hDlg, WM_DESTROY, 0, 0);
            break;
        case VK_F11:
            // 简易全屏切换
            {
                static bool fullscreen = false;
                static RECT savedRect;
                static LONG savedStyle;

                fullscreen = !fullscreen;
                if (fullscreen)
                {
                    savedStyle = GetWindowLong(hDlg, GWL_STYLE);
                    GetWindowRect(hDlg, &savedRect);

                    HMONITOR hMonitor = MonitorFromWindow(hDlg, MONITOR_DEFAULTTONEAREST);
                    MONITORINFO mi = { sizeof(mi) };
                    GetMonitorInfo(hMonitor, &mi);

                    SetWindowLong(hDlg, GWL_STYLE,
                        savedStyle & ~(WS_CAPTION | WS_THICKFRAME));
                    SetWindowPos(hDlg, HWND_TOP,
                        mi.rcMonitor.left, mi.rcMonitor.top,
                        mi.rcMonitor.right - mi.rcMonitor.left,
                        mi.rcMonitor.bottom - mi.rcMonitor.top,
                        SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
                }
                else
                {
                    SetWindowLong(hDlg, GWL_STYLE, savedStyle);
                    SetWindowPos(hDlg, NULL,
                        savedRect.left, savedRect.top,
                        savedRect.right - savedRect.left,
                        savedRect.bottom - savedRect.top,
                        SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
                }
            }
            break;
        }
    }

    //=========================================================================
    // 闲置回调 (每帧调用)
    //=========================================================================
    virtual BOOL OnIdle(LONG lCount) override
    {
        GLContext::swapBuffer();
        return TRUE;
    }
};

WindowsForm  g_WinForm;

//=============================================================================
// 入口点
//=============================================================================
int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                      _In_opt_ HINSTANCE hPrevInstance,
                      _In_ LPWSTR    lpCmdLine,
                      _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // 初始化全局字符串
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WINMAINAPP, szWindowClass, MAX_LOADSTRING);

    g_WinForm.CreateWindowFromReSource(hInstance, IDD_MAINDIALOG);
    return g_WinForm.Run();
}

// “关于”框的消息处理程序。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
