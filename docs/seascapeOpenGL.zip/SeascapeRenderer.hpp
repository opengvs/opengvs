//=============================================================================
//  SeascapeRenderer.hpp - Seascape fragment shader renderer
//  Based on the original Shadertoy work by Alexander Alekseev (TDM)
//  License: CC BY-NC-SA 3.0
//
//  Integrated into the WindowFormGL project framework using glad.h
//=============================================================================

#ifndef __SEASCAPE_RENDERER_HPP__
#define __SEASCAPE_RENDERER_HPP__

#include "glad.h"          // glad already loaded all OpenGL 4.6 functions
#include "Shader.hpp"      // Shader class
#include "VAOWithVBOandEBO.hpp"  // VAO/VBO 封装类
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

//=============================================================================
// SeascapeRenderer - Encapsulates Seascape fragment shader rendering
//=============================================================================

class SeascapeRenderer {
private:
    Shader             _shader;     // Shader program
    VAOWithVBOandEBO   _quadVAO;    // Fullscreen quad VAO (encapsulates VBO)
    int                _vertexNum;  // Vertex count

    GLint   _uniResolution;     // uResolution uniform location
    GLint   _uniTime;           // uTime uniform location
    GLint   _uniMouse;          // uMouse uniform location

    bool    _ready;

    // ---- Vertex shader (fullscreen quad) ----
    static const char* _vertSrc;

    //=========================================================================
    // Helper: read file content into szShaderSource
    //=========================================================================
    static bool readFile(const char* filename, std::string& out) {
        std::ifstream file(filename, std::ios::in | std::ios::binary);
        if (!file.is_open()) return false;
        std::stringstream ss;
        ss << file.rdbuf();
        out = ss.str();
        return true;
    }

public:
    SeascapeRenderer()
        : _shader(), _quadVAO(), _vertexNum(0)
        , _uniResolution(-1), _uniTime(-1), _uniMouse(-1)
        , _ready(false) {}

    ~SeascapeRenderer() { shutdown(); }

    bool isReady() const { return _ready; }

    //=========================================================================
    // Initialize: load shader.frag and create fullscreen quad
    //=========================================================================
    bool init() {
        if (_ready) return true;

        // ---- Load fragment shader source ----
        std::string fragSrc;
        bool loaded = readFile("shader.frag", fragSrc);

        if (!loaded) {
            // Try parent directory
            loaded = readFile("../shader.frag", fragSrc);
        }

        if (!loaded) {
            // Use embedded shader as fallback
            fragSrc = getEmbeddedFragShader();
        }

        // ---- Create shader program via Shader class ----
        // _vertSrc is the embedded vertex shader, fragSrc is the fragment shader
        _shader.InitializeShaderWithString(_vertSrc, fragSrc.c_str());

        if (_shader.getShaderID() == 0) {
            MessageBoxA(NULL, "Seascape shader program creation failed!",
                        "Error", MB_OK | MB_ICONERROR);
            return false;
        }

        // ---- Get uniform locations ----
        _shader.Use();
        _uniResolution = glGetUniformLocation(_shader.getShaderID(), "uResolution");
        _uniTime       = glGetUniformLocation(_shader.getShaderID(), "uTime");
        _uniMouse      = glGetUniformLocation(_shader.getShaderID(), "uMouse");
        _shader.UnUse();

        // ---- Create fullscreen quad via VAOWithVBOandEBO ----
        // Fullscreen quad vertices (TRIANGLE_STRIP), 2 floats per vertex (x, y)
        // Following the pattern of Terrain::InitializeData()
        float quadVertices[] = {
            -1.0f, -1.0f,   // bottom-left
             1.0f, -1.0f,   // bottom-right
            -1.0f,  1.0f,   // top-left
             1.0f,  1.0f    // top-right
        };
        _vertexNum = 4;

        // Build vertex buffer via AddVBO:
        //   - data pointer list: { quadVertices }
        //   - data size list: { 8 } (4 vertices * 2 floats)
        //   - usage: StaticDraw
        //   - attribute layout: { { 2 } } means 1 attribute, 2 floats per vertex
        _quadVAO.AddVBO({ quadVertices }, { 8 },
                        BufferUsageHint::StaticDraw, { { 2 } });

        _ready = true;
        return true;
    }

    //=========================================================================
    // Render one frame
    //=========================================================================
    void render(int width, int height, float time,
                int mouseX, int mouseY, bool mouseDown) {
        if (!_ready) return;

        glViewport(0, 0, width, height);
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        _shader.Use();
        _shader.SetVec2("uResolution", (float)width, (float)height);
        _shader.setFloat("uTime", time);
        _shader.SetVec4("uMouse", (float)mouseX, (float)mouseY,
                        mouseDown ? 1.0f : 0.0f, 0.0f);

        // Draw fullscreen quad via VAOWithVBOandEBO::DrawArrays
        // Following the pattern of Terrain::Draw()
        _quadVAO.DrawArrays(PrimitiveType::TriangleStrip, 0, _vertexNum);

        _shader.UnUse();
    }

    //=========================================================================
    // Clean up OpenGL resources
    //=========================================================================
    void shutdown() {
        // VAO/VBO auto-cleaned by VAOWithVBOandEBO destructor
        // Shader auto-cleaned by Shader destructor (glDeleteProgram)
        _vertexNum = 0;
        _ready = false;
    }

    //=========================================================================
    // Embedded fragment shader (fallback when shader.frag not found)
    //=========================================================================
    static std::string getEmbeddedFragShader() {
        return R"GLSL(#version 330 core
out vec4 fragColor;
uniform vec2  uResolution;
uniform float uTime;
uniform vec4  uMouse;

const int NUM_STEPS = 32;
const float PI = 3.141592;
const float EPSILON = 1e-3;

const int ITER_GEOMETRY = 3;
const int ITER_FRAGMENT = 5;
const float SEA_HEIGHT = 0.6;
const float SEA_CHOPPY = 4.0;
const float SEA_SPEED = 0.8;
const float SEA_FREQ = 0.16;
const vec3 SEA_BASE = vec3(0.0, 0.09, 0.18);
const vec3 SEA_WATER_COLOR = vec3(0.8, 0.9, 0.6) * 0.6;
#define SEA_TIME (1.0 + uTime * SEA_SPEED)
const mat2 octave_m = mat2(1.6, 1.2, -1.2, 1.6);

mat3 fromEuler(vec3 ang) {
    vec2 a1 = vec2(sin(ang.x), cos(ang.x));
    vec2 a2 = vec2(sin(ang.y), cos(ang.y));
    vec2 a3 = vec2(sin(ang.z), cos(ang.z));
    mat3 m;
    m[0] = vec3(a1.y*a3.y + a1.x*a2.x*a3.x, a1.y*a2.x*a3.x + a3.y*a1.x, -a2.y*a3.x);
    m[1] = vec3(-a2.y*a1.x, a1.y*a2.y, a2.x);
    m[2] = vec3(a3.y*a1.x*a2.x + a1.y*a3.x, a1.x*a3.x - a1.y*a3.y*a2.x, a2.y*a3.y);
    return m;
}

float hash(vec2 p) {
    float h = dot(p, vec2(127.1, 311.7));
    return fract(sin(h) * 43758.5453123);
}

float noise(in vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return -1.0 + 2.0 * mix(
        mix(hash(i + vec2(0.0, 0.0)), hash(i + vec2(1.0, 0.0)), u.x),
        mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
}

float diffuse(vec3 n, vec3 l, float p) {
    return pow(dot(n, l) * 0.4 + 0.6, p);
}

float specular(vec3 n, vec3 l, vec3 e, float s) {
    float nrm = (s + 8.0) / (PI * 8.0);
    return pow(max(dot(reflect(e, n), l), 0.0), s) * nrm;
}

vec3 getSkyColor(vec3 e) {
    e.y = (max(e.y, 0.0) * 0.8 + 0.2) * 0.8;
    return vec3(pow(1.0 - e.y, 2.0), 1.0 - e.y, 0.6 + (1.0 - e.y) * 0.4) * 1.1;
}

float sea_octave(vec2 uv, float choppy) {
    uv += noise(uv);
    vec2 wv = 1.0 - abs(sin(uv));
    vec2 swv = abs(cos(uv));
    wv = mix(wv, swv, wv);
    return pow(1.0 - pow(wv.x * wv.y, 0.65), choppy);
}

float map(vec3 p) {
    float freq = SEA_FREQ;
    float amp = SEA_HEIGHT;
    float choppy = SEA_CHOPPY;
    vec2 uv = p.xz; uv.x *= 0.75;
    float d, h = 0.0;
    for (int i = 0; i < ITER_GEOMETRY; i++) {
        d = sea_octave((uv + SEA_TIME) * freq, choppy);
        d += sea_octave((uv - SEA_TIME) * freq, choppy);
        h += d * amp;
        uv *= octave_m; freq *= 1.9; amp *= 0.22;
        choppy = mix(choppy, 1.0, 0.2);
    }
    return p.y - h;
}

float map_detailed(vec3 p) {
    float freq = SEA_FREQ;
    float amp = SEA_HEIGHT;
    float choppy = SEA_CHOPPY;
    vec2 uv = p.xz; uv.x *= 0.75;
    float d, h = 0.0;
    for (int i = 0; i < ITER_FRAGMENT; i++) {
        d = sea_octave((uv + SEA_TIME) * freq, choppy);
        d += sea_octave((uv - SEA_TIME) * freq, choppy);
        h += d * amp;
        uv *= octave_m; freq *= 1.9; amp *= 0.22;
        choppy = mix(choppy, 1.0, 0.2);
    }
    return p.y - h;
}

vec3 getSeaColor(vec3 p, vec3 n, vec3 l, vec3 eye, vec3 dist) {
    float fresnel = clamp(1.0 - dot(n, -eye), 0.0, 1.0);
    fresnel = min(fresnel * fresnel * fresnel, 0.5);
    vec3 reflected = getSkyColor(reflect(eye, n));
    vec3 refracted = SEA_BASE + diffuse(n, l, 80.0) * SEA_WATER_COLOR * 0.12;
    vec3 color = mix(refracted, reflected, fresnel);
    float atten = max(1.0 - dot(dist, dist) * 0.001, 0.0);
    color += SEA_WATER_COLOR * (p.y - SEA_HEIGHT) * 0.18 * atten;
    color += specular(n, l, eye, 600.0 * inversesqrt(dot(dist, dist)));
    return color;
}

vec3 getNormal(vec3 p, float eps) {
    vec3 n;
    n.y = map_detailed(p);
    n.x = map_detailed(vec3(p.x + eps, p.y, p.z)) - n.y;
    n.z = map_detailed(vec3(p.x, p.y, p.z + eps)) - n.y;
    n.y = eps;
    return normalize(n);
}

float heightMapTracing(vec3 ori, vec3 dir, out vec3 p) {
    float tm = 0.0;
    float tx = 1000.0;
    float hx = map(ori + dir * tx);
    if (hx > 0.0) { p = ori + dir * tx; return tx; }
    float hm = map(ori);
    for (int i = 0; i < NUM_STEPS; i++) {
        float tmid = mix(tm, tx, hm / (hm - hx));
        p = ori + dir * tmid;
        float hmid = map(p);
        if (hmid < 0.0) { tx = tmid; hx = hmid; }
        else { tm = tmid; hm = hmid; }
        if (abs(hmid) < EPSILON) break;
    }
    return mix(tm, tx, hm / (hm - hx));
}

vec3 getPixel(in vec2 coord, float time) {
    vec2 uv = coord / uResolution.xy;
    uv = uv * 2.0 - 1.0;
    uv.x *= uResolution.x / uResolution.y;
    vec3 ang = vec3(sin(time * 3.0) * 0.1, sin(time) * 0.2 + 0.3, time);
    vec3 ori = vec3(0.0, 3.5, time * 5.0);
    vec3 dir = normalize(vec3(uv.xy, -2.0));
    dir.z += length(uv) * 0.14;
    dir = normalize(dir) * fromEuler(ang);
    vec3 p;
    heightMapTracing(ori, dir, p);
    vec3 dist = p - ori;
    vec3 n = getNormal(p, dot(dist, dist) * (0.1 / uResolution.x));
    vec3 light = normalize(vec3(0.0, 1.0, 0.8));
    return mix(
        getSkyColor(dir),
        getSeaColor(p, n, light, dir, dist),
        pow(smoothstep(0.0, -0.02, dir.y), 0.2));
}

void main() {
    float time = uTime * 0.3 + uMouse.x * 0.01;
    vec3 color = getPixel(gl_FragCoord.xy, time);
    fragColor = vec4(pow(color, vec3(0.65)), 1.0);
}
)GLSL";
    }
};

// Vertex shader source
const char* SeascapeRenderer::_vertSrc =
    "#version 330 core\n"
    "layout(location = 0) in vec2 aPos;\n"
    "void main() {\n"
    "    gl_Position = vec4(aPos, 0.0, 1.0);\n"
    "}\n";

#endif // __SEASCAPE_RENDERER_HPP__
