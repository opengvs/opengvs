﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenGLObject;

namespace CsharpeOpenGL_Texture
{
    public  class EathSphereObject : VAO
    {
        public Texture2D m_texture;
        // 将球横纵划分成50X50的网格
        const int Y_SEGMENTS = 50;
        const int X_SEGMENTS = 50;
        List<float> _sphere_vertices = new List<float>();
        List<float> _sphere_mNormals = new List<float>();
        List<float> _sphere_mTexCoords = new List<float>();
        List<int> _sphere_indices = new List<int>();

        public Vector3 position = new Vector3(7.0f, 3.0f, 0.0f);

        public EathSphereObject(Texture2D tex) : base()
        {
            base.Bind();
            m_texture = tex;
            //base.AddVertexBufferObjectFloat(vertexData, sizeof(float) * vertexData.Length, 3, BufferUsageHint.StaticDraw, 0);
            // base.AddVertexBufferObjectFloat(textureData, sizeof(float) * textureData.Length, 2, BufferUsageHint.StaticDraw, 1);
            float radius = 2.0f;

            // 生成球的顶点
            for (int y = 0; y <= Y_SEGMENTS; y++)
            {
                for (int x = 0; x <= X_SEGMENTS; x++)
                {

                    float xSegment = (float)x / (float)X_SEGMENTS;
                    float ySegment = (float)y / (float)Y_SEGMENTS;
                    float xPos =
                       (float)(Math.Cos(xSegment * 2.0f * MathHelper.Pi) * Math.Sin(ySegment * MathHelper.Pi) * radius);
                    float yPos = (float)Math.Cos(ySegment * MathHelper.Pi) * radius;
                    float zPos =
                       (float)(Math.Sin(xSegment * 2.0f * MathHelper.Pi) * Math.Sin(ySegment * MathHelper.Pi) * radius);

                    _sphere_vertices.Add(xPos);
                    _sphere_vertices.Add(yPos);
                    _sphere_vertices.Add(zPos);

                    //这里应该使用一个临时变量Vector3 v3 = new Vector3(xPos,yPos,zPos);
                    //然后对v3进行矢量归一化
                    position.X = xPos;
                    position.Y = yPos;
                    position.Z = zPos;
                    position.Normalize();

                    _sphere_mNormals.Add(position.X);
                    _sphere_mNormals.Add(position.Y);
                    _sphere_mNormals.Add(position.Z);

                    //mTexCoords[idx] = glm::vec2(j / (float)precision,i / (float)precision);
                    float tempU = (float)x / (float)X_SEGMENTS;
                    float tempV = (float)y / (float)X_SEGMENTS;
                    _sphere_mTexCoords.Add(tempU);
                    _sphere_mTexCoords.Add(tempV);

                }
            }
            position.X = 7.0f;
            position.Y = 2.0f;
            position.Z = 0.0f;

            // 生成球的Indices
            for (int i = 0; i < Y_SEGMENTS; i++)
            {
                for (int j = 0; j < X_SEGMENTS; j++)
                {
                    _sphere_indices.Add(i * (X_SEGMENTS + 1) + j);
                    _sphere_indices.Add((i + 1) * (X_SEGMENTS + 1) + j);
                    _sphere_indices.Add((i + 1) * (X_SEGMENTS + 1) + j + 1);

                    _sphere_indices.Add(i * (X_SEGMENTS + 1) + j);
                    _sphere_indices.Add((i + 1) * (X_SEGMENTS + 1) + j + 1);
                    _sphere_indices.Add(i * (X_SEGMENTS + 1) + j + 1);
                }
            }
            //_sphere_vertices.ToArray();
            base.Bind();
            base.AddVertexBufferObjectFloat(_sphere_vertices.ToArray(), sizeof(float) * _sphere_vertices.Count, 3, BufferUsageHint.StaticDraw, 0);
            // base.AddVertexBufferObjectFloat(_sphere_mNormals.ToArray(), sizeof(float) * _sphere_mNormals.Count, 3, BufferUsageHint.StaticDraw, 1);
            base.AddVertexBufferObjectFloat(_sphere_mTexCoords.ToArray(), sizeof(float) * _sphere_mTexCoords.Count, 2, BufferUsageHint.StaticDraw, 1);

            base.SetElementBufferObject<int>(_sphere_indices.ToArray(), sizeof(int) * _sphere_indices.Count, BufferUsageHint.StaticDraw);

            base.Unbind();
        }
        float time = 0.0f;
        public override void Draw(Shader _shader)//重载不带参数的Draw函数，供OBD和OBI对象调用
        {
            this.Bind();

            /********* 纹理操作：激活、绑定 **********/
            GL.ActiveTexture(TextureUnit.Texture0);
            //绑定纹理
            m_texture.Bind(); //glBindTexture(GL_TEXTURE_2D, textureIds[i]);

            time += 0.1f;
            Matrix4 modelMat = Matrix4.CreateScale(1.0f, 1.0f, 1.0f) * Matrix4.CreateFromQuaternion(
                  Quaternion.FromEulerAngles(0.15f * time, 0.55f * time, 0f)) * Matrix4.CreateTranslation(position.X, position.Y, position.Z);
            // Matrix4 modelMat = Matrix4.Identity;
            _shader.SetMatrix4("model", modelMat);

            GL.DrawElements(PrimitiveType.Triangles, X_SEGMENTS * Y_SEGMENTS * 6, DrawElementsType.UnsignedInt, 0);
            // GL.DrawArrays(PrimitiveType.TriangleFan, 0, count);
            this.Unbind();
        }
    }
}
