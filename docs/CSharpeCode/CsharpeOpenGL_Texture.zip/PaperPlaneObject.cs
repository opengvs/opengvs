﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenGLObject;
using OpenTK.Mathematics;
using OpenTK.Graphics.OpenGL4;
using OpenGLObject;

namespace CsharpeOpenGL_Texture
{
    public class PaperPlaneObject : VAO
    {
        public static float[] vertdata = {
                0.0f, 1.0f,  2.0f,//1
                1.6f, 0.6f,  0f,//2
                1.4f, 0.8f,  0f,//3
                1.1f, 1.0f,  0f,//4
                
                0.0f, 0.0f,  0f,//5

               -1.1f, 1.0f,  0f,//6
               -1.4f, 0.8f,  0f,//7
               -1.6f, 0.6f,  0f //8
        };
        public static float[] colordata = { 1f, 0f, 0f,
                0f, 0f, 1f,
                0f,  1f, 0f,
                1f, 0f, 0f,
                0f, 0f, 1f,
                0f,  1f, 0f,
                1f, 0f, 0f,
                0f, 0f, 1f
             };
        public static byte[] indicedata = {

                0, 1, 2,
                0, 2, 3,

                0, 3, 4,
                0, 4, 5,

                0, 5, 6,
                0, 6, 7,

                0, 3, 5,
                3, 4, 5

        };
        public PaperPlaneObject() : base()
        {
            base.Bind();
            base.AddVertexBufferObjectFloat(vertdata, sizeof(float) * vertdata.Length, 3, BufferUsageHint.StaticDraw, 0);
            base.AddVertexBufferObjectFloat(colordata, sizeof(float) * colordata.Length, 3, BufferUsageHint.StaticDraw, 1);
            base.SetElementBufferObject(indicedata, sizeof(byte) * indicedata.Length, BufferUsageHint.StaticDraw);

            base.Unbind();
        }
    }
}
