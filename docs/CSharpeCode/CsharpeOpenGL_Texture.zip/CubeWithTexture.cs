﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenGLObject;
using OpenTK.Graphics.OpenGL4;

namespace CsharpeOpenGL_Texture
{
    public class CubeWithTexture:VAO
    {
        public Texture2D? texture2DUnit2;
        public float _MixFactor = 0.1f;//
        public CubeWithTexture(Texture2D texture1, Texture2D texture2, Texture2D texture3, Texture2D texture4, Texture2D texture5, Texture2D texture6) : base()
        {
            base.Bind();
            base.AddVertexBufferObjectFloat(vertexData, sizeof(float) * vertexData.Length, 3, BufferUsageHint.StaticDraw, 0);
            base.AddVertexBufferObjectFloat(textureData, sizeof(float) * textureData.Length, 2, BufferUsageHint.StaticDraw, 1);
            base.Unbind();

            _tex[0] = texture1;
            _tex[1] = texture2;
            _tex[2] = texture3;
            _tex[3] = texture4;
            _tex[4] = texture5;
            _tex[5] = texture6;
        }
        public override void Draw(Shader? _shader = null)//重载不带参数的Draw函数，供OBD和OBI对象调用
        {
            this.Bind();

            // 纹理操作：激活、绑定 
            GL.ActiveTexture(TextureUnit.Texture0);

            int count = 4;
            for (int i = 0; i < _tex.Length; i++)
            {
                int first = i * count;
                //绑定纹理
                _tex[i].Bind(); //glBindTexture(GL_TEXTURE_2D, textureIds[i]);

                if (texture2DUnit2 != null)
                {
                    texture2DUnit2.Bind(OpenTK.Graphics.OpenGL4.TextureUnit.Texture1);
                    // _tex[i].Unbind();
                    _shader.SetTextureUnitID("texture1", 0);
                    _shader.SetTextureUnitID("texture2", 1);
                    _shader.SetFloat("mixFactor", _MixFactor);
                }

                //绘制正方体的表面（6个面，每个面2个三角形）
                GL.DrawArrays(PrimitiveType.TriangleFan, first, count);
            }

            this.Unbind();
        }
        
        //顶点坐标数组
        public static float[] vertexData = new float[] {
	               //前面
	               1.0f, 1.0f, 1.0f,
                  -1.0f, 1.0f, 1.0f,
                  -1.0f, -1.0f, 1.0f,
                   1.0f, -1.0f, 1.0f,
	              //后面
	              1.0f, 1.0f, -1.0f,
                 -1.0f, 1.0f, -1.0f,
                 -1.0f, -1.0f, -1.0f,
                  1.0f, -1.0f, -1.0f,
	              //上面
	              1.0f, 1.0f, 1.0f,
                  1.0f, 1.0f, -1.0f,
                 -1.0f, 1.0f, -1.0f,
                 -1.0f, 1.0f, 1.0f,
	             //下面
	              1.0f, -1.0f, 1.0f,
                  1.0f, -1.0f, -1.0f,
                 -1.0f, -1.0f, -1.0f,
                 -1.0f, -1.0f, 1.0f,
	             //右面
	              1.0f, 1.0f, 1.0f,
                  1.0f, 1.0f, -1.0f,
                  1.0f, -1.0f, -1.0f,
                  1.0f, -1.0f, 1.0f,
	             //左面
	              -1.0f, 1.0f, 1.0f,
                  -1.0f, 1.0f, -1.0f,
                  -1.0f, -1.0f, -1.0f,
                  -1.0f, -1.0f, 1.0f
         };

        //纹理坐标数组
        public static float[] textureData = new float[] {
	              //前面
	               0f, 0f,
                   1f, 0f,
                   1f, 1f,
                   0f, 1f,
	               //后面
	               0f, 0f,
                   1f, 0f,
                   1f, 1f,
                   0f, 1f,
	              //上面
	              0f, 0f,
                  1f, 0f,
                  1f, 1f,
                  0f, 1f,
	             //下面
	              0f, 0f,
                  1f, 0f,
                  1f, 1f,
                  0f, 1f,
	             //右面
	              0f, 0f,
                  1f, 0f,
                  1f, 1f,
                  0f, 1f,
	             //左面
	              0f, 0f,
                  1f, 0f,
                  1f, 1f,
                  0f, 1f
          };
        public Texture2D[] _tex = new Texture2D[6];
    }

    /*
public class CubeWithTexture : VAO
{
    public Texture2D[] _tex = new Texture2D[6];
    public CubeWithTexture(Texture2D texture1, Texture2D texture2, Texture2D texture3, Texture2D texture4, Texture2D texture5, Texture2D texture6) : base()
    {
        base.Bind();
        base.AddVertexBufferObject<float>(vertices, sizeof(float) * vertices.Length, BufferUsageHint.StaticDraw, new int[] {3,2 });
        base.Unbind();
        _tex[0] = texture1;
        _tex[1] = texture2;
        _tex[2] = texture3;
        _tex[3] = texture4;
        _tex[4] = texture5;
        _tex[5] = texture6;
    }
    public override void Draw(Shader? _shader = null)
    {
        this.Bind();
        GL.ActiveTexture(TextureUnit.Texture0);
        _tex[0].Bind();
        GL.DrawArrays(PrimitiveType.Triangles, 0, 36);
        this.Unbind();
    }
    public static float[] vertices = new float[] {
    -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
     0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,

    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
     0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
    -0.5f,  0.5f,  0.5f,  0.0f, 1.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,

    -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
    -0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
    -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
     0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  1.0f, 1.0f,
     0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
     0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,

    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
    -0.5f,  0.5f,  0.5f,  0.0f, 0.0f,
    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f
   };
}
*/


}
