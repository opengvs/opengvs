using OpenGLObject;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using System.CodeDom;

namespace CsharpeOpenGL_Texture
{
    public partial class OpenTKMainForm : Form
    {
        public OpenTKMainForm()
        {
            InitializeComponent();
        }
        private void OpenTKMainForm_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
            openglView.Resize += openglView_Resize;
            openglView.Paint += openglView_Paint;

            int w = this.openglView.Width;
            int h = this.openglView.Height;
            float _Fov = 120;
            float _aspect = (float)h / (float)w;
            float _Near = 0.1f;
            float _Far = 1000.0f;
            m_PlaneTexture = new Texture2D("./Images/Flight_2.jpg");
            m_CubeTexture_1 = new Texture2D("./Images/Cube1.jpg");
            m_CubeTexture_2 = new Texture2D("./Images/Cube2.jpg");
            m_CubeTexture_3 = new Texture2D("./Images/Cube3.jpg");
            m_CubeTexture_4 = new Texture2D("./Images/Cube4.jpg");
            m_CubeTexture_5 = new Texture2D("./Images/Cube5.jpg");
            m_CubeTexture_6 = new Texture2D("./Images/Cube6.jpg");
            m_2UnitTexture = new Texture2D("./Images/TextrureUnit2.png");
            m_EathSphereTexture = new Texture2D("./Images/earth1024X512.png");

            GL.Viewport(0, 0, w, h);  //����ߴ�����

            m_MainCamera = new Camera(new Vector3(0f, 1f, 6f),//eyeλ��
                                       new Vector3(0, 0, 0),  //�۾��۲�����ĵ�
                                       new Vector3(0, 1, 0),  //���ϵķ���
                                       120,
                                       (float)w / (float)h,
                                       0.1f,
                                       1000.0f);
            Vector3 angleV = m_MainCamera.getRotation();

            m_Shader = new Shader(vs3D_VertexWithColor_MVP, fs3D_VertexWithColor_MVP);
            m_TextureShader = new Shader(vs3D_Texture_MVP, fs3D_Texture_MVP);
            m_2unitTextureShader = new Shader(vs3D_2UnitTexture_MVP, fs3D_2UnitTexture_MVP);



            cubeWithTexture = new CubeWithTexture(m_CubeTexture_1, m_CubeTexture_2,
                                    m_CubeTexture_3, m_CubeTexture_4, m_CubeTexture_5, m_CubeTexture_6);
            cubeWithTexture.texture2DUnit2 = m_2UnitTexture;

            m_CubeWithTextureObjectDef = new GLObjectDef();
            m_CubeWithTextureObjectDef.AddVAO(cubeWithTexture);
            m_CubeWithTextureObjectInstance = new GLObjectInstance(m_CubeWithTextureObjectDef);


            m_TerrainObjectDef = new GLObjectDef();
            m_TerrainObjectDef.AddVAO(new Terrain(30, 30));

            m_TerrainInstance = new GLObjectInstance(m_TerrainObjectDef);


            m_EathSphereObject =  new EathSphereObject(m_EathSphereTexture);
            m_EathObjectDef = new GLObjectDef();
            m_EathObjectDef.AddVAO(m_EathSphereObject);
            m_EathObjectInstance = new GLObjectInstance(m_EathObjectDef);

            // �趨�����Ļ����Ļ��ʾ�ı���ɫ������������ɫ
            GL.ClearColor(0.2f, 0.3f, 0.3f, 1.0f);

            timer1.Enabled = true;

            this.CameraPos_X.Text = m_MainCamera.Position.X.ToString("f1");
            this.CameraPos_Y.Text = m_MainCamera.Position.Y.ToString("f1");
            this.CameraPos_Z.Text = m_MainCamera.Position.Z.ToString("f1");

            this.CameraRotation_X.Text = angleV.X.ToString("f1");
            this.CameraRotation_Y.Text = angleV.Y.ToString("f1");
            this.CameraRotation_Z.Text = angleV.Z.ToString("f1");

            CameraFOV.Text = m_MainCamera.Fov.ToString("f1");
            FOV_trackBar.Value = (int)m_MainCamera.Fov;
            cameraAspectRatio.Text = m_MainCamera?.AspectRatio.ToString("f2");
            cameraNearPlane.Text = m_MainCamera?.Near.ToString("f2");
            cameraFarPlane.Text = m_MainCamera?.Far.ToString("f2");



            UpdateCameraMatView();

 

        }
        private void UpdateCameraMatView()
        {
            Matrix4 cameraMat = m_MainCamera.GetViewMatrix();
            A00.Text = cameraMat[0, 0].ToString("f2");
            A01.Text = cameraMat[0, 1].ToString("f2");
            A02.Text = cameraMat[0, 2].ToString("f2");
            A03.Text = cameraMat[0, 3].ToString("f2");
            A10.Text = cameraMat[1, 0].ToString("f2");
            A11.Text = cameraMat[1, 1].ToString("f2");
            A12.Text = cameraMat[1, 2].ToString("f2");
            A13.Text = cameraMat[1, 3].ToString("f2");
            A20.Text = cameraMat[2, 0].ToString("f2");
            A21.Text = cameraMat[2, 1].ToString("f2");
            A22.Text = cameraMat[2, 2].ToString("f2");
            A23.Text = cameraMat[2, 3].ToString("f2");
            A30.Text = cameraMat[3, 0].ToString("f2");
            A31.Text = cameraMat[3, 1].ToString("f2");
            A32.Text = cameraMat[3, 2].ToString("f2");
            A33.Text = cameraMat[3, 3].ToString("f2");

            Matrix4 cameraPrjMat = m_MainCamera.GetProjectionMatrix();
            B00.Text = cameraPrjMat[0, 0].ToString("f2");
            B01.Text = cameraPrjMat[0, 1].ToString("f2");
            B02.Text = cameraPrjMat[0, 2].ToString("f2");
            B03.Text = cameraPrjMat[0, 3].ToString("f2");
            B10.Text = cameraPrjMat[1, 0].ToString("f2");
            B11.Text = cameraPrjMat[1, 1].ToString("f2");
            B12.Text = cameraPrjMat[1, 2].ToString("f2");
            B13.Text = cameraPrjMat[1, 3].ToString("f2");
            B20.Text = cameraPrjMat[2, 0].ToString("f2");
            B21.Text = cameraPrjMat[2, 1].ToString("f2");
            B22.Text = cameraPrjMat[2, 2].ToString("f2");
            B23.Text = cameraPrjMat[2, 3].ToString("f2");
            B30.Text = cameraPrjMat[3, 0].ToString("f2");
            B31.Text = cameraPrjMat[3, 1].ToString("f2");
            B32.Text = cameraPrjMat[3, 2].ToString("f2");
            B33.Text = cameraPrjMat[3, 3].ToString("f2");
        }
        private void OpenTKMainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            cubeWithTexture?.Dispose();
            m_TextureShader?.Dispose();
            m_Shader?.Dispose();
            m_PlaneTexture?.Dispose();
            m_2unitTextureShader?.Dispose();
            m_CubeTexture_1?.Dispose();
            m_CubeTexture_2?.Dispose();
            m_CubeTexture_3?.Dispose();
            m_CubeTexture_4?.Dispose();
            m_CubeTexture_5?.Dispose();
            m_CubeTexture_6?.Dispose();
            m_EathSphereTexture?.Dispose();
            m_EathSphereObject?.Dispose();
            
        }
        static float time = 0.0f;

        private void openglView_Paint(object sender, PaintEventArgs e)
        {
            // ����
            GL.Viewport(0, 0, openglView.Width, openglView.Height);
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            GL.Enable(EnableCap.DepthTest);

            // ���ƴ���
            m_CubeWithTextureObjectInstance.SetPosition(-6.0f, 1.5f, 0.0f);
            time += 3.5f;
            m_CubeWithTextureObjectInstance.SetRotation(0.15f * time, 0.55f * time, 0f);
           


            cubeWithTexture._MixFactor = float.Parse(textBox10.Text);
            m_CubeWithTextureObjectInstance?.Draw(m_2unitTextureShader, m_MainCamera);//m_TextureShader, m_MainCamera);

            m_TerrainInstance?.Draw(m_Shader, m_MainCamera);

            m_EathObjectInstance?.Draw(m_TextureShader, m_MainCamera);
            // ��������������ֹ���������쳣
            openglView.SwapBuffers();
        }

        private void openglView_Resize(object sender, EventArgs e)
        {
            int w = this.openglView.Width;
            int h = this.openglView.Height;
            GL.Viewport(0, 0, w, h);  //����ߴ�����
            // �趨�����Ļ����Ļ��ʾ�ı���ɫ������������ɫ
            GL.ClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Refresh();
        }

        Shader? m_Shader;
        Shader? m_TextureShader;
        Shader? m_2unitTextureShader;
        Camera? m_MainCamera;


        CubeWithTexture? cubeWithTexture;
        GLObjectDef? m_CubeWithTextureObjectDef;
        GLObjectInstance? m_CubeWithTextureObjectInstance;

        GLObjectDef? m_TerrainObjectDef;
        GLObjectInstance? m_TerrainInstance;

        EathSphereObject? m_EathSphereObject;
        GLObjectDef?      m_EathObjectDef;
        GLObjectInstance? m_EathObjectInstance;
        

        Texture2D? m_PlaneTexture;
        Texture2D? m_CubeTexture_1;
        Texture2D? m_CubeTexture_2;
        Texture2D? m_CubeTexture_3;
        Texture2D? m_CubeTexture_4;
        Texture2D? m_CubeTexture_5;
        Texture2D? m_CubeTexture_6;

        Texture2D? m_2UnitTexture;
        Texture2D?  m_EathSphereTexture;

        static public string vs3D_VertexWithColor_MVP = "# version 330 core   \n" +
   "layout(location = 0) in vec3 vPosition;   \n" +
   "layout(location = 1)in  vec3 vColor;     \n" +
   "    uniform mat4 model;                  \n" +
   "    uniform mat4 view;                   \n" +
   "    uniform mat4 projection;             \n" +
   "    out vec4 color;\r\n" +
   "    void main()                              \n" +
   "   {                                     \n" +
   "        gl_Position = projection * view * model * vec4(vPosition, 1.0f);\n" +
   "        color = vec4( vColor, 1.0);                                     \n" +
   "   }";

        static public string fs3D_VertexWithColor_MVP = "#version 330 core \n" +
             "  in vec4 color;\n" +
             "  out vec4 outputColor;\n" +
             "  void main()\n" +
             "  {\n" +
             "        outputColor = color;\n" +
             "  }\n";
 

        static public string vs3D_Texture_MVP = "# version 330 core       \n" +
                 "layout(location = 0) in vec3 vPosition;                 \n" +
                 "layout(location = 1) in vec2 aUV;                       \n" +
                 "out vec2 outUV;                                         \n" +
                 "    uniform mat4 model;                                 \n" +
                 "    uniform mat4 view;                                  \n" +
                 "    uniform mat4 projection;                            \n" +

                 "void main()                                             \n" +
                 "{                                                       \n" +
                 "    gl_Position = projection* view * model* vec4(vPosition, 1.0f);\n" +
                 "    outUV = aUV;\n" +
                 "}\n";

        static public string fs3D_Texture_MVP = "#version 330 core                 \n" +
                 "out vec4 FragColor;                                              \n" +
                 "in vec2 outUV;                                                   \n" +
                 "uniform sampler2D ourTexture;                                    \n" +

                 "void main()                                                      \n" +
                 "{                                                                \n" +
                 "             FragColor = texture(ourTexture, outUV);             \n" +
                 "}";

        //�����������������Ԫ�����ںϼ��������ɫ��shader
        static public string vs3D_2UnitTexture_MVP = "# version 460 core           \n" +
                "layout(location = 0) in vec3 vPosition;                           \n" +
                "layout(location = 1) in vec2 aUV;                                 \n" +
                "out vec2 outUV;                                                   \n" +
                "    uniform mat4 model;                                           \n" +
                "    uniform mat4 view;                                            \n" +
                "    uniform mat4 projection;                                      \n" +
                "    void main()                                                   \n" +
                "    {                                                             \n" +
                "          gl_Position = projection* view * model* vec4(vPosition, 1.0f);\n" +
                "          outUV = aUV;\n" +
                "    }\n";

        static public string fs3D_2UnitTexture_MVP = "#version 460 core                  \n" +
               "  in vec4 color;                                                         \n" +
               "  out vec4 FragColor;                                                    \n" +

               "  in vec2 outUV;                                                         \n" +

               "  uniform sampler2D texture1;                                            \n" +
               "  uniform sampler2D texture2;                                            \n" +
               "  uniform float mixFactor;                                               \n" +
               "  void main()                                                            \n" +
               "  {                                                                      \n" +
               // GLSL�ڽ���mix������Ҫ��������ֵ��Ϊ�������������Ǹ��ݵ����������������Բ�ֵ��
               "     FragColor = mix(texture(texture1, outUV), texture(texture2, vec2(-outUV.x, outUV.y)), mixFactor);\n" +
               "   }";

        private void FOV_trackBar_ValueChanged(object sender, EventArgs e)
        {
            CameraFOV.Text = FOV_trackBar.Value.ToString("f1");
            if (m_MainCamera != null)
            {
                m_MainCamera.Fov = FOV_trackBar.Value;
                UpdateCameraMatView();
            }
        }

        private void ChangePosXButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(ChangePosXButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(CameraPos_X.Text);
                tempNum += 0.1f;
                CameraPos_X.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(CameraPos_X.Text);
                tempNum -= 0.1f;
                CameraPos_X.Text = tempNum.ToString("f1");
            }
            m_MainCamera.setPosition(float.Parse(CameraPos_X.Text), float.Parse(CameraPos_Y.Text), float.Parse(CameraPos_Z.Text));
            UpdateCameraMatView();
        }

        private void ChangePosYButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(ChangePosYButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(CameraPos_Y.Text);
                tempNum += 0.1f;
                CameraPos_Y.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(CameraPos_Y.Text);
                tempNum -= 0.1f;
                CameraPos_Y.Text = tempNum.ToString("f1");
            }
            m_MainCamera.setPosition(float.Parse(CameraPos_X.Text), float.Parse(CameraPos_Y.Text), float.Parse(CameraPos_Z.Text));
            UpdateCameraMatView();
        }

        private void ChangePosZButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(ChangePosZButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(CameraPos_Z.Text);
                tempNum += 0.1f;
                CameraPos_Z.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(CameraPos_Z.Text);
                tempNum -= 0.1f;
                CameraPos_Z.Text = tempNum.ToString("f1");
            }
            m_MainCamera.setPosition(float.Parse(CameraPos_X.Text), float.Parse(CameraPos_Y.Text), float.Parse(CameraPos_Z.Text));
            UpdateCameraMatView();
        }

        private void ChangeRotationXButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(ChangeRotationXButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(CameraRotation_X.Text);
                tempNum += 1f;
                CameraRotation_X.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(CameraRotation_X.Text);
                tempNum -= 1f;
                CameraRotation_X.Text = tempNum.ToString("f1");
            }
            m_MainCamera.setRotation(new Vector3(
                     float.Parse(CameraRotation_X.Text), float.Parse(CameraRotation_Y.Text), float.Parse(CameraRotation_Z.Text)));
            UpdateCameraMatView();
        }

        private void ChangeRotationYButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(ChangeRotationYButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(CameraRotation_Y.Text);
                tempNum += 1f;
                CameraRotation_Y.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(CameraRotation_Y.Text);
                tempNum -= 1f;
                CameraRotation_Y.Text = tempNum.ToString("f1");
            }
            m_MainCamera.setRotation(new Vector3(
                     float.Parse(CameraRotation_X.Text), float.Parse(CameraRotation_Y.Text), float.Parse(CameraRotation_Z.Text)));
            UpdateCameraMatView();
        }

        private void ChangeRotationZButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(ChangeRotationZButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(CameraRotation_Z.Text);
                tempNum += 1f;
                CameraRotation_Z.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(CameraRotation_Z.Text);
                tempNum -= 1f;
                CameraRotation_Z.Text = tempNum.ToString("f1");
            }
            m_MainCamera.setRotation(new Vector3(
                     float.Parse(CameraRotation_X.Text), float.Parse(CameraRotation_Y.Text), float.Parse(CameraRotation_Z.Text)));
            UpdateCameraMatView();
        }

        private void RotateRightButton_Click(object sender, EventArgs e)
        {
            float rotateX = float.Parse(CameraRotate_X.Text);
            m_MainCamera.rotateX(rotateX);
            UpdateCameraMatView();
        }

        private void RotateUpButton_Click(object sender, EventArgs e)
        {
            float rotateY = float.Parse(CameraRotate_Y.Text);
            m_MainCamera.rotateY(rotateY);
            UpdateCameraMatView();
        }

        private void RotateFrontButton_Click(object sender, EventArgs e)
        {
            float rotateZ = float.Parse(CameraRotate_Z.Text);
            m_MainCamera.rotateZ(rotateZ);
            UpdateCameraMatView();
        }

        private void cameraAspectRatioButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(cameraAspectRatioButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(cameraAspectRatio.Text);
                tempNum += 0.1f;

                cameraAspectRatio.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(cameraAspectRatio.Text);
                tempNum -= 0.1f;
                if (tempNum < 0.1)
                    tempNum = 0.1f;
                cameraAspectRatio.Text = tempNum.ToString("f1");
            }
            m_MainCamera.AspectRatio = float.Parse(cameraAspectRatio.Text);

            UpdateCameraMatView();
        }

        private void cameraNearPlaneButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(cameraNearPlaneButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(cameraNearPlane.Text);
                tempNum += 0.1f;

                cameraNearPlane.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(cameraNearPlane.Text);
                tempNum -= 0.1f;
                if (tempNum < 0.1)
                    tempNum = 0.1f;
                cameraNearPlane.Text = tempNum.ToString("f1");
            }
            m_MainCamera.Near = float.Parse(cameraNearPlane.Text);

            UpdateCameraMatView();

        }

        private void cameraFarPlaneButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(cameraFarPlaneButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(cameraFarPlane.Text);
                tempNum += 1f;

                cameraFarPlane.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(cameraFarPlane.Text);
                tempNum -= 1f;
                if (tempNum < 0.1)
                    tempNum = 0.1f;
                cameraFarPlane.Text = tempNum.ToString("f1");
            }
            m_MainCamera.Far = float.Parse(cameraFarPlane.Text);

            UpdateCameraMatView();
        }
 

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            int tempValue = trackBar1.Value;
            float tempF = tempValue;
            tempF = tempF * 0.01f;
            textBox10.Text = tempF.ToString();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                cubeWithTexture._tex[0].setMipMap(true);
                cubeWithTexture._tex[1].setMipMap(true);
                cubeWithTexture._tex[2].setMipMap(true);
                cubeWithTexture._tex[3].setMipMap(true);
                cubeWithTexture._tex[4].setMipMap(true);
                cubeWithTexture._tex[5].setMipMap(true);
                comboBox2.Items.Clear();
                comboBox2.Items.Add("GL_NEAREST_MIPMAP_NEAREST(ʹ�����ڽ��Ķ༶��Զ������ƥ�����ش�С����ʹ���ڽ���ֵ������������)");
                comboBox2.Items.Add("GL_LINEAR_MIPMAP_NEAREST(ʹ�����ڽ��Ķ༶��Զ�������𣬲�ʹ�����Բ�ֵ���в���)");
                comboBox2.Items.Add("GL_NEAREST_MIPMAP_LINEAR(��������ƥ�����ش�С�Ķ༶��Զ����֮��������Բ�ֵ��ʹ���ڽ���ֵ���в���)");
                comboBox2.Items.Add("GL_LINEAR_MIPMAP_LINEAR(�������ڽ��Ķ༶��Զ����֮��ʹ�����Բ�ֵ����ʹ�����Բ�ֵ���в���)");
                comboBox2.SelectedIndex = 0;
            }
            else
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("GL_NEAREST_MIPMAP_NEAREST(ʹ�����ڽ��Ķ༶��Զ������ƥ�����ش�С����ʹ���ڽ���ֵ������������)");
                comboBox2.Items.Add("GL_LINEAR_MIPMAP_NEAREST(ʹ�����ڽ��Ķ༶��Զ�������𣬲�ʹ�����Բ�ֵ���в���)");
                comboBox2.Items.Add("GL_NEAREST_MIPMAP_LINEAR(��������ƥ�����ش�С�Ķ༶��Զ����֮��������Բ�ֵ��ʹ���ڽ���ֵ���в���)");
                comboBox2.Items.Add("GL_LINEAR_MIPMAP_LINEAR(�������ڽ��Ķ༶��Զ����֮��ʹ�����Բ�ֵ����ʹ�����Բ�ֵ���в���)");
                comboBox2.SelectedIndex = 0;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)  //�༶����ֻ���GL_TEXTURE_MIN_FILTER���˷�ʽ��Ч
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("GL_NEAREST(ѡ���������������)");
                comboBox2.Items.Add("GL_LINEAR(�������������������Բ�ֵ����)");
                comboBox2.SelectedIndex = 0;
            }
            else
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("GL_NEAREST(ѡ���������������)");
                comboBox2.Items.Add("GL_LINEAR(�������������������Բ�ֵ����)");
                comboBox2.SelectedIndex = 0;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cubeWithTexture == null)
                return;

            if (comboBox1.SelectedIndex == 0)
            {
                cubeWithTexture._tex[0].SetTextureWrapST(TextureWrapMode.Repeat);
                cubeWithTexture._tex[1].SetTextureWrapST(TextureWrapMode.Repeat);
                cubeWithTexture._tex[2].SetTextureWrapST(TextureWrapMode.Repeat);
                cubeWithTexture._tex[3].SetTextureWrapST(TextureWrapMode.Repeat);
                cubeWithTexture._tex[4].SetTextureWrapST(TextureWrapMode.Repeat);
                cubeWithTexture._tex[5].SetTextureWrapST(TextureWrapMode.Repeat);
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                cubeWithTexture._tex[0].SetTextureWrapST(TextureWrapMode.MirroredRepeat);
                cubeWithTexture._tex[1].SetTextureWrapST(TextureWrapMode.MirroredRepeat);
                cubeWithTexture._tex[2].SetTextureWrapST(TextureWrapMode.MirroredRepeat);
                cubeWithTexture._tex[3].SetTextureWrapST(TextureWrapMode.MirroredRepeat);
                cubeWithTexture._tex[4].SetTextureWrapST(TextureWrapMode.MirroredRepeat);
                cubeWithTexture._tex[5].SetTextureWrapST(TextureWrapMode.MirroredRepeat);
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                cubeWithTexture._tex[0].SetTextureWrapST(TextureWrapMode.ClampToEdge);
                cubeWithTexture._tex[1].SetTextureWrapST(TextureWrapMode.ClampToEdge);
                cubeWithTexture._tex[2].SetTextureWrapST(TextureWrapMode.ClampToEdge);
                cubeWithTexture._tex[3].SetTextureWrapST(TextureWrapMode.ClampToEdge);
                cubeWithTexture._tex[4].SetTextureWrapST(TextureWrapMode.ClampToEdge);
                cubeWithTexture._tex[5].SetTextureWrapST(TextureWrapMode.ClampToEdge);
            }
            else if (comboBox1.SelectedIndex == 4)
            {
                cubeWithTexture._tex[0].SetTextureWrapST(TextureWrapMode.ClampToBorder, Color.Black);
                cubeWithTexture._tex[1].SetTextureWrapST(TextureWrapMode.ClampToBorder, Color.Red);
                cubeWithTexture._tex[2].SetTextureWrapST(TextureWrapMode.ClampToBorder, Color.Blue);
                cubeWithTexture._tex[3].SetTextureWrapST(TextureWrapMode.ClampToBorder, Color.Green);
                cubeWithTexture._tex[4].SetTextureWrapST(TextureWrapMode.ClampToBorder, Color.Yellow);
                cubeWithTexture._tex[5].SetTextureWrapST(TextureWrapMode.ClampToBorder, Color.White);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true) //GL_TEXTURE_MIN_FILTER���˲�������
            {
                if (checkBox3.Checked == true) //MipMapģʽ��
                {
                    if (comboBox2.Text.Contains("GL_NEAREST_MIPMAP_NEAREST") == true)
                    {
                        cubeWithTexture._tex[0].SetTextureMinFilter(TextureMinFilter.NearestMipmapNearest);
                        cubeWithTexture._tex[1].SetTextureMinFilter(TextureMinFilter.NearestMipmapNearest);
                        cubeWithTexture._tex[2].SetTextureMinFilter(TextureMinFilter.NearestMipmapNearest);
                        cubeWithTexture._tex[3].SetTextureMinFilter(TextureMinFilter.NearestMipmapNearest);
                        cubeWithTexture._tex[4].SetTextureMinFilter(TextureMinFilter.NearestMipmapNearest);
                        cubeWithTexture._tex[5].SetTextureMinFilter(TextureMinFilter.NearestMipmapNearest);
                    }
                    else if (comboBox2.Text.Contains("GL_LINEAR_MIPMAP_NEAREST") == true)
                    {
                        cubeWithTexture._tex[0].SetTextureMinFilter(TextureMinFilter.LinearMipmapNearest);
                        cubeWithTexture._tex[1].SetTextureMinFilter(TextureMinFilter.LinearMipmapNearest);
                        cubeWithTexture._tex[2].SetTextureMinFilter(TextureMinFilter.LinearMipmapNearest);
                        cubeWithTexture._tex[3].SetTextureMinFilter(TextureMinFilter.LinearMipmapNearest);
                        cubeWithTexture._tex[4].SetTextureMinFilter(TextureMinFilter.LinearMipmapNearest);
                        cubeWithTexture._tex[5].SetTextureMinFilter(TextureMinFilter.LinearMipmapNearest);
                    }
                    else if (comboBox2.Text.Contains("GL_NEAREST_MIPMAP_LINEAR") == true)
                    {
                        cubeWithTexture._tex[0].SetTextureMinFilter(TextureMinFilter.NearestMipmapLinear);
                        cubeWithTexture._tex[1].SetTextureMinFilter(TextureMinFilter.NearestMipmapLinear);
                        cubeWithTexture._tex[2].SetTextureMinFilter(TextureMinFilter.NearestMipmapLinear);
                        cubeWithTexture._tex[3].SetTextureMinFilter(TextureMinFilter.NearestMipmapLinear);
                        cubeWithTexture._tex[4].SetTextureMinFilter(TextureMinFilter.NearestMipmapLinear);
                        cubeWithTexture._tex[5].SetTextureMinFilter(TextureMinFilter.NearestMipmapLinear);
                    }
                    else if (comboBox2.Text.Contains("GL_LINEAR_MIPMAP_LINEAR") == true)
                    {
                        cubeWithTexture._tex[0].SetTextureMinFilter(TextureMinFilter.LinearMipmapLinear);
                        cubeWithTexture._tex[1].SetTextureMinFilter(TextureMinFilter.LinearMipmapLinear);
                        cubeWithTexture._tex[2].SetTextureMinFilter(TextureMinFilter.LinearMipmapLinear);
                        cubeWithTexture._tex[3].SetTextureMinFilter(TextureMinFilter.LinearMipmapLinear);
                        cubeWithTexture._tex[4].SetTextureMinFilter(TextureMinFilter.LinearMipmapLinear);
                        cubeWithTexture._tex[5].SetTextureMinFilter(TextureMinFilter.LinearMipmapLinear);

                    }
                }
                else
                {
                    if (comboBox2.Text.Contains("GL_NEAREST") == true)
                    {
                        cubeWithTexture._tex[0].SetTextureMinFilter(TextureMinFilter.Nearest);
                        cubeWithTexture._tex[1].SetTextureMinFilter(TextureMinFilter.Nearest);
                        cubeWithTexture._tex[2].SetTextureMinFilter(TextureMinFilter.Nearest);
                        cubeWithTexture._tex[3].SetTextureMinFilter(TextureMinFilter.Nearest);
                        cubeWithTexture._tex[4].SetTextureMinFilter(TextureMinFilter.Nearest);
                        cubeWithTexture._tex[5].SetTextureMinFilter(TextureMinFilter.Nearest);

                    }
                    else if (comboBox2.Text.Contains("GL_LINEAR") == true)
                    {
                        cubeWithTexture._tex[0].SetTextureMinFilter(TextureMinFilter.Linear);
                        cubeWithTexture._tex[1].SetTextureMinFilter(TextureMinFilter.Linear);
                        cubeWithTexture._tex[2].SetTextureMinFilter(TextureMinFilter.Linear);
                        cubeWithTexture._tex[3].SetTextureMinFilter(TextureMinFilter.Linear);
                        cubeWithTexture._tex[4].SetTextureMinFilter(TextureMinFilter.Linear);
                        cubeWithTexture._tex[5].SetTextureMinFilter(TextureMinFilter.Linear);

                    }
                }
            }
            else if (radioButton2.Checked == true)
            {
                if (comboBox2.Text.Contains("GL_NEAREST") == true)
                {
                    cubeWithTexture._tex[0].SetTextureMagFilter(TextureMagFilter.Nearest);
                    cubeWithTexture._tex[1].SetTextureMagFilter(TextureMagFilter.Nearest);
                    cubeWithTexture._tex[2].SetTextureMagFilter(TextureMagFilter.Nearest);
                    cubeWithTexture._tex[3].SetTextureMagFilter(TextureMagFilter.Nearest);
                    cubeWithTexture._tex[4].SetTextureMagFilter(TextureMagFilter.Nearest);
                    cubeWithTexture._tex[5].SetTextureMagFilter(TextureMagFilter.Nearest);

                }
                else if (comboBox2.Text.Contains("GL_LINEAR") == true)
                {
                    cubeWithTexture._tex[0].SetTextureMagFilter(TextureMagFilter.Nearest);
                    cubeWithTexture._tex[1].SetTextureMagFilter(TextureMagFilter.Nearest);
                    cubeWithTexture._tex[2].SetTextureMagFilter(TextureMagFilter.Nearest);
                    cubeWithTexture._tex[3].SetTextureMagFilter(TextureMagFilter.Nearest);
                    cubeWithTexture._tex[5].SetTextureMagFilter(TextureMagFilter.Nearest);

                }

            }
        }
    }

}

