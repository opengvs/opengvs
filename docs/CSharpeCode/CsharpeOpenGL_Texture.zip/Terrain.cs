﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenGLObject;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using Vec3f = OpenTK.Mathematics.Vector3;

namespace CsharpeOpenGL_Texture
{
    public class Terrain : VAO
    {
        public int rowsPointNumber = 20;
        public int columnsPointNumber = 20;

        int m_VertexNum = (10 - (-10)) * (10 - (-10)) * 6;//生成的顶点数量
        
        public Terrain(int rows, int columns) : base()
        {
            rowsPointNumber = rows;
            columns = columns;
            float[] tempVertex = new float[(2*rows)*(2* columns) * 6 * 6];// //float[6 * 20 * 20 * 6];


            int k = 0;
            for (int i = -rows; i < rows; i++)//for (int i = -10; i < 10; i++)
            {
                for (int j = -columns; j < columns; j++)//for (int j = -10; j < 10; j++)
                {
                    tempVertex[k++] = i; tempVertex[k++] = 0.0f; tempVertex[k++] = j;

                    tempVertex[k++] = 1.0f; tempVertex[k++] = 1.0f; tempVertex[k++] = 1.0f;

                    tempVertex[k++] = i + 1.0f; tempVertex[k++] = 0.0f; tempVertex[k++] = j + 1.0f;
                    tempVertex[k++] = 1.0f; tempVertex[k++] = 1.0f; tempVertex[k++] = 1.0f;
                    tempVertex[k++] = i + 1.0f; tempVertex[k++] = 0.0f; tempVertex[k++] = j;
                    tempVertex[k++] = 1.0f; tempVertex[k++] = 1.0f; tempVertex[k++] = 1.0f;
                    //1
                    tempVertex[k++] = i; tempVertex[k++] = 0.0f; tempVertex[k++] = j + 1;
                    tempVertex[k++] = 0.5f; tempVertex[k++] = 0.0f; tempVertex[k++] = 0.5f;

                    tempVertex[k++] = i + 1; tempVertex[k++] = 0.0f; tempVertex[k++] = j + 1;
                    tempVertex[k++] = 0.5f; tempVertex[k++] = 0.0f; tempVertex[k++] = 0.5f;

                    tempVertex[k++] = i; tempVertex[k++] = 0.0f; tempVertex[k++] = j;
                    tempVertex[k++] = 0.5f; tempVertex[k++] = 0.0f; tempVertex[k++] = 0.5f;
                }
            }
            m_VertexNum = k / 6;
            base.Bind();
            // VBO vVBO = base.AddVertexBufferObjectVector3(vertexList.ToArray(), (vertexList.Count * Vector3.SizeInBytes), 3, BufferUsageHint.StaticDraw, 0);
            VBO tVBO = base.AddVertexBufferObject<float>(tempVertex, sizeof(float) * tempVertex.Length, BufferUsageHint.StaticDraw, new int[] { 3, 3 });
            base.Unbind();
        }

        public override void Draw(Shader _shader)
        {
            this.Bind();
            //这里通过派生VAO的子类，实现具体的绘制功能

            GL.DrawArrays(PrimitiveType.Triangles, 0, m_VertexNum);

            this.Unbind();
        }
    };

}
