﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenTK;
using OpenTK.Graphics;
using OpenTK.Platform;
using OpenTK.Graphics.OpenGL4;
using System.Numerics;

namespace OpenGLObject
{
    public class Texture2D : IDisposable
    {
        public int _id;
        private bool disposedValue;

        static List<Tuple<string, Texture2D>> textList = new List<Tuple<string, Texture2D>>();
        public static Texture2D FindTexture(string fileName)
        {
            Texture2D  texture2D;
            foreach(Tuple<string, Texture2D> item in textList)
            {
                if( item.Item1 == fileName )
                {
                    texture2D = item.Item2;
                    return texture2D;
                }
            }
           
            return null;
        }
        public static void ReleaseAllTexture()
        {
            while (textList.Count > 0)
            {
                Texture2D  obj = textList[0].Item2;
                textList.RemoveAt(0);

                obj.Dispose();
            }
        }
        public Bitmap image;
        public bool isMipmap = true;
        public Texture2D(bool _isMipmap=true):base()
        {
            isMipmap = _isMipmap;
        }
        public Texture2D(string fileName, bool _isMipmap = true) :base()
        {
            isMipmap = _isMipmap;
            Load(fileName);
        }
     /*   public bool Load1(String fileName)
        {
            // stb_image loads from the top-left pixel, whereas OpenGL loads from the bottom-left, causing the texture to be flipped vertically.
            // This will correct that, making the texture display properly.
            StbImage.stbi_set_flip_vertically_on_load(1);
            // Load the image.
            ImageResult image = ImageResult.FromStream(File.OpenRead(fileName), ColorComponents.RedGreenBlueAlpha);
            
            // 生成纹理对象名称 
            GL.GenTextures(1, out _id);  ////Gl.glGenTextures(3, ID);
            // 创建纹理对象 
            GL.BindTexture(TextureTarget.Texture2D, _id);

            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba, image.Width, image.Height, 0, PixelFormat.Rgba, PixelType.UnsignedByte, image.Data);
            if (isMipmap == true)
            {
                GL.GenerateMipmap(GenerateMipmapTarget.Texture2D);
                GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.LinearMipmapLinear);
            }
            else
            {
                GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
                //TexParameter函数第一个参数是针对当前Content中的ActiveTexture对象
            }
            // 控制滤波 
            //GL.TextureParameter()//这个函数只能在openGL 4.5以后使用，第一个参数是ID，其他与TexParameter相同
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
            //   GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.Repeat);
            //    GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.Repeat);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.ClampToEdge);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.ClampToEdge);


            textList.Add(new Tuple<string, Texture2D>(fileName, this));
            return true;
        }*/
        public bool Load(String fileName)
        {
            ///原则上材质只应该在初始化时候载入一次，否则会影响性能
            if (image != null)
            {
                return true;
            }
            FileInfo file = new FileInfo(fileName);
            if (file.Exists == false)
            {
                MessageBox.Show("无法载入" + fileName);
                return false;
            }
            try
            {
                if (file.Extension.ToUpper() == ".TGA")
                {
                    ///C# 载入TGA 类，自行参考，这里不再列出
                    ImageTGA tga = new ImageTGA(fileName);
                    image = tga.Image;
                }
                else
                {
                    image = new Bitmap(fileName);
                }

            }
            catch (System.ArgumentException)
            {
                MessageBox.Show("无法载入" + fileName);
                return false;
            }

            if (image != null)
            {
                image.RotateFlip(RotateFlipType.RotateNoneFlipY);
                System.Drawing.Imaging.BitmapData bitmapdata;
                Rectangle rect = new Rectangle(0, 0, image.Width, image.Height);

                ///Nearest Linear MipMapped三个纹理实现，本文暂时不考虑
                bitmapdata = image.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb);// Format24bppRgb);



                /** 生成纹理对象名称 */
                GL.GenTextures(1, out _id);  ////Gl.glGenTextures(3, ID);
                /** 创建纹理对象 */
                GL.BindTexture(TextureTarget.Texture2D, _id );


                GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba, image.Width, image.Height, 0,
                       // OpenTK.Graphics.OpenGL.PixelFormat.Rgba, PixelType.UnsignedByte, bitmapdata.Scan0);
                       PixelFormat.Rgba, PixelType.UnsignedByte, bitmapdata.Scan0);
               
                
                if (isMipmap== true)
                {
                    GL.GenerateMipmap(GenerateMipmapTarget.Texture2D);
                    GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.LinearMipmapLinear);
                }
                else
                {
                    GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
                    //TexParameter函数第一个参数是针对当前Content中的ActiveTexture对象
                }
                /** 控制滤波 */
                //GL.TextureParameter()//这个函数只能在openGL 4.5以后使用，第一个参数是ID，其他与TexParameter相同
                GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
             //   GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.Repeat);
            //    GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.Repeat);
                GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.ClampToEdge);
                GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.ClampToEdge);


                textList.Add(new Tuple<string, Texture2D>(fileName, this));
               
                image.UnlockBits(bitmapdata);
            }
            return true;
        }
        public void setImage(Bitmap _image)
        {
            if (_image == null)
                return;

            if (image == _image)
                return;
            if(image != null)
                image.Dispose();

            image = _image;

            image.RotateFlip(RotateFlipType.RotateNoneFlipY);
            System.Drawing.Imaging.BitmapData bitmapdata;
            Rectangle rect = new Rectangle(0, 0, image.Width, image.Height);

            ///Nearest Linear MipMapped三个纹理实现，本文暂时不考虑
            bitmapdata = image.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb);// Format24bppRgb);


            if (_id > 0)
                GL.DeleteTexture(_id);

            /** 生成纹理对象名称 */
            GL.GenTextures(1, out _id);  ////Gl.glGenTextures(3, ID);
            /** 创建纹理对象 */
            GL.BindTexture(TextureTarget.Texture2D, _id);


            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba, image.Width, image.Height, 0,
                   OpenTK.Graphics.OpenGL4.PixelFormat.Rgba, PixelType.UnsignedByte, bitmapdata.Scan0);

            /** 控制滤波 */
            //GL.TextureParameter()//这个函数只能在openGL 4.5以后使用，第一个参数是ID，其他与TexParameter相同
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
            //TexParameter函数第一个参数是针对当前Content中的ActiveTexture对象
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.Repeat);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.Repeat);
            

            image.UnlockBits(bitmapdata);
        }
        public void SetTextureWrapST(TextureWrapMode _wrapMode,Color color = new Color() ) //Color color = new Color())
        {
            Bind();
            GL.TexParameter( TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)_wrapMode);//new int[] { (int)_wrapMode });
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)_wrapMode);//new int[] { (int)_wrapMode });
            if(_wrapMode == TextureWrapMode.ClampToBorder) //边缘颜色需要在指定特定颜色值
            {
                GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureBorderColor, new float[4] { color.R, color.G, color.B, color.A }); //GL_TEXTURE_BORDER_COLOR, borderColor);
            }
        }
        //存在Mipmap时可选参数{TextureMinFilter.LinearMipmapLinear,TextureMinFilter.LinearMipmapNearest,TextureMinFilter.NearestMipmapLinear,TextureMinFilter.NearestMipmapLinear} 
        //不使用Mipmap时{ TextureMinFilter.Nearest,TextureMinFilter.Linear}      
        public void SetTextureMinFilter(TextureMinFilter _Filter)//
        {
            Bind(); 
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)_Filter);
        }
        public void SetTextureMagFilter(TextureMagFilter _Filter)
        {
            Bind();
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)_Filter);
        }

        public void setMipMap(bool IsMipMap)
        {
            this.Bind();
            // 生成多级渐远纹理
            GL.GenerateMipmap(GenerateMipmapTarget.Texture2D);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.LinearMipmapLinear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
        }
        public void FreeImage()
          {
              // 释放内存 
              if (image != null)
              {
                   image.Dispose();
              }
            image = null;
          }
 
         protected virtual void Destory()
         {
            if(_id>0)
                GL.DeleteTexture(_id);

            FreeImage();
         }
        ~Texture2D()
        {
            // 不要更改此代码。请将清理代码放入“Dispose(bool disposing)”方法中
            Dispose(disposing: false);
        }

        public virtual void Bind(TextureUnit textureUnit= TextureUnit.Texture0)
        {
            GL.ActiveTexture(textureUnit);
            GL.BindTexture(TextureTarget.Texture2D, _id);
        }

        public virtual void Unbind(TextureUnit textureUnit = TextureUnit.Texture0)
        {
            GL.ActiveTexture(textureUnit);
            GL.BindTexture(TextureTarget.Texture2D, 0);
        }

        public int Id => _id;
        public void Dispose()
        {
            // 不要更改此代码。请将清理代码放入“Dispose(bool disposing)”方法中
            foreach (Tuple<string, Texture2D> obj in textList)
            {
                if (obj != null)
                {
                    if (obj.Item2 == this)
                    {
                        textList.Remove(obj);
                        break;
                    }
                }
            }

            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        //protected abstract void Destory();//子类必须重载Destory()函数


        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: 释放托管状态(托管对象)
                }

                // TODO: 释放未托管的资源(未托管的对象)并重写终结器
                Destory();
                // TODO: 将大型字段设置为 null
                disposedValue = true;
            }
        }
    }
}
