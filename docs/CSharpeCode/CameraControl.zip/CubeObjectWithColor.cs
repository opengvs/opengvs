﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenGLObject;
using OpenTK.Mathematics;
using OpenTK.Graphics.OpenGL4;
using OpenGLObject;

namespace CameraControl
{
    public class CubeObjectWithColor : VAO
    {
        public static float[] vertdata = {
                -0.8f, -0.8f,  -0.8f,//1
                0.8f, -0.8f,  -0.8f,//2
                0.8f, 0.8f,  -0.8f,//3
               -0.8f, 0.8f,  -0.8f,//4
               -0.8f, -0.8f,  0.8f,//5
                0.8f, -0.8f,  0.8f,//6
                0.8f, 0.8f,  0.8f,//7
               -0.8f, 0.8f,  0.8f //8
        };
        public static float[] colordata = { 1f, 0f, 0f,
                0f, 0f, 1f,
                0f,  1f, 0f,
                1f, 0f, 0f,
                0f, 0f, 1f,
                0f,  1f, 0f,
                1f, 0f, 0f,
                0f, 0f, 1f
             };
        public static byte[] indicedata = {
                //left
                0, 2, 1,
                0, 3, 2,
                //back
                1, 2, 6,
                6, 5, 1,
                //right
                4, 5, 6,
                6, 7, 4,
                //top
                2, 3, 6,
                6, 3, 7,
                //front
                0, 7, 3,
                0, 4, 7,
                //bottom
                0, 1, 5,
                0, 5, 4
            };
        public CubeObjectWithColor() : base()
        {
            base.Bind();
            base.AddVertexBufferObjectFloat(vertdata, sizeof(float) * vertdata.Length, 3, BufferUsageHint.StaticDraw, 0);
            base.AddVertexBufferObjectFloat(colordata, sizeof(float) * colordata.Length, 3, BufferUsageHint.StaticDraw, 1);
            base.SetElementBufferObject(indicedata, sizeof(byte) * indicedata.Length, BufferUsageHint.StaticDraw);

            base.Unbind();
        }
        static float time = 0.0f;
        private Vector3 _position = new Vector3(0.0f, 0.0f, 0.0f);
        public Vector3 Position { get { return _position; } set { _position = value; } }

        Matrix4 ModelMat = new Matrix4();
        public override Matrix4 getTransform()
        {
            time += 0.1f;
            //ModelMat = Matrix4.CreateScale(1.0f, 1.0f, 1.0f) * Matrix4.CreateFromQuaternion(
            //        Quaternion.FromEulerAngles(0.15f * time, 0.55f * time, 0f)) * Matrix4.CreateTranslation(5f, 1f, 0f);
            ModelMat = Matrix4.CreateScale(1.0f, 1.0f, 1.0f) * Matrix4.CreateFromQuaternion(
                    Quaternion.FromEulerAngles(0.15f * time, 0.55f * time, 0f)) * Matrix4.CreateTranslation(Position.X, Position.Y, Position.Z);

            return ModelMat;
        }


        public override void Draw(Shader _shader, Camera _camera)
        {
            base.Draw(_shader, _camera);

            GL.DrawElements(BeginMode.Triangles, 36, DrawElementsType.UnsignedByte, 0);
            // base.DrawElements(PrimitiveType.Triangles, 36, DrawElementsType.UnsignedByte);
        }
    }
}
