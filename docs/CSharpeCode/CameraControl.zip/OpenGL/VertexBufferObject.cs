﻿global using VBO = OpenGLObject.VertexBufferObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using OpenTK.Graphics;
using OpenTK.Platform;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;


namespace OpenGLObject
{
    public class VertexBufferObject : OpenglObject
    {
        public VertexBufferObject()
        {
            GL.GenBuffers(1, out _id);
        }

        public void GenBuffer()
        {
            if (_id < 1)
                _id = GL.GenBuffer();
        }

        public override void Bind()
        {
            GL.BindBuffer(BufferTarget.ArrayBuffer, _id);
        }

        public void SetData<T>(T[] data, int dataSize, BufferUsageHint usage, params int[] itemSize) where T : struct
        {
            GL.BufferData(BufferTarget.ArrayBuffer, dataSize, data, usage);
            var stride = itemSize.Sum(i => i * sizeof(float));

            var offset = 0;

            for (var i = 0; i < itemSize.Length; i++)
            {
                if (i > 0)
                    offset += itemSize[i - 1] * sizeof(float);
                GL.VertexAttribPointer(i, itemSize[i], VertexAttribPointerType.Float, false, stride, new IntPtr(offset));
                GL.EnableVertexAttribArray(i);
            }

        }
        public void setDataVector3(Vector3[] data, int dataSize, int itemSize, BufferUsageHint usage, int index)
        {

            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, dataSize, data, usage);
            GL.VertexAttribPointer(index, itemSize, VertexAttribPointerType.Float, false, itemSize * sizeof(float), 0);
            GL.EnableVertexAttribArray(index);

        }
        public void SetDataFloat(float[] data, int dataSize, int itemSize, BufferUsageHint usage, int index)
        {
            GL.BufferData(BufferTarget.ArrayBuffer, dataSize, data, usage);
            GL.VertexAttribPointer(index, itemSize, VertexAttribPointerType.Float, false, itemSize * sizeof(float), 0);
            GL.EnableVertexAttribArray(index);
        }

        public override void Unbind()
        {
            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
        }

        protected override void Destory()
        {
            GL.DeleteBuffers(1, ref _id);
        }
    }
}
