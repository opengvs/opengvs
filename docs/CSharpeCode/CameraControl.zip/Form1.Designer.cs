﻿namespace CameraControl
{
    partial class OpenTKMainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            openglView = new OpenGLObject.OpenGLView();
            timer1 = new System.Windows.Forms.Timer(components);
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            A33 = new Label();
            A32 = new Label();
            A31 = new Label();
            A30 = new Label();
            A23 = new Label();
            A22 = new Label();
            A21 = new Label();
            A20 = new Label();
            A13 = new Label();
            A12 = new Label();
            A11 = new Label();
            A10 = new Label();
            A03 = new Label();
            A02 = new Label();
            A01 = new Label();
            A00 = new Label();
            RotateFrontButton = new Button();
            RotateUpButton = new Button();
            RotateRightButton = new Button();
            CameraRotate_X = new TextBox();
            CameraRotate_Y = new TextBox();
            CameraRotate_Z = new TextBox();
            label8 = new Label();
            label9 = new Label();
            label13 = new Label();
            groupBox4 = new GroupBox();
            ChangeRotationZButton = new Button();
            ChangeRotationYButton = new Button();
            ChangeRotationXButton = new Button();
            CameraRotation_Z = new TextBox();
            CameraRotation_Y = new TextBox();
            CameraRotation_X = new TextBox();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            groupBox5 = new GroupBox();
            ChangePosZButton = new Button();
            ChangePosXButton = new Button();
            ChangePosYButton = new Button();
            CameraPos_Z = new TextBox();
            label17 = new Label();
            CameraPos_Y = new TextBox();
            label18 = new Label();
            CameraPos_X = new TextBox();
            label19 = new Label();
            tabPage3 = new TabPage();
            B33 = new Label();
            B32 = new Label();
            B31 = new Label();
            B30 = new Label();
            B23 = new Label();
            B22 = new Label();
            B21 = new Label();
            B20 = new Label();
            B13 = new Label();
            B12 = new Label();
            B11 = new Label();
            B10 = new Label();
            B03 = new Label();
            B02 = new Label();
            B01 = new Label();
            B00 = new Label();
            cameraFarPlaneButton = new Button();
            cameraFarPlane = new TextBox();
            label22 = new Label();
            cameraNearPlaneButton = new Button();
            cameraNearPlane = new TextBox();
            label21 = new Label();
            cameraAspectRatioButton = new Button();
            cameraAspectRatio = new TextBox();
            label20 = new Label();
            FOV_trackBar = new TrackBar();
            CameraFOV = new TextBox();
            label23 = new Label();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)FOV_trackBar).BeginInit();
            SuspendLayout();
            // 
            // openglView
            // 
            openglView.API = OpenTK.Windowing.Common.ContextAPI.OpenGL;
            openglView.APIVersion = new Version(3, 3, 0, 0);
            openglView.Dock = DockStyle.Left;
            openglView.Flags = OpenTK.Windowing.Common.ContextFlags.Default;
            openglView.IsEventDriven = true;
            openglView.Location = new Point(0, 0);
            openglView.Name = "openglView";
            openglView.Profile = OpenTK.Windowing.Common.ContextProfile.Core;
            openglView.SharedContext = null;
            openglView.Size = new Size(692, 544);
            openglView.TabIndex = 0;
            openglView.Paint += openglView_Paint;
            openglView.Resize += openglView_Resize;
            // 
            // timer1
            // 
            timer1.Interval = 50;
            timer1.Tick += timer1_Tick;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Location = new Point(698, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(288, 544);
            tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(A33);
            tabPage1.Controls.Add(A32);
            tabPage1.Controls.Add(A31);
            tabPage1.Controls.Add(A30);
            tabPage1.Controls.Add(A23);
            tabPage1.Controls.Add(A22);
            tabPage1.Controls.Add(A21);
            tabPage1.Controls.Add(A20);
            tabPage1.Controls.Add(A13);
            tabPage1.Controls.Add(A12);
            tabPage1.Controls.Add(A11);
            tabPage1.Controls.Add(A10);
            tabPage1.Controls.Add(A03);
            tabPage1.Controls.Add(A02);
            tabPage1.Controls.Add(A01);
            tabPage1.Controls.Add(A00);
            tabPage1.Controls.Add(RotateFrontButton);
            tabPage1.Controls.Add(RotateUpButton);
            tabPage1.Controls.Add(RotateRightButton);
            tabPage1.Controls.Add(CameraRotate_X);
            tabPage1.Controls.Add(CameraRotate_Y);
            tabPage1.Controls.Add(CameraRotate_Z);
            tabPage1.Controls.Add(label8);
            tabPage1.Controls.Add(label9);
            tabPage1.Controls.Add(label13);
            tabPage1.Controls.Add(groupBox4);
            tabPage1.Controls.Add(groupBox5);
            tabPage1.Location = new Point(4, 26);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(280, 514);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "相机变换及视矩阵";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // A33
            // 
            A33.AutoSize = true;
            A33.Location = new Point(170, 483);
            A33.Name = "A33";
            A33.Size = new Size(30, 17);
            A33.TabIndex = 30;
            A33.Text = "A00";
            // 
            // A32
            // 
            A32.AutoSize = true;
            A32.Location = new Point(122, 483);
            A32.Name = "A32";
            A32.Size = new Size(30, 17);
            A32.TabIndex = 29;
            A32.Text = "A00";
            // 
            // A31
            // 
            A31.AutoSize = true;
            A31.Location = new Point(77, 483);
            A31.Name = "A31";
            A31.Size = new Size(30, 17);
            A31.TabIndex = 28;
            A31.Text = "A00";
            // 
            // A30
            // 
            A30.AutoSize = true;
            A30.Location = new Point(32, 483);
            A30.Name = "A30";
            A30.Size = new Size(30, 17);
            A30.TabIndex = 27;
            A30.Text = "A00";
            // 
            // A23
            // 
            A23.AutoSize = true;
            A23.Location = new Point(170, 454);
            A23.Name = "A23";
            A23.Size = new Size(30, 17);
            A23.TabIndex = 26;
            A23.Text = "A00";
            // 
            // A22
            // 
            A22.AutoSize = true;
            A22.Location = new Point(122, 454);
            A22.Name = "A22";
            A22.Size = new Size(30, 17);
            A22.TabIndex = 25;
            A22.Text = "A00";
            // 
            // A21
            // 
            A21.AutoSize = true;
            A21.Location = new Point(77, 454);
            A21.Name = "A21";
            A21.Size = new Size(30, 17);
            A21.TabIndex = 24;
            A21.Text = "A00";
            // 
            // A20
            // 
            A20.AutoSize = true;
            A20.Location = new Point(29, 454);
            A20.Name = "A20";
            A20.Size = new Size(30, 17);
            A20.TabIndex = 23;
            A20.Text = "A00";
            // 
            // A13
            // 
            A13.AutoSize = true;
            A13.Location = new Point(170, 425);
            A13.Name = "A13";
            A13.Size = new Size(30, 17);
            A13.TabIndex = 22;
            A13.Text = "A00";
            // 
            // A12
            // 
            A12.AutoSize = true;
            A12.Location = new Point(122, 425);
            A12.Name = "A12";
            A12.Size = new Size(30, 17);
            A12.TabIndex = 21;
            A12.Text = "A00";
            // 
            // A11
            // 
            A11.AutoSize = true;
            A11.Location = new Point(77, 425);
            A11.Name = "A11";
            A11.Size = new Size(30, 17);
            A11.TabIndex = 20;
            A11.Text = "A00";
            // 
            // A10
            // 
            A10.AutoSize = true;
            A10.Location = new Point(28, 425);
            A10.Name = "A10";
            A10.Size = new Size(30, 17);
            A10.TabIndex = 19;
            A10.Text = "A00";
            // 
            // A03
            // 
            A03.AutoSize = true;
            A03.Location = new Point(170, 394);
            A03.Name = "A03";
            A03.Size = new Size(30, 17);
            A03.TabIndex = 18;
            A03.Text = "A00";
            // 
            // A02
            // 
            A02.AutoSize = true;
            A02.Location = new Point(122, 394);
            A02.Name = "A02";
            A02.Size = new Size(30, 17);
            A02.TabIndex = 17;
            A02.Text = "A00";
            // 
            // A01
            // 
            A01.AutoSize = true;
            A01.Location = new Point(77, 394);
            A01.Name = "A01";
            A01.Size = new Size(30, 17);
            A01.TabIndex = 16;
            A01.Text = "A00";
            // 
            // A00
            // 
            A00.AutoSize = true;
            A00.Location = new Point(28, 394);
            A00.Name = "A00";
            A00.Size = new Size(30, 17);
            A00.TabIndex = 15;
            A00.Text = "A00";
            // 
            // RotateFrontButton
            // 
            RotateFrontButton.Location = new Point(211, 351);
            RotateFrontButton.Margin = new Padding(2);
            RotateFrontButton.Name = "RotateFrontButton";
            RotateFrontButton.Size = new Size(58, 26);
            RotateFrontButton.TabIndex = 14;
            RotateFrontButton.Text = "执行";
            RotateFrontButton.UseVisualStyleBackColor = true;
            RotateFrontButton.Click += RotateFrontButton_Click;
            // 
            // RotateUpButton
            // 
            RotateUpButton.Location = new Point(212, 314);
            RotateUpButton.Margin = new Padding(2);
            RotateUpButton.Name = "RotateUpButton";
            RotateUpButton.Size = new Size(61, 27);
            RotateUpButton.TabIndex = 13;
            RotateUpButton.Text = "执行";
            RotateUpButton.UseVisualStyleBackColor = true;
            RotateUpButton.Click += RotateUpButton_Click;
            // 
            // RotateRightButton
            // 
            RotateRightButton.Location = new Point(212, 277);
            RotateRightButton.Margin = new Padding(2);
            RotateRightButton.Name = "RotateRightButton";
            RotateRightButton.Size = new Size(56, 24);
            RotateRightButton.TabIndex = 12;
            RotateRightButton.Text = "执行";
            RotateRightButton.UseVisualStyleBackColor = true;
            RotateRightButton.Click += RotateRightButton_Click;
            // 
            // CameraRotate_X
            // 
            CameraRotate_X.Location = new Point(122, 278);
            CameraRotate_X.Name = "CameraRotate_X";
            CameraRotate_X.Size = new Size(86, 23);
            CameraRotate_X.TabIndex = 11;
            CameraRotate_X.Text = "0";
            // 
            // CameraRotate_Y
            // 
            CameraRotate_Y.Location = new Point(122, 316);
            CameraRotate_Y.Name = "CameraRotate_Y";
            CameraRotate_Y.Size = new Size(85, 23);
            CameraRotate_Y.TabIndex = 10;
            CameraRotate_Y.Text = "0";
            // 
            // CameraRotate_Z
            // 
            CameraRotate_Z.Location = new Point(122, 352);
            CameraRotate_Z.Name = "CameraRotate_Z";
            CameraRotate_Z.Size = new Size(86, 23);
            CameraRotate_Z.TabIndex = 9;
            CameraRotate_Z.Text = "0";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(8, 352);
            label8.Margin = new Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new Size(109, 17);
            label8.TabIndex = 8;
            label8.Text = "RotateFrontAngle";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(11, 315);
            label9.Margin = new Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new Size(96, 17);
            label9.TabIndex = 7;
            label9.Text = "RotateUpAngle";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(8, 277);
            label13.Margin = new Padding(2, 0, 2, 0);
            label13.Name = "label13";
            label13.Size = new Size(109, 17);
            label13.TabIndex = 6;
            label13.Text = "RotateRightAngle";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(ChangeRotationZButton);
            groupBox4.Controls.Add(ChangeRotationYButton);
            groupBox4.Controls.Add(ChangeRotationXButton);
            groupBox4.Controls.Add(CameraRotation_Z);
            groupBox4.Controls.Add(CameraRotation_Y);
            groupBox4.Controls.Add(CameraRotation_X);
            groupBox4.Controls.Add(label14);
            groupBox4.Controls.Add(label15);
            groupBox4.Controls.Add(label16);
            groupBox4.Location = new Point(1, 129);
            groupBox4.Margin = new Padding(2);
            groupBox4.Name = "groupBox4";
            groupBox4.Padding = new Padding(2);
            groupBox4.Size = new Size(272, 133);
            groupBox4.TabIndex = 2;
            groupBox4.TabStop = false;
            groupBox4.Text = "Rotation";
            // 
            // ChangeRotationZButton
            // 
            ChangeRotationZButton.Image = Properties.Resources.上下;
            ChangeRotationZButton.Location = new Point(221, 94);
            ChangeRotationZButton.Margin = new Padding(2);
            ChangeRotationZButton.Name = "ChangeRotationZButton";
            ChangeRotationZButton.Size = new Size(30, 35);
            ChangeRotationZButton.TabIndex = 28;
            ChangeRotationZButton.UseVisualStyleBackColor = true;
            ChangeRotationZButton.MouseDown += ChangeRotationZButton_MouseDown;
            // 
            // ChangeRotationYButton
            // 
            ChangeRotationYButton.Image = Properties.Resources.上下;
            ChangeRotationYButton.Location = new Point(223, 53);
            ChangeRotationYButton.Margin = new Padding(2);
            ChangeRotationYButton.Name = "ChangeRotationYButton";
            ChangeRotationYButton.Size = new Size(31, 36);
            ChangeRotationYButton.TabIndex = 27;
            ChangeRotationYButton.UseVisualStyleBackColor = true;
            ChangeRotationYButton.MouseDown += ChangeRotationYButton_MouseDown;
            // 
            // ChangeRotationXButton
            // 
            ChangeRotationXButton.Image = Properties.Resources.上下;
            ChangeRotationXButton.Location = new Point(223, 15);
            ChangeRotationXButton.Margin = new Padding(2);
            ChangeRotationXButton.Name = "ChangeRotationXButton";
            ChangeRotationXButton.Size = new Size(31, 33);
            ChangeRotationXButton.TabIndex = 26;
            ChangeRotationXButton.UseVisualStyleBackColor = true;
            ChangeRotationXButton.MouseDown += ChangeRotationXButton_MouseDown;
            // 
            // CameraRotation_Z
            // 
            CameraRotation_Z.Location = new Point(55, 102);
            CameraRotation_Z.Name = "CameraRotation_Z";
            CameraRotation_Z.Size = new Size(161, 23);
            CameraRotation_Z.TabIndex = 5;
            // 
            // CameraRotation_Y
            // 
            CameraRotation_Y.Location = new Point(55, 60);
            CameraRotation_Y.Name = "CameraRotation_Y";
            CameraRotation_Y.Size = new Size(163, 23);
            CameraRotation_Y.TabIndex = 4;
            // 
            // CameraRotation_X
            // 
            CameraRotation_X.Location = new Point(55, 21);
            CameraRotation_X.Name = "CameraRotation_X";
            CameraRotation_X.Size = new Size(163, 23);
            CameraRotation_X.TabIndex = 3;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(9, 101);
            label14.Margin = new Padding(2, 0, 2, 0);
            label14.Name = "label14";
            label14.Size = new Size(48, 17);
            label14.TabIndex = 2;
            label14.Text = "AngleZ";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(9, 60);
            label15.Margin = new Padding(2, 0, 2, 0);
            label15.Name = "label15";
            label15.Size = new Size(48, 17);
            label15.TabIndex = 1;
            label15.Text = "AngleY";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(9, 23);
            label16.Margin = new Padding(2, 0, 2, 0);
            label16.Name = "label16";
            label16.Size = new Size(49, 17);
            label16.TabIndex = 0;
            label16.Text = "AngleX";
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(ChangePosZButton);
            groupBox5.Controls.Add(ChangePosXButton);
            groupBox5.Controls.Add(ChangePosYButton);
            groupBox5.Controls.Add(CameraPos_Z);
            groupBox5.Controls.Add(label17);
            groupBox5.Controls.Add(CameraPos_Y);
            groupBox5.Controls.Add(label18);
            groupBox5.Controls.Add(CameraPos_X);
            groupBox5.Controls.Add(label19);
            groupBox5.Location = new Point(0, 0);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(273, 128);
            groupBox5.TabIndex = 1;
            groupBox5.TabStop = false;
            groupBox5.Text = "Position";
            // 
            // ChangePosZButton
            // 
            ChangePosZButton.Image = Properties.Resources.上下;
            ChangePosZButton.Location = new Point(224, 88);
            ChangePosZButton.Margin = new Padding(2);
            ChangePosZButton.Name = "ChangePosZButton";
            ChangePosZButton.Size = new Size(28, 37);
            ChangePosZButton.TabIndex = 26;
            ChangePosZButton.UseVisualStyleBackColor = true;
            ChangePosZButton.MouseDown += ChangePosZButton_MouseDown;
            // 
            // ChangePosXButton
            // 
            ChangePosXButton.Image = Properties.Resources.上下;
            ChangePosXButton.Location = new Point(224, 13);
            ChangePosXButton.Margin = new Padding(2);
            ChangePosXButton.Name = "ChangePosXButton";
            ChangePosXButton.Size = new Size(28, 35);
            ChangePosXButton.TabIndex = 25;
            ChangePosXButton.UseVisualStyleBackColor = true;
            ChangePosXButton.MouseDown += ChangePosXButton_MouseDown;
            // 
            // ChangePosYButton
            // 
            ChangePosYButton.Image = Properties.Resources.上下;
            ChangePosYButton.Location = new Point(224, 49);
            ChangePosYButton.Margin = new Padding(2);
            ChangePosYButton.Name = "ChangePosYButton";
            ChangePosYButton.Size = new Size(28, 36);
            ChangePosYButton.TabIndex = 24;
            ChangePosYButton.UseVisualStyleBackColor = true;
            ChangePosYButton.MouseDown += ChangePosYButton_MouseDown;
            // 
            // CameraPos_Z
            // 
            CameraPos_Z.Location = new Point(32, 95);
            CameraPos_Z.Name = "CameraPos_Z";
            CameraPos_Z.Size = new Size(187, 23);
            CameraPos_Z.TabIndex = 5;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(11, 102);
            label17.Name = "label17";
            label17.Size = new Size(15, 17);
            label17.TabIndex = 4;
            label17.Text = "Z";
            // 
            // CameraPos_Y
            // 
            CameraPos_Y.Location = new Point(32, 59);
            CameraPos_Y.Name = "CameraPos_Y";
            CameraPos_Y.Size = new Size(187, 23);
            CameraPos_Y.TabIndex = 3;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(11, 59);
            label18.Name = "label18";
            label18.Size = new Size(15, 17);
            label18.TabIndex = 2;
            label18.Text = "Y";
            // 
            // CameraPos_X
            // 
            CameraPos_X.Location = new Point(32, 19);
            CameraPos_X.Name = "CameraPos_X";
            CameraPos_X.Size = new Size(187, 23);
            CameraPos_X.TabIndex = 1;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(10, 22);
            label19.Name = "label19";
            label19.Size = new Size(16, 17);
            label19.TabIndex = 0;
            label19.Text = "X";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(B33);
            tabPage3.Controls.Add(B32);
            tabPage3.Controls.Add(B31);
            tabPage3.Controls.Add(B30);
            tabPage3.Controls.Add(B23);
            tabPage3.Controls.Add(B22);
            tabPage3.Controls.Add(B21);
            tabPage3.Controls.Add(B20);
            tabPage3.Controls.Add(B13);
            tabPage3.Controls.Add(B12);
            tabPage3.Controls.Add(B11);
            tabPage3.Controls.Add(B10);
            tabPage3.Controls.Add(B03);
            tabPage3.Controls.Add(B02);
            tabPage3.Controls.Add(B01);
            tabPage3.Controls.Add(B00);
            tabPage3.Controls.Add(cameraFarPlaneButton);
            tabPage3.Controls.Add(cameraFarPlane);
            tabPage3.Controls.Add(label22);
            tabPage3.Controls.Add(cameraNearPlaneButton);
            tabPage3.Controls.Add(cameraNearPlane);
            tabPage3.Controls.Add(label21);
            tabPage3.Controls.Add(cameraAspectRatioButton);
            tabPage3.Controls.Add(cameraAspectRatio);
            tabPage3.Controls.Add(label20);
            tabPage3.Controls.Add(FOV_trackBar);
            tabPage3.Controls.Add(CameraFOV);
            tabPage3.Controls.Add(label23);
            tabPage3.Location = new Point(4, 26);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(280, 514);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "投影变换及投影矩阵";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // B33
            // 
            B33.AutoSize = true;
            B33.Location = new Point(184, 425);
            B33.Name = "B33";
            B33.Size = new Size(30, 17);
            B33.TabIndex = 57;
            B33.Text = "B33";
            // 
            // B32
            // 
            B32.AutoSize = true;
            B32.Location = new Point(136, 425);
            B32.Name = "B32";
            B32.Size = new Size(30, 17);
            B32.TabIndex = 56;
            B32.Text = "B22";
            // 
            // B31
            // 
            B31.AutoSize = true;
            B31.Location = new Point(91, 425);
            B31.Name = "B31";
            B31.Size = new Size(30, 17);
            B31.TabIndex = 55;
            B31.Text = "B31";
            // 
            // B30
            // 
            B30.AutoSize = true;
            B30.Location = new Point(42, 425);
            B30.Name = "B30";
            B30.Size = new Size(30, 17);
            B30.TabIndex = 54;
            B30.Text = "B30";
            // 
            // B23
            // 
            B23.AutoSize = true;
            B23.Location = new Point(184, 396);
            B23.Name = "B23";
            B23.Size = new Size(30, 17);
            B23.TabIndex = 53;
            B23.Text = "B23";
            // 
            // B22
            // 
            B22.AutoSize = true;
            B22.Location = new Point(136, 396);
            B22.Name = "B22";
            B22.Size = new Size(30, 17);
            B22.TabIndex = 52;
            B22.Text = "B22";
            // 
            // B21
            // 
            B21.AutoSize = true;
            B21.Location = new Point(91, 396);
            B21.Name = "B21";
            B21.Size = new Size(30, 17);
            B21.TabIndex = 51;
            B21.Text = "B21";
            // 
            // B20
            // 
            B20.AutoSize = true;
            B20.Location = new Point(43, 396);
            B20.Name = "B20";
            B20.Size = new Size(30, 17);
            B20.TabIndex = 50;
            B20.Text = "B20";
            // 
            // B13
            // 
            B13.AutoSize = true;
            B13.Location = new Point(184, 367);
            B13.Name = "B13";
            B13.Size = new Size(30, 17);
            B13.TabIndex = 49;
            B13.Text = "B13";
            // 
            // B12
            // 
            B12.AutoSize = true;
            B12.Location = new Point(136, 367);
            B12.Name = "B12";
            B12.Size = new Size(30, 17);
            B12.TabIndex = 48;
            B12.Text = "B12";
            // 
            // B11
            // 
            B11.AutoSize = true;
            B11.Location = new Point(91, 367);
            B11.Name = "B11";
            B11.Size = new Size(30, 17);
            B11.TabIndex = 47;
            B11.Text = "B11";
            // 
            // B10
            // 
            B10.AutoSize = true;
            B10.Location = new Point(42, 367);
            B10.Name = "B10";
            B10.Size = new Size(30, 17);
            B10.TabIndex = 46;
            B10.Text = "B10";
            // 
            // B03
            // 
            B03.AutoSize = true;
            B03.Location = new Point(184, 336);
            B03.Name = "B03";
            B03.Size = new Size(30, 17);
            B03.TabIndex = 45;
            B03.Text = "B03";
            // 
            // B02
            // 
            B02.AutoSize = true;
            B02.Location = new Point(136, 336);
            B02.Name = "B02";
            B02.Size = new Size(30, 17);
            B02.TabIndex = 44;
            B02.Text = "B02";
            // 
            // B01
            // 
            B01.AutoSize = true;
            B01.Location = new Point(91, 336);
            B01.Name = "B01";
            B01.Size = new Size(30, 17);
            B01.TabIndex = 43;
            B01.Text = "B01";
            // 
            // B00
            // 
            B00.AutoSize = true;
            B00.Location = new Point(42, 336);
            B00.Name = "B00";
            B00.Size = new Size(30, 17);
            B00.TabIndex = 42;
            B00.Text = "B00";
            // 
            // cameraFarPlaneButton
            // 
            cameraFarPlaneButton.Image = Properties.Resources.上下;
            cameraFarPlaneButton.Location = new Point(233, 234);
            cameraFarPlaneButton.Margin = new Padding(2);
            cameraFarPlaneButton.Name = "cameraFarPlaneButton";
            cameraFarPlaneButton.Size = new Size(38, 37);
            cameraFarPlaneButton.TabIndex = 41;
            cameraFarPlaneButton.UseVisualStyleBackColor = true;
            cameraFarPlaneButton.MouseDown += cameraFarPlaneButton_MouseDown;
            // 
            // cameraFarPlane
            // 
            cameraFarPlane.Location = new Point(83, 241);
            cameraFarPlane.Name = "cameraFarPlane";
            cameraFarPlane.Size = new Size(147, 23);
            cameraFarPlane.TabIndex = 40;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(9, 244);
            label22.Name = "label22";
            label22.Size = new Size(68, 17);
            label22.TabIndex = 39;
            label22.Text = "远平面距离";
            // 
            // cameraNearPlaneButton
            // 
            cameraNearPlaneButton.Image = Properties.Resources.上下;
            cameraNearPlaneButton.Location = new Point(232, 171);
            cameraNearPlaneButton.Margin = new Padding(2);
            cameraNearPlaneButton.Name = "cameraNearPlaneButton";
            cameraNearPlaneButton.Size = new Size(38, 36);
            cameraNearPlaneButton.TabIndex = 38;
            cameraNearPlaneButton.UseVisualStyleBackColor = true;
            cameraNearPlaneButton.MouseDown += cameraNearPlaneButton_MouseDown;
            // 
            // cameraNearPlane
            // 
            cameraNearPlane.Location = new Point(80, 178);
            cameraNearPlane.Name = "cameraNearPlane";
            cameraNearPlane.Size = new Size(147, 23);
            cameraNearPlane.TabIndex = 37;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(9, 184);
            label21.Name = "label21";
            label21.Size = new Size(68, 17);
            label21.TabIndex = 36;
            label21.Text = "近平面距离";
            // 
            // cameraAspectRatioButton
            // 
            cameraAspectRatioButton.Image = Properties.Resources.上下;
            cameraAspectRatioButton.Location = new Point(230, 118);
            cameraAspectRatioButton.Margin = new Padding(2);
            cameraAspectRatioButton.Name = "cameraAspectRatioButton";
            cameraAspectRatioButton.Size = new Size(38, 36);
            cameraAspectRatioButton.TabIndex = 35;
            cameraAspectRatioButton.UseVisualStyleBackColor = true;
            cameraAspectRatioButton.MouseDown += cameraAspectRatioButton_MouseDown;
            // 
            // cameraAspectRatio
            // 
            cameraAspectRatio.Location = new Point(81, 125);
            cameraAspectRatio.Name = "cameraAspectRatio";
            cameraAspectRatio.Size = new Size(146, 23);
            cameraAspectRatio.TabIndex = 7;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(9, 128);
            label20.Name = "label20";
            label20.Size = new Size(73, 17);
            label20.TabIndex = 6;
            label20.Text = "高度/宽度比";
            // 
            // FOV_trackBar
            // 
            FOV_trackBar.Location = new Point(9, 43);
            FOV_trackBar.Maximum = 160;
            FOV_trackBar.Minimum = 1;
            FOV_trackBar.Name = "FOV_trackBar";
            FOV_trackBar.Size = new Size(262, 45);
            FOV_trackBar.TabIndex = 5;
            FOV_trackBar.TickStyle = TickStyle.None;
            FOV_trackBar.Value = 120;
            FOV_trackBar.ValueChanged += FOV_trackBar_ValueChanged;
            // 
            // CameraFOV
            // 
            CameraFOV.Location = new Point(120, 14);
            CameraFOV.Name = "CameraFOV";
            CameraFOV.Size = new Size(136, 23);
            CameraFOV.TabIndex = 1;
            CameraFOV.Text = "120";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(17, 17);
            label23.Name = "label23";
            label23.Size = new Size(104, 17);
            label23.TabIndex = 0;
            label23.Text = "相机垂直方向张角";
            // 
            // OpenTKMainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(981, 544);
            Controls.Add(tabControl1);
            Controls.Add(openglView);
            Margin = new Padding(2);
            Name = "OpenTKMainForm";
            Text = "OpenTKMainForm";
            FormClosed += OpenTKMainForm_FormClosed;
            Load += OpenTKMainForm_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)FOV_trackBar).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private OpenGLObject.OpenGLView openglView;
        private System.Windows.Forms.Timer timer1;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private Button RotateFrontButton;
        private Button RotateUpButton;
        private TextBox CameraRotate_Y;
        private TextBox CameraRotate_Z;
        private Label label8;
        private Label label9;
        private GroupBox groupBox4;
        private Button ChangeRotationZButton;
        private Button ChangeRotationYButton;
        private Button ChangeRotationXButton;
        private TextBox CameraRotation_Z;
        private TextBox CameraRotation_Y;
        private TextBox CameraRotation_X;
        private Label label14;
        private Label label15;
        private Label label16;
        private GroupBox groupBox5;
        private Button ChangePosZButton;
        private Button ChangePosXButton;
        private Button ChangePosYButton;
        private TextBox CameraPos_Z;
        private Label label17;
        private TextBox CameraPos_Y;
        private Label label18;
        private TextBox CameraPos_X;
        private Label label19;
        private TabPage tabPage3;
        private Button cameraFarPlaneButton;
        private TextBox cameraFarPlane;
        private Label label22;
        private Button cameraNearPlaneButton;
        private TextBox cameraNearPlane;
        private Label label21;
        private Button cameraAspectRatioButton;
        private TextBox cameraAspectRatio;
        private Label label20;
        private TrackBar FOV_trackBar;
        private TextBox CameraFOV;
        private Label label23;
        private Button RotateRightButton;
        private TextBox CameraRotate_X;
        private Label label13;
        private Label A33;
        private Label A32;
        private Label A31;
        private Label A30;
        private Label A23;
        private Label A22;
        private Label A21;
        private Label A20;
        private Label A13;
        private Label A12;
        private Label A11;
        private Label A10;
        private Label A03;
        private Label A02;
        private Label A01;
        private Label A00;
        private Label B33;
        private Label B32;
        private Label B31;
        private Label B30;
        private Label B23;
        private Label B22;
        private Label B21;
        private Label B20;
        private Label B13;
        private Label B12;
        private Label B11;
        private Label B10;
        private Label B03;
        private Label B02;
        private Label B01;
        private Label B00;
    }
}
