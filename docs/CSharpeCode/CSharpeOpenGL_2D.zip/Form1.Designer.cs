﻿namespace CSharpeOpenGL_2D
{
    partial class OpenTKMainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            openglView = new OpenGLObject.OpenGLView();
            timer1 = new System.Windows.Forms.Timer(components);
            label5 = new Label();
            label1 = new Label();
            label3 = new Label();
            label2 = new Label();
            label4 = new Label();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            button2 = new Button();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // openglView
            // 
            openglView.API = OpenTK.Windowing.Common.ContextAPI.OpenGL;
            openglView.APIVersion = new Version(3, 3, 0, 0);
            openglView.Flags = OpenTK.Windowing.Common.ContextFlags.Default;
            openglView.IsEventDriven = true;
            openglView.Location = new Point(0, 0);
            openglView.Margin = new Padding(4, 3, 4, 3);
            openglView.Name = "openglView";
            openglView.Profile = OpenTK.Windowing.Common.ContextProfile.Core;
            openglView.SharedContext = null;
            openglView.Size = new Size(724, 560);
            openglView.TabIndex = 0;
            openglView.Paint += openglView_Paint;
            openglView.Resize += openglView_Resize;
            // 
            // timer1
            // 
            timer1.Interval = 50;
            timer1.Tick += timer1_Tick;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft YaHei UI", 14F);
            label5.Location = new Point(741, 351);
            label5.Name = "label5";
            label5.Size = new Size(92, 31);
            label5.TabIndex = 31;
            label5.Text = "缩放(Y)";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft YaHei UI", 14F);
            label1.Location = new Point(741, 272);
            label1.Name = "label1";
            label1.Size = new Size(93, 31);
            label1.TabIndex = 35;
            label1.Text = "缩放(X)";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft YaHei UI", 14F);
            label3.Location = new Point(741, 202);
            label3.Name = "label3";
            label3.Size = new Size(92, 31);
            label3.TabIndex = 34;
            label3.Text = "平移(Y)";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft YaHei UI", 14F);
            label2.Location = new Point(741, 132);
            label2.Name = "label2";
            label2.Size = new Size(93, 31);
            label2.TabIndex = 33;
            label2.Text = "平移(X)";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft YaHei UI", 14F);
            label4.Location = new Point(731, 61);
            label4.Name = "label4";
            label4.Size = new Size(117, 31);
            label4.TabIndex = 32;
            label4.Text = "旋转角(Z)";
            // 
            // button6
            // 
            button6.Image = Properties.Resources.无标题;
            button6.Location = new Point(979, 344);
            button6.Margin = new Padding(3, 2, 3, 2);
            button6.Name = "button6";
            button6.Size = new Size(31, 39);
            button6.TabIndex = 45;
            button6.UseVisualStyleBackColor = true;
            button6.MouseDown += button6_MouseDown;
            // 
            // button5
            // 
            button5.Image = Properties.Resources.无标题;
            button5.Location = new Point(979, 272);
            button5.Margin = new Padding(3, 2, 3, 2);
            button5.Name = "button5";
            button5.Size = new Size(31, 39);
            button5.TabIndex = 44;
            button5.UseVisualStyleBackColor = true;
            button5.MouseDown += button5_MouseDown;
            // 
            // button4
            // 
            button4.Image = Properties.Resources.无标题;
            button4.Location = new Point(979, 204);
            button4.Margin = new Padding(3, 2, 3, 2);
            button4.Name = "button4";
            button4.Size = new Size(31, 39);
            button4.TabIndex = 43;
            button4.UseVisualStyleBackColor = true;
            button4.MouseDown += button4_MouseDown;
            // 
            // button3
            // 
            button3.Image = Properties.Resources.无标题;
            button3.Location = new Point(979, 130);
            button3.Margin = new Padding(3, 2, 3, 2);
            button3.Name = "button3";
            button3.Size = new Size(31, 39);
            button3.TabIndex = 42;
            button3.UseVisualStyleBackColor = true;
            button3.MouseDown += button3_MouseDown;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Microsoft YaHei UI", 14F);
            textBox4.Location = new Point(842, 272);
            textBox4.Margin = new Padding(3, 2, 3, 2);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(135, 37);
            textBox4.TabIndex = 41;
            textBox4.Text = "1";
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Microsoft YaHei UI", 14F);
            textBox5.Location = new Point(838, 346);
            textBox5.Margin = new Padding(3, 2, 3, 2);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(135, 37);
            textBox5.TabIndex = 40;
            textBox5.Text = "1";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Microsoft YaHei UI", 14F);
            textBox3.Location = new Point(838, 202);
            textBox3.Margin = new Padding(3, 2, 3, 2);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(135, 37);
            textBox3.TabIndex = 39;
            textBox3.Text = "0";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Microsoft YaHei UI", 14F);
            textBox2.Location = new Point(842, 132);
            textBox2.Margin = new Padding(3, 2, 3, 2);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(135, 37);
            textBox2.TabIndex = 38;
            textBox2.Text = "0";
            // 
            // button2
            // 
            button2.Image = Properties.Resources.无标题;
            button2.Location = new Point(983, 60);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(28, 39);
            button2.TabIndex = 37;
            button2.UseVisualStyleBackColor = true;
            button2.MouseDown += button2_MouseDown;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Microsoft YaHei UI", 14F);
            textBox1.Location = new Point(842, 58);
            textBox1.Margin = new Padding(3, 2, 3, 2);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(135, 37);
            textBox1.TabIndex = 36;
            textBox1.Text = "0";
            // 
            // OpenTKMainForm
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1013, 564);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(textBox4);
            Controls.Add(textBox5);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(button2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(openglView);
            Margin = new Padding(2);
            Name = "OpenTKMainForm";
            Text = "OpenTKMainForm";
            FormClosed += OpenTKMainForm_FormClosed;
            Load += OpenTKMainForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private OpenGLObject.OpenGLView openglView;
        private System.Windows.Forms.Timer timer1;
        private Label label5;
        private Label label1;
        private Label label3;
        private Label label2;
        private Label label4;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox3;
        private TextBox textBox2;
        private Button button2;
        private TextBox textBox1;
    }
}
