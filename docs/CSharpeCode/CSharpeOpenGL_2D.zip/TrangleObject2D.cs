﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using OpenGLObject;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using Vec3f = OpenTK.Mathematics.Vector3;


namespace CSharpeOpenGL_2D
{
    public class TrangleObject2D : VAO
    {
        static float[] vertexData = { 
                       -0.5f, -0.5f ,0.0f,1.0f, 0.0f,0.0f,
                       0.5f, -0.5f ,0.0f,0.0f, 1.0f,0.0f,
                       0.0f,  0.5f ,0.0f,0.0f, 0.0f,1.0f
                   };

        static float[] positions = {
                       -0.5f, -0.5f ,0.0f,
                       0.5f, -0.5f ,0.0f,
                       0.0f,  0.5f ,0.0f
                   };
        static float[] colors = {
                      1.0f, 0.0f,0.0f,
                      0.0f, 1.0f,0.0f,
                      0.0f, 0.0f,1.0f
                  };
        public static byte[] indicedata = {
                //left
                0, 1, 2

            };
        public Vec3f _scale = new Vec3f(1f, 1f, 1f);

        public Vec3f _Move = new Vec3f(0f);

        public Vec3f _Rotate = new Vec3f(0f);


        public TrangleObject2D():base()
        {
            base.Bind();
            VBO _vbo1 = base.AddVertexBufferObjectFloat(positions, sizeof(float) * positions.Length, 3, OpenTK.Graphics.OpenGL4.BufferUsageHint.StaticDraw, 0);
            VBO _vbo2 = base.AddVertexBufferObjectFloat(colors, sizeof(float) * colors.Length, 3, BufferUsageHint.StaticDraw, 1);
           // base.AddVertexBufferObject<float>(vertexData, sizeof(float) * vertexData.Length, BufferUsageHint.StaticDraw,new [] { 3, 3} );


            EBO _ebo = base.SetElementBufferObject(indicedata, sizeof(byte) * indicedata.Length, BufferUsageHint.StaticDraw);
            base.Unbind();

            //定义完成VBO和EBO，并与VAO对象的缓冲区绑定后，如果后续程序不需要动态修改数据，这里可以删除VBO和EBO了
            //注意：我们设计AddVertexBufferObjectFloat和SetElementBufferObject内部，没有对生成的VBO和EBO对象进行删除
            //      目的是后续程序可能需要动态修改数据：glBufferSubData/glMapBuffer/glCopyBufferSubData
           // _ebo.Dispose();
            //_vbo1.Dispose();
            //_vbo2.Dispose();

        }

        public override void OpenGLDraw(Shader _shader)
        {
            base.Bind();
            base.OpenGLDraw(_shader);

            Matrix3 mat = Matrix3.CreateRotationZ(MathHelper.DegreesToRadians(_Rotate.Z));
            mat.M31 = _Move.X;
            mat.M32 = _Move.Y;

            mat.M11 *= _scale.X;
            mat.M22 *= _scale.Y;

            _shader.SetMatrix3("_transForm", mat);
            GL.DrawArrays(PrimitiveType.Triangles, 0, 3);
            // GL.DrawElements(PrimitiveType.Triangles, 3, DrawElementsType.UnsignedByte, 0);
        }
    }
}
