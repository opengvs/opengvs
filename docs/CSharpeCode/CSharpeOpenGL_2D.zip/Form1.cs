
using OpenGLObject;
using OpenTK.Graphics.OpenGL;
using CSharpeOpenGL_2D;

namespace CSharpeOpenGL_2D
{
    public partial class OpenTKMainForm : Form
    {
        static public string vs2D_ShderString = "#version 460 core                       \n" +
                 " layout(location = 0) in vec3 aPos;                                  \n" +
                 " layout(location = 1) in vec3 aColor;                                \n" +
                 " out vec3 passColor;                                                 \n" +
                 " uniform mat3   _transForm;                                         \n" +  //ע�⣺uniform���������main()������û�б�ʹ�ã����������Զ�ɾ��
                 " void main()                                                         \n" +
                 " {                                                                   \n" +
                 "      vec3 tempV3 = _transForm*vec3(aPos.x, aPos.y,1);               \n" +
                 "      gl_Position = vec4(tempV3.x, tempV3.y, 0, 1.0);                \n" +  //                                                                                              //  "      passColor = vec3(aColor[0],randomColor[1],aColor[2]);          \n" +  //vec3(aColor.x,aColor.y,randomColor[0]);\n
                 "      passColor = vec3(aColor.x,aColor.y,aColor.z);                  \n" +
                 " }                                                                   \n";
        static public string fs2D_ShderString = "#version 460 core                             \n" +
                 " out vec4 FragColor;                                                 \n" +
                 " in vec3 passColor;                                                  \n" +
                 "  uniform vec4 u_Color;                                              \n" +   // ��CPU Ҳ���ǳ������һ��vec4�ı���
                 " void main()                                                         \n" +
                 " {                                                                   \n" +
                 "     FragColor = vec4(passColor.x, passColor.y, passColor.z, 1.0f);  \n" +
                 " }                                                                   \n";

        public Shader m_Shader;
        public TrangleObject2D m_Object2d;

        public OpenTKMainForm()
        {
            InitializeComponent();
        }

        private void OpenTKMainForm_Load(object sender, EventArgs e)
        {
            openglView.Resize += openglView_Resize;
            openglView.Paint += openglView_Paint;
            //openglView1.KeyDown += Form1_KeyDown;

            int w = this.openglView.Width;
            int h = this.openglView.Height;
            GL.Viewport(0, 0, w, h);  //����ߴ�����

            // �趨�����Ļ����Ļ��ʾ�ı���ɫ������������ɫ
            GL.ClearColor(0.2f, 0.3f, 0.3f, 1.0f);
            m_Object2d = new TrangleObject2D();
            m_Shader = new Shader(vs2D_ShderString, fs2D_ShderString);
            timer1.Enabled = true;


        }

        private void OpenTKMainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            m_Object2d.Dispose();
            m_Shader.Dispose();
        }

        private void openglView_Paint(object sender, PaintEventArgs e)
        {
            // ����
            GL.Clear(ClearBufferMask.ColorBufferBit);
            // ���ƴ���
            m_Object2d.OpenGLDraw(m_Shader);
            // ��������������ֹ���������쳣
            openglView.SwapBuffers();
        }

        private void openglView_Resize(object sender, EventArgs e)
        {
            int w = this.openglView.Width;
            int h = this.openglView.Height;
            GL.Viewport(0, 0, w, h);  //����ߴ�����
            // �趨�����Ļ����Ļ��ʾ�ı���ɫ������������ɫ
            GL.ClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Refresh();
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Location.Y < (button2.Height * 0.5f))
            {
                int Angle = int.Parse(this.textBox1.Text);
                Angle += 1;
                if (Angle > 359)
                {
                    Angle = 0;
                }
                this.textBox1.Text = Convert.ToString(Angle);
            }
            else
            {
                int Angle = int.Parse(this.textBox1.Text);
                Angle -= 1;
                if (Angle < 0)
                {
                    Angle = 0;
                }
                this.textBox1.Text = Convert.ToString(Angle);
            }
            //button1_Click(sender, e);
            try
            {
                float Angle = float.Parse(this.textBox1.Text);
                m_Object2d._Rotate.Z = Angle;
            }
            catch
            {
                throw new Exception($"�ַ���ת��Ϊ����������");
            }
        }

        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            float MoveX = float.Parse(this.textBox2.Text);
            if (e.Location.Y < (button3.Height * 0.5f))
            {
                MoveX += 0.1f;
                this.textBox2.Text = MoveX.ToString("f1");//����С�����1λ
            }
            else
            {
                MoveX -= 0.1f;
                this.textBox2.Text = MoveX.ToString("f1");
            }
            m_Object2d._Move.X = MoveX;
        }

        private void button4_MouseDown(object sender, MouseEventArgs e)
        {
            float MoveY = float.Parse(this.textBox3.Text);
            if (e.Location.Y < (button4.Height * 0.5f))
            {
                MoveY += 0.1f;
                this.textBox3.Text = MoveY.ToString("f1");//����С�����1λ
            }
            else
            {
                MoveY -= 0.1f;
                this.textBox3.Text = MoveY.ToString("f1");
            }
            m_Object2d._Move.Y = MoveY;
        }

        private void button5_MouseDown(object sender, MouseEventArgs e)
        {
            float ScalseX = float.Parse(this.textBox4.Text);
            if (e.Location.Y < (button5.Height * 0.5f))
            {
                ScalseX += 0.1f;
            }
            else
            {
                ScalseX -= 0.1f;
            }
            this.textBox4.Text = ScalseX.ToString("f1");

            m_Object2d._scale.X = ScalseX;
        }

        private void button6_MouseDown(object sender, MouseEventArgs e)
        {
            float ScalseY = float.Parse(this.textBox5.Text);
            if (e.Location.Y < (button6.Height * 0.5f))
            {
                ScalseY += 0.1f;
            }
            else
            {
                ScalseY -= 0.1f;
            }
            this.textBox5.Text = ScalseY.ToString("f1");
            m_Object2d._scale.Y = ScalseY;
        }
    }
}
