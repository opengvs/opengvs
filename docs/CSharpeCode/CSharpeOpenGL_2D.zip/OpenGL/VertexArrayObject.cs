﻿global using VAO = OpenGLObject.VertexArrayObject;
using OpenGLObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using OpenTK.Graphics;
using OpenTK.Platform;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common.Input;


namespace OpenGLObject
{
    public class VertexArrayObject : OpenglObject
    {
        public PrimitiveType primitiveType = PrimitiveType.Triangles; //new PrimitiveType();
        public DrawElementsType drawElementType = DrawElementsType.UnsignedInt; //new DrawElementsType();
        
        public ElementBufferObject? pEBO = null;
        
        List<VertexBufferObject> pVBOList = new List<VertexBufferObject>();
        internal int vertexCount = 0;

        public VertexArrayObject()
        {
            GL.GenVertexArrays(1, out _id);
            primitiveType = PrimitiveType.Triangles;
        }

        public override void Bind()
        {
            GL.BindVertexArray(_id);
        }

        public override void Unbind()
        {
            GL.BindVertexArray(0);
            foreach (VertexBufferObject pVBO in pVBOList)
            {
                pVBO.Unbind();
            }
            if (pEBO != null)
            {
                pEBO.Unbind();
            }

        }

        protected override void Destory()
        {
            GL.DeleteVertexArrays(1, ref _id);
            foreach (VertexBufferObject pVBO in pVBOList)
            {
                pVBO.Dispose();
            }
            pVBOList.Clear();
            if (pEBO != null)
            {
                pEBO.Dispose();
            }

        }
        public VertexBufferObject AddVertexBufferObject<T>(T[] data, int dataSize, BufferUsageHint usage, params int[] itemSize) where T : struct
        {
            this.Bind();
            VertexBufferObject pVBO = new VertexBufferObject();
            pVBO.Bind();
            pVBO.SetData(data, dataSize,  usage, itemSize);
           
            pVBOList.Add(pVBO);


            int stride = itemSize.Sum(i => i * sizeof(float));
            int vCount = data.Length / stride;
            vertexCount = vCount;
          //  for (int i = 0; i < vCount; i++)
          //  {
          //      axisAlignedBoxf.UpdateBox((float)Convert.ChangeType(data[i * stride + 0], typeof(float)),
          //                                        (float)Convert.ChangeType(data[i * stride + 1], typeof(float)), 
          //                                        (float)Convert.ChangeType(data[i * stride + 2], typeof(float)));
          //  }
 
            return pVBO;
        }

        public VertexBufferObject AddVertexBufferObjectVector3(Vector3[] data, int size, int itemSize, BufferUsageHint usage, int index)
        {
            this.Bind();
            VertexBufferObject pVBO = new VertexBufferObject();
            pVBO.Bind();
            pVBO.setDataVector3(data, size, itemSize, usage, index);
            pVBOList.Add(pVBO);
            if (index == 0)
            {
                int vCount = data.Length;
                vertexCount = vCount;
               // for (int i = 0; i < vCount; i++)
               // {
               //     axisAlignedBoxf.UpdateBox(data[i].X, data[i].Y, data[i].Z);
               // }
            }
            return pVBO;
        }
        public VertexBufferObject AddVertexBufferObjectFloat(float[] data, int size, int itemSize, BufferUsageHint usage, int index)
        {
            this.Bind();
            VertexBufferObject pVBO = new VertexBufferObject();
            pVBO.Bind();
            pVBO.SetDataFloat(data, size, itemSize, usage, index);
            pVBOList.Add(pVBO);

            if(index==0)
            {
                int vCount = data.Length / 3;
                vertexCount = vCount;
              //  int step = 3;
               // for(int i=0;i<vCount;i++)
               // {
               //     axisAlignedBoxf.UpdateBox(data[i * step + 0], data[i * step + 1], data[i * step + 2]);
               // }
            }

            return pVBO;
        }
        public ElementBufferObject SetElementBufferObject<T>(T[] data, int itemSize, BufferUsageHint usage) where T : struct
        {
            if (pEBO != null)
                return pEBO;
            pEBO = new ElementBufferObject();
            this.Bind();
            pEBO.Bind();
            pEBO.SetData(data, itemSize, usage);
            vertexCount = data.Length;
            if ( data != null)
            {
                if (data is short[])
                {
                    drawElementType = DrawElementsType.UnsignedShort;
                }
                else if (data is int[])
                {
                    drawElementType = DrawElementsType.UnsignedInt;
                }
                else if (data is byte[])
                {
                    drawElementType = DrawElementsType.UnsignedByte;
                }
                else
                    drawElementType = DrawElementsType.UnsignedInt;
            }


            return pEBO;
        }
        public virtual void OpenGLDraw(Shader _shader)
        {
            _shader.Bind();
            this.Bind();
            //这里通过派生VAO的子类，实现具体的绘制功能
            if (pEBO == null)
            {
                GL.DrawArrays(primitiveType, 0, vertexCount);
            }
            else
            {
                GL.DrawElements(primitiveType, vertexCount, drawElementType, 0);
            }
            this.Unbind();
        }

        public virtual Matrix4 getTransform()
        {
            return Matrix4.Identity;
        }
        //该Draw函数加入了矩阵参数，用于3D图形绘制
     /*   public virtual void Draw(Shader _shader, Camera _camera)
        {
            _shader.Bind();
            this.Bind();
            if (_shader.GetUniformLocation("modelview") >= 0)
            {
                Matrix4 mat = getTransform() * _camera.GetViewMatrix() * _camera.GetProjectionMatrix();//_viewMat * _projectMat;
                _shader.SetMatrix4("modelview", mat);         
            }
            else
            {
                _shader.SetMatrix4("view", _camera.GetViewMatrix());
                _shader.SetMatrix4("projection", _camera.GetProjectionMatrix());
                
                _shader.SetMatrix4("model", getTransform() );
            }
            

        }  */

    }
 
}
