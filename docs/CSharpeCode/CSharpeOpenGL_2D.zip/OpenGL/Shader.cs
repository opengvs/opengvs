﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Graphics.OpenGL4;
using OpenTK;
using OpenTK.Graphics;
using OpenTK.Platform;
//using OpenTK.Graphics.OpenGL;
using OpenGLObject;
using System.Security.Cryptography;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static OpenTK.Graphics.OpenGL.GL;
using System.Reflection;
using System.Windows.Forms;
using OpenTK.Mathematics;
using static System.Windows.Forms.DataFormats;
using System.Drawing;
using System.Drawing.Drawing2D;


namespace OpenGLObject
{
    public class Shader : OpenglObject
    {
        // 定义(声明)一个只读的句柄
        public int Handle { get { return _id; } }

        // 定义一个只读的字典
        private readonly Dictionary<string, int> _uniformLocations;

        public Shader(string vertString, string fragString/*,bool IsString*/) : base()
        {
            string vertSource = vertString;
            FileInfo file = new FileInfo(vertString);
            if (file.Exists == true)
            {
                vertSource = File.ReadAllText(vertString);
            }
            string fragSource = fragString;
            file = new FileInfo(fragString);
            if (file.Exists == true)
            {
                fragSource = File.ReadAllText(fragString);
            }

            // 创建一个VertexShader类型的着色器
            var vertexShader = GL.CreateShader(ShaderType.VertexShader);


            // 将GLSL原代码和端点着色器绑定
            GL.ShaderSource(vertexShader, vertSource);
            // 编译端点着色器
            CompileShader(vertexShader);


            var fragmentShader = GL.CreateShader(ShaderType.FragmentShader);
            GL.ShaderSource(fragmentShader, fragSource);
            CompileShader(fragmentShader);

            // 必须将这两个着色器放入OpenGL能够执行的程序中
            // 创建一个程序
            _id = GL.CreateProgram();

            // 将两个着色器都与之绑定
            GL.AttachShader(_id, vertexShader);
            GL.AttachShader(_id, fragmentShader);

            // 然后将他们两个关联起来
            LinkProgram(_id);

            // 当程序被链接并编译以后，着色器相应的代码就被复制到了程序中，单个的着色器就不再被需要了，将着色器与程序分离，并删除他们
            GL.DetachShader(_id, vertexShader);
            GL.DetachShader(_id, fragmentShader);
            GL.DeleteShader(fragmentShader);
            GL.DeleteShader(vertexShader);

            // 获取活动的全局着色器(uniforms)数量
            GL.GetProgram(_id, GetProgramParameterName.ActiveUniforms, out var numberOfUniforms);
            // 分配字典来保存位置
            _uniformLocations = new Dictionary<string, int>();

            // 遍历所有全局着色器
            for (var i = 0; i < numberOfUniforms; i++)
            {
                // 获取全局着色器的名字
                var key = GL.GetActiveUniform(_id, i, out _, out _);

                // 获取位置
                var location = GL.GetUniformLocation(_id, key);

                // 将它添加到字典中
                _uniformLocations.Add(key, location);
            }
        }

        public int GetUniformLocation(string key)
        {
            // 使用 TryGetValue() 避免抛出异常
            if (_uniformLocations.TryGetValue(key, out int value))
            {
                return value;
            }
            else
            {
                // Console.WriteLine("Bob's age not found.");
                return -1;
            }
        }
        private static void CompileShader(int shader)
        {
            // 编译着色器
            GL.CompileShader(shader);

            // 检查是否存在编译错误
            GL.GetShader(shader, ShaderParameter.CompileStatus, out var code);
            if (code != (int)All.True)
            {
                // 使用GL.GetShaderInfoLog(shader)函数来获取作物的详细信息
                var infoLog = GL.GetShaderInfoLog(shader);
                throw new Exception($"Error occurred whilst compiling Shader({shader}).\n\n{infoLog}");
            }
        }

        private static void LinkProgram(int program)
        {
            // 链接程序
            GL.LinkProgram(program);

            // 检查错误
            GL.GetProgram(program, GetProgramParameterName.LinkStatus, out var code);
            if (code != (int)All.True)
            {
                throw new Exception($"Error occurred whilst linking Program({program})");
            }
        }


        // 启动着色器程序的封装函数
        public override void Bind()
        {
            GL.UseProgram(_id);
        }
        public override void Unbind()
        {
            GL.UseProgram(0);
        }
        public int GetAttribLocation(string attribName)
        {
            return GL.GetAttribLocation(_id, attribName);
        }

        public void SetInt(string name, int data)
        {
            GL.UseProgram(_id);
            GL.Uniform1(_uniformLocations[name], data);
        }

        public void SetFloat(string name, float data)
        {
            GL.UseProgram(_id);
            GL.Uniform1(_uniformLocations[name], data);
        }

        public void SetMatrix3(string name, Matrix3 data)
        {
            GL.UseProgram(_id);
            GL.UniformMatrix3(_uniformLocations[name], false, ref data);
        }

        public void SetMatrix4(string name, Matrix4 data)
        {
            GL.UseProgram(_id);
            GL.UniformMatrix4(_uniformLocations[name], false, ref data);
        }

        public void SetVector3(string name, Vector3 data)
        {
            GL.UseProgram(_id);
            GL.Uniform3(_uniformLocations[name], data);
        }

        public void SetVector4(string name, Vector4 data)
        {
            GL.UseProgram(_id);
            GL.Uniform4(_uniformLocations[name], data);
        }
        public void SetTextureUnitID(string name, int _unitID)
        {
            GL.UseProgram(_id);
            GL.Uniform1(_uniformLocations[name], _unitID);
        }


        protected override void Destory()
        {
            GL.DeleteProgram(_id);
        }
        public int CreateComputeShader(string _computeShaderString)
        {
            // 创建shader
            // std::cout << "load shader begin" << std::endl;
            //  GLuint computeShaderProgram = glCreateProgram();
            var computeShader = GL.CreateShader(ShaderType.ComputeShader); //GL_COMPUTE_SHADER);
            //const char* source = computeShaderSource.c_str();
            GL.ShaderSource(computeShader, _computeShaderString);
            CompileShader(computeShader);
            //glShaderSource(computeShader, 1, &source, nullptr);
            // glCompileShader(computeShader);
            if (_id == 0)
            {
                _id = GL.CreateProgram();
            }


            // 检查编译错误
            // GLint success;
            // glGetShaderiv(computeShader, GL_COMPILE_STATUS, &success);
            // if (!success)
            // {
            //     char infoLog[512];
            //     glGetShaderInfoLog(computeShader, 512, nullptr, infoLog);
            //     std::cerr << "Compute shader compilation failed: " << infoLog << std::endl;
            //  }

            // 链接着色器程序
            // glAttachShader(computeShaderProgram, computeShader);
            // glLinkProgram(computeShaderProgram);

            GL.AttachShader(_id, computeShader);


            // 然后将他们两个关联起来
            LinkProgram(_id);

            // 检查链接错误
            //  glGetProgramiv(computeShaderProgram, GL_LINK_STATUS, &success);
            //   if (!success)
            //  {
            //      char infoLog[512];
            //      glGetProgramInfoLog(computeShaderProgram, 512, nullptr, infoLog);
            //      std::cerr << "Compute shader program linking failed: " << infoLog << std::endl;
            //   }
            return computeShader;

        }
    }
}
