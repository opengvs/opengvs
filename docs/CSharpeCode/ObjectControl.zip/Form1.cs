using OpenGLObject;
using OpenTK.Graphics.OpenGL;
using OpenTK.Mathematics;

namespace ObjectControl
{
    public partial class OpenTKMainForm : Form
    {
        public OpenTKMainForm()
        {
            InitializeComponent();
        }
        private void OpenTKMainForm_Load(object sender, EventArgs e)
        {
            openglView.Resize += openglView_Resize;
            openglView.Paint += openglView_Paint;
            //openglView1.KeyDown += Form1_KeyDown;

            int w = this.openglView.Width;
            int h = this.openglView.Height;
            float _Fov = 120;
            float _aspect = (float)h / (float)w;
            float _Near = 0.1f;
            float _Far = 1000.0f;

            GL.Viewport(0, 0, w, h);  //����ߴ�����

            m_MainCamera = new Camera(new Vector3(0f, 1f, 6f),//eyeλ��
                                       new Vector3(0, 0, 0),  //�۾��۲�����ĵ�
                                       new Vector3(0, 1, 0),  //���ϵķ���
                                       120,
                                       (float)w / (float)h,
                                       0.1f,
                                       1000.0f);
            Vector3 angleV = m_MainCamera.getRotation();

            m_Shader = new Shader(vs3D_Source_MVP, fs3D_Source_MVP);



            m_PaperPlaneObjectDef = new GLObjectDef();
            m_PaperPlaneObjectDef.AddVAO(new PaperPlaneObject());
            m_PaperPlaneInstance = new GLObjectInstance(m_PaperPlaneObjectDef);


            // �趨�����Ļ����Ļ��ʾ�ı���ɫ������������ɫ
            GL.ClearColor(0.2f, 0.3f, 0.3f, 1.0f);

            timer1.Enabled = true;

            this.CameraPos_X.Text = m_MainCamera.Position.X.ToString("f1");
            this.CameraPos_Y.Text = m_MainCamera.Position.Y.ToString("f1");
            this.CameraPos_Z.Text = m_MainCamera.Position.Z.ToString("f1");

            this.CameraRotation_X.Text = angleV.X.ToString("f1");
            this.CameraRotation_Y.Text = angleV.Y.ToString("f1");
            this.CameraRotation_Z.Text = angleV.Z.ToString("f1");

            CameraFOV.Text = m_MainCamera.Fov.ToString("f1");
            FOV_trackBar.Value = (int)m_MainCamera.Fov;
            cameraAspectRatio.Text = m_MainCamera?.AspectRatio.ToString("f2");
            cameraNearPlane.Text = m_MainCamera?.Near.ToString("f2");
            cameraFarPlane.Text = m_MainCamera?.Far.ToString("f2");

            UpdateCameraMatView();

            float tempNum = m_PaperPlaneInstance.position.X;
            textBox3.Text = tempNum.ToString("f1");

            tempNum = m_PaperPlaneInstance.position.Y;
            textBox2.Text = tempNum.ToString("f1");

            tempNum = m_PaperPlaneInstance.position.X;
            textBox1.Text = tempNum.ToString("f1");

            tempNum = m_PaperPlaneInstance.rotation.X;
            textBox6.Text = tempNum.ToString("f1");

            tempNum = m_PaperPlaneInstance.rotation.Y;
            textBox5.Text = tempNum.ToString("f1");

            tempNum = m_PaperPlaneInstance.rotation.Z;
            textBox4.Text = tempNum.ToString("f1");

            tempNum = m_PaperPlaneInstance.scale.X;
            textBox9.Text = tempNum.ToString("f1");

            tempNum = m_PaperPlaneInstance.scale.Y;
            textBox8.Text = tempNum.ToString("f1");

            tempNum = m_PaperPlaneInstance.scale.Z;
            textBox7.Text = tempNum.ToString("f1");

        }
        private void UpdateCameraMatView()
        {
            Matrix4 cameraMat = m_MainCamera.GetViewMatrix();
            A00.Text = cameraMat[0, 0].ToString("f2");
            A01.Text = cameraMat[0, 1].ToString("f2");
            A02.Text = cameraMat[0, 2].ToString("f2");
            A03.Text = cameraMat[0, 3].ToString("f2");
            A10.Text = cameraMat[1, 0].ToString("f2");
            A11.Text = cameraMat[1, 1].ToString("f2");
            A12.Text = cameraMat[1, 2].ToString("f2");
            A13.Text = cameraMat[1, 3].ToString("f2");
            A20.Text = cameraMat[2, 0].ToString("f2");
            A21.Text = cameraMat[2, 1].ToString("f2");
            A22.Text = cameraMat[2, 2].ToString("f2");
            A23.Text = cameraMat[2, 3].ToString("f2");
            A30.Text = cameraMat[3, 0].ToString("f2");
            A31.Text = cameraMat[3, 1].ToString("f2");
            A32.Text = cameraMat[3, 2].ToString("f2");
            A33.Text = cameraMat[3, 3].ToString("f2");

            Matrix4 cameraPrjMat = m_MainCamera.GetProjectionMatrix();
            B00.Text = cameraPrjMat[0, 0].ToString("f2");
            B01.Text = cameraPrjMat[0, 1].ToString("f2");
            B02.Text = cameraPrjMat[0, 2].ToString("f2");
            B03.Text = cameraPrjMat[0, 3].ToString("f2");
            B10.Text = cameraPrjMat[1, 0].ToString("f2");
            B11.Text = cameraPrjMat[1, 1].ToString("f2");
            B12.Text = cameraPrjMat[1, 2].ToString("f2");
            B13.Text = cameraPrjMat[1, 3].ToString("f2");
            B20.Text = cameraPrjMat[2, 0].ToString("f2");
            B21.Text = cameraPrjMat[2, 1].ToString("f2");
            B22.Text = cameraPrjMat[2, 2].ToString("f2");
            B23.Text = cameraPrjMat[2, 3].ToString("f2");
            B30.Text = cameraPrjMat[3, 0].ToString("f2");
            B31.Text = cameraPrjMat[3, 1].ToString("f2");
            B32.Text = cameraPrjMat[3, 2].ToString("f2");
            B33.Text = cameraPrjMat[3, 3].ToString("f2");
        }
        private void OpenTKMainForm_FormClosed(object sender, FormClosedEventArgs e)
        {

            m_Shader?.Dispose();
        }

        private void openglView_Paint(object sender, PaintEventArgs e)
        {
            // ����
            GL.Viewport(0, 0, openglView.Width, openglView.Height);
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            GL.Enable(EnableCap.DepthTest);

            // ���ƴ���

            m_PaperPlaneInstance?.Draw(m_Shader, m_MainCamera);

            // ��������������ֹ���������쳣
            openglView.SwapBuffers();
        }

        private void openglView_Resize(object sender, EventArgs e)
        {
            int w = this.openglView.Width;
            int h = this.openglView.Height;
            GL.Viewport(0, 0, w, h);  //����ߴ�����
            // �趨�����Ļ����Ļ��ʾ�ı���ɫ������������ɫ
            GL.ClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Refresh();
        }

        Shader? m_Shader;
        Camera? m_MainCamera;


        GLObjectDef? m_PaperPlaneObjectDef;
        GLObjectInstance? m_PaperPlaneInstance;

        // CubeObjectWithColor? m_CubeObjectWithColor_1;
        // CubeObjectWithColor? m_CubeObjectWithColor_2;
        static public string vs3D_Source_MVP = "# version 330 core   \n" +
   "layout(location = 0) in vec3 vPosition;   \n" +
   "layout(location = 1)in  vec3 vColor;     \n" +
   "    uniform mat4 model;                  \n" +
   "    uniform mat4 view;                   \n" +
   "    uniform mat4 projection;             \n" +
   "    out vec4 color;\r\n" +
   "    void main()                              \n" +
   "   {                                     \n" +
   "        gl_Position = projection * view * model * vec4(vPosition, 1.0f);\n" +
   "        color = vec4( vColor, 1.0);                                     \n" +
   "   }";

        static public string fs3D_Source_MVP = "#version 330 core \n" +
             "  in vec4 color;\n" +
             "  out vec4 outputColor;\n" +
             "  void main()\n" +
             "  {\n" +
             "        outputColor = color;\n" +
             "  }\n";

        private void FOV_trackBar_ValueChanged(object sender, EventArgs e)
        {
            CameraFOV.Text = FOV_trackBar.Value.ToString("f1");
            if (m_MainCamera != null)
            {
                m_MainCamera.Fov = FOV_trackBar.Value;
                UpdateCameraMatView();
            }
        }

        private void ChangePosXButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(ChangePosXButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(CameraPos_X.Text);
                tempNum += 0.1f;
                CameraPos_X.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(CameraPos_X.Text);
                tempNum -= 0.1f;
                CameraPos_X.Text = tempNum.ToString("f1");
            }
            m_MainCamera.setPosition(float.Parse(CameraPos_X.Text), float.Parse(CameraPos_Y.Text), float.Parse(CameraPos_Z.Text));
            UpdateCameraMatView();
        }

        private void ChangePosYButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(ChangePosYButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(CameraPos_Y.Text);
                tempNum += 0.1f;
                CameraPos_Y.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(CameraPos_Y.Text);
                tempNum -= 0.1f;
                CameraPos_Y.Text = tempNum.ToString("f1");
            }
            m_MainCamera.setPosition(float.Parse(CameraPos_X.Text), float.Parse(CameraPos_Y.Text), float.Parse(CameraPos_Z.Text));
            UpdateCameraMatView();
        }

        private void ChangePosZButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(ChangePosZButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(CameraPos_Z.Text);
                tempNum += 0.1f;
                CameraPos_Z.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(CameraPos_Z.Text);
                tempNum -= 0.1f;
                CameraPos_Z.Text = tempNum.ToString("f1");
            }
            m_MainCamera.setPosition(float.Parse(CameraPos_X.Text), float.Parse(CameraPos_Y.Text), float.Parse(CameraPos_Z.Text));
            UpdateCameraMatView();
        }

        private void ChangeRotationXButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(ChangeRotationXButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(CameraRotation_X.Text);
                tempNum += 1f;
                CameraRotation_X.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(CameraRotation_X.Text);
                tempNum -= 1f;
                CameraRotation_X.Text = tempNum.ToString("f1");
            }
            m_MainCamera.setRotation(new Vector3(
                     float.Parse(CameraRotation_X.Text), float.Parse(CameraRotation_Y.Text), float.Parse(CameraRotation_Z.Text)));
            UpdateCameraMatView();
        }

        private void ChangeRotationYButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(ChangeRotationYButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(CameraRotation_Y.Text);
                tempNum += 1f;
                CameraRotation_Y.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(CameraRotation_Y.Text);
                tempNum -= 1f;
                CameraRotation_Y.Text = tempNum.ToString("f1");
            }
            m_MainCamera.setRotation(new Vector3(
                     float.Parse(CameraRotation_X.Text), float.Parse(CameraRotation_Y.Text), float.Parse(CameraRotation_Z.Text)));
            UpdateCameraMatView();
        }

        private void ChangeRotationZButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(ChangeRotationZButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(CameraRotation_Z.Text);
                tempNum += 1f;
                CameraRotation_Z.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(CameraRotation_Z.Text);
                tempNum -= 1f;
                CameraRotation_Z.Text = tempNum.ToString("f1");
            }
            m_MainCamera.setRotation(new Vector3(
                     float.Parse(CameraRotation_X.Text), float.Parse(CameraRotation_Y.Text), float.Parse(CameraRotation_Z.Text)));
            UpdateCameraMatView();
        }

        private void RotateRightButton_Click(object sender, EventArgs e)
        {
            float rotateX = float.Parse(CameraRotate_X.Text);
            m_MainCamera.rotateX(rotateX);
            UpdateCameraMatView();
        }

        private void RotateUpButton_Click(object sender, EventArgs e)
        {
            float rotateY = float.Parse(CameraRotate_Y.Text);
            m_MainCamera.rotateY(rotateY);
            UpdateCameraMatView();
        }

        private void RotateFrontButton_Click(object sender, EventArgs e)
        {
            float rotateZ = float.Parse(CameraRotate_Z.Text);
            m_MainCamera.rotateZ(rotateZ);
            UpdateCameraMatView();
        }

        private void cameraAspectRatioButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(cameraAspectRatioButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(cameraAspectRatio.Text);
                tempNum += 0.1f;

                cameraAspectRatio.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(cameraAspectRatio.Text);
                tempNum -= 0.1f;
                if (tempNum < 0.1)
                    tempNum = 0.1f;
                cameraAspectRatio.Text = tempNum.ToString("f1");
            }
            m_MainCamera.AspectRatio = float.Parse(cameraAspectRatio.Text);

            UpdateCameraMatView();
        }

        private void cameraNearPlaneButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(cameraNearPlaneButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(cameraNearPlane.Text);
                tempNum += 0.1f;

                cameraNearPlane.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(cameraNearPlane.Text);
                tempNum -= 0.1f;
                if (tempNum < 0.1)
                    tempNum = 0.1f;
                cameraNearPlane.Text = tempNum.ToString("f1");
            }
            m_MainCamera.Near = float.Parse(cameraNearPlane.Text);

            UpdateCameraMatView();

        }

        private void cameraFarPlaneButton_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(cameraFarPlaneButton.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(cameraFarPlane.Text);
                tempNum += 1f;

                cameraFarPlane.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(cameraFarPlane.Text);
                tempNum -= 1f;
                if (tempNum < 0.1)
                    tempNum = 0.1f;
                cameraFarPlane.Text = tempNum.ToString("f1");
            }
            m_MainCamera.Far = float.Parse(cameraFarPlane.Text);

            UpdateCameraMatView();
        }
        //����X����ƽ���¼�
        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(button2.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(textBox3.Text);
                tempNum += 1f;

                textBox3.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(textBox3.Text);
                tempNum -= 1f;

                textBox3.Text = tempNum.ToString("f1");
            }
            m_PaperPlaneInstance.position.X = float.Parse(textBox3.Text);
        }

        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(button3.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(textBox2.Text);
                tempNum += 1f;

                textBox2.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(textBox2.Text);
                tempNum -= 1f;

                textBox2.Text = tempNum.ToString("f1");
            }
            m_PaperPlaneInstance.position.Y = float.Parse(textBox2.Text);
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(button1.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(textBox1.Text);
                tempNum += 1f;

                textBox1.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(textBox1.Text);
                tempNum -= 1f;

                textBox1.Text = tempNum.ToString("f1");
            }
            m_PaperPlaneInstance.position.Z = float.Parse(textBox1.Text);
        }

        private void button6_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(button6.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(textBox6.Text);
                tempNum += 1f;
                if (tempNum >= 360f)
                {
                    tempNum = 0f;
                }
                textBox6.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(textBox6.Text);
                tempNum -= 1f;
                if (tempNum < -360f)
                {
                    tempNum = 0f;
                }
                textBox6.Text = tempNum.ToString("f1");
            }
            m_PaperPlaneInstance.rotation.X = float.Parse(textBox6.Text);

        }

        private void button5_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(button5.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(textBox5.Text);
                tempNum += 1f;
                if (tempNum >= 360f)
                {
                    tempNum = 0f;
                }
                textBox5.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(textBox5.Text);
                tempNum -= 1f;
                if (tempNum < -360f)
                {
                    tempNum = 0f;
                }
                textBox5.Text = tempNum.ToString("f1");
            }
            m_PaperPlaneInstance.rotation.Y = float.Parse(textBox5.Text);

        }

        private void button4_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(button4.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(textBox4.Text);
                tempNum += 1f;
                if (tempNum >= 360f)
                {
                    tempNum = 0f;
                }
                textBox4.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(textBox4.Text);
                tempNum -= 1f;
                if (tempNum < -360f)
                {
                    tempNum = 0f;
                }
                textBox4.Text = tempNum.ToString("f1");
            }
            m_PaperPlaneInstance.rotation.Z = float.Parse(textBox4.Text);

        }

        private void button9_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(button9.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(textBox9.Text);
                tempNum += 0.1f;

                textBox9.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(textBox9.Text);
                tempNum -= 0.1f;
                if (tempNum < 0.1)
                {
                    tempNum = 0.1f;
                }
                textBox9.Text = tempNum.ToString("f1");
            }
            m_PaperPlaneInstance.scale.X = float.Parse(textBox9.Text);

        }

        private void button8_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(button8.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(textBox8.Text);
                tempNum += 0.1f;

                textBox8.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(textBox8.Text);
                tempNum -= 0.1f;
                if (tempNum < 0.1)
                {
                    tempNum = 0.1f;
                }
                textBox8.Text = tempNum.ToString("f1");
            }
            m_PaperPlaneInstance.scale.Y = float.Parse(textBox8.Text);
        }

        private void button7_MouseDown(object sender, MouseEventArgs e)
        {
            int halfHeight = (int)(button7.Height * 0.5);
            if (e.Y < halfHeight)
            {
                float tempNum = float.Parse(textBox7.Text);
                tempNum += 0.1f;

                textBox7.Text = tempNum.ToString("f1");
            }
            else
            {
                float tempNum = float.Parse(textBox7.Text);
                tempNum -= 0.1f;
                if (tempNum < 0.1)
                {
                    tempNum = 0.1f;
                }
                textBox7.Text = tempNum.ToString("f1");
            }
            m_PaperPlaneInstance.scale.Z = float.Parse(textBox7.Text);

        }


    }

}

