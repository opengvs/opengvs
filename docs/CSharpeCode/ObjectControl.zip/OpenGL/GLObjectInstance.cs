﻿global using GL_Obi = OpenGLObject.GLObjectInstance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Mathematics;
using OpenTK.Graphics.OpenGL4;
using System.Collections;
using System.Runtime.CompilerServices;

//[assembly: InternalsVisibleTo("GLObjectDef")]
namespace OpenGLObject
{
    public class GLObjectInstance : Transform
    {
        
        private GLObjectInstance():base() { m_obd = new GLObjectDef(); }//该类定义的对象不许通过传入参数完成，屏蔽默认构造函数
        public GLObjectInstance(GLObjectDef _obd) : base()
        {
            m_obd = _obd;
        }

        public GLObjectDef m_obd;
        public bool _isDrawBox = false;

        public virtual void Draw(Shader _shader, Camera _camera)
        {
            _shader.Bind();

            Matrix4 objectDefMat4 = m_obd.GetMatrix4(); ;

            Matrix4 mat4 = this.GetMatrix4()* objectDefMat4;



            if (_shader.GetUniformLocation("modelview") >= 0)
            {
                Matrix4 mat = mat4 * _camera.GetViewMatrix() * _camera.GetProjectionMatrix();
                _shader.SetMatrix4("modelview", mat);
            }
            else
            {
                _shader.SetMatrix4("view", _camera.GetViewMatrix());
                _shader.SetMatrix4("projection", _camera.GetProjectionMatrix());

                _shader.SetMatrix4("model", mat4);
            }

            if(m_obd != null)
            {
                m_obd.Draw();
            }
        }
        public override Matrix4 GetMatrix4()
        {
            if (transformMatrixDelegete == null)
            {
                Vector3 _scale = scale * this.m_obd.scale;
                Vector3 _rotation = rotation + this.m_obd.rotation;
                Vector3 _positin = position + this.m_obd.position;
                Matrix4 mat = Matrix4.CreateFromQuaternion(
                            Quaternion.FromEulerAngles(MathHelper.DegreesToRadians(_rotation.X),
                                                       MathHelper.DegreesToRadians(_rotation.Y),
                                                       MathHelper.DegreesToRadians(_rotation.Z)))
                                       * Matrix4.CreateTranslation(_positin) * Matrix4.CreateScale(_scale);

                return mat;
            }
            else
            {
                return transformMatrixDelegete(this);
            }
        }

    }
}
