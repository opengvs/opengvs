﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenGLObject
{
    public abstract class OpenglObject : IBindable, IDisposable
    {
        public int _id;
        private bool disposedValue;
        protected static List<OpenglObject> objList = new List<OpenGLObject.OpenglObject>();
        static public void ReleaseAllOpenObj()
        {
            while (objList.Count > 0)
            {
                OpenglObject obj = objList[0];
                objList.RemoveAt(0);

                obj.Dispose();
            }
            
        }
        protected OpenglObject()
        {
            objList.Add(this);
        }
        // // TODO: 仅当“Dispose(bool disposing)”拥有用于释放未托管资源的代码时才替代终结器
        ~OpenglObject()
        {
            // 不要更改此代码。请将清理代码放入“Dispose(bool disposing)”方法中
            Dispose(disposing: false);
        }

        public abstract void Bind();

        public abstract void Unbind();

        public int Id => _id;
        public void Dispose()
        {
            // 不要更改此代码。请将清理代码放入“Dispose(bool disposing)”方法中
            foreach (OpenglObject obj in objList)
            {
                if (obj != null)
                {
                    if (obj == this)
                    {
                        objList.Remove(obj);
                        break;
                    }
                }
            }

            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        protected abstract void Destory();//子类必须重载Destory()函数


        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: 释放托管状态(托管对象)
                }

                // TODO: 释放未托管的资源(未托管的对象)并重写终结器
                Destory();
                // TODO: 将大型字段设置为 null
                disposedValue = true;
            }
        }
    }
}
