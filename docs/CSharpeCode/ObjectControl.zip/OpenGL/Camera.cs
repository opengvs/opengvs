﻿using OpenTK.Mathematics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenGLObject
{
    public class Camera
    {
        public Matrix4 _InsideMat = Matrix4.LookAt(new Vector3(0.0f, 0.0f, 1.0f),
                              new Vector3(0, 0, 0), Vector3.UnitY);

        private Vector3 _position = new Vector3(0.0f, 1.0f, 0.0f);

        //相机内部不维护center点，观察点通过_position+_front计算得到 ,这样的好处是可以随意移动相机的位置
        private Vector3 _front = -Vector3.UnitZ;

        private Vector3 _up = Vector3.UnitY;


        // The field of view of the camera (radians)
        private float _fov = MathHelper.PiOver2;//PiOver2
        private float _near = 0.1f;
        private float _far = 10000.0f;
        public Camera(Vector3 eye, Vector3 center, Vector3 up, float fov = 165.0f, float aspect = 1.0f, float near = 0.1f, float far = 10000.0f)
        {
            _position = eye;
            //_center = center;
            _front = Vector3.Normalize(center - eye);
            _up = up;

            Fov = fov;
            AspectRatio = aspect;
            _near = near;
            _far = far;
            _InsideMat = Matrix4.LookAt(eye, center, up);

        }
        // The position of the camera
        public Vector3 Position
        {
            get { return _position; } // set { _position = value; } }
            set { setPosition(value); }
        }

        public Vector3 Front { get { return _front; } }
        public Vector3 Up => _up;


        // This is simply the aspect ratio of the viewport, used for the projection matrix
        public float AspectRatio {  get; set; }

        public Vector3 Right { get { return Vector3.Normalize(Vector3.Cross(Front, _up)); } }

        public Vector3 Center { get { return Position + Front; } }

        public float Fov
        {
            get => MathHelper.RadiansToDegrees(_fov);
            set
            {
                var angle = Clamp(value, 1f, 160f);
                _fov = MathHelper.DegreesToRadians(angle);
            }
        }

        public float Near { get { return _near; } set { _near = value; } }
        public float Far { get { return _far; } set { _far = value; } }


        public void setPosition(Vector3 value)
        {
            _position = value;
            _InsideMat = Matrix4.LookAt(_position, _position + _front, _up);
        }
        public void setPosition(float x, float y, float z)
        {
            setPosition(new Vector3(x, y, z));
        }
        public void moveFront(float distance)
        {
            Position += distance * Front;
            _InsideMat = Matrix4.LookAt(_position, _position + _front, _up);
        }
        public void moveUp(float distance)
        {
            _up.Normalize();
            Position += distance * _up;
            _InsideMat = Matrix4.LookAt(_position, _position + _front, _up);
        }
        public void moveRight(float distance)
        {

            Position += distance * Right;
            _InsideMat = Matrix4.LookAt(_position, _position + _front, _up);
        }
        public Vector3 getRotation()
        {
            Quaternion quat = _InsideMat.ExtractRotation(false);
            Vector3 retRotate = quat.ToEulerAngles();
            retRotate.X = MathHelper.RadiansToDegrees(retRotate.X);
            retRotate.Y = MathHelper.RadiansToDegrees(retRotate.Y);
            retRotate.Z = MathHelper.RadiansToDegrees(retRotate.Z);

            return retRotate;
        }
        public void setRotation(Vector3 EulorAngle)
        {
            Quaternion quat = Quaternion.FromEulerAngles(MathHelper.DegreesToRadians(EulorAngle.X),
                                                         MathHelper.DegreesToRadians(EulorAngle.Y),
                                                         MathHelper.DegreesToRadians(EulorAngle.Z));
            Matrix4 mat = Matrix4.CreateFromQuaternion(quat);

            _front.X = -mat.Row0.Z;
            _front.Y = -mat.Row1.Z;
            _front.Z = -mat.Row2.Z;

            _up.X = mat.Row0.Y;
            _up.Y = mat.Row1.Y;
            _up.Z = mat.Row2.Y;


            _InsideMat = Matrix4.LookAt(Position, Position + _front, _up);
        }
        public void rotateY(float angle)
        {
            Vector3 tCenter = new Vector3(Position + Front);

            Matrix3 RotateMatrix = Matrix3.CreateFromAxisAngle(_up, MathHelper.DegreesToRadians(angle));

            tCenter = RotateMatrix * tCenter;
            _front = tCenter - _position;

            _InsideMat = Matrix4.LookAt(Position, tCenter, _up);
        }
        public void rotateX(float angle)
        {
            Vector3 tCenter = new Vector3(Position + Front);
            Vector3 tUp = new Vector3(Position + _up);
            Vector3 tRight = Right;

            Matrix3 RotateMatrix = Matrix3.CreateFromAxisAngle(tRight, MathHelper.DegreesToRadians(angle));

            tCenter = RotateMatrix * tCenter;
            _front = tCenter - _position;
            tUp = RotateMatrix * tUp;
            _up = Vector3.Normalize(tUp - _position);


            _InsideMat = Matrix4.LookAt(Position, tCenter, _up);
        }
        public void rotateZ(float angle)
        {
            Vector3 tCenter = new Vector3(Position + Front);
            Vector3 tUp = new Vector3(Position + _up);
            Matrix3 RotateMatrix = Matrix3.CreateFromAxisAngle(_front, MathHelper.DegreesToRadians(angle));
            tUp = RotateMatrix * tUp;
            _up = Vector3.Normalize(tUp - Position);
            _InsideMat = Matrix4.LookAt(Position, Position + _front, _up);
        }


        // Get the view matrix using the amazing LookAt function described more in depth on the web tutorials
        public Matrix4 GetViewMatrix()
        {
            return _InsideMat;
            //  return Matrix4.LookAt(Position, Center, _up);
        }

        // Get the projection matrix using the same method we have used up until this point
        public Matrix4 GetProjectionMatrix()
        {
            return Matrix4.CreatePerspectiveFieldOfView(_fov, AspectRatio, _near, _far);
        }


        float Clamp(float val, float min, float max)
        {
            return val > max ? max : val < min ? min : val;
        }

        //
        // 摘要:
        //     Build a world space to camera space matrix.
        //
        // 参数:
        //   eye:
        //     Eye (camera) position in world space.
        //
        //   target:
        //     Target position in world space.
        //
        //   up:
        //     Up vector in world space (should not be parallel to the camera direction, that
        //     is target - eye).
        //
        // 返回结果:
        //     A Matrix4 that transforms world space to camera space.
        public static Matrix4 LookAt(Vector3 eye, Vector3 target, Vector3 up)
        {
            Vector3 vector = Vector3.Normalize(eye - target);
            Vector3 right = Vector3.Normalize(Vector3.Cross(up, vector));
            Vector3 vector2 = Vector3.Normalize(Vector3.Cross(vector, right));

            Matrix4 result = default(Matrix4);
            result.Row0.X = right.X;
            result.Row0.Y = vector2.X;
            result.Row0.Z = vector.X;
            result.Row0.W = 0f;
            result.Row1.X = right.Y;
            result.Row1.Y = vector2.Y;
            result.Row1.Z = vector.Y;
            result.Row1.W = 0f;
            result.Row2.X = right.Z;
            result.Row2.Y = vector2.Z;
            result.Row2.Z = vector.Z;
            result.Row2.W = 0f;
            result.Row3.X = 0f - (right.X * eye.X + right.Y * eye.Y + right.Z * eye.Z);
            result.Row3.Y = 0f - (vector2.X * eye.X + vector2.Y * eye.Y + vector2.Z * eye.Z);
            result.Row3.Z = 0f - (vector.X * eye.X + vector.Y * eye.Y + vector.Z * eye.Z);
            result.Row3.W = 1f;

            /*  Vector3 tRight = new Vector3();
              tRight.X = result.Row0.X;
              tRight.Y = result.Row1.X;
              tRight.Z = result.Row2.X;

              Vector3 tFront = new Vector3();
              tFront.X = result.Row0.Z;
              tFront.Y = result.Row1.Z;
              tFront.Z = result.Row2.Z;

              Vector3 tUp = new Vector3();
              tUp.X = result.Row0.Z;
              tUp.Y = result.Row1.Z;
              tUp.Z = result.Row2.Z;

              Vector3 ttUp = new Vector3();
              ttUp = Vector3.Cross(tRight, tFront);
            */
            return result;
        }
    }
}
