﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Mathematics;

namespace OpenGLObject
{
    // 定义一个委托类型
    public delegate Matrix4 TransformMatrixDelegate(Transform obj);

    public class Transform 
    {
        public Vector3 position = new Vector3(0f, 0f, 0f);
        public Vector3 scale = new Vector3(1f, 1f, 1f);
        public Vector3 rotation = new Vector3(0f, 0f, 0f);

        public TransformMatrixDelegate? transformMatrixDelegete;
        public Transform()
        {
            transformMatrixDelegete = TransformMatrix;
        }
        static public Matrix4 TransformMatrix(Transform _tranform)
        {
            return Matrix4.CreateScale(_tranform.scale) *
                   Matrix4.CreateFromQuaternion(
                       Quaternion.FromEulerAngles(MathHelper.DegreesToRadians(_tranform.rotation.X),
                                                  MathHelper.DegreesToRadians(_tranform.rotation.Y),
                                                  MathHelper.DegreesToRadians(_tranform.rotation.Z)))
                   * Matrix4.CreateTranslation(_tranform.position);
        }
        public virtual Matrix4 GetMatrix4()
        {
            if (transformMatrixDelegete == null)
            {
                Matrix4 mat = Matrix4.CreateScale(scale) *
                        Matrix4.CreateFromQuaternion(
                            Quaternion.FromEulerAngles(MathHelper.DegreesToRadians(rotation.X),
                                                       MathHelper.DegreesToRadians(rotation.Y),
                                                       MathHelper.DegreesToRadians(rotation.Z)))
                                       * Matrix4.CreateTranslation(position);

                return mat;
            }
            else
            {
                return transformMatrixDelegete(this);
            }
        }
        public Vector3 GetPositon()
        {
            return position;
        }
        public Vector3 GetScale()
        {
            return scale;
        }
        public Vector3 GetRotation()
        {
            return rotation;
        }

        public void MoveDistance(Vector3 moveDirect, float length)
        {
            moveDirect.Normalize();
            position.X += (float)(Math.Cos(moveDirect.X) * length);
            position.Y += (float)(Math.Cos(moveDirect.Y) * length);
            position.Y += (float)(Math.Cos(moveDirect.Y) * length);
        }
        public void SetRotation(float angleX, float angleY, float angleZ)
        {
            rotation.X = angleX;
            rotation.Y = angleY;
            rotation.Z = angleZ;
        }
        public void SetRotate(float angleX, float angleY, float angleZ)
        {
            rotation.X += angleX;
            rotation.Y += angleY;
            rotation.Z += angleZ;
        }
        public void SetPosition(float x, float y, float z)
        {
            position.X = x;
            position.Y = y;
            position.Z = z;
        }
        public void SetScale(float x, float y, float z)
        {
            scale.X = x;
            scale.Y = y;
            scale.Z = z;
        }

        public void SetPosition(Vector3 v3)
        {
            position.X = v3.X;
            position.Y = v3.Y;
            position.Z = v3.Z;
        }
        public void SetScale(Vector3 v3)
        {
            scale.X = v3.X;
            scale.Y = v3.Y;
            scale.Z = v3.Z;
        }
        public void SetRotation(Vector3 v3)
        {
            rotation.X = v3.X;
            rotation.Y = v3.Y;
            rotation.Z = v3.Z;
        }

    }
}
