﻿global using EBO = OpenGLObject.ElementBufferObject;
global using IBO = OpenGLObject.ElementBufferObject;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using OpenTK.Graphics;
using OpenTK.Platform;
using OpenTK.Graphics.OpenGL4;


namespace OpenGLObject
{
    public class ElementBufferObject : OpenglObject
    {
        public ElementBufferObject()
        {
            GL.GenBuffers(1, out _id);
        }
        //注意EBO的绑定函数必须在VAO绑定函数调用后才能调用
        public override void Bind()
        {
               GL.BindBuffer(BufferTarget.ElementArrayBuffer, _id);
        }

        //注意解绑函数必须在调用VAO解绑函数调用后，才能调用
        public override void Unbind()
        {
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
        }

        public void SetData<T>(T[] data, int itemSize, BufferUsageHint usage) where T : struct
        {
           GL.BufferData(BufferTarget.ElementArrayBuffer, itemSize, data, BufferUsageHint.StaticDraw);
        }
        protected override void Destory()
        {
            GL.DeleteVertexArray(_id);
        }
    }

    
}
