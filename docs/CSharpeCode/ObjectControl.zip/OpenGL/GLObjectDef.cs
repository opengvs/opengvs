﻿global using GL_Obd = OpenGLObject.GLObjectDef;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Mathematics;
using OpenTK.Graphics.OpenGL4;
using System.Collections;
using OpenTK.Windowing.Common.Input;
using System.Runtime.CompilerServices;


namespace OpenGLObject
{
    
    public class GLObjectDef : Transform
    {

        
        public GLObjectDef(VAO _vaoObj, GLObjectDef? _parent = null) : base()
        {
            if (_parent == null)
                _parentObject = null;
            else
                _parentObject = _parent;
            AddVAO(_vaoObj);

        }
        public GLObjectDef(GLObjectDef? _parent = null) : base()
        {
            if (_parent == null)
                _parentObject = null;
            else
                _parentObject = _parent;
        }



        public List<VAO> listVAO = new List<VAO>();//每个定义的物体内部包含多个VAO对象,每一个VAO对象均可完成绘制
        public VAO AddVAO(VAO _vao)
        {
            listVAO.Add(_vao);

            return _vao;
        }
        public VAO AddVAO<T>(T[] data, int dataSize, BufferUsageHint usage, params int[] itemSize) where T : struct
        {
            VAO _vao = new VertexArrayObject();
            _vao.Bind();
            _vao.AddVertexBufferObject(data, dataSize, usage, itemSize);
            _vao.Unbind();

            return _vao;
        }
        //该函数使用顶点数组创建VAO并加入到OBD中，其他属性通过返回值的VAO对象中的函数进行设置
        public VAO AddVAO(float[] data, int size, int itemSize, BufferUsageHint usage, int index = 0)
        {
            VAO _vao = new VertexArrayObject();
            _vao.Bind();
            _vao.AddVertexBufferObjectFloat(data, size, itemSize, usage, index);
            _vao.Unbind();

            return _vao;
        }
        public VAO AddVAO(Vector3[] data, int size, int itemSize, BufferUsageHint usage, int index)
        {
            VAO _vao = new VertexArrayObject();
            _vao.Bind();
            _vao.AddVertexBufferObjectVector3(data, size, itemSize, usage, index);
            _vao.Unbind();

            return _vao;
        }

        public List<GLObjectDef> listChildren = new List<GLObjectDef>();//每个物体又可以包含多个子定义物体
        public GLObjectDef _parentObject = null;
        public bool _isDrawBox = false;

        public List<GLObjectInstance> obiList = new List<GLObjectInstance>();


        public virtual void Draw()
        {
            foreach (VAO _vao in listVAO)
            {
                _vao.Draw();
            }
            foreach (GLObjectDef childObject in listChildren)
            {
                childObject.Draw();
            }

        }


    }
}
