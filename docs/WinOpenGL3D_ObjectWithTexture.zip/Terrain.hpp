﻿//FIleName:Terrain.hpp

#ifndef  __TERRAIN_HPP__
#define  __TERRAIN_HPP__
#include "VAOWithVBOandEBO.hpp"


class Terrain
{
    VAOWithVBOandEBO   m_terrain;
    int    m_VertexNum=(10-(-10))* (10 - (-10))*6;
public:
    Terrain()
    {

    }
    ~Terrain()
    {

    }
    void InitializeData()
    {
        float *tempVertex = new float[6*20*20*6];
        int k = 0;
        for (int i = -10; i < 10; i++)
        {
            for (int j = -10; j < 10; j++)
            {
                //0 
                tempVertex[k++] = i;tempVertex[k++] = 0.0f;tempVertex[k++] = j;
               
                tempVertex[k++] = 1.0f;tempVertex[k++] = 1.0f;tempVertex[k++] = 1.0f;

                tempVertex[k++] = i + 1.0f;tempVertex[k++] = 0.0f;tempVertex[k++] = j + 1.0f;
                tempVertex[k++] = 1.0f;    tempVertex[k++] = 1.0f;tempVertex[k++] = 1.0f;
                tempVertex[k++] = i + 1.0f;tempVertex[k++] = 0.0f;tempVertex[k++] = j;
                tempVertex[k++] = 1.0f;    tempVertex[k++] = 1.0f;tempVertex[k++] = 1.0f;
                //1
                tempVertex[k++] = i;tempVertex[k++] = 0.0f; tempVertex[k++] = j + 1;
                tempVertex[k++] = 0.5f;tempVertex[k++] = 0.0f;tempVertex[k++] = 0.5f;

                tempVertex[k++] = i + 1;tempVertex[k++] = 0.0f;tempVertex[k++] = j + 1;
                tempVertex[k++] = 0.5f; tempVertex[k++] = 0.0f;tempVertex[k++] = 0.5f;
               
                tempVertex[k++] = i;    tempVertex[k++] = 0.0f;tempVertex[k++] = j;
                tempVertex[k++] = 0.5f; tempVertex[k++] = 0.0f;tempVertex[k++] = 0.5f;
            }
        }
        m_VertexNum = k / 6;

        m_terrain.AddVBO({ tempVertex }, { k }, BufferUsageHint::StaticDraw, { { 3,3 } } );
        delete[] tempVertex;
    }
    void Draw()
    {

        m_terrain.DrawArrays(PrimitiveType::Triangles, 0, m_VertexNum);
    }
};

#endif

