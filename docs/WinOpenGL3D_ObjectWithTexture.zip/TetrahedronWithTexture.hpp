﻿#pragma once
#include "VAOWithVBOandEBO.hpp"
#include "Transform.hpp"
#include "Camera.hpp"
#include "Shader.hpp"
#include "GLTexture.hpp"



class TetrahedronWithTexture : public Transform
{
    const std::string m_VertexShaderWithPosColorTex = R"(
#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in  vec3 inColor;
layout(location = 2) in vec2 aTexCoord;

out vec2 TexCoord;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(aPos, 1.0f);
    TexCoord = vec2(aTexCoord.x, aTexCoord.y);
}
)";

    const std::string m_FrageShaderWithPosColorTex = R"(
#version 330 core
out vec4 FragColor;

in vec2 TexCoord;

// texture samplers
uniform sampler2D texture1;

void main()
{
    FragColor = texture(texture1, TexCoord);
}
)";
private:
	static float m_Vertecis[];
    static float vertdata[];
    static unsigned int indicedata[];

    VAOWithVBOandEBO   m_VaoWithVbo;
    Shader     m_shader;
    GLTexture  m_texture1;
public:
    void InitializeData()
    {
        m_shader.InitializeShaderWithString(m_VertexShaderWithPosColorTex.c_str(),
            m_FrageShaderWithPosColorTex.c_str());
        std::string _pathStr = Win::GetCurrentModuleDirectory();
        m_texture1.Load_Texture_FromFile_stb(std::string(_pathStr + "\\ground.bmp").c_str());


        m_VaoWithVbo.AddVBO({ m_Vertecis }, { 8 * 12 }, BufferUsageHint::StaticDraw,
            { {3,3,2} });

    }
    void Draw(Camera& _camera)
    {
        m_shader.Use();
        m_shader.setInt("texture1", 0);
        m_shader.setInt("texture2", 1);

        m_texture1.Bind(TextureUnit::Texture0);


        
        this->RotateAngleY(glm::radians(0.05f));


        // note: currently we set the projection matrix each frame, but since the projection matrix rarely changes it's often best practice to set it outside the main loop only once.
        m_shader.SetMat4("projection", _camera.GetProjectionMat());
        m_shader.SetMat4("model", GetMat());
        m_shader.SetMat4("view", _camera.GetViewMat());

        m_VaoWithVbo.DrawArrays(PrimitiveType::Triangles, 0, 12);
       
        m_shader.UnUse();
        m_texture1.Unbind();

    }
};

float TetrahedronWithTexture::m_Vertecis[] =
{
        1.0f, 0.0f,  -1.0f,0.0f, 0.0f, 1.0f,0.5f,1.0f,
         1.0f, 0.0f,  1.0f,0.0f,  1.0f, 0.0f,0.0f,0.0f,
        -1.0f, 0.0f,  1.0f,1.0f, 0.0f, 0.0f, 1.0f,0.0f,

         1.0f, 0.0f,  -1.0f,0.0f, 0.0f, 1.0f,0.5f,1.0f,
         1.0f, 0.0f,  1.0f,0.0f,  1.0f, 0.0f,0.0f,0.0f,
        0.0f, 1.0f,  0.0f,0.0f, 1.0f,  0.0f, 1.0f,0.0f,

         1.0f, 0.0f,  -1.0f,0.0f, 0.0f, 1.0f,0.5f,1.0f,
         0.0f, 1.0f,  0.0f,0.0f, 1.0f,  0.0f,0.0f,0.0f,
        -1.0f, 0.0f,  1.0f,1.0f, 0.0f,  0.0f, 1.0f,0.0f,

         1.0f, 0.0f,  1.0f,0.0f,  1.0f, 0.0f,0.5f,1.0f,
         -1.0f, 0.0f,  1.0f,1.0f, 0.0f, 0.0f,0.0f,0.0f,
        0.0f, 1.0f,  0.0f,0.0f, 1.0f,  0.0f, 1.0f,0.0f
};

