
/*!
 * \file	StringToNumber.hpp
 * \brief	The template functions for std::string/std::wstring convert to number.
 * \date	2019-08-09
 * \
 */
#ifndef  __STRINGTONUMBER_HPP
#define  __STRINGTONUMBER_HPP

#include <string>
#include <stdexcept>
#include <iostream>
#include <sstream> //ʹ��stringstream��Ҫ�������ͷ�ļ�

 // ���ʧ�ܣ��׳�std::logic_error�쳣������Ϊstd::invalid_argument��std::out_of_range��

 /*****************************************************************************
	 toNumber(str, pos, base) ==>
		 short, ushort, int, uint, long, ulong,
		 long long, ulonglong
  *****************************************************************************/

template<typename T>
inline T toNumber(const std::string& str, std::size_t* pos, int base)
{
	throw std::invalid_argument("\\fn[toNumber(str, pos, base)] invalid template argument.");
}
template<typename T>
inline T toNumber(const std::wstring& str, std::size_t* pos, int base)
{
	throw std::invalid_argument("\\fn[toNumber(str, pos, base)] invalid template argument.");
}

template<>
inline short toNumber(const std::string& str, std::size_t* pos, int base)
{
	return static_cast<short>(std::stoi(str, pos, base));
}
template<>
inline short toNumber(const std::wstring& str, std::size_t* pos, int base)
{
	return static_cast<short>(std::stoi(str, pos, base));
}

template<>
inline unsigned short toNumber(const std::string& str, std::size_t* pos, int base)
{
	return static_cast<unsigned short>(std::stoul(str, pos, base));
}
template<>
inline unsigned short toNumber(const std::wstring& str, std::size_t* pos, int base)
{
	return static_cast<unsigned short>(std::stoul(str, pos, base));
}

template<>
inline int toNumber(const std::string& str, std::size_t* pos, int base)
{
	return std::stoi(str, pos, base);
}
template<>
inline int toNumber(const std::wstring& str, std::size_t* pos, int base)
{
	return std::stoi(str, pos, base);
}

template<>
inline unsigned int toNumber(const std::string& str, std::size_t* pos, int base)
{
	return static_cast<unsigned int>(std::stoul(str, pos, base));
}
template<>
inline unsigned int toNumber(const std::wstring& str, std::size_t* pos, int base)
{
	return static_cast<unsigned int>(std::stoul(str, pos, base));
}

template<>
inline long toNumber(const std::string& str, std::size_t* pos, int base)
{
	return std::stol(str, pos, base);
}
template<>
inline long toNumber(const std::wstring& str, std::size_t* pos, int base)
{
	return std::stol(str, pos, base);
}

template<>
inline unsigned long toNumber(const std::string& str, std::size_t* pos, int base)
{
	return std::stoul(str, pos, base);
}
template<>
inline unsigned long toNumber(const std::wstring& str, std::size_t* pos, int base)
{
	return std::stoul(str, pos, base);
}

template<>
inline long long toNumber(const std::string& str, std::size_t* pos, int base)
{
	return std::stoll(str, pos, base);
}
template<>
inline long long toNumber(const std::wstring& str, std::size_t* pos, int base)
{
	return std::stoll(str, pos, base);
}

template<>
inline unsigned long long toNumber(const std::string& str, std::size_t* pos, int base)
{
	return std::stoull(str, pos, base);
}
template<>
inline unsigned long long toNumber(const std::wstring& str, std::size_t* pos, int base)
{
	return std::stoull(str, pos, base);
}

/*****************************************************************************
	toNumber(str, pos) ==>
		short, ushort, int, uint, long, ulong,
		long long, ulonglong, float, double, long double
 *****************************************************************************/

template<typename T>
inline T toNumber(const std::string& str, std::size_t* pos)
{
	throw std::invalid_argument("\\fn[toNumber(str, pos)] invalid template argument.");
}
template<typename T>
inline T toNumber(const std::wstring& str, std::size_t* pos)
{
	throw std::invalid_argument("\\fn[toNumber(str, pos)] invalid template argument.");
}

template<>
inline short toNumber(const std::string& str, std::size_t* pos)
{
	return static_cast<short>(std::stoi(str, pos));
}
template<>
inline short toNumber(const std::wstring& str, std::size_t* pos)
{
	return static_cast<short>(std::stoi(str, pos));
}

template<>
inline unsigned short toNumber(const std::string& str, std::size_t* pos)
{
	return static_cast<unsigned short>(std::stoul(str, pos));
}
template<>
inline unsigned short toNumber(const std::wstring& str, std::size_t* pos)
{
	return static_cast<unsigned short>(std::stoul(str, pos));
}

template<>
inline int toNumber(const std::string& str, std::size_t* pos)
{
	return std::stoi(str, pos);
}
template<>
inline int toNumber(const std::wstring& str, std::size_t* pos)
{
	return std::stoi(str, pos);
}

template<>
inline unsigned int toNumber(const std::string& str, std::size_t* pos)
{
	return static_cast<unsigned int>(std::stoul(str, pos));
}
template<>
inline unsigned int toNumber(const std::wstring& str, std::size_t* pos)
{
	return static_cast<unsigned int>(std::stoul(str, pos));
}

template<>
inline long toNumber(const std::string& str, std::size_t* pos)
{
	return std::stol(str, pos);
}
template<>
inline long toNumber(const std::wstring& str, std::size_t* pos)
{
	return std::stol(str, pos);
}

template<>
inline unsigned long toNumber(const std::string& str, std::size_t* pos)
{
	return std::stoul(str, pos);
}
template<>
inline unsigned long toNumber(const std::wstring& str, std::size_t* pos)
{
	return std::stoul(str, pos);
}

template<>
inline long long toNumber(const std::string& str, std::size_t* pos)
{
	return std::stoll(str, pos);
}
template<>
inline long long toNumber(const std::wstring& str, std::size_t* pos)
{
	return std::stoll(str, pos);
}

template<>
inline unsigned long long toNumber(const std::string& str, std::size_t* pos)
{
	return std::stoull(str, pos);
}
template<>
inline unsigned long long toNumber(const std::wstring& str, std::size_t* pos)
{
	return std::stoull(str, pos);
}

template<>
inline float toNumber(const std::string& str, std::size_t* pos)
{
	return std::stof(str, pos);
}
template<>
inline float toNumber(const std::wstring& str, std::size_t* pos)
{
	return std::stof(str, pos);
}

template<>
inline double toNumber(const std::string& str, std::size_t* pos)
{
	return std::stod(str, pos);
}
template<>
inline double toNumber(const std::wstring& str, std::size_t* pos)
{
	return std::stod(str, pos);
}

template<>
inline long double toNumber(const std::string& str, std::size_t* pos)
{
	return std::stold(str, pos);
}
template<>
inline long double toNumber(const std::wstring& str, std::size_t* pos)
{
	return std::stold(str, pos);
}

/*****************************************************************************
	toNumber(str) ==>
		short, ushort, int, uint, long, ulong,
		long long, ulonglong, float, double, long double
 *****************************************************************************/

template<typename T>
inline T toNumber(const std::string& str)
{
	throw std::invalid_argument("\\fn[toNumber(str)] invalid template argument.");
}
template<typename T>
inline T toNumber(const std::wstring& str)
{
	throw std::invalid_argument("\\fn[toNumber(str)] invalid template argument.");
}

template<>
inline short toNumber(const std::string& str)
{
	return static_cast<short>(std::stoi(str));
}
template<>
inline short toNumber(const std::wstring& str)
{
	return static_cast<short>(std::stoi(str));
}

template<>
inline unsigned short toNumber(const std::string& str)
{
	return static_cast<unsigned short>(std::stoul(str));
}
template<>
inline unsigned short toNumber(const std::wstring& str)
{
	return static_cast<unsigned short>(std::stoul(str));
}

template<>
inline int toNumber(const std::string& str)
{
	return std::stoi(str);
}
template<>
inline int toNumber(const std::wstring& str)
{
	return std::stoi(str);
}

template<>
inline unsigned int toNumber(const std::string& str)
{
	return static_cast<unsigned int>(std::stoul(str));
}
template<>
inline unsigned int toNumber(const std::wstring& str)
{
	return static_cast<unsigned int>(std::stoul(str));
}

template<>
inline long toNumber(const std::string& str)
{
	return std::stol(str);
}
template<>
inline long toNumber(const std::wstring& str)
{
	return std::stol(str);
}

template<>
inline unsigned long toNumber(const std::string& str)
{
	return std::stoul(str);
}
template<>
inline unsigned long toNumber(const std::wstring& str)
{
	return std::stoul(str);
}

template<>
inline long long toNumber(const std::string& str)
{
	return std::stoll(str);
}
template<>
inline long long toNumber(const std::wstring& str)
{
	return std::stoll(str);
}

template<>
inline unsigned long long toNumber(const std::string& str)
{
	return std::stoull(str);
}
template<>
inline unsigned long long toNumber(const std::wstring& str)
{
	return std::stoull(str);
}

template<>
inline float toNumber(const std::string& str)
{
	return std::stof(str);
}
template<>
inline float toNumber(const std::wstring& str)
{
	return std::stof(str);
}

template<>
inline double toNumber(const std::string& str)
{
	return std::stod(str);
}
template<>
inline double toNumber(const std::wstring& str)
{
	return std::stod(str);
}

template<>
inline long double toNumber(const std::string& str)
{
	return std::stold(str);
}
template<>
inline long double toNumber(const std::wstring& str)
{
	return std::stold(str);
}

/*****************************************************************************
	toNumberEx()
	Ϊ���ܱ�֤ʹ��decltype�Ƶ�����ȷ������
	��:
		const int a = 0;
		String str = "2";
		auto b = strToNumber<decltype(a)>(str); // decltype(a)Ϊconst int
		// b������Ϊint
	���ʹ��
		toNumber<decltype(a)>(str). // decltype(a)Ϊconst int
	���׳��쳣��
 *****************************************************************************/

template<typename T>
inline std::decay_t<T> toNumberEx(const std::string& str, std::size_t* pos, int base)
{
	return toNumber<std::decay_t<T>>(str, pos, base);
}
template<typename T>
inline std::decay_t<T> toNumberEx(const std::wstring& str, std::size_t* pos, int base)
{
	return toNumber<std::decay_t<T>>(str, pos, base);
}

template<typename T>
inline std::decay_t<T> toNumberEx(const std::string& str, std::size_t* pos)
{
	return toNumber<std::decay_t<T>>(str, pos);
}
template<typename T>
inline std::decay_t<T> toNumberEx(const std::wstring& str, std::size_t* pos)
{
	return toNumber<std::decay_t<T>>(str, pos);
}

template<typename T>
inline std::decay_t<T> toNumberEx(const std::string& str)
{
	return toNumber<std::decay_t<T>>(str);
}
template<typename T>
inline std::decay_t<T> toNumberEx(const std::wstring& str)
{
	return toNumber<std::decay_t<T>>(str);
}


template<class Type>
inline std::string NumToString(const Type& num)
{
	std::stringstream iss;
	iss << num;
	std::string str;
	iss >> str;
	return str;
}
template<class Type>
inline std::string NumListToString(Type* Coord, int nCount, std::string splt = ",")
{
	std::string strList;
	for (int i = 0; i < nCount; i++)
	{
		std::string str = NumToString<Type>(Coord[i]);
		if (i < nCount - 1)
			strList = strList + str + splt;
		else
			strList = strList + str;
	}
	//    strList = strList.substr(0, strList.length()-1);
	return strList;
}

template<class Type>
inline std::wstring NumToWString(const Type& num)
{
	std::wstringstream iss;
	iss << num;
	std::wstring str;
	iss >> str;
	return str;
}
template<class Type>
inline std::wstring NumListToString(Type* Coord, int nCount, std::wstring splt = ",")
{
	std::wstring strList;
	for (int i = 0; i < nCount; i++)
	{
		std::wstring str = NumToWString<Type>(Coord[i]);
		if (i < nCount - 1)
			strList = strList + str + splt;
		else
			strList = strList + str;
	}
	//    strList = strList.substr(0, strList.length()-1);
	return strList;
}

#endif 