﻿// WinMainApp.cpp : 定义应用程序的入口点。
//

#include "framework.h"
#include "WinMainApp.h"
#include "WinForm.hpp"
#include "GLContext.hpp"
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"
#include <string>
#include "Shader.hpp"
#include "Camera.hpp"
#include "Format.h"

#include "Terrain.hpp"
#include "CubeObjectWithPositionTexture.hpp"
#include "TetrahedronWithTexture.hpp"


#define MAX_LOADSTRING 100

// 全局变量:
HINSTANCE hInst;                                // 当前实例
WCHAR szTitle[MAX_LOADSTRING];                  // 标题栏文本
WCHAR szWindowClass[MAX_LOADSTRING];            // 主窗口类名
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

class  WindowsForm :public Win::WinForm, public GLContext
{
private:
    //注意: attribute属性修饰在更高版本的GLSL中被弃用，使用in替代
    std::string  m_vertexShader = R"(
        #version 460 core
        layout(location = 0) in  vec3 inPosition;
        layout(location = 1) in  vec3 inColor;
        uniform mat4 ModelMatrix;
        uniform mat4 ViewMatrix;
        uniform mat4 ProjectionMatrix;
        
        out VertexAtrbuteData {
              vec3 color;
        } vs_out;

        void main()
        {
            gl_Position = ProjectionMatrix * ViewMatrix * ModelMatrix *vec4(inPosition,1.0);
            vs_out.color = inColor;
        }
                                )";



    std::string  m_fragmentShader = R"(
    #version 460 core
    in VertexAtrbuteData {
              vec3 color;
        } fs_in;
    out vec4 color;
    void main()
    {
        color = vec4(fs_in.color,1);
    }
  )";

private:
    Win::Button  m_AboutButton;
    Win::Button  m_CloseButton;
    Win::EditBox m_Mat00;
    Win::EditBox m_Mat01;
    Win::EditBox m_Mat02;
    Win::EditBox m_Mat03;

    Win::EditBox m_Mat10;
    Win::EditBox m_Mat11;
    Win::EditBox m_Mat12;
    Win::EditBox m_Mat13;
    Win::EditBox m_Mat20;
    Win::EditBox m_Mat21;
    Win::EditBox m_Mat22;
    Win::EditBox m_Mat23;
    Win::EditBox m_Mat30;
    Win::EditBox m_Mat31;
    Win::EditBox m_Mat32;
    Win::EditBox m_Mat33;

    Win::EditBox m_Rotation_X_Edit;
    Win::EditBox m_Rotation_Y_Edit;
    Win::EditBox m_Rotation_Z_Edit;

    Win::Button  m_RatationButtion;
    Win::RadioButton m_AUTORATATION;
    Win::UpDownBox   m_MOVEX_SPIN;
    Win::UpDownBox   m_MOVEY_SPIN;

    Win::EditBox   m_SCALE_X_EDIT;
    Win::EditBox   m_SCALE_Y_EDIT;
    Win::EditBox   m_SCALE_Z_EDIT;
    Win::Trackbar  m_SCALE_X_SLIDER;
    Win::Trackbar  m_SCALE_Y_SLIDER;
    Win::Trackbar  m_SCALE_Z_SLIDER;

    Win::RadioButton m_RADIO1;
    Win::RadioButton m_RADIO2;
  //  Win::RadioButton m_RADIO3;

    Win::Button m_CAMERAMOVEFORWARD;
    Win::Button m_CAMERAMOVEBACK;
    Win::Button m_CAMERAMOVELEFT;
    Win::Button m_CAMERAMOVERIGHT;
    Win::Button m_CAMERAMOVEUP;
    Win::Button m_CAMERAMOVEDOWN;
    

    Win::TextBox m_VIEWMAT00;
    Win::TextBox m_VIEWMAT01;
    Win::TextBox m_VIEWMAT02;
    Win::TextBox m_VIEWMAT03;

    Win::TextBox m_VIEWMAT10;
    Win::TextBox m_VIEWMAT11;
    Win::TextBox m_VIEWMAT12;
    Win::TextBox m_VIEWMAT13;

    Win::TextBox m_VIEWMAT20;
    Win::TextBox m_VIEWMAT21;
    Win::TextBox m_VIEWMAT22;
    Win::TextBox m_VIEWMAT23;

    Win::TextBox m_VIEWMAT30;
    Win::TextBox m_VIEWMAT31;
    Win::TextBox m_VIEWMAT32;
    Win::TextBox m_VIEWMAT33;

    Win::RadioButton m_AROUNDEYEPOSITION;  
    Win::RadioButton m_AROUNDEYELOOKAT;
    Win::UpDownBox m_AROUND_UP;
    Win::UpDownBox m_AROUNDFRONT;
    Win::UpDownBox m_AROUNDRIGHT;

    Win::EditBox m_CAMERA_FOV_EDIT;
    Win::EditBox m_CAMERA_NEAR_EDIT;
    Win::EditBox m_CAMERA_FAR_EDIT;

    Win::TextBox m_CAMERA_PRJ_MAT_00;
    Win::TextBox m_CAMERA_PRJ_MAT_01;
    Win::TextBox m_CAMERA_PRJ_MAT_02;
    Win::TextBox m_CAMERA_PRJ_MAT_03;

    Win::TextBox m_CAMERA_PRJ_MAT_10;
    Win::TextBox m_CAMERA_PRJ_MAT_11;
    Win::TextBox m_CAMERA_PRJ_MAT_12;
    Win::TextBox m_CAMERA_PRJ_MAT_13;

    Win::TextBox m_CAMERA_PRJ_MAT_20;
    Win::TextBox m_CAMERA_PRJ_MAT_21;
    Win::TextBox m_CAMERA_PRJ_MAT_22;
    Win::TextBox m_CAMERA_PRJ_MAT_23;

    Win::TextBox m_CAMERA_PRJ_MAT_30;
    Win::TextBox m_CAMERA_PRJ_MAT_31;
    Win::TextBox m_CAMERA_PRJ_MAT_32;
    Win::TextBox m_CAMERA_PRJ_MAT_33;

    Win::CheckBox m_CREATEMIPMAPBOOL;
    Win::ComboBox m_TEXTUREWRAPMODECOMBO;
    Win::ComboBox m_TEXTUREMAGFILTERMODECOMBO;
    Win::ComboBox m_TEXTUREMINFILTERMODECOMBO;
    Win::Trackbar m_TEXTUREMIXBLENDINGFACTORSLIDER;

public:
    WindowsForm() :Win::WinForm(), GLContext()
    {

    };
    void SetViewProjectMat(const glm::mat4& mat)
    {
        std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][0]);
        m_CAMERA_PRJ_MAT_00.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][1]);
        m_CAMERA_PRJ_MAT_01.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][2]);
        m_CAMERA_PRJ_MAT_02.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][3]);
        m_CAMERA_PRJ_MAT_03.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][0]);
        m_CAMERA_PRJ_MAT_10.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][1]);
        m_CAMERA_PRJ_MAT_11.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][2]);
        m_CAMERA_PRJ_MAT_12.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][3]);
        m_CAMERA_PRJ_MAT_13.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][0]);
        m_CAMERA_PRJ_MAT_20.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][1]);
        m_CAMERA_PRJ_MAT_21.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][2]);
        m_CAMERA_PRJ_MAT_22.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][3]);
        m_CAMERA_PRJ_MAT_23.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][0]);
        m_CAMERA_PRJ_MAT_30.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][1]);
        m_CAMERA_PRJ_MAT_31.setText(tempStr.c_str());
        float tempF = mat[3][2];
        tempStr = StringFormat::wstr_format(L"%.2lf", tempF);
        m_CAMERA_PRJ_MAT_32.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][3]);
        m_CAMERA_PRJ_MAT_33.setText(tempStr.c_str());
    }
    void SetViewMat(const glm::mat4& mat)
    {
        std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][0]);
        m_VIEWMAT00.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][1]);
        m_VIEWMAT01.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][2]);
        m_VIEWMAT02.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][3]);
        m_VIEWMAT03.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][0]);
        m_VIEWMAT10.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][1]);
        m_VIEWMAT11.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][2]);
        m_VIEWMAT12.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][3]);
        m_VIEWMAT13.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][0]);
        m_VIEWMAT20.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][1]);
        m_VIEWMAT21.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][2]);
        m_VIEWMAT22.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][3]);
        m_VIEWMAT23.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][0]);
        m_VIEWMAT30.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][1]);
        m_VIEWMAT31.setText(tempStr.c_str());
        float tempF = mat[3][2];
        tempStr = StringFormat::wstr_format(L"%.2lf", tempF);
        m_VIEWMAT32.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][3]);
        m_VIEWMAT33.setText(tempStr.c_str());
    }
    void SetModelMat( Transform& _transform)
    {
        glm::mat4 mat = _transform.GetMat();
        std::wstring tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][0]);
        m_Mat00.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][1]);
        m_Mat01.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][2]);
        m_Mat02.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[0][3]);
        m_Mat03.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][0]);
        m_Mat10.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][1]);
        m_Mat11.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][2]);
        m_Mat12.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[1][3]);
        m_Mat13.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][0]);
        m_Mat20.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][1]);
        m_Mat21.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][2]);
        m_Mat22.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[2][3]);
        m_Mat23.setText(tempStr.c_str());

        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][0]);
        m_Mat30.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][1]);
        m_Mat31.setText(tempStr.c_str());
        float tempF = mat[3][2];
        tempStr = StringFormat::wstr_format(L"%.2lf", tempF);
        m_Mat32.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", mat[3][3]);
        m_Mat33.setText(tempStr.c_str());

        const glm::vec3& rotation = _transform.GetRotation();
        tempStr = StringFormat::wstr_format(L"%.2lf", glm::degrees(rotation.x));
        m_Rotation_X_Edit.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", glm::degrees(rotation.y));
        m_Rotation_Y_Edit.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", glm::degrees(rotation.z));
        m_Rotation_Z_Edit.setText(tempStr.c_str());

        const glm::vec3& scale = _transform.GetScale();
        tempStr = StringFormat::wstr_format(L"%.2lf", scale.x);
        m_SCALE_X_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", scale.y);
        m_SCALE_Y_EDIT.setText(tempStr.c_str());
        tempStr = StringFormat::wstr_format(L"%.2lf", scale.z);
        m_SCALE_Z_EDIT.setText(tempStr.c_str());

    }
    virtual void Init_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        HWND hWnd = hDlg;// ::GetDlgItem(hDlg, IDC_OPENGLVIEW);
        //::SetWindowPos(hDlg, NULL,0, 0, 680, 650, SWP_NOMOVE);
        m_AboutButton.set(hDlg, IDD_ABOUTBOX);
        m_CloseButton.set(hDlg, IDM_EXIT);
        m_Mat00.set(hDlg, IDC_MAT00);
        m_Mat01.set(hDlg, IDC_MAT01);
        m_Mat02.set(hDlg, IDC_MAT02);
        m_Mat03.set(hDlg, IDC_MAT03);
        m_Mat10.set(hDlg, IDC_MAT10);
        m_Mat11.set(hDlg, IDC_MAT11);
        m_Mat12.set(hDlg, IDC_MAT12);
        m_Mat13.set(hDlg, IDC_MAT13);
        m_Mat20.set(hDlg, IDC_MAT20);
        m_Mat21.set(hDlg, IDC_MAT21);
        m_Mat22.set(hDlg, IDC_MAT22);
        m_Mat23.set(hDlg, IDC_MAT23);
        m_Mat30.set(hDlg, IDC_MAT30);
        m_Mat31.set(hDlg, IDC_MAT31);
        m_Mat32.set(hDlg, IDC_MAT32);
        m_Mat33.set(hDlg, IDC_MAT33);


        m_Rotation_X_Edit.set(hDlg, IDC_ROTATION_X_EDIT);
        m_Rotation_X_Edit.setText(L"0");
        m_Rotation_Y_Edit.set(hDlg, IDC_ROTATION_Y_EDIT);
        m_Rotation_Y_Edit.setText(L"0");
        m_Rotation_Z_Edit.set(hDlg, IDC_ROTATION_Z_EDIT);
        m_Rotation_Z_Edit.setText(L"0");

        m_RatationButtion.set(hDlg, IDC_ROTATIONBUTTON);
        m_AUTORATATION.set(hDlg, IDC_AUTORATATION);
        m_MOVEX_SPIN.set(hDlg, IDC_MOVEX_SPIN);
        m_MOVEX_SPIN.setRange(-100, 100);
        m_MOVEX_SPIN.setPos(0);
        m_MOVEY_SPIN.set(hDlg, IDC_MOVEY_SPIN);
        m_MOVEY_SPIN.setRange(-100, 100);
        m_MOVEY_SPIN.setPos(0);
        m_SCALE_X_EDIT.set(hDlg, IDC_SCALE_X_EDIT);
        m_SCALE_X_EDIT.setText(L"1");
        m_SCALE_Y_EDIT.set(hDlg, IDC_SCALE_Y_EDIT);
        m_SCALE_Y_EDIT.setText(L"1");
        m_SCALE_Z_EDIT.set(hDlg, IDC_SCALE_Z_EDIT);
        m_SCALE_Z_EDIT.setText(L"1");
        m_SCALE_X_SLIDER.set(hDlg, IDC_SCALE_X_SLIDER);
        m_SCALE_X_SLIDER.setRange(1, 100);
        m_SCALE_X_SLIDER.setPos(50);
        m_SCALE_Y_SLIDER.set(hDlg, IDC_SCALE_Y_SLIDER);
        m_SCALE_Y_SLIDER.setRange(1, 100);
        m_SCALE_Y_SLIDER.setPos(50);
        m_SCALE_Z_SLIDER.set(hDlg, IDC_SCALE_Z_SLIDER);
        m_SCALE_Z_SLIDER.setRange(1, 100);
        m_SCALE_Z_SLIDER.setPos(50);

        m_RADIO1.set(hDlg, IDC_RADIO1);
        m_RADIO2.set(hDlg, IDC_RADIO2);
        m_RADIO1.check();

        m_CAMERAMOVEFORWARD.set(hDlg, IDC_CAMERAMOVEFORWARD);
        m_CAMERAMOVEBACK.set(hDlg, IDC_CAMERAMOVEBACK);
        m_CAMERAMOVELEFT.set(hDlg, IDC_CAMERAMOVELEFT);
        m_CAMERAMOVERIGHT.set(hDlg, IDC_CAMERAMOVERIGHT);
        m_CAMERAMOVEUP.set(hDlg, IDC_CAMERAMOVEUP);
        m_CAMERAMOVEDOWN.set(hDlg, IDC_CAMERAMOVEDOWN);
        m_AROUND_UP.set(hDlg, IDC_AROUND_UP);
        m_AROUNDFRONT.set(hDlg, IDC_AROUNDFRONT);
        m_AROUNDRIGHT.set(hDlg, IDC_AROUNDRIGHT);


        m_VIEWMAT00.set(hDlg, IDC_VIEWMAT00);
        m_VIEWMAT01.set(hDlg, IDC_VIEWMAT01);        
        m_VIEWMAT02.set(hDlg, IDC_VIEWMAT02);
        m_VIEWMAT03.set(hDlg, IDC_VIEWMAT03);
        m_VIEWMAT10.set(hDlg, IDC_VIEWMAT10);
        m_VIEWMAT11.set(hDlg, IDC_VIEWMAT11);
        m_VIEWMAT12.set(hDlg, IDC_VIEWMAT12);
        m_VIEWMAT13.set(hDlg, IDC_VIEWMAT13);
       
        m_VIEWMAT20.set(hDlg, IDC_VIEWMAT20);
        m_VIEWMAT21.set(hDlg, IDC_VIEWMAT21);
        m_VIEWMAT22.set(hDlg, IDC_VIEWMAT22);
        m_VIEWMAT23.set(hDlg, IDC_VIEWMAT23);
        m_VIEWMAT30.set(hDlg, IDC_VIEWMAT30);
        m_VIEWMAT31.set(hDlg, IDC_VIEWMAT31);
        m_VIEWMAT32.set(hDlg, IDC_VIEWMAT32);
        m_VIEWMAT33.set(hDlg, IDC_VIEWMAT33);
        m_AROUNDEYEPOSITION.set(hDlg, IDC_AROUNDEYEPOSITION);
        m_AROUNDEYELOOKAT.set(hDlg, IDC_AROUNDEYELOOKAT);
        m_AROUNDEYEPOSITION.check();
        m_CAMERA_FOV_EDIT.set(hDlg, IDC_CAMERA_FOV_EDIT);
        m_CAMERA_FOV_EDIT.setText(L"75");

        m_CAMERA_NEAR_EDIT.set(hDlg, IDC_CAMERA_NEAR_EDIT);
        m_CAMERA_NEAR_EDIT.setText(L"0.1");
        m_CAMERA_FAR_EDIT.set(hDlg, IDC_CAMERA_FAR_EDIT);
        m_CAMERA_FAR_EDIT.setText(L"100");

        m_CAMERA_PRJ_MAT_00.set(hDlg, IDC_CAMERA_PRJ_MAT_00);
        m_CAMERA_PRJ_MAT_01.set(hDlg, IDC_CAMERA_PRJ_MAT_01);
        m_CAMERA_PRJ_MAT_02.set(hDlg, IDC_CAMERA_PRJ_MAT_02);
        m_CAMERA_PRJ_MAT_03.set(hDlg, IDC_CAMERA_PRJ_MAT_03);

        m_CAMERA_PRJ_MAT_10.set(hDlg, IDC_CAMERA_PRJ_MAT_10);
        m_CAMERA_PRJ_MAT_11.set(hDlg, IDC_CAMERA_PRJ_MAT_11);
        m_CAMERA_PRJ_MAT_12.set(hDlg, IDC_CAMERA_PRJ_MAT_12);
        m_CAMERA_PRJ_MAT_13.set(hDlg, IDC_CAMERA_PRJ_MAT_13);

        m_CAMERA_PRJ_MAT_20.set(hDlg, IDC_CAMERA_PRJ_MAT_20);
        m_CAMERA_PRJ_MAT_21.set(hDlg, IDC_CAMERA_PRJ_MAT_21);
        m_CAMERA_PRJ_MAT_22.set(hDlg, IDC_CAMERA_PRJ_MAT_22);
        m_CAMERA_PRJ_MAT_23.set(hDlg, IDC_CAMERA_PRJ_MAT_23);

        m_CAMERA_PRJ_MAT_30.set(hDlg, IDC_CAMERA_PRJ_MAT_30);
        m_CAMERA_PRJ_MAT_31.set(hDlg, IDC_CAMERA_PRJ_MAT_31);
        m_CAMERA_PRJ_MAT_32.set(hDlg, IDC_CAMERA_PRJ_MAT_32);
        m_CAMERA_PRJ_MAT_33.set(hDlg, IDC_CAMERA_PRJ_MAT_33);

        m_CREATEMIPMAPBOOL.set(hDlg, IDC_CREATEMIPMAPBOOL);
        m_CREATEMIPMAPBOOL.check();
        m_CREATEMIPMAPBOOL.disable();

        int itemHeight = 30; // 设置你希望的高度
        SendMessage(m_TEXTUREWRAPMODECOMBO.getHandle(), CB_SETITEMHEIGHT, 0, MAKELPARAM(itemHeight, 0));

        m_TEXTUREWRAPMODECOMBO.set(hDlg, IDC_TEXTUREWRAPMODECOMBO);
        m_TEXTUREWRAPMODECOMBO.addString(L"GL_REPEAT");
        m_TEXTUREWRAPMODECOMBO.addString(L"GL_MIRRORED_REPEAT");
        m_TEXTUREWRAPMODECOMBO.addString(L"GL_CLAMP_TO_EDGE");
        m_TEXTUREWRAPMODECOMBO.addString(L"GL_CLAMP_TO_BORDER");
        m_TEXTUREWRAPMODECOMBO.setCurrentSelection(0);

        m_TEXTUREMAGFILTERMODECOMBO.set(hDlg, IDC_TEXTUREMAGFILTERMODECOMBO);
        m_TEXTUREMAGFILTERMODECOMBO.addString(L"GL_NEAREST");
        m_TEXTUREMAGFILTERMODECOMBO.addString(L"GL_LINEAR");
        m_TEXTUREMAGFILTERMODECOMBO.setCurrentSelection(0);

        m_TEXTUREMINFILTERMODECOMBO.set(hDlg, IDC_TEXTUREMINFILTERMODECOMBO);
        m_TEXTUREMINFILTERMODECOMBO.addString(L"GL_NEAREST");
        m_TEXTUREMINFILTERMODECOMBO.addString(L"GL_LINEAR");
        m_TEXTUREMINFILTERMODECOMBO.addString(L"GL_NEAREST_MIPMAP_NEAREST");
        m_TEXTUREMINFILTERMODECOMBO.addString(L"GL_LINEAR_MIPMAP_NEAREST");
        m_TEXTUREMINFILTERMODECOMBO.addString(L"GL_NEAREST_MIPMAP_LINEAR");
        m_TEXTUREMINFILTERMODECOMBO.addString(L"GL_LINEAR_MIPMAP_LINEAR");
        m_TEXTUREMINFILTERMODECOMBO.setCurrentSelection(0);

        m_TEXTUREMIXBLENDINGFACTORSLIDER.set(hDlg, IDC_TEXTUREMIXBLENDINGFACTORSLIDER);
        m_TEXTUREMIXBLENDINGFACTORSLIDER.setRange(0, 10);
        m_TEXTUREMIXBLENDINGFACTORSLIDER.setPos(8);


        wchar_t  tempWchar[64];

       // m_Mat21.getText(tempWchar,64);
       // tempwstr = tempWchar;
       // float tF = std::stof(tempwstr);

        HWND hOpenGLWnd =  ::GetDlgItem(hDlg, IDC_OPENGLVIEW);

        bool succ = CreateGLContent(hOpenGLWnd, TRUE);
        if (!succ)
        {
            ::MessageBox(hWnd, L"初始化OpenGL窗口发生错误", L"系统信息", MB_OK);
            return;
        }


        return;
    };
    virtual void Resize_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        WindowResize();
    }
    virtual void Destroy_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
         shutdown();
    }
    virtual BOOL  OnIdle(LONG lCount)
    {
        GLContext::swapBuffer();

        return TRUE;
    }

    virtual void Command_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        int wmId = LOWORD(wParam);
        if (wmId == IDD_ABOUTBOX)
        {
            Win::WinForm::ShowModelDialog(IDD_ABOUTBOX, hDlg, About);// Win::WinForm::DialogWindowProc);
        }
        else if (wmId == IDC_ROTATIONBUTTON_X_UP)
        {
            if (m_RADIO1.isChecked())
            {
                m_TetrahedronObjectWithPositionTexture.RotateAngleX(glm::radians(5.0f));
                SetModelMat(m_TetrahedronObjectWithPositionTexture);
            }
            else if (m_RADIO2.isChecked())
            {
                m_cubeObjectWithPositionTexture.RotateAngleX(glm::radians(5.0f));
                SetModelMat(m_cubeObjectWithPositionTexture);
            }
        }
        else if (wmId == IDC_ROTATIONBUTTON_X_DOWN)
        {
            if (m_RADIO1.isChecked())
            {
                m_TetrahedronObjectWithPositionTexture.RotateAngleX(glm::radians(-5.0f));
                SetModelMat(m_TetrahedronObjectWithPositionTexture);
            }
            else if (m_RADIO2.isChecked())
            {
                m_cubeObjectWithPositionTexture.RotateAngleX(glm::radians(-5.0f));
                SetModelMat(m_cubeObjectWithPositionTexture);
            }
        }
        else if (wmId == IDC_ROTATIONBUTTON_Y_UP)
        {
            if (m_RADIO1.isChecked())
            {
                m_TetrahedronObjectWithPositionTexture.RotateAngleY(glm::radians(5.0f));
                SetModelMat(m_TetrahedronObjectWithPositionTexture);
            }
            else if (m_RADIO2.isChecked())
            {
                m_cubeObjectWithPositionTexture.RotateAngleY(glm::radians(5.0f));
                SetModelMat(m_cubeObjectWithPositionTexture);
            }
        }
        else if (wmId == IDC_ROTATIONBUTTON_Y_DOWN)
        {
            if (m_RADIO1.isChecked())
            {
                m_TetrahedronObjectWithPositionTexture.RotateAngleY(glm::radians(-5.0f));
                SetModelMat(m_TetrahedronObjectWithPositionTexture);
            }
            else if (m_RADIO2.isChecked())
            {
                m_cubeObjectWithPositionTexture.RotateAngleY(glm::radians(-5.0f));
                SetModelMat(m_cubeObjectWithPositionTexture);
            }
        }
        else if (wmId == IDC_ROTATIONBUTTON_Z_UP)
        {
            if (m_RADIO1.isChecked())
            {
                m_TetrahedronObjectWithPositionTexture.RotateAngleZ(glm::radians(5.0f));
                SetModelMat(m_TetrahedronObjectWithPositionTexture);
            }
            else if (m_RADIO2.isChecked())
            {
                m_cubeObjectWithPositionTexture.RotateAngleZ(glm::radians(5.0f));
                SetModelMat(m_cubeObjectWithPositionTexture);
            }
        }
        else if (wmId == IDC_ROTATIONBUTTON_Z_DOWN)
        {
            if (m_RADIO1.isChecked())
            {
                m_TetrahedronObjectWithPositionTexture.RotateAngleZ(glm::radians(-5.0f));
                SetModelMat(m_TetrahedronObjectWithPositionTexture);
            }
            else if (m_RADIO2.isChecked())
            {
                m_cubeObjectWithPositionTexture.RotateAngleZ(glm::radians(-5.0f));
                SetModelMat(m_cubeObjectWithPositionTexture);
            }
        }
        else if (wmId == IDM_EXIT)
        {
            ::SendMessageW(hDlg, WM_DESTROY, 0, 0);
        }
        else if (wmId == IDC_CAMERAMOVEFORWARD)
        {
            m_camera.MoveFront(0.5f);
            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else if (wmId == IDC_CAMERAMOVEBACK)
        {
            m_camera.MoveFront(-0.5f);
            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else if (wmId == IDC_CAMERAMOVEUP)
        {
            m_camera.MoveUp(0.5f);
            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else if (wmId == IDC_CAMERAMOVEDOWN)
        {
            m_camera.MoveUp(-0.5f);
            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
 
        }
        else if (wmId == IDC_CAMERAMOVELEFT)
        {
            m_camera.MoveRight(0.5f);
            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else if (wmId == IDC_CAMERAMOVERIGHT)
        {
            m_camera.MoveRight(-0.5f);
            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else if (wmId == IDC_RADIO1)
        {
            if (m_RADIO1.isChecked())
            {
                SetModelMat(m_TetrahedronObjectWithPositionTexture);
            }
        }
        else if (wmId == IDC_RADIO2)
        {
            if (m_RADIO2.isChecked())
            {
                SetModelMat(m_cubeObjectWithPositionTexture);
            }
        }


    }
    virtual void Notify_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        NMHDR* p = (NMHDR*)(void*)lParam;

        LONG iID = wParam;
        if (iID == IDC_MOVEX_SPIN)
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta > 0)
            {
                if (m_RADIO1.isChecked())
                {
                    m_TetrahedronObjectWithPositionTexture.MoveAlongVectorDistance(glm::vec3(1.0f, 0, 0), 1.0f);
                    SetModelMat(m_TetrahedronObjectWithPositionTexture);
                }
                else if (m_RADIO2.isChecked())
                {
                    m_cubeObjectWithPositionTexture.MoveAlongVectorDistance(glm::vec3(1.0f, 0, 0), 1.0f);
                    SetModelMat(m_cubeObjectWithPositionTexture);

                }
            }
            else
            {
                if (m_RADIO1.isChecked())
                {
                    m_TetrahedronObjectWithPositionTexture.MoveAlongVectorDistance(glm::vec3(1.0f, 0, 0), -1.0f);
                    SetModelMat(m_TetrahedronObjectWithPositionTexture);
                }
                else if (m_RADIO2.isChecked())
                {
                    m_cubeObjectWithPositionTexture.MoveAlongVectorDistance(glm::vec3(1.0f, 0, 0), -1.0f);
                    SetModelMat(m_cubeObjectWithPositionTexture);

                }

            }

        }
        else if (iID == IDC_MOVEY_SPIN)
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta > 0)
            {
                if (m_RADIO1.isChecked())
                {
                    m_TetrahedronObjectWithPositionTexture.MoveAlongVectorDistance(glm::vec3(0.0f, 1.0f, 0), 1.0f);
                    SetModelMat(m_TetrahedronObjectWithPositionTexture);
                }
                else if (m_RADIO2.isChecked())
                {
                    m_cubeObjectWithPositionTexture.MoveAlongVectorDistance(glm::vec3(0.0f, 1.0f, 0), 1.0f);
                    SetModelMat(m_cubeObjectWithPositionTexture);

                }
            }
            else
            {
                if (m_RADIO1.isChecked())
                {
                    m_TetrahedronObjectWithPositionTexture.MoveAlongVectorDistance(glm::vec3(0.0f, 1.0f, 0), -1.0f);
                    SetModelMat(m_TetrahedronObjectWithPositionTexture);
                }
                else if (m_RADIO2.isChecked())
                {
                    m_cubeObjectWithPositionTexture.MoveAlongVectorDistance(glm::vec3(0.0f, 1.0f, 0), -1.0f);
                    SetModelMat(m_cubeObjectWithPositionTexture);

                }

            }

        }
        else if (iID == IDC_MOVEZ_SPIN)
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (pNMUpDown->iDelta > 0)
            {
                if (m_RADIO1.isChecked())
                {
                    m_TetrahedronObjectWithPositionTexture.MoveAlongVectorDistance(glm::vec3(0.0f, 0, 1.0f), 1.0f);
                    SetModelMat(m_TetrahedronObjectWithPositionTexture);
                }
                else if (m_RADIO2.isChecked())
                {
                    m_cubeObjectWithPositionTexture.MoveAlongVectorDistance(glm::vec3(0.0f, 0, 1.0f), 1.0f);
                    SetModelMat(m_cubeObjectWithPositionTexture);

                }
            }
            else
            {
                if (m_RADIO1.isChecked())
                {
                    m_TetrahedronObjectWithPositionTexture.MoveAlongVectorDistance(glm::vec3(0.0f, 0, 1.0f), -1.0f);
                    SetModelMat(m_TetrahedronObjectWithPositionTexture);
                }
                else if (m_RADIO2.isChecked())
                {
                    m_cubeObjectWithPositionTexture.MoveAlongVectorDistance(glm::vec3(0.0f, 0, 1.0f), -1.0f);
                    SetModelMat(m_cubeObjectWithPositionTexture);

                }

            }

        }
        else if (iID == IDC_SCALE_X_SLIDER)
        {
            int tPos = m_SCALE_X_SLIDER.getPos();
            float tempF = 1.0f;
            std::wstring tempStr;// = std::to_wstring(tPos);
            if (tPos == 50)
                tempStr = L"1";
            else
            {
                if (tPos > 50)
                {
                    tempF = 1.0f - (9.0f / 50.0f) * (50- tPos);
                    tempStr = std::to_wstring(tempF);
                }
                else
                {
                    tempF = (0.9f/49.0f)*(tPos -1)+0.1f;
                    tempStr = std::to_wstring(tempF);
                }
            }
            m_SCALE_X_EDIT.setText(tempStr.c_str());
            if (m_RADIO1.isChecked())
            {
                glm::vec3 _scale = m_TetrahedronObjectWithPositionTexture.GetScale();
                m_TetrahedronObjectWithPositionTexture.SetScale(glm::vec3(tempF, _scale.y, _scale.z));
            }
            else if (m_RADIO2.isChecked())
            {
                glm::vec3 _scale = m_cubeObjectWithPositionTexture.GetScale();
                m_cubeObjectWithPositionTexture.SetScale(glm::vec3(tempF, _scale.y, _scale.z));
            }

            
        }
        else if (iID == IDC_SCALE_Y_SLIDER)
        {
            int tPos = m_SCALE_Y_SLIDER.getPos();
            float tempF = 1.0f;
            std::wstring tempStr;// = std::to_wstring(tPos);
            if (tPos == 50)
                tempStr = L"1";
            else
            {
                if (tPos > 50)
                {
                    tempF = 1.0f - (9.0f / 50.0f) * (50 - tPos);
                    tempStr = std::to_wstring(tempF);
                }
                else
                {
                    tempF = (0.9f / 49.0f) * (tPos - 1) + 0.1f;
                    tempStr = std::to_wstring(tempF);
                }
            }
            m_SCALE_Y_EDIT.setText(tempStr.c_str());
            if (m_RADIO1.isChecked())
            {
                glm::vec3 _scale = m_TetrahedronObjectWithPositionTexture.GetScale();
                m_TetrahedronObjectWithPositionTexture.SetScale(glm::vec3(_scale.x, tempF, _scale.z));
            }
            else if (m_RADIO2.isChecked())
            {
                glm::vec3 _scale = m_cubeObjectWithPositionTexture.GetScale();
                m_cubeObjectWithPositionTexture.SetScale(glm::vec3(_scale.x, tempF, _scale.z));
            }
        }
        else if (iID == IDC_SCALE_Z_SLIDER)
        {
            int tPos = m_SCALE_Z_SLIDER.getPos();
            float tempF = 1.0f;
            std::wstring tempStr;// = std::to_wstring(tPos);
            if (tPos == 50)
                tempStr = L"1";
            else
            {
                if (tPos > 50)
                {
                    tempF = 1.0f - (9.0f / 50.0f) * (50 - tPos);
                    tempStr = std::to_wstring(tempF);
                }
                else
                {
                    tempF = (0.9f / 49.0f) * (tPos - 1) + 0.1f;
                    tempStr = std::to_wstring(tempF);
                }
            }
            m_SCALE_Z_EDIT.setText(tempStr.c_str());
            if (m_RADIO1.isChecked())
            {
                glm::vec3 _scale = m_TetrahedronObjectWithPositionTexture.GetScale();
                m_TetrahedronObjectWithPositionTexture.SetScale(glm::vec3(_scale.x, _scale.y, tempF));
            }
            else if (m_RADIO2.isChecked())
            {
                glm::vec3 _scale = m_cubeObjectWithPositionTexture.GetScale();
                m_cubeObjectWithPositionTexture.SetScale(glm::vec3(_scale.x, _scale.y, tempF));
            }
        }
        else if (iID == IDC_TEXTUREMIXBLENDINGFACTORSLIDER)
        {
            int tPos = m_TEXTUREMIXBLENDINGFACTORSLIDER.getPos();
            m_TextureMixBlendingFactor = 0.1 * tPos;
        }
        else  if ( iID == IDC_AROUND_UP )
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (m_AROUNDEYEPOSITION.isChecked() == true)
            {
                if (pNMUpDown->iDelta > 0)
                {
                    // m_AROUND_UP
                    m_camera.RotateCenterEyePosAroundVecter(glm::radians(1.0f), m_camera.m_EyeUp);
                }
                else  if (pNMUpDown->iDelta < 0)
                {
                    m_camera.RotateCenterEyePosAroundVecter(glm::radians(-1.0f), m_camera.m_EyeUp);
                }
            }
            else
            {
                if (pNMUpDown->iDelta > 0)
                {
                    // m_AROUND_UP
                    m_camera.RotateCenterLookatAroundVecter(glm::radians(1.0f), m_camera.m_EyeUp);
                }
                else  if (pNMUpDown->iDelta < 0)
                {
                    m_camera.RotateCenterLookatAroundVecter(glm::radians(-1.0f), m_camera.m_EyeUp);
                }
            }

            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else  if (iID == IDC_AROUNDFRONT)
        {  //m_AROUNDFRONT
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (m_AROUNDEYEPOSITION.isChecked() == true)
            {
                if (pNMUpDown->iDelta > 0)
                {
                    m_camera.RotateCenterEyePosAroundVecter(glm::radians(-1.0f), m_camera.GetFront());
                }
                else  if (pNMUpDown->iDelta < 0)
                {
                    m_camera.RotateCenterEyePosAroundVecter(glm::radians(-1.0f), m_camera.GetFront());
                }
            }
            else
            {
                if (pNMUpDown->iDelta > 0)
                {
                    // m_AROUND_UP
                    m_camera.RotateCenterLookatAroundVecter(glm::radians(1.0f), m_camera.GetFront());
                }
                else  if (pNMUpDown->iDelta < 0)
                {
                    m_camera.RotateCenterLookatAroundVecter(glm::radians(-1.0f), m_camera.GetFront());
                }
            }

            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else  if (iID == IDC_AROUNDRIGHT)
        {//m_AROUNDRIGHT
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            if (m_AROUNDEYEPOSITION.isChecked() == true)
            {
                if (pNMUpDown->iDelta > 0)
                {
                    m_camera.RotateCenterEyePosAroundVecter(glm::radians(1.0f), m_camera.GetRight());
                }
                else  if (pNMUpDown->iDelta < 0)
                {
                    m_camera.RotateCenterEyePosAroundVecter(glm::radians(-1.0f), m_camera.GetRight());
                }
            }
            else
            {
                if (pNMUpDown->iDelta > 0)
                {
                    m_camera.RotateCenterLookatAroundVecter(glm::radians(1.0f), m_camera.GetRight());
                }
                else  if (pNMUpDown->iDelta < 0)
                {
                    m_camera.RotateCenterLookatAroundVecter(glm::radians(-1.0f), m_camera.GetRight());
                }
            }

            glm::mat4 tempMat = m_camera.GetViewMat();
            SetViewMat(tempMat);
        }
        else if (iID == IDC_CAMERA_FOV_SPIN)
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            float tempFovH = m_camera.GetFovY();
            if (pNMUpDown->iDelta > 0)
            {
                tempFovH += 1.0f;
                if (tempFovH > 150.0f)
                    tempFovH = 150.0f;
            }
            else
            {
                tempFovH -= 1.0f;
                if (tempFovH < 1.0f)
                    tempFovH = 1.0f;
            }
            m_camera.SetFovY(tempFovH);
            std::wstring tempStr = std::to_wstring(tempFovH);
            m_CAMERA_FOV_EDIT.setText(tempStr.c_str());

            SetViewProjectMat(m_camera.GetProjectionMat());
        }
        else if (iID == IDC_CAMERA_NEAR_SPIN)
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            float tempNear = m_camera.GetNear();
            if (pNMUpDown->iDelta > 0)
            {
                tempNear += 0.5;
                if (tempNear > m_camera.GetFar())
                    tempNear = m_camera.GetFar() - 1;
            }
            else
            {
                tempNear -= 0.5;
                if (tempNear < 0.1)
                    tempNear = 0.1;
            }
            m_camera.SetNear(tempNear);
            std::wstring tempStr = std::to_wstring(tempNear);
            m_CAMERA_NEAR_EDIT.setText(tempStr.c_str());

            SetViewProjectMat(m_camera.GetProjectionMat());
        }
        else if (iID == IDC_CAMERA_FAR_SPIN)
        {
            NMHDR* p = (NMHDR*)(void*)lParam;
            NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)p;
            float tempFar = m_camera.GetFar();
            if (pNMUpDown->iDelta > 0)
            {
                tempFar += 0.5;
                if (tempFar > 200 )
                    tempFar = 200;
            }
            else
            {
                tempFar -= 0.5;
                if (tempFar < m_camera.GetNear())
                    tempFar = m_camera.GetNear() + 1;
            }
            m_camera.SetFar(tempFar);
            std::wstring tempStr = std::to_wstring(tempFar);
            m_CAMERA_FAR_EDIT.setText(tempStr.c_str());

            SetViewProjectMat(m_camera.GetProjectionMat());
        }
    }

    Camera                m_camera;
    Shader                m_ShaderWithColor;
    Terrain    m_terrainObject;

    CubeObjectWithPositionTexture  m_cubeObjectWithPositionTexture;
    TetrahedronWithTexture      m_TetrahedronObjectWithPositionTexture;
    float m_TextureMixBlendingFactor=0.8;

    virtual void UserInitialize() 
    {
        RECT rect;
        ::GetWindowRect(m_hWnd, &rect);
        int width = rect.right - rect.left;
        int height = rect.bottom - rect.top;

        
        m_ShaderWithColor.InitializeShaderWithString(m_vertexShader.c_str(), m_fragmentShader.c_str());
       
       
        m_camera.InitializeUseLookat(glm::vec3(0.0f, 1.0f, 5), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.));
        m_camera.SetPerspectiveProjection(75, (float)width / (float)height, 0.1f, 100.0f);
       
        glm::mat4 tempMat = m_camera.GetViewMat();
        SetViewMat(tempMat);
        tempMat = m_camera.GetProjectionMat();
        SetViewProjectMat(tempMat);
        



        m_terrainObject.InitializeData();

       

        m_cubeObjectWithPositionTexture.InitializeData();
        m_cubeObjectWithPositionTexture.SetPosition(glm::vec3(2.0f, 1.0f, 0.0f));
        
        m_TetrahedronObjectWithPositionTexture.InitializeData();
        m_TetrahedronObjectWithPositionTexture.SetPosition(glm::vec3(-2.0f, 0.0f, -1.0f));

        SetModelMat(m_TetrahedronObjectWithPositionTexture);
    };

    virtual void PreDrawProcess(GL_Channel& _channel) 
    {
        RECT rect;
        //-----------------------------------------------------------
        ::GetWindowRect(_channel._hWnd, &rect);
        int width = rect.right - rect.left;
        int height = rect.bottom - rect.top;

        glViewport(0, 0, width, height);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        
       // float* p = glm::value_ptr(ProjectionMat);
       // glLoadMatrixf(p);

        glMatrixMode(GL_MODELVIEW);	// 选择模型观察矩阵



    };
    virtual void GLDrawProcess(GL_Channel& _channel) 
    {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // 清理颜色缓存和深度缓存
        glClearColor(0.1, 0.0, 0.5, 0.0);
        glColor3f(1.0, 1.0, 1.0);
       
        
        
        m_ShaderWithColor.Use();

        m_ShaderWithColor.SetMat4("ModelMatrix", glm::mat4(1.0f));
        m_ShaderWithColor.SetMat4("ViewMatrix", m_camera.GetViewMat());
        m_ShaderWithColor.SetMat4("ProjectionMatrix", m_camera.GetProjectionMat());// ProjectionMat);

        static float _RatateAngle = 0.0f;
        _RatateAngle += 0.01f;
        if (_RatateAngle > 359.0f)
            _RatateAngle = 0.0f;

        m_terrainObject.Draw();

        m_cubeObjectWithPositionTexture.Draw(m_camera, m_TextureMixBlendingFactor);

        m_TetrahedronObjectWithPositionTexture.Draw(m_camera);
    };

    virtual void UserDestroy() 
    {

    };

   
   
};
WindowsForm  g_WinForm;

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    OutputDebugStringW(L"字符串");

    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 在此处放置代码。

    // 初始化全局字符串
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WINMAINAPP, szWindowClass, MAX_LOADSTRING);



    g_WinForm.CreateWindowFromReSource(hInstance, IDD_MAINDIALOG);
    return g_WinForm.Run(); 
}

// “关于”框的消息处理程序。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

