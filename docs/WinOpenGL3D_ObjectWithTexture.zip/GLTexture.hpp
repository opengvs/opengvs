/*  GLTexture.hpp  ���ڴ�������C++���򿪷�OpenGL����ʱʹ����������ͷ�ļ���
  ���ļ��Ķ���ͷ�ļ���������ƽ�������stb_image.hͷ�ļ���ȷ����ͷ�ļ��Ա��ļ�����ͬһĿ¼
  ��������֧�ֵ�����ͼƬ��ʽ������JPG, PNG, TGA, BMP, PSD, GIF, HDR, PIC��
  ������ʽ�������ļ���Ҫ����stb_image�������ͷ�ļ�
  ��Ȩ����        ������    2023.11 �ȷ�   */
#ifndef __GLTEXTURE_HPP__
#define __GLTEXTURE_HPP__

#include<windows.h>
#include "glad.h"

enum class TextureWrapMode
{
	//     [requires: v1.0] Original was GL_REPEAT = 0x2901
	Repeat = 10497,

	//     [requires: v1.3] Original was GL_CLAMP_TO_BORDER = 0x812D
	ClampToBorder = 33069,

	//     [requires: ARB_texture_border_clamp] Original was GL_CLAMP_TO_BORDER_ARB = 0x812D
	ClampToBorderArb = 33069,

	//     Original was GL_CLAMP_TO_BORDER_NV = 0x812D
	ClampToBorderNv = 33069,

	//     Original was GL_CLAMP_TO_BORDER_SGIS = 0x812D
	ClampToBorderSgis = 33069,

	//     [requires: v1.2] Original was GL_CLAMP_TO_EDGE = 0x812F
	ClampToEdge = 33071,

	//     Original was GL_CLAMP_TO_EDGE_SGIS = 0x812F
	ClampToEdgeSgis = 33071,

	//     [requires: v1.4] Original was GL_MIRRORED_REPEAT = 0x8370
	MirroredRepeat = 33648
};

enum  class TextureMagFilter
{
	//     [requires: v1.0] Original was GL_NEAREST = 0x2600
	Nearest = 9728,

	//     [requires: v1.0] Original was GL_LINEAR = 0x2601
	Linear = 9729,

	//     Original was GL_LINEAR_DETAIL_SGIS = 0x8097
	LinearDetailSgis = 32919,

	//     Original was GL_LINEAR_DETAIL_ALPHA_SGIS = 0x8098
	LinearDetailAlphaSgis = 32920,

	//     Original was GL_LINEAR_DETAIL_COLOR_SGIS = 0x8099
	LinearDetailColorSgis = 32921,

	//     Original was GL_LINEAR_SHARPEN_SGIS = 0x80AD
	LinearSharpenSgis = 32941,

	//     Original was GL_LINEAR_SHARPEN_ALPHA_SGIS = 0x80AE
	LinearSharpenAlphaSgis = 32942,

	//     Original was GL_LINEAR_SHARPEN_COLOR_SGIS = 0x80AF
	LinearSharpenColorSgis = 32943,

	//     Original was GL_FILTER4_SGIS = 0x8146
	Filter4Sgis = 33094,

	//     Original was GL_PIXEL_TEX_GEN_Q_CEILING_SGIX = 0x8184
	PixelTexGenQCeilingSgix = 33156,

	//     Original was GL_PIXEL_TEX_GEN_Q_ROUND_SGIX = 0x8185
	PixelTexGenQRoundSgix = 33157,

	//     Original was GL_PIXEL_TEX_GEN_Q_FLOOR_SGIX = 0x8186
	PixelTexGenQFloorSgix = 33158
};

enum class TextureMinFilter
{
	//     [requires: v1.0] Original was GL_NEAREST = 0x2600
	Nearest = 9728,

	//     [requires: v1.0] Original was GL_LINEAR = 0x2601
	Linear = 9729,

	//     [requires: v1.0] Original was GL_NEAREST_MIPMAP_NEAREST = 0x2700
	NearestMipmapNearest = 9984,

	//     [requires: v1.0] Original was GL_LINEAR_MIPMAP_NEAREST = 0x2701
	LinearMipmapNearest = 9985,

	//     [requires: v1.0] Original was GL_NEAREST_MIPMAP_LINEAR = 0x2702
	NearestMipmapLinear = 9986,

	//     [requires: v1.0] Original was GL_LINEAR_MIPMAP_LINEAR = 0x2703
	LinearMipmapLinear = 9987,

	//     Original was GL_FILTER4_SGIS = 0x8146
	Filter4Sgis = 33094,

	//     Original was GL_LINEAR_CLIPMAP_LINEAR_SGIX = 0x8170
	LinearClipmapLinearSgix = 33136,

	//     Original was GL_PIXEL_TEX_GEN_Q_CEILING_SGIX = 0x8184
	PixelTexGenQCeilingSgix = 33156,

	//     Original was GL_PIXEL_TEX_GEN_Q_ROUND_SGIX = 0x8185
	PixelTexGenQRoundSgix = 33157,

	//     Original was GL_PIXEL_TEX_GEN_Q_FLOOR_SGIX = 0x8186
	PixelTexGenQFloorSgix = 33158,

	//     Original was GL_NEAREST_CLIPMAP_NEAREST_SGIX = 0x844D
	NearestClipmapNearestSgix = 33869,

	//     Original was GL_NEAREST_CLIPMAP_LINEAR_SGIX = 0x844E
	NearestClipmapLinearSgix = 33870,

	//     Original was GL_LINEAR_CLIPMAP_NEAREST_SGIX = 0x844F
	LinearClipmapNearestSgix = 33871
};

enum class TextureParameterName
{
    //     [requires: v1.0] Original was GL_TEXTURE_WIDTH = 0x1000
    TextureWidth = 4096,
    //     [requires: v1.0] Original was GL_TEXTURE_HEIGHT = 0x1001
    TextureHeight = 4097,

    //     Original was GL_TEXTURE_COMPONENTS = 0x1003
    TextureComponents = 4099,

    //     [requires: v1.1] Original was GL_TEXTURE_INTERNAL_FORMAT = 0x1003
    TextureInternalFormat = 4099,

    //     [requires: v1.0] Original was GL_TEXTURE_BORDER_COLOR = 0x1004
    TextureBorderColor = 4100,

    //     Original was GL_TEXTURE_BORDER_COLOR_NV = 0x1004
    TextureBorderColorNv = 4100,

    //     Original was GL_TEXTURE_BORDER = 0x1005
    TextureBorder = 4101,

    //     [requires: v1.0] Original was GL_TEXTURE_MAG_FILTER = 0x2800
    TextureMagFilter = 10240,

    //     [requires: v1.0] Original was GL_TEXTURE_MIN_FILTER = 0x2801
    TextureMinFilter = 10241,

    //     [requires: v1.0] Original was GL_TEXTURE_WRAP_S = 0x2802
    TextureWrapS = 10242,

    //     [requires: v1.0] Original was GL_TEXTURE_WRAP_T = 0x2803
    TextureWrapT = 10243,

    //     [requires: v1.1] Original was GL_TEXTURE_RED_SIZE = 0x805C
    TextureRedSize = 32860,

    //     [requires: v1.1] Original was GL_TEXTURE_GREEN_SIZE = 0x805D
    TextureGreenSize = 32861,

    //     [requires: v1.1] Original was GL_TEXTURE_BLUE_SIZE = 0x805E
    TextureBlueSize = 32862,

    //     [requires: v1.1] Original was GL_TEXTURE_ALPHA_SIZE = 0x805F
    TextureAlphaSize = 32863,

    //     Original was GL_TEXTURE_LUMINANCE_SIZE = 0x8060
    TextureLuminanceSize = 32864,

    //     Original was GL_TEXTURE_INTENSITY_SIZE = 0x8061
    TextureIntensitySize = 32865,

    //     Original was GL_TEXTURE_PRIORITY = 0x8066
    TexturePriority = 32870,

    //     Original was GL_TEXTURE_PRIORITY_EXT = 0x8066
    TexturePriorityExt = 32870,

    //     Original was GL_TEXTURE_RESIDENT = 0x8067
    TextureResident = 32871,

    //     [requires: v1.2] Original was GL_TEXTURE_DEPTH = 0x8071
    TextureDepth = 32881,

    //     Original was GL_TEXTURE_DEPTH_EXT = 0x8071
    TextureDepthExt = 32881,

    //     [requires: v1.2] Original was GL_TEXTURE_WRAP_R = 0x8072
    TextureWrapR = 32882,

    //     Original was GL_TEXTURE_WRAP_R_EXT = 0x8072
    TextureWrapRExt = 32882,

    //     Original was GL_TEXTURE_WRAP_R_OES = 0x8072
    TextureWrapROes = 32882,

    //     Original was GL_DETAIL_TEXTURE_LEVEL_SGIS = 0x809A
    DetailTextureLevelSgis = 32922,

    //     Original was GL_DETAIL_TEXTURE_MODE_SGIS = 0x809B
    DetailTextureModeSgis = 32923,

    //     Original was GL_DETAIL_TEXTURE_FUNC_POINTS_SGIS = 0x809C
    DetailTextureFuncPointsSgis = 32924,

    //     Original was GL_SHARPEN_TEXTURE_FUNC_POINTS_SGIS = 0x80B0
    SharpenTextureFuncPointsSgis = 32944,

    //     Original was GL_SHADOW_AMBIENT_SGIX = 0x80BF
    ShadowAmbientSgix = 32959,

    //     Original was GL_TEXTURE_COMPARE_FAIL_VALUE = 0x80BF
    TextureCompareFailValue = 32959,

    //     Original was GL_DUAL_TEXTURE_SELECT_SGIS = 0x8124
    DualTextureSelectSgis = 33060,

    //     Original was GL_QUAD_TEXTURE_SELECT_SGIS = 0x8125
    QuadTextureSelectSgis = 33061,

    //     [requires: v1.3] Original was GL_CLAMP_TO_BORDER = 0x812D
    ClampToBorder = 33069,

    //     [requires: v1.2] Original was GL_CLAMP_TO_EDGE = 0x812F
    ClampToEdge = 33071,

    //     Original was GL_TEXTURE_4DSIZE_SGIS = 0x8136
    Texture4DsizeSgis = 33078,

    //     Original was GL_TEXTURE_WRAP_Q_SGIS = 0x8137
    TextureWrapQSgis = 33079,

    //     [requires: v1.2] Original was GL_TEXTURE_MIN_LOD = 0x813A
    TextureMinLod = 33082,

    //     Original was GL_TEXTURE_MIN_LOD_SGIS = 0x813A
    TextureMinLodSgis = 33082,

    //     [requires: v1.2] Original was GL_TEXTURE_MAX_LOD = 0x813B
    TextureMaxLod = 33083,

    //     Original was GL_TEXTURE_MAX_LOD_SGIS = 0x813B
    TextureMaxLodSgis = 33083,

    //     [requires: v1.2] Original was GL_TEXTURE_BASE_LEVEL = 0x813C
    TextureBaseLevel = 33084,

    //     Original was GL_TEXTURE_BASE_LEVEL_SGIS = 0x813C
    TextureBaseLevelSgis = 33084,

    //     [requires: v1.2] Original was GL_TEXTURE_MAX_LEVEL = 0x813D
    TextureMaxLevel = 33085,

    //     Original was GL_TEXTURE_MAX_LEVEL_SGIS = 0x813D
    TextureMaxLevelSgis = 33085,

    //     Original was GL_TEXTURE_FILTER4_SIZE_SGIS = 0x8147
    TextureFilter4SizeSgis = 33095,

    //     Original was GL_TEXTURE_CLIPMAP_CENTER_SGIX = 0x8171
    TextureClipmapCenterSgix = 33137,

    //     Original was GL_TEXTURE_CLIPMAP_FRAME_SGIX = 0x8172
    TextureClipmapFrameSgix = 33138,

    //     Original was GL_TEXTURE_CLIPMAP_OFFSET_SGIX = 0x8173
    TextureClipmapOffsetSgix = 33139,

    //     Original was GL_TEXTURE_CLIPMAP_VIRTUAL_DEPTH_SGIX = 0x8174
    TextureClipmapVirtualDepthSgix = 33140,

    //     Original was GL_TEXTURE_CLIPMAP_LOD_OFFSET_SGIX = 0x8175
    TextureClipmapLodOffsetSgix = 33141,

    //     Original was GL_TEXTURE_CLIPMAP_DEPTH_SGIX = 0x8176
    TextureClipmapDepthSgix = 33142,

    //     Original was GL_POST_TEXTURE_FILTER_BIAS_SGIX = 0x8179
    PostTextureFilterBiasSgix = 33145,

    //     Original was GL_POST_TEXTURE_FILTER_SCALE_SGIX = 0x817A
    PostTextureFilterScaleSgix = 33146,

    //     Original was GL_TEXTURE_LOD_BIAS_S_SGIX = 0x818E
    TextureLodBiasSSgix = 33166,

    //     Original was GL_TEXTURE_LOD_BIAS_T_SGIX = 0x818F
    TextureLodBiasTSgix = 33167,

    //     Original was GL_TEXTURE_LOD_BIAS_R_SGIX = 0x8190
    TextureLodBiasRSgix = 33168,

    //     Original was GL_GENERATE_MIPMAP = 0x8191
    GenerateMipmap = 33169,

    //     Original was GL_GENERATE_MIPMAP_SGIS = 0x8191
    GenerateMipmapSgis = 33169,

    //     Original was GL_TEXTURE_COMPARE_SGIX = 0x819A
    TextureCompareSgix = 33178,

    //     Original was GL_TEXTURE_COMPARE_OPERATOR_SGIX = 0x819B
    TextureCompareOperatorSgix = 33179,

    //     Original was GL_TEXTURE_LEQUAL_R_SGIX = 0x819C
    TextureLequalRSgix = 33180,

    //     Original was GL_TEXTURE_GEQUAL_R_SGIX = 0x819D
    TextureGequalRSgix = 33181,

    //     Original was GL_TEXTURE_MAX_CLAMP_S_SGIX = 0x8369
    TextureMaxClampSSgix = 33641,

    //     Original was GL_TEXTURE_MAX_CLAMP_T_SGIX = 0x836A
    TextureMaxClampTSgix = 33642,

    //     Original was GL_TEXTURE_MAX_CLAMP_R_SGIX = 0x836B
    TextureMaxClampRSgix = 33643,

    //     [requires: v4.6 or ARB_texture_filter_anisotropic] Original was GL_TEXTURE_MAX_ANISOTROPY
    //     = 0x84FE
    TextureMaxAnisotropy = 34046,

    //     [requires: v1.4] Original was GL_TEXTURE_LOD_BIAS = 0x8501
    TextureLodBias = 34049,

    //     Original was GL_DEPTH_TEXTURE_MODE = 0x884B
    DepthTextureMode = 34891,

    //     [requires: v1.4] Original was GL_TEXTURE_COMPARE_MODE = 0x884C
    TextureCompareMode = 34892,

    //     [requires: v1.4] Original was GL_TEXTURE_COMPARE_FUNC = 0x884D
    TextureCompareFunc = 34893,

    //     [requires: v3.2 or ARB_seamless_cube_map, ARB_seamless_cubemap_per_texture] Original
    //     was GL_TEXTURE_CUBE_MAP_SEAMLESS = 0x884F
    TextureCubeMapSeamless = 34895,
    //
    // ժҪ:
    //     [requires: v3.3 or ARB_texture_swizzle] Original was GL_TEXTURE_SWIZZLE_R = 0x8E42
    TextureSwizzleR = 36418,

    //     [requires: v3.3 or ARB_texture_swizzle] Original was GL_TEXTURE_SWIZZLE_G = 0x8E43
    TextureSwizzleG = 36419,

    //     [requires: v3.3 or ARB_texture_swizzle] Original was GL_TEXTURE_SWIZZLE_B = 0x8E44
    TextureSwizzleB = 36420,

    //     [requires: v3.3 or ARB_texture_swizzle] Original was GL_TEXTURE_SWIZZLE_A = 0x8E45
    TextureSwizzleA = 36421,

    //     [requires: v3.3 or ARB_texture_swizzle] Original was GL_TEXTURE_SWIZZLE_RGBA
    //     = 0x8E46
    TextureSwizzleRgba = 36422,

    //     [requires: v4.3 or ARB_stencil_texturing] Original was GL_DEPTH_STENCIL_TEXTURE_MODE
    //     = 0x90EA
    DepthStencilTextureMode = 37098,

    //     Original was GL_TEXTURE_TILING_EXT = 0x9580
    TextureTilingExt = 38272
};
enum class PixelInternalFormat
{
    //     [requires: v1.0] Original was GL_DEPTH_COMPONENT = 0x1902
    DepthComponent = 6402,

    //     [requires: v1.0] Original was GL_ALPHA = 0x1906
    Alpha = 6406,

    //     [requires: v1.0] Original was GL_RGB = 0x1907
    Rgb = 6407,

    //     [requires: v1.0] Original was GL_RGBA = 0x1908
    Rgba = 6408,

    //     Original was GL_LUMINANCE = 0x1909
    Luminance = 6409,

    //     Original was GL_LUMINANCE_ALPHA = 0x190A
    LuminanceAlpha = 6410,

    //     [requires: v1.1] Original was GL_R3_G3_B2 = 0x2A10
    R3G3B2 = 10768,

    //     Original was GL_RGB2_EXT = 0x804E
    Rgb2Ext = 32846,

    //     [requires: v1.1] Original was GL_RGB4 = 0x804F
    Rgb4 = 32847,

    //     [requires: v1.1] Original was GL_RGB5 = 0x8050
    Rgb5 = 32848,

    //     [requires: v1.1] Original was GL_RGB8 = 0x8051
    Rgb8 = 32849,

    //     [requires: v1.1] Original was GL_RGB10 = 0x8052
    Rgb10 = 32850,

    //     [requires: v1.1] Original was GL_RGB12 = 0x8053
    Rgb12 = 32851,

    //     [requires: v1.1] Original was GL_RGB16 = 0x8054
    Rgb16 = 32852,

    //     [requires: v1.1] Original was GL_RGBA2 = 0x8055
    Rgba2 = 32853,

    //     [requires: v1.1] Original was GL_RGBA4 = 0x8056
    Rgba4 = 32854,

    //     [requires: v1.1] Original was GL_RGB5_A1 = 0x8057
    Rgb5A1 = 32855,

    //     [requires: v1.1] Original was GL_RGBA8 = 0x8058
    Rgba8 = 32856,

    //     [requires: v1.1] Original was GL_RGB10_A2 = 0x8059
    Rgb10A2 = 32857,

    //     [requires: v1.1] Original was GL_RGBA12 = 0x805A
    Rgba12 = 32858,

    //     [requires: v1.1] Original was GL_RGBA16 = 0x805B
    Rgba16 = 32859,

    //     Original was GL_DUAL_ALPHA4_SGIS = 0x8110
    DualAlpha4Sgis = 33040,

    //     Original was GL_DUAL_ALPHA8_SGIS = 0x8111
    DualAlpha8Sgis = 33041,

    //     Original was GL_DUAL_ALPHA12_SGIS = 0x8112
    DualAlpha12Sgis = 33042,

    //     Original was GL_DUAL_ALPHA16_SGIS = 0x8113
    DualAlpha16Sgis = 33043,

    //     Original was GL_DUAL_LUMINANCE4_SGIS = 0x8114
    DualLuminance4Sgis = 33044,

    //     Original was GL_DUAL_LUMINANCE8_SGIS = 0x8115
    DualLuminance8Sgis = 33045,

    //     Original was GL_DUAL_LUMINANCE12_SGIS = 0x8116
    DualLuminance12Sgis = 33046,

    //     Original was GL_DUAL_LUMINANCE16_SGIS = 0x8117
    DualLuminance16Sgis = 33047,

    //     Original was GL_DUAL_INTENSITY4_SGIS = 0x8118
    DualIntensity4Sgis = 33048,

    //     Original was GL_DUAL_INTENSITY8_SGIS = 0x8119
    DualIntensity8Sgis = 33049,

    //     Original was GL_DUAL_INTENSITY12_SGIS = 0x811A
    DualIntensity12Sgis = 33050,

    //     Original was GL_DUAL_INTENSITY16_SGIS = 0x811B
    DualIntensity16Sgis = 33051,

    //     Original was GL_DUAL_LUMINANCE_ALPHA4_SGIS = 0x811C
    DualLuminanceAlpha4Sgis = 33052,

    //     Original was GL_DUAL_LUMINANCE_ALPHA8_SGIS = 0x811D
    DualLuminanceAlpha8Sgis = 33053,

    //     Original was GL_QUAD_ALPHA4_SGIS = 0x811E
    QuadAlpha4Sgis = 33054,

    //     Original was GL_QUAD_ALPHA8_SGIS = 0x811F
    QuadAlpha8Sgis = 33055,

    //     Original was GL_QUAD_LUMINANCE4_SGIS = 0x8120
    QuadLuminance4Sgis = 33056,

    //     Original was GL_QUAD_LUMINANCE8_SGIS = 0x8121
    QuadLuminance8Sgis = 33057,

    //     Original was GL_QUAD_INTENSITY4_SGIS = 0x8122
    QuadIntensity4Sgis = 33058,

    //     Original was GL_QUAD_INTENSITY8_SGIS = 0x8123
    QuadIntensity8Sgis = 33059,

    //     [requires: v1.4] Original was GL_DEPTH_COMPONENT16 = 0x81a5
    DepthComponent16 = 33189,

    //     Original was GL_DEPTH_COMPONENT16_SGIX = 0x81A5
    DepthComponent16Sgix = 33189,

    //     [requires: v1.4] Original was GL_DEPTH_COMPONENT24 = 0x81a6
    DepthComponent24 = 33190,

    //     Original was GL_DEPTH_COMPONENT24_SGIX = 0x81A6
    DepthComponent24Sgix = 33190,

    //     [requires: v1.4] Original was GL_DEPTH_COMPONENT32 = 0x81a7
    DepthComponent32 = 33191,

    //     Original was GL_DEPTH_COMPONENT32_SGIX = 0x81A7
    DepthComponent32Sgix = 33191,

    //     [requires: v3.0] Original was GL_COMPRESSED_RED = 0x8225
    CompressedRed = 33317,

    //     [requires: v3.0] Original was GL_COMPRESSED_RG = 0x8226
    CompressedRg = 33318,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_R8 = 0x8229
    R8 = 33321,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_R16 = 0x822A
    R16 = 33322,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_RG8 = 0x822B
    Rg8 = 33323,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_RG16 = 0x822C
    Rg16 = 33324,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_R16F = 0x822D
    R16f = 33325,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_R32F = 0x822E
    R32f = 33326,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_RG16F = 0x822F
    Rg16f = 33327,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_RG32F = 0x8230
    Rg32f = 33328,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_R8I = 0x8231
    R8i = 33329,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_R8UI = 0x8232
    R8ui = 33330,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_R16I = 0x8233
    R16i = 33331,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_R16UI = 0x8234
    R16ui = 33332,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_R32I = 0x8235
    R32i = 33333,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_R32UI = 0x8236
    R32ui = 33334,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_RG8I = 0x8237
    Rg8i = 33335,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_RG8UI = 0x8238
    Rg8ui = 33336,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_RG16I = 0x8239
    Rg16i = 33337,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_RG16UI = 0x823A
    Rg16ui = 33338,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_RG32I = 0x823B
    Rg32i = 33339,

    //     [requires: v3.0 or ARB_texture_rg] Original was GL_RG32UI = 0x823C
    Rg32ui = 33340,

    //     [requires: EXT_texture_compression_s3tc] Original was GL_COMPRESSED_RGB_S3TC_DXT1_EXT
    //     = 0x83F0
    CompressedRgbS3tcDxt1Ext = 33776,

    //     [requires: EXT_texture_compression_s3tc] Original was GL_COMPRESSED_RGBA_S3TC_DXT1_EXT
    //     = 0x83F1
    CompressedRgbaS3tcDxt1Ext = 33777,

    //     [requires: EXT_texture_compression_s3tc] Original was GL_COMPRESSED_RGBA_S3TC_DXT3_EXT
    //     = 0x83F2
    CompressedRgbaS3tcDxt3Ext = 33778,

    //     [requires: EXT_texture_compression_s3tc] Original was GL_COMPRESSED_RGBA_S3TC_DXT5_EXT
    //     = 0x83F3
    CompressedRgbaS3tcDxt5Ext = 33779,

    //     [requires: SGIX_icc_texture] Original was GL_RGB_ICC_SGIX = 0x8460
    RgbIccSgix = 33888,

    //     [requires: SGIX_icc_texture] Original was GL_RGBA_ICC_SGIX = 0x8461
    RgbaIccSgix = 33889,

    //     [requires: SGIX_icc_texture] Original was GL_ALPHA_ICC_SGIX = 0x8462
    AlphaIccSgix = 33890,

    //     [requires: SGIX_icc_texture] Original was GL_LUMINANCE_ICC_SGIX = 0x8463
    LuminanceIccSgix = 33891,
    //
    // ժҪ:
    //     [requires: SGIX_icc_texture] Original was GL_INTENSITY_ICC_SGIX = 0x8464
    IntensityIccSgix = 33892,

    //     [requires: SGIX_icc_texture] Original was GL_LUMINANCE_ALPHA_ICC_SGIX = 0x8465
    LuminanceAlphaIccSgix = 33893,

    //     [requires: SGIX_icc_texture] Original was GL_R5_G6_B5_ICC_SGIX = 0x8466
    R5G6B5IccSgix = 33894,

    //     [requires: SGIX_icc_texture] Original was GL_R5_G6_B5_A8_ICC_SGIX = 0x8467
    R5G6B5A8IccSgix = 33895,

    //     [requires: SGIX_icc_texture] Original was GL_ALPHA16_ICC_SGIX = 0x8468
    Alpha16IccSgix = 33896,

    //     [requires: SGIX_icc_texture] Original was GL_LUMINANCE16_ICC_SGIX = 0x8469
    Luminance16IccSgix = 33897,

    //     [requires: SGIX_icc_texture] Original was GL_INTENSITY16_ICC_SGIX = 0x846A
    Intensity16IccSgix = 33898,

    //     [requires: SGIX_icc_texture] Original was GL_LUMINANCE16_ALPHA8_ICC_SGIX = 0x846B
    Luminance16Alpha8IccSgix = 33899,

    //     Original was GL_COMPRESSED_ALPHA = 0x84E9
    CompressedAlpha = 34025,

    //     Original was GL_COMPRESSED_LUMINANCE = 0x84EA
    CompressedLuminance = 34026,

    //     Original was GL_COMPRESSED_LUMINANCE_ALPHA = 0x84EB
    CompressedLuminanceAlpha = 34027,

    //     Original was GL_COMPRESSED_INTENSITY = 0x84EC
    CompressedIntensity = 34028,

    //     [requires: v1.3] Original was GL_COMPRESSED_RGB = 0x84ED
    CompressedRgb = 34029,

    //     [requires: v1.3] Original was GL_COMPRESSED_RGBA = 0x84EE
    CompressedRgba = 34030,

    //     [requires: v3.0 or ARB_framebuffer_object] Original was GL_DEPTH_STENCIL = 0x84F9
    DepthStencil = 34041,

    //     [requires: v3.0] Original was GL_RGBA32F = 0x8814
    Rgba32f = 34836,
    //
    // ժҪ:
    //     [requires: v3.0 or ARB_texture_buffer_object_rgb32] Original was GL_RGB32F =
    //     0x8815
    Rgb32f = 34837,
    //
    // ժҪ:
    //     [requires: v3.0] Original was GL_RGBA16F = 0x881A
    Rgba16f = 34842,

    //     [requires: v3.0] Original was GL_RGB16F = 0x881B
    Rgb16f = 34843,

    //     [requires: v3.0 or ARB_framebuffer_object] Original was GL_DEPTH24_STENCIL8 =
    //     0x88F0
    Depth24Stencil8 = 35056,

    //     [requires: v3.0] Original was GL_R11F_G11F_B10F = 0x8C3A
    R11fG11fB10f = 35898,

    //     [requires: v3.0] Original was GL_RGB9_E5 = 0x8C3D
    Rgb9E5 = 35901,

    //     [requires: v2.1] Original was GL_SRGB = 0x8C40
    Srgb = 35904,

    //     [requires: v2.1] Original was GL_SRGB8 = 0x8C41
    Srgb8 = 35905,

    //     [requires: v2.1] Original was GL_SRGB_ALPHA = 0x8C42
    SrgbAlpha = 35906,

    //     [requires: v2.1] Original was GL_SRGB8_ALPHA8 = 0x8C43
    Srgb8Alpha8 = 35907,

    //     Original was GL_SLUMINANCE_ALPHA = 0x8C44
    SluminanceAlpha = 35908,

    //     Original was GL_SLUMINANCE8_ALPHA8 = 0x8C45
    Sluminance8Alpha8 = 35909,

    //     Original was GL_SLUMINANCE = 0x8C46
    Sluminance = 35910,

    //     Original was GL_SLUMINANCE8 = 0x8C47
    Sluminance8 = 35911,

    //     [requires: v2.1] Original was GL_COMPRESSED_SRGB = 0x8C48
    CompressedSrgb = 35912,

    //     [requires: v2.1] Original was GL_COMPRESSED_SRGB_ALPHA = 0x8C49
    CompressedSrgbAlpha = 35913,

    //     Original was GL_COMPRESSED_SLUMINANCE = 0x8C4A
    CompressedSluminance = 35914,

    //     Original was GL_COMPRESSED_SLUMINANCE_ALPHA = 0x8C4B
    CompressedSluminanceAlpha = 35915,

    //     Original was GL_COMPRESSED_SRGB_S3TC_DXT1_EXT = 0x8C4C
    CompressedSrgbS3tcDxt1Ext = 35916,

    //     Original was GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT = 0x8C4D
    CompressedSrgbAlphaS3tcDxt1Ext = 35917,

    //     Original was GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT = 0x8C4E
    CompressedSrgbAlphaS3tcDxt3Ext = 35918,

    //     Original was GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT = 0x8C4F
    CompressedSrgbAlphaS3tcDxt5Ext = 35919,

    //     [requires: v3.0 or ARB_depth_buffer_float] Original was GL_DEPTH_COMPONENT32F
    //     = 0x8CAC
    DepthComponent32f = 36012,

    //     [requires: v3.0 or ARB_depth_buffer_float] Original was GL_DEPTH32F_STENCIL8
    //     = 0x8CAD
    Depth32fStencil8 = 36013,

    //     [requires: v3.0] Original was GL_RGBA32UI = 0x8D70
    Rgba32ui = 36208,

    //     [requires: v3.0 or ARB_texture_buffer_object_rgb32] Original was GL_RGB32UI =
    //     0x8D71
    Rgb32ui = 36209,

    //     [requires: v3.0] Original was GL_RGBA16UI = 0x8D76
    Rgba16ui = 36214,

    //     [requires: v3.0] Original was GL_RGB16UI = 0x8D77
    Rgb16ui = 36215,

    //     [requires: v3.0] Original was GL_RGBA8UI = 0x8D7C
    Rgba8ui = 36220,

    //     [requires: v3.0] Original was GL_RGB8UI = 0x8D7D
    Rgb8ui = 36221,

    //     [requires: v3.0] Original was GL_RGBA32I = 0x8D82
    Rgba32i = 36226,

    //     [requires: v3.0 or ARB_texture_buffer_object_rgb32, ARB_vertex_attrib_64bit]
    //     Original was GL_RGB32I = 0x8D83
    Rgb32i = 36227,

    //     [requires: v3.0] Original was GL_RGBA16I = 0x8D88
    Rgba16i = 36232,

    //     [requires: v3.0] Original was GL_RGB16I = 0x8D89
    Rgb16i = 36233,

    //     [requires: v3.0] Original was GL_RGBA8I = 0x8D8E
    Rgba8i = 36238,

    //     [requires: v3.0] Original was GL_RGB8I = 0x8D8F
    Rgb8i = 36239,

    //     [requires: v3.0 or ARB_depth_buffer_float] Original was GL_FLOAT_32_UNSIGNED_INT_24_8_REV
    //     = 0x8DAD
    Float32UnsignedInt248Rev = 36269,

    //     [requires: v3.0 or ARB_texture_compression_rgtc] Original was GL_COMPRESSED_RED_RGTC1
    //     = 0x8DBB
    CompressedRedRgtc1 = 36283,

    //     [requires: v3.0 or ARB_texture_compression_rgtc] Original was GL_COMPRESSED_SIGNED_RED_RGTC1
    //     = 0x8DBC
    CompressedSignedRedRgtc1 = 36284,

    //     [requires: v3.0 or ARB_texture_compression_rgtc] Original was GL_COMPRESSED_RG_RGTC2
    //     = 0x8DBD
    CompressedRgRgtc2 = 36285,

    //     [requires: v3.0 or ARB_texture_compression_rgtc] Original was GL_COMPRESSED_SIGNED_RG_RGTC2
    //     = 0x8DBE
    CompressedSignedRgRgtc2 = 36286,

    //     [requires: v4.2] Original was GL_COMPRESSED_RGBA_BPTC_UNORM = 0x8E8C
    CompressedRgbaBptcUnorm = 36492,

    //     [requires: v4.2] Original was GL_COMPRESSED_SRGB_ALPHA_BPTC_UNORM = 0x8E8D
    CompressedSrgbAlphaBptcUnorm = 36493,
    //
    // ժҪ:
    //     [requires: v4.2] Original was GL_COMPRESSED_RGB_BPTC_SIGNED_FLOAT = 0x8E8E
    CompressedRgbBptcSignedFloat = 36494,

    //     [requires: v4.2] Original was GL_COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT = 0x8E8F
    CompressedRgbBptcUnsignedFloat = 36495,

    //     [requires: v3.1] Original was GL_R8_SNORM = 0x8F94
    R8Snorm = 36756,

    //     [requires: v3.1] Original was GL_RG8_SNORM = 0x8F95
    Rg8Snorm = 36757,

    //     [requires: v3.1] Original was GL_RGB8_SNORM = 0x8F96
    Rgb8Snorm = 36758,

    //     [requires: v3.1] Original was GL_RGBA8_SNORM = 0x8F97
    Rgba8Snorm = 36759,

    //     [requires: v3.1] Original was GL_R16_SNORM = 0x8F98
    R16Snorm = 36760,
    //
    // ժҪ:
    //     [requires: v3.1] Original was GL_RG16_SNORM = 0x8F99
    Rg16Snorm = 36761,

    //     [requires: v3.1] Original was GL_RGB16_SNORM = 0x8F9A
    Rgb16Snorm = 36762,

    //     [requires: v3.1] Original was GL_RGBA16_SNORM = 0x8F9B
    Rgba16Snorm = 36763,

    //     [requires: v3.3 or ARB_texture_rgb10_a2ui] Original was GL_RGB10_A2UI = 0x906F
    Rgb10A2ui = 36975,
    //
    // ժҪ:
    //     [requires: v1.0] Original was GL_ONE = 1
    One = 1,

    //     Original was GL_TWO = 2
    Two = 2,

    //     Original was GL_THREE = 3
    Three = 3,

    //     Original was GL_FOUR = 4
    Four = 4
};
enum  class TextureUnit
{
     //     [requires: v1.3] Original was GL_TEXTURE0 = 0x84C0
    Texture0 = 33984,

    //     [requires: v1.3] Original was GL_TEXTURE1 = 0x84C1
    Texture1,

    //     [requires: v1.3] Original was GL_TEXTURE2 = 0x84C2
    Texture2,

    //     [requires: v1.3] Original was GL_TEXTURE3 = 0x84C3
    Texture3,

    //     [requires: v1.3] Original was GL_TEXTURE4 = 0x84C4
    Texture4,

    //     [requires: v1.3] Original was GL_TEXTURE5 = 0x84C5
    Texture5,

    //     [requires: v1.3] Original was GL_TEXTURE6 = 0x84C6
    Texture6,

    //     [requires: v1.3] Original was GL_TEXTURE7 = 0x84C7
    Texture7,

    //     [requires: v1.3] Original was GL_TEXTURE8 = 0x84C8
    Texture8,

    //     [requires: v1.3] Original was GL_TEXTURE9 = 0x84C9
    Texture9,
    //
    // ժҪ:
    //     [requires: v1.3] Original was GL_TEXTURE10 = 0x84CA
    Texture10,

    //     [requires: v1.3] Original was GL_TEXTURE11 = 0x84CB
    Texture11,

    //     [requires: v1.3] Original was GL_TEXTURE12 = 0x84CC
    Texture12,
    //
    // ժҪ:
    //     [requires: v1.3] Original was GL_TEXTURE13 = 0x84CD
    Texture13,

    //     [requires: v1.3] Original was GL_TEXTURE14 = 0x84CE
    Texture14,

    //     [requires: v1.3] Original was GL_TEXTURE15 = 0x84CF
    Texture15,

    //     [requires: v1.3] Original was GL_TEXTURE16 = 0x84D0
    Texture16,

    //     [requires: v1.3] Original was GL_TEXTURE17 = 0x84D1
    Texture17,

    //     [requires: v1.3] Original was GL_TEXTURE18 = 0x84D2
    Texture18,

    //     [requires: v1.3] Original was GL_TEXTURE19 = 0x84D3
    Texture19,

    //     [requires: v1.3] Original was GL_TEXTURE20 = 0x84D4
    Texture20,

    //     [requires: v1.3] Original was GL_TEXTURE21 = 0x84D5
    Texture21,

    //     [requires: v1.3] Original was GL_TEXTURE22 = 0x84D6
    Texture22,

    //     [requires: v1.3] Original was GL_TEXTURE23 = 0x84D7
    Texture23,

    //     [requires: v1.3] Original was GL_TEXTURE24 = 0x84D8
    Texture24,

    //     [requires: v1.3] Original was GL_TEXTURE25 = 0x84D9
    Texture25,

    //     [requires: v1.3] Original was GL_TEXTURE26 = 0x84DA
    Texture26,

    //     [requires: v1.3] Original was GL_TEXTURE27 = 0x84DB
    Texture27,

    //     [requires: v1.3] Original was GL_TEXTURE28 = 0x84DC
    Texture28,

    //     [requires: v1.3] Original was GL_TEXTURE29 = 0x84DD
    Texture29,

    //     [requires: v1.3] Original was GL_TEXTURE30 = 0x84DE
    Texture30,

    //     [requires: v1.3] Original was GL_TEXTURE31 = 0x84DF
    Texture31
};

class  GLTexture
{
public:
	int   m_TextureID;
	int   m_Txr_Width = 0;
	int   m_Txr_Height = 0;//
    int   m_Txr_nrChannels = 4;

	enum TextureWrapMode    m_WrapMode = TextureWrapMode::Repeat;
    enum TextureMagFilter   m_MagFilter = TextureMagFilter::Linear;
    enum TextureMinFilter   m_MinFilter = TextureMinFilter::Linear;
    enum PixelInternalFormat  m_PixelInternalFormat = PixelInternalFormat::Rgba;

	bool  m_IsGenerateMipmap = true;

public:
    GLTexture() { m_TextureID = 0; };
	~GLTexture();
    
    void Bind(TextureUnit textureUnit = TextureUnit::Texture0)
    {
        glActiveTexture((int)textureUnit);
        glBindTexture(GL_TEXTURE_2D, m_TextureID);
    }

    void Unbind(TextureUnit textureUnit = TextureUnit::Texture0)
    {
        glActiveTexture((int)textureUnit);
        glBindTexture(GL_TEXTURE_2D, 0);
    }
public:
    GLuint  Load_Texture_FromFile_stb(const char* _filename);
   // int  Load_Texture_From_File(const char* _fileName);
};
inline GLTexture::~GLTexture()
{
	if (m_TextureID != 0)
	{
		glDeleteTextures(1, (GLuint*)&m_TextureID);
	}
}
/*
static AUX_RGBImageRec* LoadBMP(const char* Filename)        // Loads a bitmap image
{
    FILE* File = NULL;              // File handle

    if (!Filename)		        // Make sure a filename was given
    {
        return NULL;	        // If not return NULL
    }

    File = fopen(Filename, "r");	// Check to see if the file exists

    if (File)			// Does the file exist?
    {
        fclose(File);		// Close the handle
        //USES_CONVERSION;
        //auxDIBImageLoad(A2CW((LPCSTR)Filename));
        std::wstring  wFileName = String2WString(Filename);

       // USES_CONVERSION;

        return auxDIBImageLoad(wFileName.c_str());// A2CW((LPCSTR)Filename));       // Load the bitmap and return a pointer
    }

    return NULL;                    // If load failed return NULL
}

int  GL_Texture::Load_Texture_From_File(const char* _fileName)
{
    int Status = false;     // Status indicator

    AUX_RGBImageRec* TextureImage[1];               // Create storage space for the texture

    TextureImage[0] = NULL; // memset(TextureImage, 0, sizeof(void*) * 1);        // Set the pointer to NULL

    // Load the bitmap, check for errors, if bitmap's not found quit
    if (TextureImage[0] = LoadBMP(_fileName)) // "Data/NeHe.bmp"))
    {
        Status = true;				// Set the status yo TRUE

        glGenTextures(1, (GLuint*)&m_TextureID[0]);		// Create the texture

        // Typical texture generation using data from the bitmap
        glBindTexture(GL_TEXTURE_2D, m_TextureID[0]);
        glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[0]->sizeX, TextureImage[0]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[0]->data);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glBindTexture(GL_TEXTURE_2D, 0);
    }

    if (TextureImage[0])			// If texture exists
    {
        if (TextureImage[0]->data)	// If texture image exists
        {
            free(TextureImage[0]->data);	// Free the texture image memory
        }

        free(TextureImage[0]);			// Free the image structure
    }

    return Status;				// Return the status
}*/


#endif