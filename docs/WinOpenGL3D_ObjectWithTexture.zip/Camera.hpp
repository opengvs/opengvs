/* FileName:Camera.hpp  ����OpenGL�����������õ��������
   ��ͷ�ļ�������ͶӰ���͵Ķ���GLProjectionType��GLProjection�������
    Ϊ�����û��������Ŀ��ƣ�Camera���б����m_EyePos��m_EyeLookat��m_EyeUp����������ע��û�б���Front��Right��Up����������λʸ����Ҫ����õ���
	2020��1�� ������ �����ںӱ��ȷ�    ��Ȩ����  */

#ifndef  __CAMERA_HPP__
#define  __CAMERA_HPP__

#include "glad.h"
#include <string>
#include "g_consts.h"
#include "glm/glm.hpp"
#include "glm/gtc/type_ptr.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/quaternion.hpp"
#define GLM_ENABLE_EXPERIMENTAL
#include "glm/gtx/euler_angles.hpp"
#include "LineAndPlane.hpp"

enum GLProjectionType
{
	Orthographic = 0,
	Perspective = 1
};
struct GLProjection
{
	GLProjection() {}

	/*GLProjectionType _type = Perspective*/
	void SetPerspectiveProjection( float fovY, float aspectRatio, float _near=0.1f, float _far=1000.0f);
	/*GLProjectionType _type = Orthographic*/
	void SetOrthographicProjection( float _left, float _right, float _bottom, float _top, float _near=0.1f, float _far=1000.0f);
	void TraditionalSetProjection(void);
	glm::mat4  GetProjectionMat(void)
	{
		if (projectionType == Perspective)
			return glm::frustum(Left, Right, Bottom, Top, Near, Far);
		else
			return glm::ortho(Left, Right, Bottom, Top, Near, Far);
	}
	GLProjectionType   projectionType;
	float getFovY();
	void SetFovY(float AngleDegrees)
	{
		float  aspectRatio = (Right - Left) / (Top- Bottom);
		float tangent = tanf(0.5f * AngleDegrees * G_DEG_TO_RAD);
		float height = Near * tangent;           // half height of near plane
		float width = height * aspectRatio;       // half width of near plane
		
		Left = -width;
		Right = width;
		Top = height;
		Bottom = -height;
	}
	void SetNear(float _near)
	{
		float  aspectRatio = (Right - Left) / (Top - Bottom);
		float tempFov = atan(fabs(Bottom / Near));
		Near = _near;

		float tangent = tanf(tempFov);   // tangent of half fovY

		float height = _near * tangent;           // half height of near plane
		float width = height * aspectRatio;       // half width of near plane
		Left = -width;
		Right = width;
		Top = height;
		Bottom = -height;
	}
	float Left;
	float Right;
	float Bottom;
	float Top;

	

	float Near=0.1f;
	float Far=1000.0f;
};
//------------------------------------------------------------------------------------------
inline void GLProjection::SetPerspectiveProjection( float fovY, float aspectRatio, float _near, float _far)
{
	projectionType = Perspective;
	Near = _near;
	Far = _far;

	float tangent = tanf(0.5f*fovY * G_DEG_TO_RAD);   // tangent of half fovY
	
	float height = _near * tangent;           // half height of near plane
	float width = height * aspectRatio;       // half width of near plane
	Left = -width;
	Right = width;
	Top = height;
	Bottom = -height;
}
inline void GLProjection::SetOrthographicProjection( float _left, float _right, float _bottom, float _top, float _near, float _far)
{
	projectionType = Orthographic;
	Near = _near;
	Far = _far;

	Left = _left;
	Right = _right;
	Top = _top;
	Bottom = _bottom;
}
inline float GLProjection::getFovY()
{
	float tempF = atan(fabs(Bottom / Near));
	return tempF * 2 * G_RAD_TO_DEG;
}
inline void GLProjection::TraditionalSetProjection(void)
{
	glMatrixMode(GL_PROJECTION);	// ѡ��ͶӰ����
	glLoadIdentity();				// ����ͶӰ����
	if (projectionType == Perspective)
	{
		glFrustum(Left, Right, Bottom, Top,Near,Far);
	}
	else
	{
		glOrtho(Left, Right, Bottom, Top, Near, Far);
	}
	glMatrixMode(GL_MODELVIEW);	// ѡ��ģ�͹۲����
}
//---------------------------------------------------------------------------------------
class  Camera
{
public:
	glm::vec3  m_EyePos = glm::vec3(0.0f, 0.0f, 1.0f);
	glm::vec3  m_EyeLookat = glm::vec3(0.0f, 0.0f,0.0f);
	glm::vec3  m_EyeUp = glm::vec3(0.0f, 1.0f, 0.0f);

	GLProjection   m_Projection;
public:
	Camera() {};
	~Camera() {};
	void  SetCamera(glm::vec3 _Pos = glm::vec3(0.0f, 0.0f, 1.0f), glm::vec3  _Lookat = glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3 _Up = glm::vec3(0.0f, 1.0f, 0.0f))
	{
		m_EyePos = _Pos;
		m_EyeLookat = _Lookat;
		m_EyeUp = _Up;
		
	}
	void SetPerspectiveProjection(float fovY, float aspectRatio, float _near, float _far);
	void SetOrthographicProjection(float _left, float _right, float _bottom, float _top, float _near, float _far);
	void TraditionalSetProjection(void)
	{
		m_Projection.TraditionalSetProjection();
	}
	const glm::mat4  GetProjectionMat(void)
	{
		return  m_Projection.GetProjectionMat();
	}

	glm::mat4  InitializeUseLookat(glm::vec3 _Pos = glm::vec3(0.0f, 0.0f, 1.0f), glm::vec3  _Lookat = glm::vec3(0.0f, 0.0f, 0.0f),
		                                   glm::vec3 _Up = glm::vec3(0.0f, 1.0f, 0.0f))
	{
		m_EyePos = _Pos;
		m_EyeLookat = _Lookat;
		m_EyeUp = _Up;
		
		return  glm::lookAt(_Pos, _Lookat, _Up);
	}
	const glm::mat4  GetViewMat()
	{
		return   glm::lookAt(m_EyePos, m_EyeLookat, m_EyeUp);
	}
	const glm::vec3 GetFront()
	{
		return glm::normalize(m_EyeLookat- m_EyePos);
	}
	const glm::vec3 GetUp()
	{
		glm::vec3 _Front = GetFront();
		glm::vec3 _Right = glm::normalize(glm::cross(_Front, m_EyeUp));
		return glm::normalize(glm::cross(_Right, _Front));
	}
	glm::vec3 GetRight()
	{
		return glm::normalize(glm::cross(GetFront(), m_EyeUp));
	}
	const glm::vec3& GetEyePosition()
	{
		return m_EyePos;
	} 
	const glm::vec3& GetPosition()
	{
		return m_EyePos;
	}
	void SetPosition(const glm::vec3& cNewPos)
	{
		glm::vec3 tVec3 = cNewPos - m_EyePos;
		m_EyePos += tVec3;
		m_EyeLookat += tVec3;
	}
	const glm::vec3 GetRotation()
	{
		glm::vec3  t_vec3;
		glm::mat4 _RotMat = GetViewMat();
		glm::extractEulerAngleYXZ(_RotMat, t_vec3.y, t_vec3.x, t_vec3.z);
		return t_vec3;
	}
    //ע�⣺���
	void SetRotation(const glm::vec3& cRot,BOOL ChangeEyeUp= FALSE )
	{
		glm::mat4 _RotMat = glm::mat4(1.0f);
		glm::qua<float> q = glm::qua<float>(cRot); //glm::radians(glm::vec3(0.0f, 0.0f, 90.0f))); //����һ����z����ת90�ȵ���Ԫ��
		
		_RotMat = glm::mat4_cast(q) * _RotMat;	//�õ�һ����ת��ģ�;���

		glm::vec3 front;
		front.x = -_RotMat[0][2];
		front.y = -_RotMat[1][2];
		front.z = -_RotMat[2][2];

		float _Distance = sqrt((m_EyeLookat.x - m_EyePos.x) * (m_EyeLookat.x - m_EyePos.x) +
			(m_EyeLookat.y - m_EyePos.y) * (m_EyeLookat.y - m_EyePos.y) +
			(m_EyeLookat.z - m_EyePos.z) * (m_EyeLookat.z - m_EyePos.z));
		
		front = glm::normalize(front);
		m_EyeLookat = m_EyeLookat + front * _Distance;
		//ע�����������Upʸ������m_EyeLookat��ֱ��ʸ�������ԭ����m_EyeUp���ϵ�ʸ��������ͬ

		if (ChangeEyeUp == TRUE)
		{
			//glm::vec3 euler = glm::eulerAngles(q) * 3.14159f / 180.f;
			m_EyeUp.x = _RotMat[0][1];
			m_EyeUp.y = _RotMat[1][1];
			m_EyeUp.z = _RotMat[2][1];
		}
		
	}
    void MoveFront(float distance)
	{

		glm::vec3 _Front = GetFront();
		m_EyePos += _Front * distance;
		m_EyeLookat += _Front * distance;
		
	}

	void MoveUp(float distance)
	{
		glm::vec3 _Up = GetUp();
		m_EyePos += _Up * distance;
		m_EyeLookat += _Up * distance;
		
	}
	void MoveRight(float distance)
	{
		glm::vec3 _right = GetRight();
		m_EyePos += _right * distance;
		m_EyeLookat += _right * distance;
	}
	void Rotate(const float& _Angle,const glm::vec3& _Center, const glm::vec3& _AroundVector)
	{
		glm::mat4 trans = glm::mat4(1.0f);
		trans *= glm::translate(trans, -_Center);
		trans *= glm::rotate(trans, _Angle, _AroundVector );
		trans *= glm::translate(trans, _Center);
		m_EyePos = glm::vec4(m_EyePos,1.0f) * trans;
		m_EyeLookat = glm::vec4(m_EyeLookat, 1.0f) * trans;
		m_EyeUp = glm::vec4(m_EyeUp, 1.0f) * trans;
	}
	void RotateCenterLookatAroundVecter(const float& _Angle,const glm::vec3& _AroundVector)
	{
		Rotate(_Angle,m_EyeLookat, _AroundVector);
	}
	void RotateCenterEyePosAroundVecter(const float& _Angle, const glm::vec3& _AroundVector)
	{
		Rotate(_Angle, m_EyePos, _AroundVector);
	}
	void RotateCenterLookatAroundEyeUp(const float& _Angle)
	{
		Rotate(_Angle, m_EyeLookat, m_EyeUp);
	}
	void RotateCenterLookatAroundEyeFront(const float& _Angle)
	{
		Rotate(_Angle, m_EyeLookat, GetFront());
	}
	void RotateCenterLookatAroundEyeRight(const float& _Angle)
	{
		Rotate(_Angle, m_EyeLookat, GetRight() );
	}
	void RotateCenterEyePosAroundEyeUp(const float& _Angle)
	{
		Rotate(_Angle, m_EyePos, m_EyeUp);
	}
	void RotateCenterEyePosAroundEyeFront(const float& _Angle)
	{
		Rotate(_Angle, m_EyePos, GetFront());
	}
	void RotateCenterEyePosAroundEyeRight(const float& _Angle)
	{
		Rotate(_Angle, m_EyePos, GetRight());
	}

	float GetFovY()
	{
		return m_Projection.getFovY();
	}
	void SetFovY(float AngleDegrees)
	{
		m_Projection.SetFovY(AngleDegrees);
	}
	float GetNear()
	{
		return m_Projection.Near;
	}
	void SetNear(float _near)
	{
		m_Projection.SetNear(_near);
	}
	float GetFar()
	{
		return m_Projection.Far;
	}
	void SetFar(float _far)
	{
		m_Projection.Far = _far;
	}
};

inline void Camera::SetPerspectiveProjection(float fovY, float aspectRatio, float _near, float _far)
{
	m_Projection.SetPerspectiveProjection(fovY, aspectRatio, _near, _far);
}
inline void Camera::SetOrthographicProjection(float _left, float _right, float _bottom, float _top, float _near, float _far)
{
	m_Projection.SetOrthographicProjection(_left, _right, _bottom, _top, _near, _far);
}

#endif 

/*
void  GetLookatParameter(glm::mat4& mat)
	{
		glm::vec3 front;
		glm::vec3 up;
		glm::vec3 right;
		glm::vec3 pos;
		right.x = mat[0][0];
		right.y = mat[1][0];
		right.z = mat[2][0];
		up.x = mat[0][1];
		up.y = mat[1][1];
		up.z = mat[2][1];
		front.x = -mat[0][2];
		front.y = -mat[1][2];
		front.z = -mat[2][2];

		glm::mat3 tempMat3 = glm::mat3(1.0f);
		tempMat3[0][0] = right.x;
		tempMat3[1][0] = right.y;
		tempMat3[2][0] = right.z;
		tempMat3[0][1] = up.x;
		tempMat3[1][1] = up.y;
		tempMat3[2][1] = up.z;
		tempMat3[0][2] = front.x;
		tempMat3[1][2] = front.y;
		tempMat3[2][2] = front.z;


		glm::vec3 tempPos = glm::inverse(tempMat3) * glm::vec3(-mat[3][0], -mat[3][1], mat[3][2]);

	}
glm::vec3 GetEyePosition()
	{
		glm::vec3 front;
		glm::vec3 up;
		glm::vec3 right;
		glm::vec3 pos;
		right.x = m_ViewMat[0][0];
		right.y = m_ViewMat[1][0];
		right.z = m_ViewMat[2][0];

		up.x = m_ViewMat[0][1];
		up.y = m_ViewMat[1][1];
		up.z = m_ViewMat[2][1];
		front.x = -m_ViewMat[0][2];
		front.y = -m_ViewMat[1][2];
		front.z = -m_ViewMat[2][2];

		glm::mat3 tempMat3 = glm::mat3(1.0f);
		tempMat3[0][0] = right.x;
		tempMat3[1][0] = right.y;
		tempMat3[2][0] = right.z;
		tempMat3[0][1] = up.x;
		tempMat3[1][1] = up.y;
		tempMat3[2][1] = up.z;
		tempMat3[0][2] = front.x;
		tempMat3[1][2] = front.y;
		tempMat3[2][2] = front.z;


		glm::vec3 eyePos = glm::inverse(tempMat3) * glm::vec3(-m_ViewMat[3][0], -m_ViewMat[3][1], m_ViewMat[3][2]);
		return  eyePos;
		
	}
*/