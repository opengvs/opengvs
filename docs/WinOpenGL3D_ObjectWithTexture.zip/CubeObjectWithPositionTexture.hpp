#pragma once
#include "VAOWithVBOandEBO.hpp"
#include "Transform.hpp"
#include "Camera.hpp"
#include "Shader.hpp"
#include "GLTexture.hpp"
#include "WinForm.hpp"

float vertices[] = {
        -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
         0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
        -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,

        -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
         0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
        -0.5f,  0.5f,  0.5f,  0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,

        -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
        -0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
        -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

         0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
         0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
         0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
         0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

        -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
         0.5f, -0.5f, -0.5f,  1.0f, 1.0f,
         0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
         0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
        -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,

        -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
        -0.5f,  0.5f,  0.5f,  0.0f, 0.0f,
        -0.5f,  0.5f, -0.5f,  0.0f, 1.0f
};


class CubeObjectWithPositionTexture : public Transform
{
    const std::string m_VertexShaderWithPosTex = R"(
#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aTexCoord;

out vec2 TexCoord;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(aPos, 1.0f);
    TexCoord = vec2(aTexCoord.x, aTexCoord.y);
}
)";

    const std::string m_FrageShaderWithPosTex = R"(
#version 330 core
out vec4 FragColor;

in vec2 TexCoord;

// texture samplers
uniform sampler2D texture1;
uniform sampler2D texture2;
uniform float mixFactor;
void main()
{
    // linearly interpolate between both textures (80% container, 20% awesomeface)
    FragColor = mix(texture(texture1, TexCoord), texture(texture2, TexCoord), mixFactor);
}
)";
    


   // unsigned int VBO, VAO;
    VAOWithVBOandEBO  m_VaoWithVbo;
    GLTexture  m_texture1, m_texture2;
    Shader     m_shader;
public:
    CubeObjectWithPositionTexture() {}
    ~CubeObjectWithPositionTexture()
    {
      /*  if (VAO != 0)
        {
            glDeleteVertexArrays(1, &VAO);
        }
        if (VBO != 0)
        {
            glDeleteBuffers(1, &VBO);
        }
        */
    }
    void InitializeData()
    {
        m_shader.InitializeShaderWithString(m_VertexShaderWithPosTex.c_str(),
            m_FrageShaderWithPosTex.c_str());

        std::string _pathStr = Win::GetCurrentModuleDirectory();

        m_texture1.Load_Texture_FromFile_stb(std::string(_pathStr+"\\milla.bmp").c_str());
        m_texture2.Load_Texture_FromFile_stb(std::string(_pathStr + "\\wall.bmp").c_str());

        m_VaoWithVbo.AddVBO({ vertices }, { 5 * 36 }, BufferUsageHint::StaticDraw,
            { {3,2} });

    }
    void Draw(Camera& _camera,float _MixFactor=0.5)
    {
        m_shader.Use();
        m_shader.setInt("texture1", 0);
        m_shader.setInt("texture2", 1);
        m_shader.setFloat("mixFactor", _MixFactor);
        m_texture1.Bind(TextureUnit::Texture0);
        m_texture2.Bind(TextureUnit::Texture1);

        this->RotateAngleY(glm::radians(0.05f));


        // note: currently we set the projection matrix each frame, but since the projection matrix rarely changes it's often best practice to set it outside the main loop only once.
        m_shader.SetMat4("projection", _camera.GetProjectionMat());
        m_shader.SetMat4("model", GetMat());
        m_shader.SetMat4("view", _camera.GetViewMat());

        m_VaoWithVbo.DrawArrays(PrimitiveType::Triangles, 0, 36);
        m_shader.UnUse();
        m_texture1.Unbind();
        m_texture2.Unbind();
    }
   /* void InitializeData()
    {
        m_shader.InitializeShaderWithString(m_VertexShaderWithPosTex.c_str(),
            m_FrageShaderWithPosTex.c_str() );
        m_texture1.Load_Texture_FromFile_stb("d:/wall.bmp");
        m_texture2.Load_Texture_FromFile_stb("d:/milla.bmp");

        glGenVertexArrays(1, &VAO);
        glGenBuffers(1, &VBO);

        glBindVertexArray(VAO);

        glBindBuffer(GL_ARRAY_BUFFER, VBO);
        glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

        // position attribute
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(0);
        // texture coord attribute
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
        glEnableVertexAttribArray(1);

        
        glBindVertexArray(0);
        glBindBuffer(GL_ARRAY_BUFFER, 0);
    }
    void Draw(Camera& _camera)
    {
        m_shader.Use();
        m_shader.setInt("texture1", 0);
        m_shader.setInt("texture2", 1);

        m_texture1.Bind(TextureUnit::Texture0);
        m_texture2.Bind(TextureUnit::Texture1);

        this->SetPosition(glm::vec3(2.0f, 1.0f, 0.0f));
        this->RotateAngleY( glm::radians(0.05f) );
     

        // note: currently we set the projection matrix each frame, but since the projection matrix rarely changes it's often best practice to set it outside the main loop only once.
        m_shader.SetMat4("projection", _camera.GetProjectionMat());
        m_shader.SetMat4("model", GetMat());
        m_shader.SetMat4("view", _camera.GetViewMat());

        // render box
        glBindVertexArray(VAO);
        glDrawArrays(GL_TRIANGLES, 0, 36);

        m_shader.UnUse();
        m_texture1.Unbind();
        m_texture2.Unbind();
    }
    */
};
