#pragma once
// ============================================================================
// Transformer/Transformer.h —— 组装层 + 模型组件 + GGUF 头解析（统一 namespace trans）
//
// 本次重构（按用户架构意图）把原先分散在 guff/guff.h、Transformer/layers.h 的内容
// 全部收敛到本文件（trans 命名空间），并删除 guff/、layers.h 两个文件：
//   * GGUF 文件头解析（GUFFHeadInfor，直接 FILE* 读字节流）
//   * 张量读取助手（ggufTensorBytes / loadTensorMatrix / loadTensorVector）
//   * 模型组件：RMSNorm / RoPE / Linear / MultiHeadAttention / FeedForward / Sampler 已迁入 calculations.h（ops 命名空间）；KVCache 仍留在本文件
//   * 四个业务类：GUFFHeadInfor / EmbeddingInfor / LayerInfor / Transformer
//
// 四个类的职责（用户设定）：
//   ⓿ GUFFHeadInfor —— GGUF 文件「头信息」的结构化承载（不含 token 列表、不含 embedding 矩阵）
//   ① EmbeddingInfor       —— token 列表 + embedding 矩阵 + decode/encode(BPE) + KVCache
//                       （模型级「非逐层」权重也归此处：末层归一化 output_norm + LM 头 output）
//   ② LayerInfor    —— 单层推理所需的全部权重 + 该层的前向计算过程
//   ③ Transformer   —— 组装 headInfor/embeddingInfor/layers，完成整段推理（forward / generate）
//
// 数值原语来自 tensor20.h（wb）；结构算子来自 calculations.h（ops::rmsNorm / ops::applyRoPEToRow）。
// ============================================================================
#include "../tensor/tensor20.h"
#include "../calculations/calculations.h"   // ops::rmsNorm / ops::applyRoPEToRow / ops::Linear（Linear 已迁入此处）
#include <iostream>
#include <list>
#include <vector>
#include <string>
#include <unordered_map>
#include <memory>
#include <utility>
#include <cstdio>
#include <cstring>
#include <functional>
#include <cctype>     // tokenizerEncode(BPE) 用 std::isspace
#include <climits>    // tokenizerEncode(BPE) 用 INT_MAX 表示「无合并」
#include <stdexcept>

namespace trans {

using namespace wb;   // Matrix / Vector / Tensor / ggml_type / makeDense / traitsOf 在本命名空间内可见

// 下列「含模型结构知识」的类已迁入 calculations/calculations.h（namespace ops），
// 此处用 using 引入，使 trans 内原有代码（MultiHeadAttention / FeedForward / RoPE /
// Sampler / RMSNorm / Linear 的无限定引用）无需逐个改动即可继续编译。
//using ops::Linear;
//using ops::RMSNorm;
//using ops::RoPE;
//using ops::MultiHeadAttention;
//using ops::FeedForward;
//using ops::Sampler;


// ============================================================================
// GGUF 张量读取助手（原 guff.h 内容，迁移到 trans）
// ============================================================================
// 单张量数据块字节数：复用 tensor20.h 的 wb::traitsOf（QuantTraits 表）
//   F32=4n、F16=2n、Q8_0=块*34，Q4_0/Q8_1/Q2_0… 等按其块参数自动正确（对齐 llama.cpp ggml_nbytes）
inline size_t ggufTensorBytes(ggml_type type, size_t nElems) {
    const QuantTraits& q = traitsOf(type);
    if (q.blck_size > 1) {
        const size_t nblocks = (nElems + q.blck_size - 1) / q.blck_size;
        return nblocks * q.blck_bytes;
    }
    return nElems * q.blck_bytes;
}

// ----------------------------------------------------------------------------
// GUFFHeadInfor —— GGUF 文件「头信息」(Head Information) 的结构化承载
// ----------------------------------------------------------------------------
// 一个 GGUF 文件 = 头信息(Head) + 权重数据段(Body)。本类把文件头里除权重字节以外
// 的全部描述按 llama.cpp 语义分成四组保存，并逐字段注明推理时的用途。
//
// 数据来源：直接以 FILE* 读取 GGUF 文件字节流（不经 GUFFFile::load）。
//   - 固定头（magic/version/计数）经 fread 读入；
//   - meta（KV 元数据）由 loadFrom(FILE*) 边读边解析为下面的结构化字段；
//   - tensors（张量信息表）拷贝为轻量的 TensorEntry 列表（不含权重字节）。
//
// 注意：按用户架构约定，本类「不含 embedding 矩阵」，但「持有 token 列表 tokens」——
//   tokenizer.ggml.tokens（词表）在 loadFrom 时直接存入本类 tokens 成员（单一事实来源），
//   EmbeddingInfor 通过 const 视图指针 vocabPtr 引用它（零拷贝）；
//   embedding 矩阵由 EmbeddingInfor.loadFromFile 负责读取。本类只保留「结构/超参」描述。
// ============================================================================
class GUFFHeadInfor {
public:
    // ---- 组 0：文件级固定头（magic/version/计数）—— GGUF 二进制最前部 ----
    std::string magic       = "GGUF"; // 魔数，恒为 "GGUF"，用于识别文件格式
    uint32_t    version     = 3;      // GGUF 版本号（当前 v3）
    uint64_t    tensor_count = 0;     // 张量个数（= 权重张量数）
    uint64_t    metadata_count = 0;   // KV 元数据条数
    uint64_t    data_offset = 0;      // 数据段（权重区）起点在文件中的「绝对偏移」：
                                      //   紧接张量元信息之后、按 alignment 向上对齐的位置。
                                      //   EmbeddingInfor/LayerInfor 据此 + 张量 offset 直接 fseek 定位权重字节。

    // ---- 组 A：general.* —— 文件/架构标识（决定「用哪个网络类」）----
    std::string architecture;         // general.architecture：如 "llama"。最关键：
                                      //   加载器据此选择网络结构与张量命名约定。
    std::string name;                 // general.name：模型名（人类可读，不影响推理）
    std::string description;          // general.description：描述（人类可读）
    uint32_t    alignment  = 32;      // general.alignment：数据段字节对齐基准（默认 32）
    uint32_t    file_type  = 0;       // general.file_type：整体量化类型编号（0=F32）

    // ---- 组 B：llama.* —— 推理超参（决定「网络长什么样」，核心）----
    uint32_t vocab_size          = 0; // llama.vocab_size：词表大小 → embedding 行数 / logits 维度
    uint32_t context_length      = 0; // llama.context_length：训练最大序列长 → KV cache / 位置上限
    uint32_t embedding_length    = 0; // llama.embedding_length：隐藏维 d_model → 所有层宽度
    uint32_t block_count         = 0; // llama.block_count：Transformer 层数 n_layer
    uint32_t feed_forward_length = 0; // llama.feed_forward_length：FFN 中间维 d_ff
    uint32_t head_count          = 0; // llama.attention.head_count：Q 头数 n_head（head_dim=d_model/n_head）
    uint32_t head_count_kv       = 0; // llama.attention.head_count_kv：KV 头数（=head_count 即 MHA）
    uint32_t key_length          = 0; // llama.attention.key_length：每 KV 头维（n_embd_head_k）
    uint32_t value_length        = 0; // llama.attention.value_length：每 V 头维（n_embd_head_v）
    float    rms_eps             = 1e-5f; // llama.attention.layer_norm_rms_epsilon：RMSNorm 稳定项
    bool     causal              = true;  // llama.attention.causal：因果掩码（自回归）
    uint32_t rope_dimension_count = 0; // llama.rope.dimension_count：每头旋转维数（RoPE 作用维度）

    // ---- 组 C：tokenizer.* —— 分词器（prompt↔ids↔logits 的翻译）----
    // token 列表（tokenizer.ggml.tokens）按本架构约定「存于本类」，作为词表的单一事实来源；
    //   EmbeddingInfor 仅持有一个 const 视图指针指向它（零拷贝、不重复持有副本）。其余为分词「规则/开关」元数据。
    std::vector<std::string> tokens;           // tokenizer.ggml.tokens：词表本体（token 串，id = 下标），单一事实来源
    std::string              tokenizer_model;  // tokenizer.ggml.model：分词算法标识（如 "llama"）
    std::vector<float>       scores;           // tokenizer.ggml.scores：BPE 合并分数（单字模型全 0）
    std::vector<uint32_t>    token_type;       // tokenizer.ggml.token_type：token 类型（1=normal）
    std::vector<std::string> merges;           // tokenizer.ggml.merges：BPE 合并规则（单字模型为空）
    uint32_t bos_token_id = 0;                 // tokenizer.ggml.bos_token_id：句首特殊 token
    uint32_t eos_token_id = 0;                 // tokenizer.ggml.eos_token_id：句尾特殊 token（本 demo=11 即 '='）
    bool     add_bos      = false;             // tokenizer.ggml.add_bos：是否自动加 BOS
    bool     add_eos      = false;             // tokenizer.ggml.add_eos：是否自动加 EOS

    // ---- 组 D：张量信息表 —— 权重「地图」(name/dims/type/offset)，不含权重字节 ----
    struct TensorEntry {
        std::string    name;             // 张量名（定位落到哪一层，如 blk.0.attn_q.weight）
        uint32_t       n_dims = 0;       // 维度数（矩阵=2，向量=1）
        uint64_t       dims[4] = {0,0,0,0}; // 各维尺寸，方向约定 {IN,OUT}：dims[0]=输入维, dims[1]=输出维
        ggml_type type = GGML_TYPE_F32;  // 存储/量化类型（F32/F16/Q8_0…）
        uint64_t       offset = 0;       // 相对数据段起点的字节偏移（按 alignment 对齐）
    };
    std::vector<TensorEntry> tensors;    // 张量信息表（与文件 header.tensors 一一对应）

    GUFFHeadInfor() = default;

    // 直接以 FILE* 读取 GGUF 文件头信息（固定头 + KV + 张量信息表），顺序解析并
    // 构建本对象；成功返回 true。无需先经 GUFFFile::load。
    //   词表（tokenizer.ggml.tokens）解析后直接存入本类 tokens 成员（单一事实来源），
    //   EmbeddingInfor 通过 const 视图指针引用它，避免重复持有/重复解析。
    //   字节格式（对齐 llama.cpp gguf）：
    //     magic(4) | version(u32) | tensor_count(u64) | metadata_count(u64)
    //     KV*  : key(string) | type(i32) | [ARRAY: arrType(i32) arrN(u64) elems] | value
    //     Tensor*: name(string) | n_dims(u32) | dims(u64×n) | type(i32) | offset(u64)
    //   字符串 = u64 长度 + 原始字节；枚举按 i32 存；bool 按 i8 存；GGUF 为小端。
    bool loadFrom(FILE* guffFile) {
        if (!guffFile) return false;

        // ---- 组⓿：文件级固定头 ----
        char mg[4];
        if (fread(mg, 1, 4, guffFile) != 4) return false;
        if (std::memcmp(mg, "GGUF", 4) != 0) return false;   // 非 GGUF 文件
        magic.assign(mg, 4);
        if (fread(&version,        4, 1, guffFile) != 1) return false;
        if (fread(&tensor_count,   8, 1, guffFile) != 1) return false;
        if (fread(&metadata_count, 8, 1, guffFile) != 1) return false;

        // ---- 基础读取小工具 ----
        std::function<bool(uint32_t&)> readU32 = [&](uint32_t& v) { return fread(&v, 4, 1, guffFile) == 1; };
        std::function<bool(uint64_t&)> readU64 = [&](uint64_t& v) { return fread(&v, 8, 1, guffFile) == 1; };
        std::function<bool(std::string&)> readStr = [&](std::string& s) -> bool {
            uint64_t n = 0; if (!readU64(n)) return false;
            s.assign((size_t)n, '\0');
            if (n && fread(&s[0], 1, n, guffFile) != n) return false;
            return true;
        };
        // 读一个标量值（非 ARRAY/STRING），按 GGUFType 宽度放入 uout(整数) / fout(浮点)
        //   （GGUFType 标签值在 loadForm 时已并入本 switch 的整型分支，故此处直接用整型字面量）
        std::function<bool(uint32_t, uint64_t&, double&)> readScalar = [&](uint32_t t, uint64_t& uout, double& fout) -> bool {
            switch (t) {
                case 0:  { uint8_t  v; if (fread(&v,1,1,guffFile)!=1) return false; uout = v;        break; } // UINT8
                case 1:  { int8_t   v; if (fread(&v,1,1,guffFile)!=1) return false; uout = (uint64_t)(int64_t)v; break; } // INT8
                case 2:  { uint16_t v; if (fread(&v,2,1,guffFile)!=1) return false; uout = v;        break; } // UINT16
                case 3:  { int16_t  v; if (fread(&v,2,1,guffFile)!=1) return false; uout = (uint64_t)(int64_t)v; break; } // INT16
                case 4:  { uint32_t v; if (fread(&v,4,1,guffFile)!=1) return false; uout = v;        break; } // UINT32
                case 5:  { int32_t  v; if (fread(&v,4,1,guffFile)!=1) return false; uout = (uint64_t)(int64_t)v; break; } // INT32
                case 6:  { float    v; if (fread(&v,4,1,guffFile)!=1) return false; fout = (double)v; break; } // FLOAT32
                case 7:  { uint8_t  v; if (fread(&v,1,1,guffFile)!=1) return false; uout = v ? 1 : 0; break; } // BOOL
                case 10: { uint64_t v; if (fread(&v,8,1,guffFile)!=1) return false; uout = v;        break; } // UINT64
                case 11: { int64_t  v; if (fread(&v,8,1,guffFile)!=1) return false; uout = (uint64_t)v; break; } // INT64
                case 12: { double   v; if (fread(&v,8,1,guffFile)!=1) return false; fout = v;        break; } // FLOAT64
                default: return false;   // 不支持的标量类型
            }
            return true;
        };

        // ---- Ⓐ general.* / Ⓑ llama.* / Ⓒ tokenizer.*：KV 元数据 ----
        for (uint64_t k = 0; k < metadata_count; ++k) 
        {
            std::string key;
            if (!readStr(key)) 
                return false;
            uint32_t vt = 0;
            if (!readU32(vt)) 
                return false;

            if (vt == 9) 
            {                                  // ARRAY
                uint32_t arrType = 0;
                if (!readU32(arrType)) 
                    return false;
                uint64_t arrLen = 0;
                if (!readU64(arrLen)) 
                    return false;
                if (arrType == 8) 
                {                         // 字符串数组
                    std::vector<std::string> arr; 
                    arr.reserve((size_t)arrLen);
                    for (uint64_t i = 0; i < arrLen; ++i) 
                    {
                        std::string s; 
                        if (!readStr(s)) 
                            return false; 
                        arr.push_back(std::move(s));
                    }
                    if(key == "tokenizer.ggml.tokens") 
                        tokens = std::move(arr);
                    else if (key == "tokenizer.ggml.merges")
                        merges = arr;
                } else {                                     // 数值数组
                    std::vector<uint64_t> uarr; uarr.reserve((size_t)arrLen);
                    std::vector<double>    farr; farr.reserve((size_t)arrLen);
                    for (uint64_t i = 0; i < arrLen; ++i) {
                        uint64_t u = 0; double fv = 0;
                        if (!readScalar(arrType, u, fv)) return false;
                        if      (arrType == 6)  farr.push_back(fv);   // FLOAT32
                        else if (arrType == 12) farr.push_back(fv);   // FLOAT64
                        else                    uarr.push_back(u);     // 整型 / BOOL
                    }
                    if      (key == "tokenizer.ggml.scores")     scores.assign(farr.begin(), farr.end());
                    else if (key == "tokenizer.ggml.token_type") token_type.assign(uarr.begin(), uarr.end());
                }
            } else if (vt == 8) {                            // STRING 标量
                std::string s; if (!readStr(s)) return false;
                if      (key == "general.architecture") architecture = s;
                else if (key == "general.name")         name = s;
                else if (key == "general.description")  description = s;
                else if (key == "tokenizer.ggml.model") tokenizer_model = s;
            } else {                                        // 数值标量（找不到的键忽略，已消费字节）
                uint64_t u = 0; double fv = 0;
                if (!readScalar(vt, u, fv)) return false;
                // 架构无关匹配：llama.* 与 bitnet.* 前缀都接受
                //   （BitNet 复用 llama 的超参结构，llama.cpp 也把 bitnet.* 映射到同一组参数；
                //   只认 llama.* 会导致 bitnet 模型 block_count/embedding_length/vocab_size 全为 0）
                std::function<bool(const char*)> isKey = [&](const char* suf) {
                    return key == std::string("llama.") + suf
                        || key == std::string("bitnet.") + suf;
                };
                if      (key == "general.alignment")               alignment = (uint32_t)u;
                else if (key == "general.file_type")               file_type = (uint32_t)u;
                else if (isKey("vocab_size"))                      vocab_size = (uint32_t)u;
                else if (isKey("context_length"))                  context_length = (uint32_t)u;
                else if (isKey("embedding_length"))                embedding_length = (uint32_t)u;
                else if (isKey("block_count"))                     block_count = (uint32_t)u;
                else if (isKey("feed_forward_length") )            feed_forward_length = (uint32_t)u;
                else if (isKey("attention.head_count"))            head_count = (uint32_t)u;
                else if (isKey("attention.head_count_kv"))         head_count_kv = (uint32_t)u;
                else if (isKey("attention.key_length"))            key_length = (uint32_t)u;
                else if (isKey("attention.value_length"))          value_length = (uint32_t)u;
                else if (isKey("attention.layer_norm_rms_epsilon")) rms_eps = (float)fv;
                else if (isKey("rope.dimension_count"))            rope_dimension_count = (uint32_t)u;
                else if (key == "tokenizer.ggml.bos_token_id")     bos_token_id = (uint32_t)u;
                else if (key == "tokenizer.ggml.eos_token_id")     eos_token_id = (uint32_t)u;
                else if (isKey("attention.causal"))                causal = (u != 0);
                else if (key == "tokenizer.ggml.add_bos")          add_bos = (u != 0);
                else if (key == "tokenizer.ggml.add_eos")          add_eos = (u != 0);
            }
        }

        // ---- Ⓓ 张量信息表（name/dims/type/offset，不含权重字节）----
        tensors.clear();
        tensors.reserve((size_t)tensor_count);
        for (uint64_t t = 0; t < tensor_count; ++t) 
		{
            TensorEntry e;
            if (!readStr(e.name)) return false;
            uint32_t nd = 0; if (!readU32(nd)) return false; e.n_dims = nd;
            for (uint32_t d = 0; d < nd && d < 4; ++d) 
			{
                uint64_t dim = 0; if (!readU64(dim)) return false; e.dims[d] = dim;
            }
            for (uint32_t d = nd; d > 4; --d) 
			{ 
		       uint64_t skip = 0; 
			   if (!readU64(skip)) 
				   return false; 
			} // 丢弃多余维
            uint32_t qt = 0; if (!readU32(qt)) 
				return false; 
			e.type = (ggml_type)qt;
            uint64_t off = 0; 
			if (!readU64(off)) 
				return false; 
			e.offset = off;
            tensors.push_back(std::move(e));
        }

        // ---- 计算数据段（权重区）起点绝对偏移：紧接张量元信息之后、按 alignment 对齐 ----
        {
            uint64_t pos = (uint64_t)_ftelli64(guffFile);   // 64 位偏移，兼容 >2.1GB 文件
            uint64_t al  = alignment ? alignment : 32;
            data_offset  = ((pos + al - 1) / al) * al;
        }
        return true;
    }

    // 每头维度（= embedding_length / head_count），供注意力分头使用
    uint32_t headDim() const { return head_count ? embedding_length / head_count : 0; }


    // 打印头信息摘要（四组 + 张量表条数）
    void print(std::ostream& os = std::cout) const {
        os << "[GUFFHeadInfor] " << magic << " v" << version
           << " tensors=" << tensor_count << " metadata=" << metadata_count << "\n";
        os << "  A/general : arch=" << architecture << " name=" << name
           << " align=" << alignment << " file_type=" << file_type << "\n";
        os << "  B/llama   : vocab=" << vocab_size << " d_model=" << embedding_length
           << " layers=" << block_count << " heads=" << head_count << "/" << head_count_kv
           << " d_ff=" << feed_forward_length << " head_dim=" << headDim()
           << " rope_dim=" << rope_dimension_count << " eps=" << rms_eps
           << " causal=" << (causal ? "true" : "false") << "\n";
        os << "  C/tokenizer: model=" << tokenizer_model << " (tokens in EmbeddingInfor)"
           << " merges=" << merges.size() << " bos=" << bos_token_id << " eos=" << eos_token_id << "\n";
        os << "  D/tensors  : " << tensors.size() << " 个张量（name/dims/type/offset）\n";
    }
};

// ----------------------------------------------------------------------------
// GGUF 张量读取助手（定义于 GUFFHeadInfor 之后，故可访问 TensorEntry）
// ----------------------------------------------------------------------------
// 从 FILE* 读取一个 2 维张量（name 在 h.tensors 中）→ 原生类型 Tensor（shape=[OUT, IN]，OUT=dims[1], IN=dims[0]）
// 按用户意图：权重按 GGUF 原始类型驻留内存（F32/F16/BF16/Q8_0/Q4_0…），计算时由 Tensor::matvec/matmul
//   经 get()/vec_dot 现场反量化（呼应 llama.cpp 权重按原始类型存储、推理时反量化）。
// F32 模型下原生类型即 F32，字节布局与 [OUT][IN] 行主序连续 float 一致，行为等价于旧 F32 Matrix；
// 量化模型下省内存、省反量化带宽（不再在此处逐元素反量化成 F32）。
inline bool loadTensorMatrix(FILE* _file, const GUFFHeadInfor& h, const std::string& name, std::shared_ptr<Tensor>& M) {
    const GUFFHeadInfor::TensorEntry* e = nullptr;
    for (const GUFFHeadInfor::TensorEntry& t : h.tensors) if (t.name == name) { e = &t; break; }
    if (!e)  { std::cout << "[loadTensor] 缺失张量: " << name << "\n"; return false; }
    if (e->n_dims != 2) { std::cout << "[loadTensor] 非 2 维张量: " << name << "\n"; return false; }

    size_t IN  = (size_t)e->dims[0];
    size_t OUT = (size_t)e->dims[1];
    size_t nElems = IN * OUT;
    size_t nb = ggufTensorBytes(e->type, nElems);
    if (nb == 0) { std::cout << "[loadTensor] 不支持的张量类型: " << name << "\n"; return false; }

    uint64_t abs = h.data_offset + e->offset;
    if (_fseeki64(_file, (long long)abs, SEEK_SET) != 0) {   // 64 位偏移，兼容 >2.1GB 文件
        std::cout << "[loadTensor] fseek 失败: " << name << "\n"; return false;
    }
    // —— 原生类型驻留：一次分配 + 整块 fread，零逐元素循环（量化/非 F32 不再在此反量化）——
    M = makeDense({OUT, IN}, e->type);          // 原生类型、原生字节缓冲（shape[0]=OUT, shape[1]=IN，与旧 Matrix(OUT,IN) 一致）
    if (fread(M->raw(), 1, nb, _file) != nb) {
        std::cout << "[loadTensor] 读权重失败: " << name << "\n"; return false;
    }
    return true;
}

// 从 FILE* 读取一个 1 维张量（RMSNorm 的 gamma 向量）→ Vector(n)
inline bool loadTensorVector(FILE* _file, const GUFFHeadInfor& h, const std::string& name, Vector& v) {
    const GUFFHeadInfor::TensorEntry* e = nullptr;
    for (const GUFFHeadInfor::TensorEntry& t : h.tensors) if (t.name == name) { e = &t; break; }
    if (!e)  { std::cout << "[loadTensor] 缺失张量: " << name << "\n"; return false; }
    if (e->n_dims != 1) { std::cout << "[loadTensor] 非 1 维张量: " << name << "\n"; return false; }

    size_t n = (size_t)e->dims[0];
    size_t nb = ggufTensorBytes(e->type, n);
    if (nb == 0) { std::cout << "[loadTensor] 不支持的张量类型: " << name << "\n"; return false; }

    uint64_t abs = h.data_offset + e->offset;
    if (_fseeki64(_file, (long long)abs, SEEK_SET) != 0) {   // 64 位偏移，兼容 >2.1GB 文件
        std::cout << "[loadTensor] fseek 失败: " << name << "\n"; return false;
    }
    if (e->type == GGML_TYPE_F32) {
        // —— F32 快路径：直接整块读进 v 的底层缓冲，省去中间缓冲与逐元素代理拷贝 ——
        v = Vector(n);
        if (fread(v.data(), sizeof(float), (size_t)n, _file) != (size_t)n) {
            std::cout << "[loadTensor] 读权重失败: " << name << "\n"; return false;
        }
        return true;
    }

    std::unique_ptr<Tensor> ten = makeDense({n}, e->type);
    if (fread(ten->raw(), 1, nb, _file) != nb) {
        std::cout << "[loadTensor] 读权重失败: " << name << "\n"; return false;
    }
    v = Vector(n);
    for (size_t i = 0; i < n; ++i) v.set(i, ten->get(i));   // 量化类型经 get() 透明反量化
    return true;
}

// ============================================================================
// KVCache —— 逐层 K/V 缓存（Key-Value Cache），为「增量解码」预留的承载结构
//
// 背景 / 为什么要 KV 缓存
// -----------------------
// Transformer 自回归生成时，第 t 步只需基于「最新的 1 个 token」算出新隐状态，
// 但注意力要看到全部历史。朴素做法（本 demo 当前采用的「整序列重算」）是每一步把
// 1..t 全部 token 重新跑一遍注意力——历史越算越长，复杂度变成 O(seq²)，非常浪费。
// KV 缓存的核心思想：把每一层已经算好的 Key、Value 投影（Wk·x / Wv·x）**按层存下来**，
// 后续步只需算「新 token 的 K/V」并追加到缓存，再与全部历史 K/V 做注意力，
// 复杂度降为每步 O(seq)。这是生产级推理（vLLM / llama.cpp）加速解码的标准手段。
//
// 本类在系统中的位置
// ------------------
// 由 EmbeddingInfor 持有（属于「模型级非逐层权重的一部分」，与 embedding / 分词器同级）。
// 逐层各存一张 K、一张 V 矩阵：K[l] / V[l] 是第 l 层到目前为止的全部历史
// Key / Value，形状 [cur_seq, d_model]（cur_seq 随生成增长、上限 max_seq）。
//
// 当前状态
// --------
// 本 demo 的 MultiHeadAttention::forward 仍走「整序列重算」（对整张 X 重算 Q/K/V），
// 尚未读取/追加本缓存。因此本类目前**仅作为承载结构预留**：构造时按层数预分配空的
// K/V 矩阵容器，真正的「增量追加」与「注意力取缓存」逻辑留待后续接入（见下方 append 占位）。
//
// 接入增量解码的最小改造（TODO）
// ------------------------------
//   1) MultiHeadAttention 增加一个（可选）KVCache& 参数；
//   2) 新 token 只算其 Q/K/V，把 K/V 追加进 K[l]/V[l]（行数 +1）；
//   3) 注意力在「全部历史 K/V」（含缓存）上做缩放点积，而非重算 1..t。
// 届时 K[l].rows() 即为当前序列长度，无需再传完整 X 重算。
// ============================================================================
// ---------------------------------------------------------------------------
// KVCache —— 单层 Key/Value 缓存（增量解码时供【本层】注意力复用历史 K/V）
// ---------------------------------------------------------------------------
// 本版本为「单层版」：每个 LayerInfor 持有一份，仅存【本层】的 K/V 矩阵。
//   K / V：形状 [cur_seq, d_model]，随生成逐行追加（cur_seq = 已见 token 数）。
// 与「模型级集中缓存」(一个 KVCache 内部用 std::vector 按层索引 K[l]/V[l]) 相比，
//   本版本把缓存下放到层，使 LayerInfor 自洽——更接近「每个 decoder 层自己记住
//   它产生的 K/V」的教学直觉，也便于 LayerInfor::forward 直接读写 this->kv。
// 当前 demo 的 MultiHeadAttention::forward 仍走整序列重算，本类仅作承载结构预留；
//   增量解码接入时由 append() 把新 token 的 K/V 行追加到本层缓存。
// ---------------------------------------------------------------------------
class KVCache {
public:
    size_t n_heads;     // 注意力头数 H（形状描述，[cur_seq, H*head_dim] = [cur_seq, d_model]）
    size_t head_dim;    // 每头维度 hd（= d_model / n_heads）
    size_t max_seq;     // 序列长度上限：缓存可容纳的最大历史 token 数（超长需截断/滑动窗口）
    // 本层 Key / Value 矩阵，[cur_seq, d_model]；初始为零行矩阵，append 时逐行增长。
    Matrix K, V;

    // 默认构造：标量清零、K/V 为零行矩阵（待 loadFromFile 用 3 参构造重新赋值）
    KVCache() : n_heads(0), head_dim(0), max_seq(0) {}
    // 按形状超参构造（不预分配行，K/V 保持零行，append 时再增长）
    KVCache(size_t H, size_t hd, size_t maxs)
        : n_heads(H), head_dim(hd), max_seq(maxs) {}

    // 增量追加（把新 token 的 K/V 行追加到【本层】缓存）；真实实现留待增量解码接入：
    //   void append(const Vector& newK, const Vector& newV);
    //   内部做 K.appendRow(newK); V.appendRow(newV);（cur_seq++）。
};

// ============================================================================
// EmbeddingInfor —— 嵌入词表、嵌入矩阵、分词器(BPE) 与「模型级非逐层权重」
// ----------------------------------------------------------------------------
// 本类集中保存「进入注意力之前 / 跨层共享」的内容：
//   1) 嵌入词表视图 vocabPtr（const 指针，指向 GUFFHeadInfor::tokens，零拷贝、单一事实来源；
//      token 串 id = 下标，来自 tokenizer.ggml.tokens，本类不重复持有副本）；
//   2) 嵌入矩阵 embedding（token_embd.weight：[vocab, d_model]，token id → 向量）；
//   3) 分词器接口（tokenizerEncode / tokenizerDecode，含真实 BPE 重载）；
//   4) 模型级非逐层权重：末层归一化 finalNorm(output_norm.weight) + LM 头 lmHead(output.weight)；
//   5) （KV 缓存已下放到 LayerInfor.kv，本类不再持有——见 LayerInfor 的单层 KVCache）
// 说明：逐层权重（Wq/Wk/Wv/Wo/ffn_*）已在 LayerInfor；KV 缓存(kv)也随层走（见 LayerInfor）。
//   本类只负责「嵌入词表 + 嵌入矩阵 + 分词 + 模型级尾巴」这一跨层共享的表示。
//   （该类已从历史命名 KVInfor 重命名为 EmbeddingInfor，语义不变：集中承载跨层共享的
//   嵌入词表、嵌入矩阵、分词器与模型级非逐层权重）
// ============================================================================
class EmbeddingInfor {
public:
    const std::vector<std::string>* vocabPtr = nullptr;  // 词表视图：指向 GUFFHeadInfor::tokens（零拷贝、单一来源）
    std::shared_ptr<Tensor> embedding;  // 词表对应的张量 [vocab, d_model]（token_embd.weight，原生类型驻留）
    Vector finalNorm;                  // 末层 RMSNorm 的 gamma [d_model]（output_norm.weight）
    ops::Linear lmHead;                     // LM 头：logits = h · W_lmᵀ , W_lm:[vocab, d_model]（output.weight；若缺失则 tied 到 token_embd.weight）
    // token 串 -> id 反向索引（llama.cpp 的 llama_vocab::token_to_id 等价物）。
    // 在 vocabPtr 指向词表后由 buildTokenIndex() 一次性构建；之后 encode 直接 O(1) 查表，
    // 避免每次 encode 都线性重建索引（对应 llama.cpp 把 token_to_id 作为词表常驻成员）。
    std::unordered_map<std::string, size_t> idOf_;

    EmbeddingInfor() = default;

    // 绑定词表视图：令 vocabPtr 指向 headInfor.tokens（零拷贝）。调用方须保证该 vector 生命周期
    //   覆盖本 EmbeddingInfor 对象（LoadFormFile 中 headInfor 与 embeddingInfor 同为 Transformer 成员，headInfor 先声明，
    //   故 embeddingInfor 析构早于 headInfor，指针在其生命周期内始终有效）。
    void bindVocab(const std::vector<std::string>& tokens) { vocabPtr = &tokens; }

    // 由 vocabPtr 指向的词表重建「token 串 -> id」反向索引（末次出现优先，与 llama.cpp token_to_id 覆盖语义一致）。
    // 在 bindVocab 之后调用，之后 encode 直接复用。
    void buildTokenIndex() {
        idOf_.clear();
        if (!vocabPtr) return;
        for (size_t i = 0; i < vocabPtr->size(); ++i) idOf_[(*vocabPtr)[i]] = i;
    }

    // 依据 headInfor 的信息，直接从 GGUF 文件（FILE*）读取并初始化本对象：
    //   - embedding   ← 张量 token_embd.weight（[vocab, d_model]）
    //   - finalNorm   ← 张量 output_norm.weight（[d_model]，模型级末层归一化 gamma）
    //   - lmHead      ← 张量 output.weight（[vocab, d_model]，LM 头 W_lm）；若模型不含该张量（权重绑定）则复用 token_embd.weight
    // 注意：KV 缓存(kv)不再由本函数构建，已下放到 LayerInfor.loadFromFile（见 LayerInfor.kv）。
    // 注意：词表视图 vocabPtr 已由 LoadFormFile 在调用本函数之前，经 embeddingInfor.bindVocab(headInfor.tokens)
    //   绑定到 headInfor.tokens（零拷贝、单一来源），本函数不再重复设置词表。
    // 张量定位：absolute = headInfor.data_offset（数据段起点，已对齐） + 张量 offset，
    //   fseek 到该位置读出字节，再按类型（F32/F16/Q8_0）反量化到 f32（经 get() 透明完成）。
    // 矩阵重建沿用 {IN,OUT} 约定：dims[0]=IN(列), dims[1]=OUT(行)，M=Matrix(OUT,IN)。
    bool loadFromFile(FILE* guffFile, const GUFFHeadInfor& headInfor) {
        if (!guffFile) return false;

        if (!loadTensorMatrix(guffFile, headInfor, "token_embd.weight", embedding)) return false;
        if (!loadTensorVector(guffFile, headInfor, "output_norm.weight", finalNorm)) return false;
        lmHead = ops::Linear(embedding->cols(), embedding->rows());   // [out=vocab, in=d_model]
        // BitNet/llama 允许「权重绑定(tied)」：若模型不含独立的 output.weight 张量，
        // 则 LM 头复用 token_embd.weight（与 llama.cpp 行为一致）。否则正常加载 output.weight。
        bool hasOutputW = false;
        for (const auto& t : headInfor.tensors)
            if (t.name == "output.weight") { hasOutputW = true; break; }
        if (hasOutputW) {
            std::shared_ptr<Tensor> ow;
            if (!loadTensorMatrix(guffFile, headInfor, "output.weight", ow)) return false;
            lmHead.W = ow;
        } else {
            lmHead.W = embedding;   // tied weights：LM 头 = 词嵌入矩阵（共享原生张量，零拷贝）
        }

        // 注：KV 缓存(kv)已下放到 LayerInfor，由各层在 loadFromFile 中按自身超参构建。
        return true;
    }

    size_t vocabSize() const { return vocabPtr ? vocabPtr->size() : 0; }
    size_t dModel()    const { return embedding->cols(); }

    // ---- 分词器接口 ----
    // 两组重载：
    //   (A) 无 GUFFHeadInfor 参数：词表级、字符级 demo 分词（本类仅持有 vocab，不含 merges/scores）。
    //   (B) 带 const GUFFHeadInfor& 参数：真实 BPE 分词，利用 headInfor.merges/scores/
    //       add_bos/add_eos 走完整「合并」主算法。两者共存，调用方按需选择。
    // 把单个 token id 还原为词表串（越界抛 std::out_of_range）
    std::string tokenizerDecode(size_t id) const {
        if (!vocabPtr || id >= vocabPtr->size()) throw std::out_of_range("EmbeddingInfor::tokenizerDecode id 越界");
        return (*vocabPtr)[id];
    }

    // 把字符串逐字符映射为 token id 序列（每个字符作一 token 查表；查不到抛 std::invalid_argument）。
    // 直接复用类内缓存的 idOf_（token_to_id 等价物），无需每次重建索引。
    std::vector<size_t> tokenizerEncode(const std::string& s) const {
        std::vector<size_t> ids;
        ids.reserve(s.size());
        for (char ch : s) {
            std::unordered_map<std::string, size_t>::const_iterator it = idOf_.find(std::string(1, ch));
            if (it == idOf_.end()) throw std::invalid_argument("EmbeddingInfor::tokenizerEncode: 未知字符");
            ids.push_back(it->second);
        }
        return ids;
    }

    // ---- 真实 BPE 分词（重载：带 const GUFFHeadInfor&，利用 tokenizer.ggml.* 元数据）----
    // 与上面的「逐字符 demo 版」不同，这里走完整的 Byte-Pair-Encoding 主算法（与 llama.cpp
    //   llm_tokenizer_bpe 思路一致）：预分词 → 码点切分 → 反复合并 rank 最小相邻对 → 查 idOf_ 得 id
    //   → 若 add_bos/add_eos 为真分别前置/追加 bos/eos_token_id。
    // 依赖 headInfor 字段：merges / add_bos / bos_token_id / add_eos / eos_token_id。
    std::vector<size_t> tokenizerEncode(const std::string& s, const GUFFHeadInfor& headerInfor) const {
        std::unordered_map<std::string, int> rankOf;
        for (size_t k = 0; k < headerInfor.merges.size(); ++k) {
            const std::string& m = headerInfor.merges[k];
            size_t sp = m.find(' ');
            if (sp == std::string::npos) continue;          // 格式异常行，跳过
            rankOf[m.substr(0, sp) + "\x01" + m.substr(sp + 1)] = (int)k;
        }

        std::function<std::vector<std::string>(const std::string&)> toCodepoints = [](const std::string& w) -> std::vector<std::string> {
            std::vector<std::string> cps;
            size_t i = 0, n = w.size();
            while (i < n) {
                unsigned char c = (unsigned char)w[i];
                size_t len = (c < 0x80) ? 1
                           : ((c >> 5) == 0x6) ? 2
                           : ((c >> 4) == 0xE) ? 3
                           : ((c >> 3) == 0x1E) ? 4 : 1;
                cps.push_back(w.substr(i, len));
                i += len;
            }
            return cps;
        };

        std::vector<size_t> ids;
        size_t i = 0, n = s.size();
        while (i < n) {
            if (std::isspace((unsigned char)s[i])) { ++i; continue; }   // 空白仅作词边界
            size_t j = i;
            while (j < n && !std::isspace((unsigned char)s[j])) ++j;
            std::string word = s.substr(i, j - i);
            i = j;

            std::vector<std::string> sym = toCodepoints(word);
            std::function<int(const std::string&, const std::string&)> rank =
                [&](const std::string& a, const std::string& b) -> int {
                std::unordered_map<std::string, int>::const_iterator it = rankOf.find(a + "\x01" + b);
                return it == rankOf.end() ? INT_MAX : it->second;
            };
            bool merged = true;
            while (merged && sym.size() > 1) {
                merged = false;
                int best = INT_MAX; size_t bp = 0;
                for (size_t k = 0; k + 1 < sym.size(); ++k) {
                    int r = rank(sym[k], sym[k + 1]);
                    if (r < best) { best = r; bp = k; }
                }
                if (best != INT_MAX) {
                    sym[bp] = sym[bp] + sym[bp + 1];   // 合并相邻符号
                    sym.erase(sym.begin() + bp + 1);
                    merged = true;
                }
            }
            for (std::string& t : sym) {
                std::unordered_map<std::string, size_t>::const_iterator it = idOf_.find(t);
                if (it == idOf_.end())
                    throw std::invalid_argument("EmbeddingInfor::tokenizerEncode(BPE): 未知片段 '" + t + "'");
                ids.push_back(it->second);
            }
        }
        if (headerInfor.add_bos) ids.insert(ids.begin(), headerInfor.bos_token_id);
        if (headerInfor.add_eos) ids.push_back(headerInfor.eos_token_id);
        return ids;
    }

    // ---- 真实 BPE 版的 decode（重载：带 const GUFFHeadInfor&）----
    // 词表由 vocabPtr 指向 headerInfor.tokens（同一份，零拷贝），故经 vocabPtr[id] 还原；
    // headerInfor 仅用于语义一致性（此处未使用其字段）。越界抛 std::out_of_range。
    std::string tokenizerDecode(size_t id, const GUFFHeadInfor& headerInfor) const {
        (void)headerInfor;
        if (!vocabPtr || id >= vocabPtr->size())
            throw std::out_of_range("EmbeddingInfor::tokenizerDecode(id,headerInfor): id 越界");
        return (*vocabPtr)[id];
    }

    // 取某个 token id 的嵌入行向量（越界抛异常）
    Vector embeddingOf(size_t id) const {
        if (id >= embedding->rows()) throw std::out_of_range("EmbeddingInfor::embeddingOf id 越界");
        Vector v(embedding->cols());
        for (size_t j = 0; j < embedding->cols(); ++j) v.set(j, embedding->get({id, j}));
        return v;
    }

    void print(std::ostream& os = std::cout) const {
        os << "[EmbeddingInfor] vocab=" << vocabSize()
           << " embedding[" << embedding->rows() << "," << embedding->cols() << "]"
           << " finalNorm[" << finalNorm.length() << "]"
           << " lmHead[" << lmHead.W->rows() << "," << lmHead.W->cols() << "]\n";
    }
};

// ============================================================================
// LayerInfor —— 单个 Transformer 层「推理所需的全部模型参数 + 前向计算过程」
// ----------------------------------------------------------------------------
// 一层 = 预归一化 → 多头注意力(QKVO) → 残差 → 预归一化 → 前馈(SwiGLU) → 残差。
// 本类把这一层用到的所有权重集中保存（与 GGUF 里 blk.L.* 张量一一对应），并提供
// forward() 完成该层计算（复用 trans 命名空间下的 MultiHeadAttention / FeedForward /
// RMSNorm / ops::rmsNorm），使「按层遍历推理」时每层自包含、便于检视与调试。
// ============================================================================
class LayerInfor {
public:
    size_t     layer_index = 0;   // 层号（0 起）

    // ---- 注意力子层 ----
    Vector attn_norm;         // blk.L.attn_norm.weight：注意力前 RMSNorm 的 gamma [d_model]，保持 F32
    std::shared_ptr<Tensor> Wq;   // blk.L.attn_q.weight     [d_model, d_model]（原生类型驻留）
    std::shared_ptr<Tensor> Wk;   // blk.L.attn_k.weight     [d_model, d_model]
    std::shared_ptr<Tensor> Wv;   // blk.L.attn_v.weight     [d_model, d_model]
    std::shared_ptr<Tensor> Wo;   // blk.L.attn_output.weight[d_model, d_model]

    // ---- 前馈子层（SwiGLU：down(silu(gate(x)) ⊙ up(x))）----
    Vector ffn_norm;          // blk.L.ffn_norm.weight：前馈前 RMSNorm 的 gamma [d_model]，保持 F32
    std::shared_ptr<Tensor> ffn_gate;   // blk.L.ffn_gate.weight   [d_ff, d_model]（SwiGLU gate，原生类型）
    std::shared_ptr<Tensor> ffn_up;     // blk.L.ffn_up.weight     [d_ff, d_model]（SwiGLU up）
    std::shared_ptr<Tensor> ffn_down;   // blk.L.ffn_down.weight   [d_model, d_ff]（降回 d_model）

    // ---- 结构标量（便于该层自洽地前向）----
    size_t d_model  = 0;          // 隐藏维
    size_t n_heads  = 0;          // 头数
    size_t head_dim = 0;          // 每头维（= d_model / n_heads）
    size_t d_ff     = 0;          // 前馈中间维
    float  eps      = 1e-5f;      // RMSNorm 稳定项

    // ---- 本层 KV 缓存（增量解码时复用历史 K/V；demo 当前整序列重算，仅作承载结构）----
    KVCache kv;                   // 单层版缓存：仅存本层 K/V，[cur_seq, d_model]，max_seq 来自上下文长度

    LayerInfor() = default;

    // 依据 headInfor 的信息 + 指定层号，直接从 GGUF 文件（FILE*）读取并初始化本层全部参数：
    //   注意力子层：attn_norm(向量) / Wq / Wk / Wv / Wo（矩阵）
    //   前馈子层  ：ffn_norm(向量) / ffn_gate / ffn_up / ffn_down（矩阵）
    //   结构标量  ：d_model/n_heads/d_ff/eps/head_dim 直接来自 headInfor（组 B 超参）。
    // 张量定位：absolute = headInfor.data_offset（数据段起点，已对齐） + 张量 offset，
    //   fseek 到该位置读出字节，再按类型（F32/F16/Q8_0）反量化到 f32（经 get() 透明完成）。
    // 矩阵重建沿用 {IN,OUT} 约定：dims[0]=IN(列), dims[1]=OUT(行)，M=Matrix(OUT,IN)。
    // 张量名形如 blk.<layerNumber>.attn_q.weight 等。成功返回 true；失败输出提示并返回 false。
    bool loadFromFile(FILE* guffFile, const size_t& layerNumber, const GUFFHeadInfor& headInfor) {
        if (!guffFile) return false;
        layer_index = layerNumber;

        d_model  = headInfor.embedding_length;
        n_heads  = headInfor.head_count;
        d_ff     = headInfor.feed_forward_length;
        eps      = headInfor.rms_eps;
        head_dim = n_heads ? d_model / n_heads : 0;

        // 构建本层 KV 缓存（单层版：仅本层 K/V，max_seq 由上下文长度决定，缺省 16）
        kv = KVCache(n_heads, head_dim, headInfor.context_length ? headInfor.context_length : 16);

        std::string p = "blk." + std::to_string(layerNumber) + ".";
        if (!loadTensorVector(guffFile, headInfor, p + "attn_norm.weight",    attn_norm)) return false;
        if (!loadTensorMatrix(guffFile, headInfor, p + "attn_q.weight",       Wq))        return false;
        if (!loadTensorMatrix(guffFile, headInfor, p + "attn_k.weight",       Wk))        return false;
        if (!loadTensorMatrix(guffFile, headInfor, p + "attn_v.weight",       Wv))        return false;
        if (!loadTensorMatrix(guffFile, headInfor, p + "attn_output.weight",  Wo))        return false;
        if (!loadTensorVector(guffFile, headInfor, p + "ffn_norm.weight",     ffn_norm))  return false;
        if (!loadTensorMatrix(guffFile, headInfor, p + "ffn_gate.weight",     ffn_gate))  return false;
        if (!loadTensorMatrix(guffFile, headInfor, p + "ffn_up.weight",       ffn_up))    return false;
        if (!loadTensorMatrix(guffFile, headInfor, p + "ffn_down.weight",     ffn_down))  return false;
        return true;
    }

    // 本层前向：pre-norm → MHA → 残差 → pre-norm → FFN → 残差
    //   X:[seq, d_model] → 返回 [seq, d_model]
    std::unique_ptr<Matrix> forward(const Matrix& X, float eps) const {
        std::unique_ptr<Matrix> h  = ops::rmsNorm(X, attn_norm, eps);
        ops::MultiHeadAttention attn(d_model, n_heads, head_dim);
        attn.Wq.W = Wq; attn.Wk.W = Wk; attn.Wv.W = Wv; attn.Wo.W = Wo;
        std::unique_ptr<Matrix> a  = attn.forward(*h);
        std::unique_ptr<Matrix> r1 = std::unique_ptr<Matrix>(static_cast<Matrix*>(X.add(*a).release()));
        std::unique_ptr<Matrix> h2 = ops::rmsNorm(*r1, ffn_norm, eps);
        ops::FeedForward ffn(d_model, d_ff);
        ffn.up.W = ffn_gate; ffn.up2.W = ffn_up; ffn.down.W = ffn_down;
        std::unique_ptr<Matrix> f  = ffn.forward(*h2);
        return std::unique_ptr<Matrix>(static_cast<Matrix*>(r1->add(*f).release()));
    }

    // 本层可训练参数总量（元素个数，便于检视规模）
    size_t paramCount() const {
        return attn_norm.length() + ffn_norm.length()
             + Wq->rows()*Wq->cols() + Wk->rows()*Wk->cols()
             + Wv->rows()*Wv->cols() + Wo->rows()*Wo->cols()
             + ffn_gate->rows()*ffn_gate->cols() + ffn_up->rows()*ffn_up->cols()
             + ffn_down->rows()*ffn_down->cols();
    }

    void print(std::ostream& os = std::cout) const {
        os << "  [LayerInfor #" << layer_index << "] d_model=" << d_model
           << " heads=" << n_heads << " head_dim=" << head_dim << " d_ff=" << d_ff
           << " kv(max=" << kv.max_seq << ")"
           << " params=" << paramCount() << "\n";
    }
};

class Transformer {
public:
    // ---- GGUF 头信息 / 嵌入词表与矩阵 / 逐层参数（均由 LoadFormFile 从文件填充）----
    GUFFHeadInfor        headInfor;   // 本模型文件的全部头信息（四组分类，含 token 词表 tokens 单一事实来源）
    EmbeddingInfor              embeddingInfor;     // 嵌入词表视图 + embedding 矩阵 + 分词器 + 模型级尾巴（KV 缓存在 LayerInfor.kv）
    std::list<LayerInfor> layers;     // 每层推理所需的全部参数 + 计算过程（按层顺序）

    Transformer() = default;   // 默认构造：成员为空维度，权重由 LoadFormFile 从 GGUF 文件填充

    // 以 C 语言风格 FILE* 从 GGUF 模型文件「直接」构建三个信息类：
    //   headInfor（四组头信息，含 token 词表 tokens，作为单一事实来源）、
    //   embeddingInfor（词表视图 + embedding + 末层归一化 + LM 头；vocabPtr 指向 headInfor.tokens）、
    //   layers（逐层 LayerInfor 全部权重 + 计算过程，含各层 Q/K/V 投影）。
    // 与旧 LoadGUFF（依赖 GUFF::GUFFFile 库）不同，本函数纯手写 FILE* 字节流读取，
    //   且不再构建独立的运行时 blocks / embedding / lmHead 成员——推理由各信息类直接驱动。
    // 流程：fopen → headInfor.loadFrom(FILE*) 读头信息（含 token 词表）→
    //       embeddingInfor.bindVocab(headInfor.tokens) 绑定词表视图 → embeddingInfor.buildTokenIndex() 建反向索引 →
    //       embeddingInfor.loadFromFile(FILE*, headInfor) 读 embedding/末层归一化/LM头 →
    //       按 block_count 多次 LayerInfor.loadFromFile(FILE*, l, headInfor) 逐层读权重并 push 进 layers。
    // 成功返回 true；失败打印提示并 fclose 后返回 false。
    bool LoadFormFile(const char* GUFFFileName) 
    {
        FILE* hfile = std::fopen(GUFFFileName, "rb");
        if (!hfile) { std::cout << "[LoadFormFile] 无法打开文件: " << GUFFFileName << "\n"; return false; }

        // 1) 直接以 FILE* 读取文件「全部头信息」（四组分类，含 token 词表 tokens）到 headInfor
        if (!headInfor.loadFrom(hfile)) {
            std::cout << "[LoadFormFile] 头信息解析失败: " << GUFFFileName << "\n";
            std::fclose(hfile); return false;
        }
        embeddingInfor.bindVocab(headInfor.tokens);   // vocab 视图指向 headInfor.tokens（零拷贝、单一来源）
        embeddingInfor.buildTokenIndex();             // vocab 更新后同步重建 token -> id 反向索引

        // 2) 由 headInfor 初始化 嵌入词表 + embedding 矩阵 + 末层归一化 + LM 头
        if (!embeddingInfor.loadFromFile(hfile, headInfor)) {
            std::cout << "[LoadFormFile] EmbeddingInfor 读取失败: " << GUFFFileName << "\n";
            std::fclose(hfile); return false;
        }

        // 3) 按模型层数，逐层创建 LayerInfor 并调用其 loadFromFile 完成初始化，存入 layers
        layers.clear();
        for (uint64_t i = 0; i < headInfor.block_count; ++i) {
            LayerInfor _layerInfor;
            if (!_layerInfor.loadFromFile(hfile, (size_t)i, headInfor)) {
                std::cout << "[LoadFormFile] 第 " << i << " 层读取失败: " << GUFFFileName << "\n";
                std::fclose(hfile); return false;
            }
            layers.push_back(std::move(_layerInfor));
        }

        std::fclose(hfile);
        return true;
    }

    // 前向：ids -> logits[seq, vocab]
    //   用 embeddingInfor.embedding 做嵌入、ops::RoPE 加位置、逐层 LayerInfor::forward、
    //   末层用 embeddingInfor.finalNorm 归一化、再用 embeddingInfor.lmHead 投影出 logits。
    std::unique_ptr<Matrix> forward(const std::vector<size_t>& ids, bool trace = false) const 
    {
        std::unique_ptr<Matrix> X = embeddingInfor.embedding->gather(ids, 0);   // [seq, d]  (tensor20.h 成员：沿 axis0 按 ids 取行)
        ops::RoPE rope(embeddingInfor.dModel());                  // 旋转位置编码（d = 隐藏维）
        rope.apply(*X);                               // 加位置信息
        if (trace) {
            std::cout << "  [forward] seq=" << X->rows()
                      << " d=" << X->cols() << " (嵌入+RoPE 完成)\n";
        }
        for (const LayerInfor& _layer : layers) 
        {
            X = _layer.forward(*X, headInfor.rms_eps);
            if (trace) {
                float n = 0.0f;
                for (size_t j = 0; j < embeddingInfor.dModel(); ++j) { float v = (*X)(0, j); n += v * v; }
                std::cout << "  [forward] 第 " << (_layer.layer_index + 1) << " 层后 |h0|=" << std::sqrt(n) << "\n";
            }
        }
        // 末层归一化（用 embeddingInfor.finalNorm，即 output_norm.weight）
        std::unique_ptr<Matrix> Xn = ops::rmsNorm(*X, embeddingInfor.finalNorm, headInfor.rms_eps);
        // logits = Xn · W_lmᵀ  ->  [seq, vocab]
        std::unique_ptr<Matrix> logits = embeddingInfor.lmHead.forwardBatch(*Xn);
        return logits;
    }

    // 自回归生成：从 prompt 出发，贪心取下一 token，直到生成 eos 或达 maxNew
    std::string generate(const std::string& prompt, size_t maxNew = 8, bool trace = false) const 
    {
        std::vector<size_t> ids = embeddingInfor.tokenizerEncode(prompt, headInfor);   // 真实 BPE 分词
        if (trace) std::cout << "[generate] prompt=\"" << prompt << "\" ids=" << ids.size() << "\n";
        
        ops::Sampler sampler;   // 贪心解码（本类不再持有 sampler 成员）
        for (size_t step = 0; step < maxNew; ++step) 
        {
            std::unique_ptr<Matrix> logits = forward(ids, trace);

            size_t last = logits->rows() - 1;
            size_t best = sampler.argmax(*logits, last);
            if (trace) std::cout << "  [generate] step " << step
                                 << " -> 预测 token '" << embeddingInfor.tokenizerDecode(best, headInfor) << "'\n";
            ids.push_back(best);
            if (best == headInfor.eos_token_id) break;   // 遇到 eos 结束
        }
        std::string out;
        for (size_t id : ids) out += embeddingInfor.tokenizerDecode(id, headInfor);
        return out;
    }
};

} // namespace trans
