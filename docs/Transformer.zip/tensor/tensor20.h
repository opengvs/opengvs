#pragma once
// ============================================================================
// Tensor20.h —— Tensor 类层次 2.0（与 ggml 同构的存储模型）
// 相对 1.x 的头文件 tensor.h，本版本把张量存储改造成【与 ggml_tensor 同构】：
//   * data_  : void*  （原 compute_type* / float*），即原始字节缓冲，与 ggml 的 data 一致
//   * nb_    : 各维【字节】步长（原 stride_ 为元素步长），与 ggml 的 nb[] 完全一致
//   * type_  : ggml_type 存储数据类型标签（F32/F16/BF16/F64/I8..I64 标量，及 Q4_0/Q8_0… 量化），驱动“type 感知访问”
//   * 访问   : 统一经 readElem(offset)/writeElem(offset) 按 type_ 解释字节；
//             F32 走快路径；operator()/at 返回 ElemRef 代理，对所有标量类型均可用
//             （F32 零开销直连真实 float&，其余经代理读写）。
// 计算宿主类型 compute_type 仍为 float/F32：operator()/at 经 ElemRef 代理，F32 直连真实 float&
// 其余标量类型自动转换读写；量化类型(Q*) 经 QuantTraits 表的 dequant/quant 块解包/打包透明参与访问。
// 后续把 data_ 真正对接 ggml_tensor 的量化布局后即可无缝用于权重 / KV 缓存等量化存储。
//
// 类型适应能力范围（当前实现）：
//   * F32          : 全功能。operator()/at 返回直连真实 float& 的 ElemRef 代理；get/set/fill 正常；分配/步长正常。
//   * 标量非 F32    : F16/BF16/I8/I16/I32/I64/F64 —— 全功能。ElemRef 代理让 operator()/at 可读写
//                    （elemBytes 取正确字节数，readElem/writeElem 有对应分支自动转 float，
//                     get/set/fill/value/setValue 均不抛异常）；compute_type=float，F64 经 float 宿主有精度损失。
//   * 量化类型      : 已适配 Q4_0 / Q4_1 / Q8_0 / Q8_1 / Q1_0 / Q2_0 共 6 种（见 QuantTraits 表，blck_size/blck_bytes 已登记）。
//                     存储按“块”布局（每块 blck_size 个元素、占 blck_bytes 字节）；get/set/fill 经
//                     dequant/quant 透明读写单个 float，调用方无感；ElemRef 代理亦可用（走 get/set）。
//                     其余量化（Q2_K~Q8_K、IQ*、MXFP4、NVFP4、TQ* 等）暂未适配：构造即抛
//                     “traitsOf: 未适配的 ggml_type”，需后续补表项 + codec 才能用。
//                     参与 matmul 等计算推荐在融合内核里内联 dequant（不整张 unpack），结果一般不回量化
//                     （KV 缓存例外），见开发过程笔记第 12 节。
// ============================================================================
#include <vector>
#include <stdexcept>
#include <memory>
#include <string>
#include <initializer_list>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <sstream>
#include <array>
#include <cmath>
#include <algorithm>
#include <limits>

namespace wb {

    // ----------------------------------------------------------------------------
    // ggml_type：张量元素的存储数据类型（与 llama.cpp/ggml 保持一致）
    // 如项目已 #include "ggml.h"，可删除本枚举并写 `using ::ggml_type;`
    // ----------------------------------------------------------------------------
    enum ggml_type {
        GGML_TYPE_F32 = 0,
        GGML_TYPE_F16 = 1,
        GGML_TYPE_Q4_0 = 2,
        GGML_TYPE_Q4_1 = 3,
        // GGML_TYPE_Q4_2 = 4, support has been removed
        // GGML_TYPE_Q4_3 = 5, support has been removed
        GGML_TYPE_Q5_0 = 6,
        GGML_TYPE_Q5_1 = 7,
        GGML_TYPE_Q8_0 = 8,
        GGML_TYPE_Q8_1 = 9,
        GGML_TYPE_Q2_K = 10,
        GGML_TYPE_Q3_K = 11,
        GGML_TYPE_Q4_K = 12,
        GGML_TYPE_Q5_K = 13,
        GGML_TYPE_Q6_K = 14,
        GGML_TYPE_Q8_K = 15,
        GGML_TYPE_IQ2_XXS = 16,
        GGML_TYPE_IQ2_XS = 17,
        GGML_TYPE_IQ3_XXS = 18,
        GGML_TYPE_IQ1_S = 19,
        GGML_TYPE_IQ4_NL = 20,
        GGML_TYPE_IQ3_S = 21,
        GGML_TYPE_IQ2_S = 22,
        GGML_TYPE_IQ4_XS = 23,
        GGML_TYPE_I8 = 24,
        GGML_TYPE_I16 = 25,
        GGML_TYPE_I32 = 26,
        GGML_TYPE_I64 = 27,
        GGML_TYPE_F64 = 28,
        GGML_TYPE_IQ1_M = 29,
        GGML_TYPE_BF16 = 30,
        // GGML_TYPE_Q4_0_4_4 = 31, support has been removed from gguf files
        // GGML_TYPE_Q4_0_4_8 = 32,
        // GGML_TYPE_Q4_0_8_8 = 33,
        GGML_TYPE_TQ1_0 = 34,
        GGML_TYPE_TQ2_0 = 35,
        // GGML_TYPE_IQ4_NL_4_4 = 36,
        // GGML_TYPE_IQ4_NL_4_8 = 37,
        // GGML_TYPE_IQ4_NL_8_8 = 38,
        GGML_TYPE_MXFP4 = 39, // MXFP4 (1 block)
        GGML_TYPE_NVFP4 = 40, // NVFP4 (4 blocks, E4M3 scale)
        GGML_TYPE_Q1_0 = 41,
        GGML_TYPE_Q2_0 = 42,
        GGML_TYPE_COUNT = 43,
    };

    // 枚举名 -> 字符串（C++ 枚举无内建名字反射）
    inline const char* ggml_type_name(ggml_type t) {
        switch (t) {
        case GGML_TYPE_F32:     return "F32";
        case GGML_TYPE_F16:     return "F16";
        case GGML_TYPE_Q4_0:    return "Q4_0";
        case GGML_TYPE_Q4_1:    return "Q4_1";
        case GGML_TYPE_Q5_0:    return "Q5_0";
        case GGML_TYPE_Q5_1:    return "Q5_1";
        case GGML_TYPE_Q8_0:    return "Q8_0";
        case GGML_TYPE_Q8_1:    return "Q8_1";
        case GGML_TYPE_Q2_K:    return "Q2_K";
        case GGML_TYPE_Q3_K:    return "Q3_K";
        case GGML_TYPE_Q4_K:    return "Q4_K";
        case GGML_TYPE_Q5_K:    return "Q5_K";
        case GGML_TYPE_Q6_K:    return "Q6_K";
        case GGML_TYPE_Q8_K:    return "Q8_K";
        case GGML_TYPE_IQ2_XXS: return "IQ2_XXS";
        case GGML_TYPE_IQ2_XS:  return "IQ2_XS";
        case GGML_TYPE_IQ3_XXS: return "IQ3_XXS";
        case GGML_TYPE_IQ1_S:   return "IQ1_S";
        case GGML_TYPE_IQ4_NL:  return "IQ4_NL";
        case GGML_TYPE_IQ3_S:   return "IQ3_S";
        case GGML_TYPE_IQ2_S:   return "IQ2_S";
        case GGML_TYPE_IQ4_XS:  return "IQ4_XS";
        case GGML_TYPE_I8:      return "I8";
        case GGML_TYPE_I16:     return "I16";
        case GGML_TYPE_I32:     return "I32";
        case GGML_TYPE_I64:     return "I64";
        case GGML_TYPE_F64:     return "F64";
        case GGML_TYPE_IQ1_M:   return "IQ1_M";
        case GGML_TYPE_BF16:    return "BF16";
        case GGML_TYPE_TQ1_0:   return "TQ1_0";
        case GGML_TYPE_TQ2_0:   return "TQ2_0";
        case GGML_TYPE_MXFP4:   return "MXFP4";
        case GGML_TYPE_NVFP4:   return "NVFP4";
        case GGML_TYPE_Q1_0:    return "Q1_0";
        case GGML_TYPE_Q2_0:    return "Q2_0";
        case GGML_TYPE_COUNT:   return "COUNT";
        default:                return "UNKNOWN";
        }
    }

    // 单元素字节数（仅标量类型准确；量化类型按块存储，无逐元素字节数）
    inline size_t ggml_type_size(ggml_type t) {
        switch (t) {
        case GGML_TYPE_F32: return 4;
        case GGML_TYPE_F16: return 2;
        case GGML_TYPE_BF16: return 2;
        case GGML_TYPE_F64: return 8;
        case GGML_TYPE_I8:  return 1;
        case GGML_TYPE_I16: return 2;
        case GGML_TYPE_I32: return 4;
        case GGML_TYPE_I64: return 8;
        default:            return 0; // 量化 / MXFP4 / NVFP4 等：块结构，需查 ggml.c
        }
    }

    // ----------------------------------------------------------------------------
    // 半精度浮点互转（F16 / BF16）——最小实现，覆盖常规范围，够示例/对接用。
    // 真正生产可用请替换为 ggml 的 ggml_fp16_to_fp32 / ggml_fp32_to_fp16。
    // ----------------------------------------------------------------------------
    inline uint16_t float_to_fp16(float f) {
        uint32_t x; std::memcpy(&x, &f, 4);
        uint32_t sign = (x >> 16) & 0x8000u;
        int32_t  exp  = static_cast<int32_t>((x >> 23) & 0xFFu) - 127 + 15;
        uint32_t mant = x & 0x7FFFFFu;
        if (exp <= 0)  return static_cast<uint16_t>(sign);          // 下溢 -> 0
        if (exp >= 31) return static_cast<uint16_t>(sign | 0x7C00u); // 上溢 -> 无穷
        uint32_t mant16 = (mant + 0x1000u) >> 13;                   // 四舍五入
        if (mant16 & 0x400u) { mant16 = 0; ++exp; }
        if (exp >= 31) return static_cast<uint16_t>(sign | 0x7C00u);
        return static_cast<uint16_t>(sign | (static_cast<uint32_t>(exp) << 10) | (mant16 & 0x3FFu));
    }
    inline float fp16_to_float(uint16_t h) {
        uint32_t sign = (h >> 15) & 0x1u;
        uint32_t exp  = (h >> 10) & 0x1Fu;
        uint32_t mant = h & 0x3FFu;
        uint32_t f;
        if (exp == 0)       f = (sign << 31) | (mant << 13);
        else if (exp == 31) f = (sign << 31) | 0x7F800000u | (mant << 13);
        else                f = (sign << 31) | ((exp - 15 + 127) << 23) | (mant << 13);
        float r; std::memcpy(&r, &f, 4); return r;
    }
    inline uint16_t float_to_bf16(float f) {
        uint32_t x; std::memcpy(&x, &f, 4);
        return static_cast<uint16_t>((x >> 16) & 0xFFFFu); // BF16 = float 高 16 位
    }
    inline float bf16_to_float(uint16_t b) {
        uint32_t x = static_cast<uint32_t>(b) << 16;
        float r; std::memcpy(&r, &x, 4); return r;
    }

    // ----------------------------------------------------------------------------
    // Axis：张量命名轴（代替裸数字下标，使转置 / 轴重排更直观）
    //   枚举值即轴序号：axisX=0, axisY=1, axisZ=2, axisW=3
    //   在生成 PermuteView 视图时优先用命名轴，可读性更好：
    //     矩阵转置        = permute({axisY, axisX})
    //     三阶轴轮转      = permute({axisZ, axisX, axisY})
    //     四阶后两块提前  = permute({axisZ, axisY, axisX, axisW})
    //   注意：更高维可继续扩展（如 axisV=4 ...），上限受 GGML_MAX_DIMS=4 约束。
    // ----------------------------------------------------------------------------
    enum Axis : size_t {
        axisX = 0,
        axisY = 1,
        axisZ = 2,
        axisW = 3,
    };

    // ----------------------------------------------------------------------------

    // 元素引用代理（reference proxy）：让 operator()/at 对所有标量类型都具备读写语义。
    // 完整定义见 class Tensor 之后（需要 Tensor 为完整类型才能调用其 get/set/raw/offset/type）。
    class ElemRef;

    // 前向声明：gather() 返回物化的 Matrix（见各子类定义）。
    class Matrix;

    // ============================================================================
    // 量化特征表 QuantTraits —— 按 ggml_type 静态索引，承载“块结构”知识
    // 设计要点（最小侵入）：
    //   * Tensor 类本身“格式无关”：只认 type_ + 查表，不写死任何量化分支。
    //   * 每种 ggml_type 一条记录：blck_size(每块元素数) / blck_bytes(每块字节数)
    //     + dequant(块 -> blck_size 个 float) / quant(blck_size 个 float -> 块)。
    //   * 标量类型 blck_size==1、dequant/quant 为 nullptr，走 readElem/writeElem 快路径；
    //     量化类型走块解包/打包。新增类型只改本表，不动 Tensor。
    //   * 关键：makeNb 让每条轴步长都是 blck_bytes 的整数倍，故 offset(idx)/blck_bytes
    //     永远是合法“缓冲内线性元素序号”，量化路径与视图(PermuteView/TransposeView)共用一套逻辑。
    static constexpr size_t QK_MAX = 128;   // 最大块元素数（Q1_0 = 128），作栈缓冲上限

    struct QuantTraits {
        ggml_type type;
        size_t    blck_size;   // 每块元素数（标量 = 1）
        size_t    blck_bytes;  // 每块字节数
        void (*dequant)(const void* block, float* out); // out 长度 = blck_size
        void (*quant)(const float* in, void* block);    // in 长度 = blck_size
        // 融合点积内核（仅量化类型注册，标量类型为 nullptr）：把【整行(长度 n)】量化字节缓冲
        //   按块解包、在寄存器/栈内现场 dequant 后，逐块累加 dot(块, x)，返回 Σ_j q_j·x_j。
        //   关键：全程只在寄存器/栈内 dequant，绝不物化整张 F32 权重矩阵（呼应第 12 节融合内核）；
        //   签名 (rowBlock, xF32, n) -> float，n 必为 blck_size 整数倍。matvec 量化路径直接调它。
        float (*vec_dot)(const void* q, const float* x, size_t n);
    };

    // —— 6 种量化类型的块解包/打包（与 ggml 的 dequantize_row_qX_0 同公式）——
    inline void dequant_q4_0(const void* b, float* out) {
        const uint8_t* p = (const uint8_t*)b;
        const float d = fp16_to_float(*(const uint16_t*)p);
        const uint8_t* qs = p + 2;
        for (int j = 0; j < 16; ++j) {
            out[j]      = ((qs[j] & 0x0F) - 8) * d;
            out[j + 16] = ((qs[j] >>   4) - 8) * d;
        }
    }
    inline void quant_q4_0(const float* in, void* b) {
        uint8_t* p = (uint8_t*)b;
        float mx = 0; for (int j = 0; j < 32; ++j) mx = std::max(mx, std::fabs(in[j]));
        const float d = mx > 0 ? mx / 7.0f : 0.0f;   // 有符号 nibble 范围 [-8,7]
        *(uint16_t*)p = float_to_fp16(d);
        uint8_t* qs = p + 2;
        for (int j = 0; j < 16; ++j) {
            int x0 = (int)std::lround(in[j]      / d) + 8;
            int x1 = (int)std::lround(in[j + 16] / d) + 8;
            x0 = std::max(0, std::min(15, x0));
            x1 = std::max(0, std::min(15, x1));
            qs[j] = (uint8_t)(x0 | (x1 << 4));
        }
    }
    inline void dequant_q4_1(const void* b, float* out) {
        const uint8_t* p = (const uint8_t*)b;
        const float d = fp16_to_float(*(const uint16_t*)p);
        const float m = fp16_to_float(*(const uint16_t*)(p + 2));
        const uint8_t* qs = p + 4;
        for (int j = 0; j < 16; ++j) {
            out[j]      = (qs[j] & 0x0F) * d + m;
            out[j + 16] = (qs[j] >>   4) * d + m;
        }
    }
    inline void quant_q4_1(const float* in, void* b) {
        uint8_t* p = (uint8_t*)b;
        float mn = in[0], mx = in[0];
        for (int j = 0; j < 32; ++j) { mn = std::min(mn, in[j]); mx = std::max(mx, in[j]); }
        const float d = (mx > mn) ? (mx - mn) / 15.0f : 0.0f;
        const float m = mn;
        *(uint16_t*)p = float_to_fp16(d);
        *(uint16_t*)(p + 2) = float_to_fp16(m);
        uint8_t* qs = p + 4;
        for (int j = 0; j < 16; ++j) {
            int x0 = (int)std::lround((in[j]      - m) / d);
            int x1 = (int)std::lround((in[j + 16] - m) / d);
            x0 = std::max(0, std::min(15, x0));
            x1 = std::max(0, std::min(15, x1));
            qs[j] = (uint8_t)(x0 | (x1 << 4));
        }
    }
    inline void dequant_q8_0(const void* b, float* out) {
        const uint8_t* p = (const uint8_t*)b;
        const float d = fp16_to_float(*(const uint16_t*)p);
        const int8_t* qs = (const int8_t*)(p + 2);
        for (int j = 0; j < 32; ++j) out[j] = qs[j] * d;
    }
    inline void quant_q8_0(const float* in, void* b) {
        uint8_t* p = (uint8_t*)b;
        float mx = 0; for (int j = 0; j < 32; ++j) mx = std::max(mx, std::fabs(in[j]));
        const float d = mx > 0 ? mx / 127.0f : 0.0f;
        *(uint16_t*)p = float_to_fp16(d);
        int8_t* qs = (int8_t*)(p + 2);
        for (int j = 0; j < 32; ++j) {
            int q = (int)std::lround(in[j] / d);
            q = std::max(-128, std::min(127, q));
            qs[j] = (int8_t)q;
        }
    }
    inline void dequant_q8_1(const void* b, float* out) {
        const uint8_t* p = (const uint8_t*)b;
        const float d = fp16_to_float(*(const uint16_t*)p);
        const float m = fp16_to_float(*(const uint16_t*)(p + 2));
        const uint8_t* qs = (const uint8_t*)(p + 4);   // Q8_1 为 0..255 无符号
        for (int j = 0; j < 32; ++j) out[j] = qs[j] * d + m;
    }
    inline void quant_q8_1(const float* in, void* b) {
        uint8_t* p = (uint8_t*)b;
        float mn = in[0], mx = in[0];
        for (int j = 0; j < 32; ++j) { mn = std::min(mn, in[j]); mx = std::max(mx, in[j]); }
        const float d = (mx > mn) ? (mx - mn) / 255.0f : 0.0f;
        const float m = mn;
        *(uint16_t*)p = float_to_fp16(d);
        *(uint16_t*)(p + 2) = float_to_fp16(m);
        uint8_t* qs = (uint8_t*)(p + 4);
        for (int j = 0; j < 32; ++j) {
            int q = (int)std::lround((in[j] - m) / d);
            q = std::max(0, std::min(255, q));
            qs[j] = (uint8_t)q;
        }
    }
    inline void dequant_q1_0(const void* b, float* out) {
        const uint8_t* p = (const uint8_t*)b;
        const float d = fp16_to_float(*(const uint16_t*)p);
        const uint8_t* qs = p + 2;   // 128 元素 / 8 = 16 字节
        for (int j = 0; j < 128; ++j) {
            int byte = j / 8, bit = j % 8;
            uint8_t v = (qs[byte] >> bit) & 1;
            out[j] = v ? d : -d;
        }
    }
    inline void quant_q1_0(const float* in, void* b) {
        uint8_t* p = (uint8_t*)b;
        float mx = 0; for (int j = 0; j < 128; ++j) mx = std::max(mx, std::fabs(in[j]));
        const float d = mx;   // 两电平 ±d
        *(uint16_t*)p = float_to_fp16(d);
        uint8_t* qs = p + 2;
        for (int j = 0; j < 16; ++j) qs[j] = 0;
        for (int j = 0; j < 128; ++j) {   // 1 bit/元素：>=0 -> +d(bit1)，<0 -> -d(bit0)
            int byte = j / 8, bit = j % 8;
            if (in[j] >= 0) qs[byte] |= (uint8_t)(1u << bit);
        }
    }
    inline void dequant_q2_0(const void* b, float* out) {
        const uint8_t* p = (const uint8_t*)b;
        const float d = fp16_to_float(*(const uint16_t*)p);
        const uint8_t* qs = p + 2;   // 64 元素 / 4 = 16 字节
        for (int j = 0; j < 64; ++j) {
            int byte = j / 4, off = (j % 4) * 2;
            uint8_t q = (qs[byte] >> off) & 0x03;
            out[j] = (int(q) - 1.5f) * d;   // 00=-1.5d 01=-0.5d 10=+0.5d 11=+1.5d（中心对称，峰值 +1.5d 精确）
        }
    }
    inline void quant_q2_0(const float* in, void* b) {
        uint8_t* p = (uint8_t*)b;
        float mx = 0; for (int j = 0; j < 64; ++j) mx = std::max(mx, std::fabs(in[j]));
        const float d = mx > 0 ? mx / 1.5f : 0.0f;   // 峰值对应 +1.5d
        *(uint16_t*)p = float_to_fp16(d);
        uint8_t* qs = p + 2;
        for (int j = 0; j < 16; ++j) qs[j] = 0;
        for (int j = 0; j < 64; ++j) {
            int q = (int)std::lround(in[j] / d + 1.5f);
            q = std::max(0, std::min(3, q));
            int byte = j / 4, off = (j % 4) * 2;
            qs[byte] |= (uint8_t)(q << off);
        }
    }

    // —— 量化融合点积内核（matvec 量化路径直接调用 traitsOf(type_).vec_dot）——
    // 前向声明：vec_dot_quant 体内调 traitsOf，而 traitsOf 的表又引用下方 vec_dot_qX，
    // 故先前向声明 traitsOf，再定义 vec_dot 块，最后定义 traitsOf（其表即可引用已定义的 vec_dot_qX）。
    inline const QuantTraits& traitsOf(ggml_type t);

    // 通用实现：把整行(长度 n)量化字节缓冲按块解包到【栈缓冲】(大小 = blck_size，常量、不随 N 增长)，
    // 逐块累加 dot(块, x)。全程只在寄存器/栈内 dequant，绝不物化整张 F32 权重矩阵
    // （否则省内存意义尽失，呼应第 12 节融合内核）。n 须为 blck_size 整数倍（matvec 已保证）。
    inline float vec_dot_quant(const void* q, const float* x, size_t n,
                               ggml_type t, void (*deq)(const void*, float*)) {
        const auto& qt = traitsOf(t);
        const size_t bs     = qt.blck_size;
        const size_t bbytes = qt.blck_bytes;
        const size_t nblk   = n / bs;
        float sum = 0.0f;
        float buf[QK_MAX];                 // 仅块级临时，常量大小（最大 Q1_0 = 128）
        const uint8_t* p = static_cast<const uint8_t*>(q);
        for (size_t b = 0; b < nblk; ++b) {
            deq(p, buf);                   // 解包第 b 块到栈上（已 dequant 为 blck_size 个 float）
            const float* xx = x + b * bs;
            for (size_t j = 0; j < bs; ++j) sum += buf[j] * xx[j];
            p += bbytes;                   // 推进到下一物理块
        }
        return sum;
    }
    inline float vec_dot_q4_0(const void* q, const float* x, size_t n) { return vec_dot_quant(q, x, n, GGML_TYPE_Q4_0, dequant_q4_0); }
    inline float vec_dot_q4_1(const void* q, const float* x, size_t n) { return vec_dot_quant(q, x, n, GGML_TYPE_Q4_1, dequant_q4_1); }
    inline float vec_dot_q8_0(const void* q, const float* x, size_t n) { return vec_dot_quant(q, x, n, GGML_TYPE_Q8_0, dequant_q8_0); }
    inline float vec_dot_q8_1(const void* q, const float* x, size_t n) { return vec_dot_quant(q, x, n, GGML_TYPE_Q8_1, dequant_q8_1); }
    inline float vec_dot_q1_0(const void* q, const float* x, size_t n) { return vec_dot_quant(q, x, n, GGML_TYPE_Q1_0, dequant_q1_0); }
    inline float vec_dot_q2_0(const void* q, const float* x, size_t n) { return vec_dot_quant(q, x, n, GGML_TYPE_Q2_0, dequant_q2_0); }

    inline const QuantTraits& traitsOf(ggml_type t) {
        static const QuantTraits table[] = {
            { GGML_TYPE_F32,  1,  4, nullptr,      nullptr,      nullptr },
            { GGML_TYPE_F16,  1,  2, nullptr,      nullptr,      nullptr },
            { GGML_TYPE_BF16,  1,  2, nullptr,      nullptr,      nullptr },
            { GGML_TYPE_I8,   1,  1, nullptr,      nullptr,      nullptr },
            { GGML_TYPE_I16,  1,  2, nullptr,      nullptr,      nullptr },
            { GGML_TYPE_I32,  1,  4, nullptr,      nullptr,      nullptr },
            { GGML_TYPE_I64,  1,  8, nullptr,      nullptr,      nullptr },
            { GGML_TYPE_F64,  1,  8, nullptr,      nullptr,      nullptr },
            { GGML_TYPE_Q4_0, 32, 18, dequant_q4_0, quant_q4_0, vec_dot_q4_0 },
            { GGML_TYPE_Q4_1, 32, 20, dequant_q4_1, quant_q4_1, vec_dot_q4_1 },
            { GGML_TYPE_Q8_0, 32, 34, dequant_q8_0, quant_q8_0, vec_dot_q8_0 },
            { GGML_TYPE_Q8_1, 32, 36, dequant_q8_1, quant_q8_1, vec_dot_q8_1 },
            { GGML_TYPE_Q1_0,128, 18, dequant_q1_0, quant_q1_0, vec_dot_q1_0 },
            { GGML_TYPE_Q2_0, 64, 18, dequant_q2_0, quant_q2_0, vec_dot_q2_0 },
            // Q2_K~Q8_K / IQ 等超级块/特殊类型暂未适配
        };
        for (const auto& q : table) if (q.type == t) return q;
        throw std::runtime_error(std::string("traitsOf: 未适配的 ggml_type ") + ggml_type_name(t));
    }

    class Tensor {
    public:
        friend class ElemRef;   // 引用代理需调用受保护的 offset()
        // 宿主标量类型（CPU 计算/接口用的 float）；存储格式由 type_ 决定，data_ 为 void* 字节缓冲，二者解耦
        using compute_type = float;
        using shape_type = std::vector<size_t>;   // 各维尺寸，如 [m, n]
        using index_type = std::vector<size_t>;   // 多索引，如 {r, c}

        // ---- Rule of Five：持有裸指针必须自己管理资源 ----
        explicit Tensor(ggml_type t = GGML_TYPE_F32) : type_(t) {}
        virtual ~Tensor() { if (owns_data_) freeBuffer(data_); }

        // 深拷贝（字节级 memcpy，含 type_ / shape_ / nb_ / 数据）
        Tensor(const Tensor& other)
            : type_(other.type_), shape_(other.shape_), nb_(other.nb_), count_(other.count_) {
            const size_t nbytes = bufferBytes(count_, type_);
            data_ = allocBuffer(nbytes);
            owns_data_ = true;
            std::memcpy(data_, other.data_, nbytes);
        }
        Tensor& operator=(const Tensor& other) {
            if (this != &other) {
                if (owns_data_) freeBuffer(data_);
                type_ = other.type_;
                shape_ = other.shape_;
                nb_ = other.nb_;
                count_ = other.count_;
                const size_t nbytes = bufferBytes(count_, type_);
                data_ = allocBuffer(nbytes);
                owns_data_ = true;        // 深拷贝得到独立缓冲，归本对象所有
                std::memcpy(data_, other.data_, nbytes);
            }
            return *this;
        }
        // 移动（搬运指针，零拷贝）
        Tensor(Tensor&& other) noexcept
            : data_(other.data_), type_(other.type_),
            shape_(other.shape_), nb_(other.nb_), count_(other.count_),
            owns_data_(other.owns_data_) {
            other.data_ = nullptr;
            other.count_ = 0;
            other.owns_data_ = false;
            other.shape_.clear();
            other.nb_.clear();
        }
        Tensor& operator=(Tensor&& other) noexcept {
            if (this != &other) {
                if (owns_data_) freeBuffer(data_);
                data_ = other.data_;
                type_ = other.type_;
                shape_ = other.shape_;
                nb_ = other.nb_;
                count_ = other.count_;
                owns_data_ = other.owns_data_;
                other.data_ = nullptr;
                other.count_ = 0;
                other.owns_data_ = false;
                other.shape_.clear();
                other.nb_.clear();
            }
            return *this;
        }

        // ---- 子类必须实现的接口 ----
        virtual size_t rank() const = 0;            // 阶 / 秩
        virtual const shape_type& dims() const = 0; // 各维尺寸
        // 各维【字节】步长（与 ggml 的 nb[] 完全一致，单位=字节）。
        // 同时提供 strides() 别名以保持兼容；nb() 为 ggml 风格命名。
        const shape_type& strides() const { return nb_; }
        const shape_type& nb() const { return nb_; }
        virtual const char* typeName() const = 0;   // 运行时类型名

        // ---- 基类统一提供的接口 ----
        ggml_type type() const { return type_; }     // 存储数据类型标签

        size_t size() const {                        // 元素总数
            size_t n = 1;
            for (size_t d : dims()) n *= d;
            return n;
        }

        // 通用访问：通过索引向量，运行时做维度/越界检查；按 type_ 解释字节（type 感知）。
        // 【设计红线】非虚实函数，仅基类存在，且函数体内不得出现任何虚调用（含索引映射钩子）：
        //   get/set 是整个推理最热的元素访问路径，一旦内部夹带虚分发，既无法内联，也无法被
        //   AVX2/AVX-512/GPU 等加速后端整体特化编译，性能上等价甚至劣于把 get/set 直接做成虚函数。
        //   因此定位固定走「checkIndex -> offset(idx) 纯算术 -> readElem/writeElem」一条直线路径。
        // 索引重排（转置/permute）由视图类在构造时重排 nb_ 字节步长表达，不需要运行期钩子；
        // 无法用等距步长表达的重排（如 gather 按 ids 取行）一律在构造时物化为独立缓冲（见 gather()），
        // 绝不以“在 get/set 里插一次虚映射”的方式实现。
        compute_type get(const index_type& idx) const {
            checkIndex(idx);
            return readElem(offset(idx));
        }
        void set(const index_type& idx, compute_type v) {
            checkIndex(idx);
            writeElem(offset(idx), v);
        }

        // 按个数传下标的便捷重载（非虚 inline，全部委托给 get/set(index_type)）。
        // 按 rank() 自动截取有效下标个数，统一走 checkIndex + offset + readElem/writeElem 一条路径。
        // 子类不再需要各写一份 get(r,c)/set(i,v)/check1/check2…——全部自动继承。
        compute_type get(size_t a, size_t b = 0, size_t c = 0, size_t d = 0) const {
            index_type idx;
            idx.reserve(rank());
            idx.push_back(a);
            if (rank() >= 2) idx.push_back(b);
            if (rank() >= 3) idx.push_back(c);
            if (rank() >= 4) idx.push_back(d);
            return get(idx);
        }
        void set(size_t a, compute_type v)                                         { set(index_type{ a }, v); }
        void set(size_t a, size_t b, compute_type v)                               { set(index_type{ a, b }, v); }
        void set(size_t a, size_t b, size_t c, compute_type v)                     { set(index_type{ a, b, c }, v); }
        void set(size_t a, size_t b, size_t c, size_t d, compute_type v)           { set(index_type{ a, b, c, d }, v); }

        // 深拷贝（子类返回具体类型，外部统一收为 unique_ptr<Tensor>）
        virtual std::unique_ptr<Tensor> clone() const = 0;

        // 任意轴 permute 视图：返回共享本对象 data_ 的 PermuteView（零拷贝）。
        // perm[k] 表示“新轴 k 取源的第 perm[k] 轴”；矩阵转置 = permute({1,0})，
        // 三阶轴轮转 = permute({2,0,1})。视图不拥有内存，源须比视图活得久。
        virtual std::unique_ptr<Tensor> permute(const index_type& perm);

        // 命名轴重载（可读性更好，推荐）：t.permute({axisY, axisX}) 等价于 permute({1,0})。
        // 例：矩阵转置 = permute({axisY, axisX})；
        //     三阶轴轮转 = permute({axisZ, axisX, axisY})；
        //     四阶重排 = permute({axisW, axisZ, axisY, axisX})。
        // 内部仅把命名轴转成下标向量，再转发到上面的虚函数，保证多态语义一致。
        std::unique_ptr<Tensor> permute(std::initializer_list<Axis> perm) {
            return permute(index_type(perm.begin(), perm.end()));
        }

        // gather：按 ids 沿 axis 维取片，返回【物化的普通 Matrix】（与 ggml_get_rows 同为算子而非 view）。
        // 主要用于 Embedding 查表：embed[vocab, dim] + token_ids[seq] -> 输出 [seq, dim]，
        // 输出第 i 行 = embed[ids[i]]。
        // 实现语义：构造时【一次性物化】为独立缓冲，返回的对象就是一个普通的、可写的 Matrix，
        //   不再有 GatherView 之类子类——gather 的“索引重排”只发生在算子内部这一次，结果对下游而言
        //   与任何手建的稠密张量无异（可自由读写、可继续参与矩阵乘/注意力）。理由：ids 任意、行
        //   间不等距，无法用 nb_ 步长表达；若做成零拷贝视图就必须在 get/set 里插运行期索引映射钩子，
        //   违反访问层零虚调用的设计红线；且物化后内存连续，后续 AVX2/GPU 内核可直接顺序访存，整体更快。
        // 输出沿用源 type_（量化表仍按块拷贝）；若下游统一吃 F32，可在调用处反量化。
        std::unique_ptr<Matrix> gather(const std::vector<size_t>& ids, int axis = 0) const;

        // 全视图（identity 排列）：返回共享本对象 data_ 的 PermuteView，供多维访问替代
        // 已移除的链式 operator[]。用法：auto v = t.view(); v->get({i,j,...}) / v->operator()(i,j,...)。
        std::unique_ptr<Tensor> view() {
            index_type perm(rank());
            for (size_t k = 0; k < rank(); ++k) perm[k] = k;
            return permute(perm);
        }

        // 统一的元素访问虚入口：固定 4 个下标，基类全带默认值 0（保证经 Tensor* 多态调用时
        // 用户不必填写多余下标）。各派生类「本阶实际用到的下标」为真实索引（不带默认，直接调具体
        // 对象时必须提供），超出本阶的下标默认 =0 并被忽略。因签名（类型）在派生类间一致，可经 Tensor* 多态分发。
        // operator()/at 返回 ElemRef 引用代理：F32 直连真实 float&（零开销）；
        // 其他标量类型(F16/BF16/I8/I16/I32/I64/F64)经代理“读时取 float、赋值时写回”，亦全功能。
        // 量化类型(Q*) 经 QuantTraits 的 dequant/quant 透明参与（已适配 Q4_0/Q4_1/Q8_0/Q8_1/Q1_0/Q2_0），其余见头部说明。
        virtual ElemRef operator()(size_t a = 0, size_t b = 0,
            size_t c = 0, size_t d = 0) = 0;
        virtual ElemRef operator()(size_t a = 0, size_t b = 0,
            size_t c = 0, size_t d = 0) const = 0;

        void fill(compute_type v) {
            const auto& q = traitsOf(type_);
            if (q.blck_size > 1) {   // 量化：逐块填同一个 float（dequant/quant 透明）
                const size_t nblocks = (count_ + q.blck_size - 1) / q.blck_size;
                float buf[QK_MAX];
                for (size_t j = 0; j < q.blck_size; ++j) buf[j] = static_cast<float>(v);
                for (size_t b = 0; b < nblocks; ++b)
                    q.quant(buf, reinterpret_cast<char*>(data_) + b * q.blck_bytes);
                return;
            }
            const size_t eb = q.blck_bytes;
            for (size_t i = 0; i < count_; ++i) writeElem(i * eb, v);
        }

        // =====================================================================
        // A.1 一元逐元素运算（直接命名成员函数，inline）
        // 设计取舍：不在类里放 enum + applyUnary 包装，而是把每个运算做成直接命名、
        // 可读性高的成员函数。每个运算都提供两种形式：
        //   * 返回新张量（const）：返回 std::unique_ptr<Tensor>，形状同 this，类型一律 F32。
        //   * 改写自身（InPlace，非 const）：把结果写回 this。
        // 两者都经下方 protected 的 unaryMap / unaryMapInPlace 内核逐元素迭代（访问走
        // 基类非虚 get/set，定位为 offset(idx) 纯算术），因此 TransposeView/PermuteView
        // 靠 nb_ 字节步长表达的索引重排自动正确，无需特判；
        // F32 走 readElem/writeElem 快路径，标量非 F32 与量化类型经 ElemRef+QuantTraits 透明读写。
        // 结果一律 F32（符合第 13 节设计约束：除 quantizeTo/kvCacheUpdate 显式回量化外，
        // 中间运算结果不回量化）。
        // =====================================================================

        // exp：逐元素自然指数 y = e^x。
        //   —— 用途：softmax 分母稳定化、注意力分数指数、各类指数/概率变换。
        std::unique_ptr<Tensor> exp()    const { return unaryMap([](float x){ return std::exp(x); }); }
        void                     expInPlace()    { unaryMapInPlace([](float x){ return std::exp(x); }); }

        // rsqrt：逐元素平方根倒数 y = 1/√x（即 x^{-1/2}）。
        //   比“先 sqrt 再取倒数”数值更稳、在多数硬件上更快（ggml 也提供 rsqrt 原语）。
        //   —— 用途：RMSNorm 的归一化因子 1/√(mean(x²)+eps) 即此运算；亦用于方差缩放。要求 x>0。
        std::unique_ptr<Tensor> rsqrt()  const { return unaryMap([](float x){ return 1.0f / std::sqrt(x); }); }
        void                     rsqrtInPlace()  { unaryMapInPlace([](float x){ return 1.0f / std::sqrt(x); }); }

        // sigmoid：逐元素逻辑斯蒂 y = 1/(1+e^{-x})，把任意实数压到 (0,1)。
        //   —— 用途：门控、概率输出。注意 SwiGLU 用的是 silu 而非 sigmoid；如需 sigmoid 门控可据此组合。
        std::unique_ptr<Tensor> sigmoid()const { return unaryMap([](float x){ return 1.0f / (1.0f + std::exp(-x)); }); }
        void                     sigmoidInPlace(){ unaryMapInPlace([](float x){ return 1.0f / (1.0f + std::exp(-x)); }); }

        // silu：逐元素 SiLU（Sigmoid Linear Unit）y = x·sigmoid(x) = x/(1+e^{-x})。
        //   —— 用途：LLaMA 系列 FFN 的 gate 分支核心激活；SwiGLU = silu(a) ⊙ b，其中 gate 分支即此。
        std::unique_ptr<Tensor> silu()   const { return unaryMap([](float x){ return x / (1.0f + std::exp(-x)); }); }
        void                     siluInPlace()   { unaryMapInPlace([](float x){ return x / (1.0f + std::exp(-x)); }); }

        // tanh：逐元素双曲正切 y = tanh(x)，把实数压到 (-1,1)。
        //   —— 用途：LSTM / 部分旧式注意力与门控、某些归一化前变换。注意 LLaMA 注意力分数缩放一般不用 tanh。
        std::unique_ptr<Tensor> tanh()   const { return unaryMap([](float x){ return std::tanh(x); }); }
        void                     tanhInPlace()   { unaryMapInPlace([](float x){ return std::tanh(x); }); }

        // relu：逐元素线性整流（ReLU）y = max(0, x)。
        //   —— 用途：最常用激活之一，Vision / 部分 Transformer MLP 使用。LLaMA FFN 默认 silu，
        //      但作为通用原语保留，以备其他结构或实验。
        std::unique_ptr<Tensor> relu()   const { return unaryMap([](float x){ return x > 0.0f ? x : 0.0f; }); }
        void                     reluInPlace()   { unaryMapInPlace([](float x){ return x > 0.0f ? x : 0.0f; }); }

        // abs：逐元素绝对值 y = |x|。
        //   —— 用途：误差/距离度量、正则项、注意力权重的非负处理等基础计算。
        std::unique_ptr<Tensor> abs()    const { return unaryMap([](float x){ return std::fabs(x); }); }
        void                     absInPlace()    { unaryMapInPlace([](float x){ return std::fabs(x); }); }

        // negate：逐元素取负 y = -x（等价于乘 -1）。
        //   —— 用途：符号反转、梯度翻转、RoPE 中 cos/sin 负频分量的构造（由计算层组合）。
        std::unique_ptr<Tensor> negate() const { return unaryMap([](float x){ return -x; }); }
        void                     negateInPlace() { unaryMapInPlace([](float x){ return -x; }); }

        // log：逐元素自然对数 y = ln(x)。要求 x>0；x<=0 按 IEEE 浮点产生 NaN/±∞（不抛异常）。
        //   —— 用途：交叉熵/对数似然、log_softmax、log-sum-exp 稳定化。
        std::unique_ptr<Tensor> log()    const { return unaryMap([](float x){ return std::log(x); }); }
        void                     logInPlace()    { unaryMapInPlace([](float x){ return std::log(x); }); }

        // reciprocal：逐元素倒数 y = 1/x。x=0 时为 ±∞（IEEE，不抛异常）；注意与 rsqrt(1/√x) 区分。
        //   —— 用途：归一化中的“除以和/方差”、与 scale 配合做除法等价。
        std::unique_ptr<Tensor> reciprocal() const { return unaryMap([](float x){ return 1.0f / x; }); }
        void                     reciprocalInPlace() { unaryMapInPlace([](float x){ return 1.0f / x; }); }

        // clamp：逐元素限幅 y = max(lo, min(hi, x))，把值夹到区间 [lo, hi]。
        //   lo/hi 为 float 参数（非张量），与 add/sub 等二元张量运算区分。
        //   —— 用途：logits 裁剪、输出范围限制、数值稳定（防溢出）、注意力/概率截断。
        std::unique_ptr<Tensor> clamp(float lo, float hi) const {
            return unaryMap([lo, hi](float x){ return std::max(lo, std::min(hi, x)); });
        }
        void                     clampInPlace(float lo, float hi) {
            unaryMapInPlace([lo, hi](float x){ return std::max(lo, std::min(hi, x)); });
        }

        // =====================================================================
        // A.2 二元逐元素运算（含 NumPy 式广播）
        // 设计取舍：与 A.1 同向——直接命名的成员函数。每个运算提供两种形式：
        //   * 张量形式（const）：z_i = op(a_i, b_i)，b 可经广播对齐；返回新建 F32 张量（形状=广播后形状）。
        //   * 标量重载（const）：z_i = a_i op s（s 为常数），走 unaryMap 单操作数路径，更快。
        // 通用内核是 applyBinary(b, op) 与 binaryMap 模板（定义见文件末尾）。
        // 广播规则（形状右对齐比较）：某维为 1 或“缺失”（阶数较低一方视为前导 1）时，可拉伸到对方该维；
        //   两维不等且均 >1 则不可广播，抛 std::invalid_argument。结果形状 = 广播后形状。
        // 结果类型一律 F32：任一操作数为 Q 类型时，get 经 QuantTraits 自动 dequant 到 float 后再算
        //   （中间激活不回量化，呼应第 12/13 节）；若两操作数都 F32，则纯 F32 路径。
        // 用途：RoPE 的旋转乘加、SwiGLU 门控乘（silu(a) ⊙ b）、偏置加（x + bias）等底层都由它构成。
        // 注：返回类型用 std::unique_ptr<Tensor>（与 A.1 一致；Tensor 为抽象基类，不能按值返回“一个张量”）。
        // =====================================================================
        enum class BinaryOp { Add, Sub, Mul, Div, Pow, Max, Min };

        // applyBinary：二元逐元素的统一入口。op 指定算子（Add/Sub/Mul/Div/Pow/Max/Min），
        //   b 为另一操作数（张量；标量、向量可广播到本张量形状）。返回新建 F32 张量，形状为广播后形状。
        std::unique_ptr<Tensor> applyBinary(const Tensor& b, BinaryOp op) const;

        // —— 张量形式：逐元素 z_i = op(a_i, b_i)，b 经 NumPy 式广播对齐到本张量 ——
        //   返回新建 F32 张量（形状 = 广播后形状）。七个函数对应 BinaryOp 的七个枚举值。
        std::unique_ptr<Tensor> add(const Tensor& b) const;  // z = a + b  —— 偏置加、残差加、位置偏置
        std::unique_ptr<Tensor> sub(const Tensor& b) const;  // z = a - b  —— 残差减、门控差
        std::unique_ptr<Tensor> mul(const Tensor& b) const;  // z = a * b  —— SwiGLU 门控乘、逐元素缩放
        std::unique_ptr<Tensor> div(const Tensor& b) const;  // z = a / b  —— 归一化除法、1/x 配合
        std::unique_ptr<Tensor> pow(const Tensor& b) const;  // z = a ^ b  —— 逐元素幂（含 1/3 等分数幂）
        std::unique_ptr<Tensor> max(const Tensor& b) const;  // z = max(a, b)  —— 逐元素上限、clip 下限
        std::unique_ptr<Tensor> min(const Tensor& b) const;  // z = min(a, b)  —— 逐元素下限、clip 上限

        // —— 标量重载：z_i = a_i op s（s 为常数）。等价于把 s 当作 0 阶张量广播，
        //   但走 unaryMap 单操作数路径，避免额外的广播索引计算。返回新建 F32 张量，形状同本张量。 ——
        std::unique_ptr<Tensor> add(float s) const;  // z = a + s
        std::unique_ptr<Tensor> sub(float s) const;  // z = a - s
        std::unique_ptr<Tensor> mul(float s) const;  // z = a * s
        std::unique_ptr<Tensor> div(float s) const;  // z = a / s
        std::unique_ptr<Tensor> pow(float s) const;  // z = a ^ s
        std::unique_ptr<Tensor> max(float s) const;  // z = max(a, s)
        std::unique_ptr<Tensor> min(float s) const;  // z = min(a, s)

        // =====================================================================
        // A.3 标量辅助（全元素标量运算 & 偏置加）
        // 设计取舍：继续沿用 A.1/A.2 的约定——in-place 形式改写自身、const 形式返回
        //   std::unique_ptr<Tensor>（Tensor 为抽象基类，不能按值返回；与 A.1/A.2 完全一致）。
        //   * scale / addScalar：全元素乘 / 加一个标量。其中 scaled/addScalar 的“新建 / 改写”
        //     语义与 A.2 的 mul(s)/add(s) 完全相同，这里补全【in-place】版本（scale/addScalar），
        //     方便就地缩放 / 平移激活而无需额外分配；scaled 则提供“缩放副本”命名（等价于 mul(s)）。
        //   * addBias / withBias：b 形状 [out_dim]，沿【最后维】广播加到本张量——
        //     即本张量第 i 元素（多索引 idx）加上 b[idx.back()]。这是注意力输出投影
        //     (out_proj: y = x·W + bias)、FFN 的偏置加等最常用的“通道维偏置”。
        //   结果类型：in-place 改写自身（量化类型经 set 写回块，有损，符合预期，与 A.1 unaryMapInPlace 一致）；
        //     const 的 withBias 返回新建 F32 张量（中间激活不回量化，呼应第 12/13 节）。
        // =====================================================================

        // scale：全元素乘标量 s（in-place）。y_i = x_i * s。
        //   —— 用途：温度 / 学习率缩放、激活幅度调整、与 reciprocal 配合做除法等价。
        void scale(float s);

        // scaled：全元素乘标量 s，返回新建张量（const）。y_i = x_i * s（形状同 this，类型 F32）。
        //   —— 与 A.2 mul(s) 等价（此处保留独立命名，便于“缩放副本”语义表达）。
        std::unique_ptr<Tensor> scaled(float s) const;

        // addScalar：全元素加标量 s（in-place）。y_i = x_i + s。
        //   —— 用途：全局平移 / 偏置、归一化后的位移、数值稳定偏移。
        void addScalar(float s);

        // addBias：把 b（形状 [out_dim]）沿【最后维】广播加到自身（in-place）。
        //   y[idx] = x[idx] + b[idx.back()]。要求 b 为 1 维且长度 == 本张量最后维尺寸，
        //   否则抛 std::invalid_argument。
        //   —— 用途：注意力输出投影 y = x·W + bias、FFN 偏置加等通道维偏置。
        void addBias(const Tensor& b);

        // withBias：把 b（形状 [out_dim]）沿【最后维】广播加，返回新建 F32 张量（const）。
        //   y[idx] = x[idx] + b[idx.back()]，形状同本张量，类型 F32。b 的约束同 addBias。
        std::unique_ptr<Tensor> withBias(const Tensor& b) const;

        // =====================================================================
        // B 类 · 归约（reduction）
        // 设计取舍：与 A 系列一致——沿维版返回 std::unique_ptr<Tensor>（Tensor 为抽象基类，
        //   不能按值返回）；reduceAll 返回 compute_type 标量（直接按值）。
        //   * reduceAll：整张量 → 一个标量（Sum/Mean/Max/Min/Prod/L2）。
        //   * sum/mean/max/norm/var/argmax(int dim)：沿 dim 归约，该维尺寸【塌缩为 1】
        //     （可随后 squeeze）。argmax 返回【整数索引】——值以 float 承载整型位置下标，
        //     并非归约值本身。norm 为 L2 范数 √(Σx²)；var 为总体方差 (1/N)Σ(x-μ)²。
        //   * softmax(int dim)：沿 dim 做【数值稳定】归一化，同形、不塌缩。公式
        //     y_i = exp(x_i - max_x) / Σ_j exp(x_j - max_x)；先减该维最大值再 exp 防上溢。
        //   类型适配：输入为 Q/标量类型时先经 get 自动 dequant 到 float 再归约，结果一律 F32；
        //     dim 越界（<0 或 >= rank）抛 std::invalid_argument。
        //   实现要点：归约遍历经基类 get(index)（offset 纯算术、非虚），对视图/别名也天然正确
        //     （视图重排只影响索引映射，不进 get 热路径），无需特判。
        // =====================================================================
        enum class ReductionOp { Sum, Mean, Max, Min, Prod, L2 };

        // reduceAll：整张量归约为一个 compute_type 标量。
        //   Sum=Σx, Mean=平均值, Max/Min=最值, Prod=连乘, L2=√(Σx²)（向量模长）。
        compute_type reduceAll(ReductionOp op) const;

        // 沿 dim 归约，该维塌缩为 1（输出形状同输入但 dims()[dim]=1）。结果一律 F32。
        std::unique_ptr<Tensor> sum(int dim)  const;  // Σx             —— 注意力分数求和、embedding 池化
        std::unique_ptr<Tensor> mean(int dim) const;  // 均值           —— 序列均值池化、归一化
        std::unique_ptr<Tensor> max(int dim)  const;  // 最值           —— 池化、门控取大
        std::unique_ptr<Tensor> norm(int dim) const;  // L2 范数 √(Σx²) —— 向量归一化、注意力缩放
        std::unique_ptr<Tensor> var(int dim)  const;  // 总体方差       —— LayerNorm 方差（1/N Σ(x-μ)²）

        // argmax：沿 dim 取最大值索引，该维塌缩为 1。返回【整数索引】（值以 float 承载位置下标，
        //   非归约值）。平局取首个出现的下标。结果 F32（整型内容）。用途：分类预测、top-1 取词。
        std::unique_ptr<Tensor> argmax(int dim) const;

        // softmax：沿 dim 做数值稳定归一化（同形、不塌缩）。通用算子：注意力分数、输出 logits 概率化。
        std::unique_ptr<Tensor> softmax(int dim) const;

        // =====================================================================
        // C 类 · 矩阵乘（推理计算核心）
        // =====================================================================
        // C.1 matvec —— 向量 × 矩阵（推理最高频算子）
        //   y = W·x，其中 this 视为 [M, N]（或视图等效），x 为 [N] 向量，返回 [M]。
        //   * F32 路径：逐行 y_i = Σ_j W_ij·x_j，直接用 float* 行指针 + x 浮点指针累加（连续行快路径）。
        //   * 量化融合路径（关键）：若 this->type_ 是 Q 类型（Q4_0/Q4_1/Q8_0/Q8_1/Q1_0/Q2_0），
        //       每行块直接调 traitsOf(type_).vec_dot(rowBlock, xF32, n)——在寄存器级现场 dequant 累加，
        //       不物化整张 F32 权重矩阵（否则省内存意义尽失，呼应第 12 节融合内核）。
        //   * 结果回 F32：激活/中间结果不回量化（KV 缓存除外）。
        //   * 用途：QKV 投影、输出投影、FFN 的三个 matvec 全部走它。
        //   形状校验：this 须为 2 阶 [M,N]；x 须为 1 阶且长度 == N；量化权重要求 N 为 blck_size 整数倍；
        //     违反任一条抛 std::invalid_argument。行连续（nb_[0]==行字节数）走快路径，否则退化为逐元素 get（视图安全）。
        //   返回 std::unique_ptr<Tensor>（Tensor 为抽象基类，不能按值返回；与 A/B 系列约定统一）。
        std::unique_ptr<Tensor> matvec(const Tensor& x) const;

        // C.2 matmul —— 矩阵 × 矩阵（推理 GEMM；多为 GEMV 退化，但 FFN / 部分层 / bmm 退化都会用到）
        //   C = A·B，其中 this 视为 A:[M,K]，B 为 [K,N]，返回 C:[M,N]（F32）。
        //   * F32 直算：A、B 均为稠密 F32 且行连续（nb_[0]==行字节数）时，直接三循环、float* 行指针累加
        //       （i 外层、k 中层、j 内层——B 列内连续、C 行内连续，cache 友好）。
        //   * 量化融合路径（关键）：若 A->type_ 是 Q 类型（Q4_0/Q4_1/Q8_0/Q8_1/Q1_0/Q2_0），把 matmul 拆成
        //       N 次 GEMV——逐“输出列 j”取 B 的第 j 列（F32，可量化 B 经 get 自动 dequant）作为 x，
        //       对 A 的每一行块直接调 traitsOf(type_).vec_dot(rowBlock, xF32, K) 现场 dequant 累加，
        //       不物化整张 F32 权重矩阵（呼应第 12 节，与 matvec 同内核）。
        //   * 通用兜底：标量非 F32 / 非连续视图 / B 量化等，退化为逐元素 get 三循环（视图安全，结果 F32）。
        //   * 结果一律 F32：激活/中间结果不回量化（KV 缓存例外）。
        //   形状校验：A、B 均须 2 阶；A 列(K) == B 行(K)；量化 A 要求 K 为 blck_size 整数倍；违反抛 std::invalid_argument。
        //   返回 std::unique_ptr<Tensor>（Tensor 为抽象基类，不能按值返回；与 A/B/C.1 约定统一）。
        std::unique_ptr<Tensor> matmul(const Tensor& B) const;

        // =====================================================================
        // D 类 · 三/四阶 + 量化桥（推理计算核心扩展）
        // =====================================================================
        // D.1 bmm —— 批矩阵乘（多头注意力核心）
        //   C = A·B，其中 this 视为 A:[B,M,K]，B 为 [B,K,N]，返回 C:[B,M,N]（F32）。
        //   * 实现：对批维度（轴 0）每个切片独立做 matmul；量化 A 权重同样走 vec_dot 融合
        //     （逐批拆成 N 次 GEMV，A 每行块调 vec_dot 现场 dequant 累加），不物化整张 F32
        //     权重矩阵（呼应第 12 节融合内核）。
        //   * 结果一律 F32（中间结果不回量化）。
        //   形状校验：A、B 均须 3 阶；A 轴0(B) == B 轴0(B)；A 轴2(K) == B 轴1(K)；
        //     量化 A 要求 K 为 blck_size 整数倍；违反抛 std::invalid_argument。
        //   返回 std::unique_ptr<Tensor>（Tensor 为抽象基类，不能按值返回；与 A/B/C 系列统一）。
        std::unique_ptr<Tensor> bmm(const Tensor& B) const;

        // D.2 gather —— 索引取片（Embedding 查表原语）
        //   沿 axis 按 indices 取值。weight[vocab, dim] + indices[seq] -> [seq, dim]；
        //     indices 可为多阶（如 [batch, seq]）-> 输出 [batch, seq, dim]。
        //   语义（与 tf.gather 一致）：输出形状 = this.shape[0..axis-1] ++ indices.shape ++ this.shape[axis+1..]；
        //     输出 (o_prefix, i_idx, o_suffix) = this (o_prefix, g, o_suffix)，其中 g = indices[i_idx]（整数下标）。
        //   实现：一次性物化为独立缓冲（与 ggml_get_rows 同为算子而非 view；非等距重排故物化，
        //     不进 get/set 热路径，呼应访问层零虚面红线）。输出沿用源 type_（量化表仍按块拷贝）；
        //     indices 越界抛 std::out_of_range。与既有 gather(const std::vector<size_t>&, int) 构成重载
        //     （后者专供二阶 Embedding 权重表，返回可写 Matrix）。
        std::unique_ptr<Tensor> gather(const Tensor& indices, int axis = 0) const;

        // D.3 dequantize —— 量化桥：Q → 新 F32 张量（整张解量化）
        //   逐元素经基类非虚 get（Q 类型自动 dequant 到 float）拷入新建 F32 稠密张量；
        //   对视图/别名也正确（get 走 offset 纯算术）。F32/标量源等价返回 F32 副本。
        //   用途：调试或少数需 F32 精度的路径；普通推理不必调（matvec 已融合，省内存）。
        std::unique_ptr<Tensor> dequantize() const;

        // D.4 quantizeTo —— 量化桥：F32/任意 → 目标 Q 类型（逐块量化）
        //   新建目标类型 t 的稠密张量（形状同 this），逐块（每 blck_size 个元素、按元素序）调
        //     QuantTraits::quant 写入；对视图/别名输入也正确（get 把任意源布局归一到元素序）。
        //   t 须为已适配的量化类型，否则 traitsOf 抛“未适配的 ggml_type”；元素数须为 t.blck_size
        //     整数倍，否则抛 std::invalid_argument。
        //   用途：KV cache 写入、权重加载后格式转换（与 D.3 共成“量化桥”）。
        std::unique_ptr<Tensor> quantizeTo(ggml_type t) const;

        // 原始数据访问（与 ggml 同构：void* 字节缓冲 + nb[] 字节步长）
        const void* raw() const { return data_; }
        void*       raw()       { return data_; }
        const void* data() const { return data_; }
        void*       data()       { return data_; }
        size_t      capacity() const { return count_; } // 已分配元素个数

        // 2 维张量的便捷访问（原生驻留权重常按 [OUT,IN] 2 阶存储）：
        //   rows() = dims()[0]，cols() = dims()[1]。Matrix 自带同名方法（隐藏本基类版，语义一致）。
        size_t rows() const { const shape_type& d = dims(); return d.size() < 1 ? 0 : d[0]; }
        size_t cols() const { const shape_type& d = dims(); return d.size() < 2 ? 0 : d[1]; }

        // 描述信息，便于调试打印
        virtual std::string describe() const {
            std::ostringstream os;
            os << typeName()
                << " [type=" << ggml_type_name(type_)
                << ", rank=" << rank() << ", dims=";
            for (size_t i = 0; i < dims().size(); ++i) {
                if (i) os << "x";
                os << dims()[i];
            }
            os << ", size=" << size() << "]";
            return os.str();
        }

    protected:
        void*       data_ = nullptr;  // 原始字节缓冲（与 ggml_tensor.data 同构），裸指针
        // type_ 是【成员默认初始化器】，不是写死的字面量：所有构造函数都把 ggml_type t 一路透传
        // （基类 197 行 Tensor(ggml_type t = GGML_TYPE_F32)、各子类 : Tensor(t)、makeDense 883 行也接受 ggml_type t）。
        // 因此构建时可指定任意 ggml_type（如 GGML_TYPE_Q8_0），不传参则默认 F32。
        ggml_type   type_ = GGML_TYPE_F32; // 存储数据类型标签（驱动 type 感知访问）
        shape_type  shape_;           // 各维尺寸；标量可保持为空
        shape_type  nb_;              // 各维【字节】步长（与 ggml 的 nb[] 字节步长完全一致）；
        // 视图可重排。offset(idx) = Σ idx[k] * nb_[k]，得到字节偏移。
        size_t      count_ = 0;       // 已分配元素个数（便于 fill / 调试）
        bool        owns_data_ = true;// 视图/别名对象置 false：析构时不释放共享缓冲

        // 行主序元素步长：shape {d0,d1,d2} -> {d1*d2, d2, 1}
        static shape_type makeStrides(const shape_type& sh) {
            shape_type s(sh.size(), 1);
            size_t st = 1;
            for (size_t k = sh.size(); k-- > 0; ) { s[k] = st; st *= sh[k]; }
            return s;
        }

        // 字节步长（与 ggml nb[] 同构）：元素步长 * 每“虚拟元素”字节数（量化下 eb = blck_bytes）。
        // 这使 offset(idx) 恒为 blck_bytes 的整数倍，readElem/writeElem 可据此定位“块号 + 块内序号”。
        static shape_type makeNb(const shape_type& sh, ggml_type t) {
            const size_t eb = elemBytes(t);
            shape_type s = makeStrides(sh);
            for (size_t& e : s) e *= eb;
            return s;
        }

        // 每元素字节数（与 ggml 的“块结构”对齐）：
        //   * 标量类型：blck_bytes == 单元素字节数（F32=4,F16=2,…），即逐元素字节数。
        //   * 量化类型：blck_bytes == 一块字节数（Q8_0=34,…）；偏移/步长以“块字节”为单位，
        //     故 offset(idx)/blck_bytes 恒为合法线性元素序号，readElem/writeElem 据此按块解包。
        // 统一由 QuantTraits 表驱动，不再对量化类型抛异常。
        static size_t elemBytes(ggml_type t) {
            return traitsOf(t).blck_bytes;
        }

        // 给定元素数 -> 实际分配的字节数（量化按“块”向上取整，避免行主序 n*blck_bytes 的过量分配）
        static size_t bufferBytes(size_t nElems, ggml_type t) {
            const auto& q = traitsOf(t);
            if (q.blck_size > 1) {
                const size_t nblocks = (nElems + q.blck_size - 1) / q.blck_size;
                return nblocks * q.blck_bytes;
            }
            return nElems * q.blck_bytes;
        }

        // ---- A.1 一元逐元素运算内核（私有成员模板）----
        // unaryMap        : const，对全部元素依次 f 后写入“新建的 F32 张量”（形状同 this），返回 unique_ptr<Tensor>。
        // unaryMapInPlace : 非 const，原地把 f 作用到自身每个元素（量化类型经 set 写回块，有损，符合预期）。
        // 把函数体放在文件末尾（advanceIndex/makeDense 完整声明之后），以满足模板两阶段查找。
        template <typename F>
        std::unique_ptr<Tensor> unaryMap(F f) const;
        template <typename F>
        void unaryMapInPlace(F f);

        // ---- A.2 二元逐元素运算内核（私有成员模板）----
        // binaryMap：const，对“this(a) 与 b”先做 NumPy 式广播，再逐元素 f(a_i, b_i)，
        //   结果写入“新建的 F32 张量”（形状 = 广播后形状），返回 unique_ptr<Tensor>。
        // 访问走基类非虚 get/set（offset 纯算术）；广播只影响“索引映射”这一步，不进 get/set 热路径。
        // 把函数体放在文件末尾（advanceIndex/makeDense 完整声明之后），以满足模板两阶段查找。
        template <typename F>
        std::unique_ptr<Tensor> binaryMap(const Tensor& b, F f) const;

        // ---- B 类归约内核（私有成员模板）----
        // reduceDimTo：沿 dim 归约（该维塌缩为 1）。对每个输出位置遍历 dim 切片：
        //   用 init 初始化累加器 acc，对每个元素 v 做 acc = comb(acc, v)，最后 out = fin(acc)。
        //   访问走基类非虚 get/set（offset 纯算术），视图重排自动正确。sum/mean/max/norm/var 均复用它；
        //   argmax/softmax 因语义特殊（索引 / 需两趟 max+sum）单独实现。
        //   把函数体放在文件末尾（advanceIndex/makeDense 完整声明之后），以满足模板两阶段查找。
        template <typename Acc, typename Comb, typename Final>
        std::unique_ptr<Tensor> reduceDimTo(int dim, Acc init, Comb comb, Final fin) const;

        // 按给定 shape 分配并清零（同步计算 nb_ 字节步长）
        void allocate(const shape_type& sh) {
            shape_ = sh;
            nb_ = makeNb(sh, type_);
            size_t n = 1;
            for (size_t d : sh) n *= d;
            data_ = allocBuffer(bufferBytes(n, type_));
            count_ = n;
        }

        // 索引 -> 字节偏移：sum_k idx[k]*nb_[k]。offset 为非虚实函数，仅基类存在；
        // 视图/别名类在构造函数里重排 nb_（字节步长表）即可实现零拷贝重排，
        // 继承的 get/set/offset 自动映射到正确位置，无需任何虚重写。
        size_t offset(const index_type& idx) const {
            size_t off = 0;
            for (size_t k = 0; k < nb_.size(); ++k)
                off += (k < idx.size() ? idx[k] : 0) * nb_[k];
            return off;
        }
        // 注：曾试验过 virtual index_type mapIndex() 索引映射钩子（供 gather 类视图重写），已移除。
        // 原因：它必然被 get/set/offset 这条最热路径调用，等于把虚分发和一次 vector 构造
        // 塞进每次元素访问，与「访问层零虚调用、可整体编译进加速库」的设计红线冲突。
        // 结论：等距重排 -> 改 nb_；非等距重排（gather）-> 构造时物化。访问层不留任何运行期钩子。

        // type 感知读写：按 type_ 解释 (char*)data_ + 字节偏移 处的字节
        compute_type readElem(size_t byteOff) const {
            const auto& q = traitsOf(type_);
            if (q.blck_size > 1) {   // 量化类型：虚拟偏移必为 blck_bytes 整数倍 -> 块号 + 块内序号
                const size_t e = byteOff / q.blck_bytes;   // 线性元素序号
                const size_t b = e / q.blck_size;          // 块号
                const size_t j = e % q.blck_size;          // 块内序号
                float buf[QK_MAX];
                q.dequant(reinterpret_cast<const char*>(data_) + b * q.blck_bytes, buf);
                return static_cast<compute_type>(buf[j]);
            }
            const char* p = reinterpret_cast<const char*>(data_) + byteOff;
            switch (type_) {
            case GGML_TYPE_F32: return static_cast<compute_type>(*reinterpret_cast<const float*>(p));
            case GGML_TYPE_F64: return static_cast<compute_type>(*reinterpret_cast<const double*>(p));
            case GGML_TYPE_I8:  return static_cast<compute_type>(*reinterpret_cast<const int8_t*>(p));
            case GGML_TYPE_I16: return static_cast<compute_type>(*reinterpret_cast<const int16_t*>(p));
            case GGML_TYPE_I32: return static_cast<compute_type>(*reinterpret_cast<const int32_t*>(p));
            case GGML_TYPE_I64: return static_cast<compute_type>(*reinterpret_cast<const int64_t*>(p));
            case GGML_TYPE_F16: return static_cast<compute_type>(fp16_to_float(*reinterpret_cast<const uint16_t*>(p)));
            case GGML_TYPE_BF16: return static_cast<compute_type>(bf16_to_float(*reinterpret_cast<const uint16_t*>(p)));
            default:
                throw std::runtime_error(std::string("readElem: 未适配类型 ")
                    + ggml_type_name(type_));
            }
        }
        void writeElem(size_t byteOff, compute_type v) {
            const auto& q = traitsOf(type_);
            if (q.blck_size > 1) {   // 量化类型：解包整块 -> 改单元素 -> 重打包（调用方无感）
                const size_t e = byteOff / q.blck_bytes;
                const size_t b = e / q.blck_size;
                const size_t j = e % q.blck_size;
                float buf[QK_MAX];
                q.dequant(reinterpret_cast<const char*>(data_) + b * q.blck_bytes, buf);
                buf[j] = static_cast<float>(v);
                q.quant(buf, reinterpret_cast<char*>(data_) + b * q.blck_bytes);
                return;
            }
            char* p = reinterpret_cast<char*>(data_) + byteOff;
            switch (type_) {
            case GGML_TYPE_F32: *reinterpret_cast<float*>(p)   = static_cast<float>(v); break;
            case GGML_TYPE_F64: *reinterpret_cast<double*>(p)  = static_cast<double>(v); break;
            case GGML_TYPE_I8:  *reinterpret_cast<int8_t*>(p)   = static_cast<int8_t>(v); break;
            case GGML_TYPE_I16: *reinterpret_cast<int16_t*>(p)  = static_cast<int16_t>(v); break;
            case GGML_TYPE_I32: *reinterpret_cast<int32_t*>(p)  = static_cast<int32_t>(v); break;
            case GGML_TYPE_I64: *reinterpret_cast<int64_t*>(p)  = static_cast<int64_t>(v); break;
            case GGML_TYPE_F16: *reinterpret_cast<uint16_t*>(p) = float_to_fp16(static_cast<float>(v)); break;
            case GGML_TYPE_BF16: *reinterpret_cast<uint16_t*>(p) = float_to_bf16(static_cast<float>(v)); break;
            default:
                throw std::runtime_error(std::string("writeElem: 未适配类型 ")
                    + ggml_type_name(type_));
            }
        }

        // 元素引用代理入口（代替原 refAt）：F32 返回可直连真实 float* 的代理；
        // 其他标量类型 / 已适配量化类型返回“读时取 float、赋值时写回”的代理（量化经 QuantTraits 透明转换）。
        // 函数体在 class Tensor 之后、ElemRef 定义完整处给出（inline）。
        ElemRef refElem(const index_type& idx);
        ElemRef refElem(const index_type& idx) const;

        void checkIndex(const index_type& idx) const {
            if (idx.size() != shape_.size())
                throw std::invalid_argument(std::string(typeName()) + ": 索引维数与阶不符");
            for (size_t i = 0; i < idx.size(); ++i)
                if (idx[i] >= shape_[i])
                    throw std::out_of_range(std::string(typeName()) + ": 索引越界");
        }

        // ---- 内存池接入点：将来只改这两个静态函数 ----
        static void* allocBuffer(size_t nBytes) {
            // 内存池版本示例：
            //   return static_cast<void*>(MemPool::instance().allocate(nBytes));
            // operator new 返回 max_align_t 对齐内存，可安全 reinterpret 为 float*/uint16_t* 等。
            return new char[nBytes]();   // 值初始化为 0
        }
        static void freeBuffer(void* p) {
            // 内存池版本示例：
            //   if (p) MemPool::instance().deallocate(p); return;
            delete[] reinterpret_cast<char*>(p);
        }
    };

    // ----------------------------------------------------------------------------
    // 元素引用代理 ElemRef
    // 让 operator()/at 对所有标量类型都具备“读写”语义：
    //   * F32   : 内部持有真实 float*，读/写均零开销，行为与旧 operator()& 一致；
    //   * 其他标量类型(F16/BF16/I8/I16/I32/I64/F64)：读时从 type 感知缓冲取 float，
    //     赋值时经 Tensor::set 写回（float -> 真实存储类型）。
    //   * 来自 const 张量时 owner_==nullptr，仅可读，写入会抛清晰错误。
    class ElemRef {
        ElemRef(const ElemRef&) = default;       // 显式默认拷贝，避免 -Wdeprecated-copy
        Tensor*             owner_ = nullptr;   // 可写时非 null；来自 const 张量时为 null
        const Tensor*       cowner_ = nullptr;  // 用于读取
        Tensor::index_type  idx_;
        float*              fptr_ = nullptr;    // F32 快路径：直接指向真实 float
        float               cache_ = 0.0f;     // 非 F32 读缓存

        void bindF32() {
            char* base = const_cast<char*>(static_cast<const char*>(cowner_->raw()));
            fptr_ = reinterpret_cast<float*>(base + cowner_->offset(idx_));
        }
    public:
        ElemRef(Tensor* t, const Tensor::index_type& idx) : owner_(t), cowner_(t), idx_(idx) {
            if (t->type() == GGML_TYPE_F32) bindF32();
            else cache_ = t->get(idx);
        }
        ElemRef(const Tensor* t, const Tensor::index_type& idx) : cowner_(t), idx_(idx) {
            if (t->type() == GGML_TYPE_F32) bindF32();
            else cache_ = t->get(idx);
        }

        // 读：隐式转 float
        operator float() const { return fptr_ ? *fptr_ : cache_; }

        // 写
        ElemRef& operator=(float v) {
            if (!owner_) throw std::runtime_error("ElemRef: 来自 const 张量，只读");
            if (fptr_) { *fptr_ = v; return *this; }
            owner_->set(idx_, v);
            cache_ = v;
            return *this;
        }
        ElemRef& operator=(const ElemRef& o) { return operator=(float(o)); }

        // 便捷算术，使 m(i,j) += x 之类可用
        ElemRef& operator+=(float v) { return operator=(float(*this) + v); }
        ElemRef& operator-=(float v) { return operator=(float(*this) - v); }
        ElemRef& operator*=(float v) { return operator=(float(*this) * v); }
        ElemRef& operator/=(float v) { return operator=(float(*this) / v); }
    };

    inline ElemRef Tensor::refElem(const index_type& idx) {
        return ElemRef(this, idx);
    }
    inline ElemRef Tensor::refElem(const index_type& idx) const {
        return ElemRef(static_cast<const Tensor*>(this), idx);
    }

    // ----------------------------------------------------------------------------
    // 数组式链式 operator[] 已移除：多维访问统一改用视图（View）——
    //   auto v = t.view();            // 返回共享 t 的 data_ 的 PermuteView（identity 排列）
    //   v->get({i, j, ...});          // 索引向量访问
    //   v->operator()(i, j, ...);     // 函数式访问
    // 以及矩阵转置 t.transpose()、三/四阶轴交换 t3.swapaxes(a,b) / t4.swapaxes(a,b)。
    // 视图按 nb[]（与 ggml 的 nb[] 字节步长同构）重排索引映射，零拷贝共享存储。
    // ----------------------------------------------------------------------------

    // ----------------------------------------------------------------------------
    // 标量 Scalar —— 0 阶
    // ----------------------------------------------------------------------------
    class Scalar : public Tensor {
    public:
        explicit Scalar(compute_type v = compute_type{}, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            data_ = allocBuffer(elemBytes(type_));   // 标量只存 1 个元素；shape_ 保持空，rank=0
            count_ = 1;
            writeElem(0, v);
        }
        size_t rank() const override { return 0; }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "Scalar"; }

        compute_type value() const { return readElem(0); }
        void setValue(compute_type v) { writeElem(0, v); }

        // 统一虚入口（4 参数，全部默认 0；标量只有 data_[0]，多余参数忽略）
        ElemRef operator()(size_t = 0, size_t = 0, size_t = 0, size_t = 0) override {
            return refElem({});
        }
        ElemRef operator()(size_t = 0, size_t = 0, size_t = 0, size_t = 0) const override {
            return refElem({});
        }

        std::unique_ptr<Tensor> clone() const override {
            return std::make_unique<Scalar>(*this);
        }
    };

    // ----------------------------------------------------------------------------
    // 矢量 Vector —— 1 阶
    // ----------------------------------------------------------------------------
    class Vector : public Tensor {
    public:
        explicit Vector(size_t n = 0, compute_type v = compute_type{}, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            allocate({ n }); if (v != compute_type{}) fill(v);
        }
        Vector(std::initializer_list<compute_type> list, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            allocate({ list.size() });
            size_t i = 0;
            for (compute_type x : list) set(i++, x);   // type 感知写入
        }
        // 仅供视图/别名派生类（如 VectorView）：仅设类型、不分配缓冲，
        // 由派生类接管 data_ / shape_ / owns_data_。
        explicit Vector(ggml_type t) : Tensor(t) {}

        size_t rank() const override { return 1; }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "Vector"; }

        size_t length() const { return shape_.empty() ? 0 : shape_[0]; }

        // 统一虚入口：a 为本阶实际索引（不带默认），b/c/d 超出阶数默认 0 并忽略
        ElemRef operator()(size_t a, size_t = 0, size_t = 0, size_t = 0) override {
            return refElem({ a });
        }
        ElemRef operator()(size_t a, size_t = 0, size_t = 0, size_t = 0) const override {
            return refElem({ a });
        }

        std::unique_ptr<Tensor> clone() const override {
            return std::make_unique<Vector>(*this);
        }
    };

    // ----------------------------------------------------------------------------
    // VectorView —— Vector 的非拥有（零拷贝）别名视图
    //
    // 与 Vector 的唯一区别：构造时把一段【外部】字节 [data, data + n*eb) 包装为 1 维 Vector，
    // 并强制 owns_data_ = false，故析构【绝不】释放被引用缓冲——避免误删源 Matrix 的行数据。
    // 这正是“行向量指针”的安全形态：你拿到整行的零拷贝 Vector 视图并读取（甚至写回）其元素，
    // 但视图销毁时绝不触及底层 Matrix 的内存（与访问层零虚面红线无冲突）。
    //
    // 前置（调用方保证）：外部缓冲在视图存活期间保持有效且不可重分配。
    //   * 标量/连续类型（blck_size==1）：整行是干净连续字节切片，可直接别名。
    //   * 量化类型（blck_size>1）：仅当行长度 n 恰为 blck_size 整数倍（整行=完整块序列、
    //     独立可寻址）时方能零拷贝别名——与大模型词表矩阵“行长 32 对齐”的约定一致。
    //   （非对齐量化行无法零拷贝别名，Matrix::row 会据此抛错；需物化副本时另走别径。）
    // 视图语义：拷贝/移动均“浅”共享同一缓冲（不分配、不拥有），故必须是非拥有的；
    //   同时禁止任何“拥有式”构造，避免误用成独立缓冲而触发深拷贝、进而令 aliasing 失效。
    class VectorView : public Vector {
    public:
        // 别名构造：指向外部字节 [data, data + n*elemBytes)，不分配、不拥有。
        VectorView(ggml_type t, const void* data, size_t n) {
            type_      = t;
            data_      = const_cast<void*>(data);
            shape_     = { n };
            nb_        = makeNb({ n }, t);   // 1 维步长 = 每“虚拟元素”字节数（量化下为 blck_bytes）
            count_     = n;
            owns_data_ = false;              // 关键：析构不释放共享缓冲
        }
        // 浅拷贝 / 浅移动：仅复制指针与元数据，保持 owns_data_ = false（仍是视图，绝不拥有）。
        VectorView(const VectorView& o) : Vector(o.type_) {
            type_ = o.type_; data_ = o.data_; shape_ = o.shape_;
            nb_ = o.nb_; count_ = o.count_; owns_data_ = false;
        }
        VectorView(VectorView&& o) noexcept : Vector(o.type_) {
            type_ = o.type_; data_ = o.data_; shape_ = o.shape_;
            nb_ = o.nb_; count_ = o.count_; owns_data_ = false;
        }
        VectorView& operator=(const VectorView&) = delete;   // 禁止赋值，避免拥有/非拥有语义混淆
        VectorView& operator=(VectorView&&) = delete;
        // VectorView 只能是别名，禁止任何“拥有式”构造。
        VectorView() = delete;
        VectorView(size_t, compute_type, ggml_type) = delete;
        VectorView(std::initializer_list<compute_type>, ggml_type) = delete;
    };

    // ----------------------------------------------------------------------------
    // 矩阵 Matrix —— 2 阶
    // ----------------------------------------------------------------------------
    class TransposeView;   // 前向声明：Matrix::transpose() 返回 unique_ptr<TransposeView>
    class Matrix : public Tensor {
    public:
        Matrix(size_t rows = 0, size_t cols = 0, compute_type v = compute_type{}, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            allocate({ rows, cols }); if (v != compute_type{}) fill(v);
        }
        Matrix(std::initializer_list<std::initializer_list<compute_type>> init, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            if (init.size() == 0) { allocate({ 0, 0 }); return; }
            size_t r = init.size();
            size_t c = init.begin()->size();
            allocate({ r, c });
            size_t i = 0;
            for (const auto& row : init) {
                if (row.size() != c) throw std::invalid_argument("Matrix: 行长度不一致");
                size_t j = 0;
                for (compute_type x : row) set(i, j++, x);   // type 感知写入
                ++i;
            }
        }

        // 仅供视图/别名派生类（如 TransposeView）：仅设类型、不分配缓冲，
        // 由派生类接管 data_ / shape_ / owns_data_。
        explicit Matrix(ggml_type t) : Tensor(t) {}

        size_t rank() const override { return 2; }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "Matrix"; }

        size_t rows() const { return shape_.size() < 1 ? 0 : shape_[0]; }
        size_t cols() const { return shape_.size() < 2 ? 0 : shape_[1]; }

        // 返回第 r 行的“行视图”VectorView（零拷贝别名，不拥有缓冲、析构不释放源数据）。
        //   * 标量/连续类型（blck_size==1）：整行 [r·nb[0], (r+1)·nb[0]) 是干净连续字节切片，直接别名。
        //   * 量化类型（blck_size>1）：仅当 cols % blck_size == 0（整行 = 完整块序列、独立可寻址）时
        //     零拷贝别名；大模型词表矩阵行长通常 32 对齐，满足此条件。否则抛 std::invalid_argument
        //     （非对齐量化行无法零拷贝，本方法按“视图”语义仅做别名，不做物化）。
        // r 越界抛 std::out_of_range。返回的 VectorView 与 Matrix 共享缓冲，经其写回会修改本 Matrix
        // （实验性视图语义，GatherMatrixView 仅读不写）。
        VectorView row(size_t r) const {
            if (r >= rows()) throw std::out_of_range("Matrix::row: 行号越界");
            const auto& q = traitsOf(type_);
            if (q.blck_size > 1 && cols() % q.blck_size != 0)
                throw std::invalid_argument("Matrix::row: 量化行非块对齐(cols % blck_size != 0)，无法零拷贝别名");
            // 零拷贝别名：行 r 的真实字节偏移 = r ×（单行字节数）。
            // 注意：标量类型下单行字节数 = nb[0] = cols×eb；但量化类型下 makeNb 的“虚拟行步长”为
            // cols×blck_bytes（readElem 靠块号归约来定位），故必须用真实行字节数 (cols/blck_size)×blck_bytes，
            // 不能用 nb[0]，否则量化行会被偏移到错误位置。
            const size_t rowBytes = bufferBytes(cols(), type_);
            return VectorView(type(), static_cast<const char*>(data()) + r * rowBytes, cols());
        }

        // 统一虚入口：a,b 为本阶实际索引（不带默认），c/d 超出阶数默认 0 并忽略
        ElemRef operator()(size_t a, size_t b, size_t = 0, size_t = 0) override {
            return refElem({ a, b });
        }
        ElemRef operator()(size_t a, size_t b, size_t = 0, size_t = 0) const override {
            return refElem({ a, b });
        }

        std::unique_ptr<Tensor> clone() const override {
            return std::make_unique<Matrix>(*this);
        }

        // 转置视图：返回共享本对象 data_ 的 TransposeView（零拷贝）。
        // 注意：视图不拥有内存，本 Matrix 必须比视图活得久（典型 view 语义）。
        std::unique_ptr<TransposeView> transpose();
    };

    // ----------------------------------------------------------------------------
    // MatrixView —— Matrix 的非拥有（零拷贝）别名视图
    //
    // 与 Matrix 的唯一区别：构造时把一段【外部】字节缓冲包装为 2 维 Matrix（形状 rows×cols），
    // 并强制 owns_data_ = false，故析构【绝不】释放被引用缓冲——避免误删源张量的数据。
    // 这正是“矩阵别名”的安全形态：你拿到整张（或某段）零拷贝 Matrix 视图并读取（甚至写回）其元素，
    // 但视图销毁时绝不触及底层源的内存（与访问层零虚面红线无冲突）。
    //
    // 前置（调用方保证）：外部缓冲在视图存活期间保持有效且不可重分配。
    //   * 标量/连续类型（blck_size==1）：整段是干净连续字节切片，可直接别名。
    //   * 量化类型（blck_size>1）：仅当元素总数（rows×cols）恰为 blck_size 整数倍时方能
    //     零拷贝别名——整段 = 完整块序列、独立可寻址；否则块跨边界、无法干净切片（需物化副本时另走别径）。
    // 视图语义：拷贝/移动均“浅”共享同一缓冲（不分配、不拥有），故必须是非拥有的；
    //   同时禁止任何“拥有式”构造，避免误用成独立缓冲而触发深拷贝、进而令 aliasing 失效。
    class MatrixView : public Matrix {
    public:
        // 别名构造：指向外部字节缓冲（形状 rows×cols），不分配、不拥有。
        MatrixView(ggml_type t, const void* data, size_t rows, size_t cols) {
            type_      = t;
            data_      = const_cast<void*>(data);
            shape_     = { rows, cols };
            nb_        = makeNb({ rows, cols }, t);   // 各维字节步长，与 Matrix 同构
            count_     = rows * cols;
            owns_data_ = false;                       // 关键：析构不释放共享缓冲
        }
        // 浅拷贝 / 浅移动：仅复制指针与元数据，保持 owns_data_ = false（仍是视图，绝不拥有）。
        MatrixView(const MatrixView& o) : Matrix(o.type_) {
            type_ = o.type_; data_ = o.data_; shape_ = o.shape_;
            nb_ = o.nb_; count_ = o.count_; owns_data_ = false;
        }
        MatrixView(MatrixView&& o) noexcept : Matrix(o.type_) {
            type_ = o.type_; data_ = o.data_; shape_ = o.shape_;
            nb_ = o.nb_; count_ = o.count_; owns_data_ = false;
        }
        MatrixView& operator=(const MatrixView&) = delete;   // 禁止赋值，避免拥有/非拥有语义混淆
        MatrixView& operator=(MatrixView&&) = delete;
        // MatrixView 只能是别名，禁止任何“拥有式”构造。
        MatrixView() = delete;
        MatrixView(size_t, size_t, compute_type, ggml_type) = delete;
        MatrixView(std::initializer_list<std::initializer_list<compute_type>>, ggml_type) = delete;
    };

    // 注：TransposeView / PermuteView / 物化辅助 的完整定义见文件末尾
    //     （需所有派生类（含 Tensor4）完整类型，故放在 namespace 关闭前）。

    // ----------------------------------------------------------------------------
    // 三阶张量 Tensor3 —— 3 阶
    // ----------------------------------------------------------------------------
    class Tensor3 : public Tensor {
    public:
        Tensor3(size_t d0 = 0, size_t d1 = 0, size_t d2 = 0, compute_type v = compute_type{}, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            allocate({ d0, d1, d2 }); if (v != compute_type{}) fill(v);
        }
        // 仅供视图/别名派生类（如 Tensor3View）：仅设类型、不分配缓冲，
        // 由派生类接管 data_ / shape_ / owns_data_。
        explicit Tensor3(ggml_type t) : Tensor(t) {}

        size_t rank() const override { return 3; }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "Tensor3"; }

        size_t dim(size_t i) const { return shape_.size() <= i ? 0 : shape_[i]; }

        ElemRef at(size_t i, size_t j, size_t k) { return refElem({ i, j, k }); }
        ElemRef at(size_t i, size_t j, size_t k) const { return refElem({ i, j, k }); }

        // 统一虚入口：a,b,c 为本阶实际索引（不带默认），d 超出阶数默认 0 并忽略
        ElemRef operator()(size_t a, size_t b, size_t c, size_t = 0) override {
            return refElem({ a, b, c });
        }
        ElemRef operator()(size_t a, size_t b, size_t c, size_t = 0) const override {
            return refElem({ a, b, c });
        }

        // 轴交换视图：交换轴 a 与轴 b（其余不变），返回共享 data_ 的 PermuteView（零拷贝）。
        // 例：swapaxes(0,2) 把 (i,j,k) 重排为 (k,j,i)；形状随之交换。视图不拥有内存，源须比视图活得久。
        std::unique_ptr<Tensor> swapaxes(size_t a, size_t b) {
            if (a >= 3 || b >= 3) throw std::out_of_range("Tensor3::swapaxes: 轴越界");
            index_type perm{ 0, 1, 2 };
            size_t tmp = perm[a]; perm[a] = perm[b]; perm[b] = tmp;
            return permute(perm);
        }

        // 命名轴重载：t3.swapaxes(axisX, axisZ) 等价于 swapaxes(0,2)（把 (i,j,k) 重排为 (k,j,i)）。
        std::unique_ptr<Tensor> swapaxes(Axis a, Axis b) {
            return swapaxes(size_t(a), size_t(b));
        }

        // 取沿轴 0 的第 idx 个矩阵切片（形状 d1×d2），返回【非拥有】零拷贝 MatrixView 别名。
        // 源张量须比返回视图活得久；经视图写回会直接改源缓冲（与 Matrix::row / VectorView / MatrixView 同源设计）。
        //   * 量化类型（blck_size>1）：仅当切片元素总数（d1×d2）恰为 blck_size 整数倍时方能零拷贝别名，
        //     否则块跨边界、无法干净切片，抛 std::invalid_argument（本方法仅做别名、不做物化）。
        //   * 切片内部按连续步长解释（默认布局下成立，与 Matrix::row 同前提）；非连续（如 permuted 内层）需先物化。
        // idx 越界抛 std::out_of_range。
        MatrixView getMatrix(const size_t& idx) const {
            if (idx >= dim(0)) throw std::out_of_range("Tensor3::getMatrix: 索引越界");
            const auto& q = traitsOf(type_);
            if (q.blck_size > 1 && (dim(1) * dim(2)) % q.blck_size != 0)
                throw std::invalid_argument("Tensor3::getMatrix: 量化切片非块对齐(d1×d2 % blck_size != 0)，无法零拷贝别名");
            // 零拷贝别名：第 idx 个矩阵切片的起始字节 = data + idx × nb[0]（轴 0 字节步长）。
            // nb[0] 对任意布局（含视图/别名）都正确给出沿轴 0 的步长，故切片基址定位普适正确；
            // 切片内部的 (d1,d2) 则按连续步长解释（默认布局下严格成立）。
            const char* base = static_cast<const char*>(data()) + idx * nb_[0];
            return MatrixView(type(), base, dim(1), dim(2));
        }

        std::unique_ptr<Tensor> clone() const override {
            return std::make_unique<Tensor3>(*this);
        }
    };

    // ----------------------------------------------------------------------------
    // Tensor3View —— Tensor3 的非拥有（零拷贝）别名视图
    //
    // 与 Tensor3 的唯一区别：构造时把一段【外部】字节缓冲包装为 3 维 Tensor3（形状 d0×d1×d2），
    // 并强制 owns_data_ = false，故析构【绝不】释放被引用缓冲——避免误删源张量的数据。
    // 这正是“三阶别名”的安全形态：你拿到整块零拷贝 Tensor3 视图并读取（甚至写回）其元素，
    // 但视图销毁时绝不触及底层源的内存（与访问层零虚面红线无冲突）。
    //
    // 前置（调用方保证）：外部缓冲在视图存活期间保持有效且不可重分配。
    //   * 标量/连续类型（blck_size==1）：整段是干净连续字节切片，可直接别名。
    //   * 量化类型（blck_size>1）：仅当元素总数（d0×d1×d2）恰为 blck_size 整数倍时方能
    //     零拷贝别名——整段 = 完整块序列、独立可寻址；否则块跨边界、无法干净切片（需物化副本时另走别径）。
    // 视图语义：拷贝/移动均“浅”共享同一缓冲（不分配、不拥有），故必须是非拥有的；
    //   同时禁止任何“拥有式”构造，避免误用成独立缓冲而触发深拷贝、进而令 aliasing 失效。
    class Tensor3View : public Tensor3 {
    public:
        // 别名构造：指向外部字节缓冲（形状 d0×d1×d2），不分配、不拥有。
        Tensor3View(ggml_type t, const void* data, size_t d0, size_t d1, size_t d2) {
            type_      = t;
            data_      = const_cast<void*>(data);
            shape_     = { d0, d1, d2 };
            nb_        = makeNb({ d0, d1, d2 }, t);   // 各维字节步长，与 Tensor3 同构
            count_     = d0 * d1 * d2;
            owns_data_ = false;                       // 关键：析构不释放共享缓冲
        }
        // 浅拷贝 / 浅移动：仅复制指针与元数据，保持 owns_data_ = false（仍是视图，绝不拥有）。
        Tensor3View(const Tensor3View& o) : Tensor3(o.type_) {
            type_ = o.type_; data_ = o.data_; shape_ = o.shape_;
            nb_ = o.nb_; count_ = o.count_; owns_data_ = false;
        }
        Tensor3View(Tensor3View&& o) noexcept : Tensor3(o.type_) {
            type_ = o.type_; data_ = o.data_; shape_ = o.shape_;
            nb_ = o.nb_; count_ = o.count_; owns_data_ = false;
        }
        Tensor3View& operator=(const Tensor3View&) = delete;   // 禁止赋值，避免拥有/非拥有语义混淆
        Tensor3View& operator=(Tensor3View&&) = delete;
        // Tensor3View 只能是别名，禁止任何“拥有式”构造。
        Tensor3View() = delete;
        Tensor3View(size_t, size_t, size_t, compute_type, ggml_type) = delete;
    };

    // ----------------------------------------------------------------------------
    // 四阶张量 Tensor4 —— 4 阶
    // ----------------------------------------------------------------------------
    class Tensor4 : public Tensor {
    public:
        Tensor4(size_t d0 = 0, size_t d1 = 0, size_t d2 = 0, size_t d3 = 0,
            compute_type v = compute_type{}, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            allocate({ d0, d1, d2, d3 }); if (v != compute_type{}) fill(v);
        }
        // 仅供视图/别名派生类（如 Tensor4View）：仅设类型、不分配缓冲，
        // 由派生类接管 data_ / shape_ / owns_data_。
        explicit Tensor4(ggml_type t) : Tensor(t) {}

        size_t rank() const override { return 4; }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "Tensor4"; }

        size_t dim(size_t i) const { return shape_.size() <= i ? 0 : shape_[i]; }

        ElemRef at(size_t i, size_t j, size_t k, size_t l) { return refElem({ i, j, k, l }); }
        ElemRef at(size_t i, size_t j, size_t k, size_t l) const { return refElem({ i, j, k, l }); }

        // 统一虚入口：a,b,c,d 均为本阶实际索引（不带默认）
        ElemRef operator()(size_t a, size_t b, size_t c, size_t d) override {
            return refElem({ a, b, c, d });
        }
        ElemRef operator()(size_t a, size_t b, size_t c, size_t d) const override {
            return refElem({ a, b, c, d });
        }

        // 轴交换视图：交换轴 a 与轴 b（其余不变），返回共享 data_ 的 PermuteView（零拷贝）。
        // 例：swapaxes(1,3) 把 (i,j,k,l) 重排为 (i,l,k,j)；形状随之交换。视图不拥有内存，源须比视图活得久。
        std::unique_ptr<Tensor> swapaxes(size_t a, size_t b) {
            if (a >= 4 || b >= 4) throw std::out_of_range("Tensor4::swapaxes: 轴越界");
            index_type perm{ 0, 1, 2, 3 };
            size_t tmp = perm[a]; perm[a] = perm[b]; perm[b] = tmp;
            return permute(perm);
        }

        // 命名轴重载：t4.swapaxes(axisY, axisW) 等价于 swapaxes(1,3)（把 (i,j,k,l) 重排为 (i,l,k,j)）。
        std::unique_ptr<Tensor> swapaxes(Axis a, Axis b) {
            return swapaxes(size_t(a), size_t(b));
        }

        // 取沿轴 0 的第 idx 个三阶切片（形状 d1×d2×d3），返回【非拥有】零拷贝 Tensor3View 别名。
        // 源张量须比返回视图活得久；经视图写回会直接改源缓冲（与 Tensor3::getMatrix / Matrix::row 同源设计）。
        //   * 量化类型（blck_size>1）：仅当切片元素总数（d1×d2×d3）恰为 blck_size 整数倍时方能零拷贝别名，
        //     否则块跨边界、无法干净切片，抛 std::invalid_argument（本方法仅做别名、不做物化）。
        //   * 切片内部按连续步长解释（默认布局下成立，与 Matrix::row 同前提）；非连续（如 permuted 内层）需先物化。
        // idx 越界抛 std::out_of_range。
        Tensor3View getTensor3(const size_t& idx) const {
            if (idx >= dim(0)) throw std::out_of_range("Tensor4::getTensor3: 索引越界");
            const auto& q = traitsOf(type_);
            if (q.blck_size > 1 && (dim(1) * dim(2) * dim(3)) % q.blck_size != 0)
                throw std::invalid_argument("Tensor4::getTensor3: 量化切片非块对齐(d1×d2×d3 % blck_size != 0)，无法零拷贝别名");
            // 零拷贝别名：第 idx 个三阶切片的起始字节 = data + idx × nb[0]（轴 0 字节步长）。
            // nb[0] 对任意布局（含视图/别名）都正确给出沿轴 0 的步长，故切片基址定位普适正确；
            // 切片内部的 (d1,d2,d3) 则按连续步长解释（默认布局下严格成立）。
            const char* base = static_cast<const char*>(data()) + idx * nb_[0];
            return Tensor3View(type(), base, dim(1), dim(2), dim(3));
        }

        std::unique_ptr<Tensor> clone() const override {
            return std::make_unique<Tensor4>(*this);
        }
    };

    // ----------------------------------------------------------------------------
    // Tensor4View —— Tensor4 的非拥有（零拷贝）别名视图
    //
    // 与 Tensor4 的唯一区别：构造时把一段【外部】字节缓冲包装为 4 维 Tensor4（形状 d0×d1×d2×d3），
    // 并强制 owns_data_ = false，故析构【绝不】释放被引用缓冲——避免误删源张量的数据。
    // 这正是“四阶别名”的安全形态：你拿到整块零拷贝 Tensor4 视图并读取（甚至写回）其元素，
    // 但视图销毁时绝不触及底层源的内存（与访问层零虚面红线无冲突）。
    //
    // 前置（调用方保证）：外部缓冲在视图存活期间保持有效且不可重分配。
    //   * 标量/连续类型（blck_size==1）：整段是干净连续字节切片，可直接别名。
    //   * 量化类型（blck_size>1）：仅当元素总数（d0×d1×d2×d3）恰为 blck_size 整数倍时方能
    //     零拷贝别名——整段 = 完整块序列、独立可寻址；否则块跨边界、无法干净切片（需物化副本时另走别径）。
    // 视图语义：拷贝/移动均“浅”共享同一缓冲（不分配、不拥有），故必须是非拥有的；
    //   同时禁止任何“拥有式”构造，避免误用成独立缓冲而触发深拷贝、进而令 aliasing 失效。
    class Tensor4View : public Tensor4 {
    public:
        // 别名构造：指向外部字节缓冲（形状 d0×d1×d2×d3），不分配、不拥有。
        Tensor4View(ggml_type t, const void* data, size_t d0, size_t d1, size_t d2, size_t d3) {
            type_      = t;
            data_      = const_cast<void*>(data);
            shape_     = { d0, d1, d2, d3 };
            nb_        = makeNb({ d0, d1, d2, d3 }, t);   // 各维字节步长，与 Tensor4 同构
            count_     = d0 * d1 * d2 * d3;
            owns_data_ = false;                           // 关键：析构不释放共享缓冲
        }
        // 浅拷贝 / 浅移动：仅复制指针与元数据，保持 owns_data_ = false（仍是视图，绝不拥有）。
        Tensor4View(const Tensor4View& o) : Tensor4(o.type_) {
            type_ = o.type_; data_ = o.data_; shape_ = o.shape_;
            nb_ = o.nb_; count_ = o.count_; owns_data_ = false;
        }
        Tensor4View(Tensor4View&& o) noexcept : Tensor4(o.type_) {
            type_ = o.type_; data_ = o.data_; shape_ = o.shape_;
            nb_ = o.nb_; count_ = o.count_; owns_data_ = false;
        }
        Tensor4View& operator=(const Tensor4View&) = delete;   // 禁止赋值，避免拥有/非拥有语义混淆
        Tensor4View& operator=(Tensor4View&&) = delete;
        // Tensor4View 只能是别名，禁止任何“拥有式”构造。
        Tensor4View() = delete;
        Tensor4View(size_t, size_t, size_t, size_t, compute_type, ggml_type) = delete;
    };

    // ----------------------------------------------------------------------------
    // PermuteView 相关辅助（前向声明；完整定义见下方）
    // ----------------------------------------------------------------------------
    std::unique_ptr<Tensor> makeDense(const Tensor::shape_type& shape, ggml_type t = GGML_TYPE_F32);
    bool advanceIndex(Tensor::shape_type& idx, const Tensor::shape_type& shape);

    // ----------------------------------------------------------------------------
    // PermuteView —— 任意轴重排视图（共享源 Tensor 的 data_，零拷贝）
    //   基于 nb[]（与 ggml 的 nb[] 字节步长完全一致，单位为“字节”）实现：
    //   新视图轴 k 的字节步长 = 源“第 perm[k] 轴”的字节步长；形状同理重排。
    //   因此 view(i,j,k) 自动映射到源的正确字节位置，且不搬任何数据。
    //   不拥有内存（owns_data_ = false），故“源 Tensor 必须比视图活得久”（典型 view 语义）。
    //   非连续/重排布局下链式 operator[] 语义错位，故 PermuteView 不提供 operator[]，
    //   请改用 view(i,j,...) / view.get({i,j,...})。
    // ----------------------------------------------------------------------------
    class PermuteView : public Tensor {
    public:
        // src：被观察的张量（不拥有其内存）；perm：轴重排，长度须 == src.rank()，
        //      如矩阵转置 = {1,0}，三阶轴轮转 = {2,0,1}。
        PermuteView(Tensor* src, const index_type& perm) : Tensor(src->type()) {
            if (perm.size() != src->rank())
                throw std::invalid_argument("PermuteView: perm 长度必须等于源阶数");
            std::vector<char> seen(perm.size(), 0);
            for (size_t p : perm) {
                if (p >= perm.size() || seen[p])
                    throw std::invalid_argument("PermuteView: perm 必须是 0..rank-1 的合法排列");
                seen[p] = 1;
            }
            const auto& sh = src->dims();
            const auto& st = src->strides();   // 源【字节】步长（nb[]）
            shape_.resize(perm.size());
            nb_.resize(perm.size());
            for (size_t k = 0; k < perm.size(); ++k) {
                shape_[k] = sh[perm[k]];     // 形状按新轴顺序重排
                nb_[k] = st[perm[k]];        // 字节步长按新轴顺序重排（与 ggml nb[] 同构）
            }
            data_ = src->data(); // 共享源缓冲（浅拷贝，零拷贝）
            owns_data_ = false;          // 析构时不释放共享缓冲
            count_ = src->capacity();
            source_ = src;
        }

        size_t rank() const override { return shape_.size(); }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "PermuteView"; }

        // 统一虚入口：按本视图阶数定位（越界检查由基类 get/checkIndex 统一处理）
        ElemRef operator()(size_t a, size_t b = 0, size_t c = 0, size_t d = 0) override {
            return refElem({ a, b, c, d });
        }
        ElemRef operator()(size_t a, size_t b = 0, size_t c = 0, size_t d = 0) const override {
            return refElem({ a, b, c, d });
        }

        // 物化：返回独立稠密张量（按视图形状逐元素拷出，脱离源仍可存活）
        std::unique_ptr<Tensor> clone() const override {
            auto dst = makeDense(shape_, type());
            index_type idx(shape_.size(), 0);
            do { dst->set(idx, this->get(idx)); } while (advanceIndex(idx, shape_));
            return dst;
        }

        const Tensor* source() const { return source_; }

        // 注意：describe() 在基类非 virtual，此处仅为“具体对象直接调用”时给出别名信息；
        // 经 Tensor* 调用仍走基类 describe()，但 typeName() 为 virtual，类型名正确。
        std::string describe() const {
            std::ostringstream os;
            os << typeName() << " [type=" << ggml_type_name(type())
                << ", rank=" << rank() << ", dims=";
            for (size_t i = 0; i < dims().size(); ++i) {
                if (i) os << "x";
                os << dims()[i];
            }
            os << ", size=" << size() << ", 别名视图, 源=" << source_->typeName() << "]";
            return os.str();
        }

    protected:
        const Tensor* source_ = nullptr;

        // 不再重写 offset()：nb_ 已按字节步长正确设置，基类 offset() 即可算出正确字节偏移。
    };

    // ----------------------------------------------------------------------------
    // TransposeView —— 矩阵转置视图（共享源 Matrix 的 data_，零拷贝）
    //   直接继承 Tensor，自带转置的“索引 -> 字节位置”实现（靠重排后的 nb_ 自动完成），
    //   不依赖 PermuteView，与 v11 原始实现一致。view(i,j) 实际访问源 M(j,i)。
    //   不拥有内存（owns_data_ = false），故“源 Matrix 必须比视图活得久”（典型 view 语义）。
    //   与 ggml 的 nb[] 字节步长视图是同一思路：只改变映射，不搬数据。
    // ----------------------------------------------------------------------------
    class TransposeView : public Tensor {
    public:
        explicit TransposeView(Matrix& src) : Tensor(src.type()) {
            source_ = &src;
            data_ = src.data();        // 共享源缓冲（浅拷贝指针，零拷贝）
            owns_data_ = false;             // 析构时不释放共享缓冲
            shape_ = { src.cols(), src.rows() };  // 形状交换：视图为 (C, R)
            const size_t eb = elemBytes(type());
            nb_ = { eb, src.cols() * eb }; // 字节步长：轴0 步长=元素字节数，轴1 步长=源列数*元素字节数
            count_ = src.cols() * src.rows();
        }

        size_t rank() const override { return 2; }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "TransposeView"; }

        size_t rows() const { return shape_.size() < 1 ? 0 : shape_[0]; }  // = 源 cols
        size_t cols() const { return shape_.size() < 2 ? 0 : shape_[1]; }  // = 源 rows

        // 统一虚入口：a,b 为本阶实际索引（不带默认），c/d 超出阶数默认 0 并忽略
        ElemRef operator()(size_t a, size_t b, size_t = 0, size_t = 0) override {
            return refElem({ a, b });
        }
        ElemRef operator()(size_t a, size_t b, size_t = 0, size_t = 0) const override {
            return refElem({ a, b });
        }

        // 物化：返回独立 Matrix，把转置后的数据拷进自有缓冲（可脱离源独立存活）
        std::unique_ptr<Tensor> clone() const override {
            auto m = std::make_unique<Matrix>(dims()[0], dims()[1], compute_type{}, type());
            for (size_t i = 0; i < dims()[0]; ++i)
                for (size_t j = 0; j < dims()[1]; ++j)
                    (*m)(i, j) = (*this)(i, j);  // 经本视图的转置映射取值
            return m;
        }

        const Matrix* source() const { return source_; }

        // 具体对象直接调用时给出别名信息（经 Tensor* 调用走基类 describe，类型名仍正确）
        std::string describe() const {
            std::ostringstream os;
            os << typeName() << " [type=" << ggml_type_name(type())
                << ", rank=" << rank() << ", dims=";
            for (size_t i = 0; i < dims().size(); ++i) {
                if (i) os << "x";
                os << dims()[i];
            }
            os << ", size=" << size() << ", 别名视图, 源=" << source_->typeName() << "]";
            return os.str();
        }

    protected:
        Matrix* source_ = nullptr;

        // 不再重写 offset()：nb_ 已正确设置（轴0=eb, 轴1=cols*eb），基类 offset() 自动得到
        // view(i,j) -> 字节偏移 = i*eb + j*cols*eb = (i + j*cols)*eb = 源 M(j,i) 的字节位置。
    };

    // Matrix::transpose() 定义放在 TransposeView 完整类型之后
    inline std::unique_ptr<TransposeView> Matrix::transpose() {
        return std::make_unique<TransposeView>(*this);
    }

    // ----------------------------------------------------------------------------
    // Tensor::gather —— Embedding 查表（算子式一次性物化，返回普通可写 Matrix）
    //   例：embed[32000, 4096] + ids[seq] -> 输出 [seq, 4096]，输出第 i 行 = embed[ids[i]]。
    // 与 ggml_get_rows 同构：结果就是一张普通、可写的 Matrix，不再有专门子类。
    //   ids 任意、被取行不等距，无法用 nb_ 步长表达成零拷贝视图；若做视图就必须在 get/set 里
    //   插运行期索引映射，违反访问层零虚调用的设计红线。故改为构造时一次性物化：分配独立缓冲、
    //   拷贝所选行，下游拿到的就是稠密张量，可直接参与后续计算。物化代价（seq*dim 次拷贝）相对
    //   后续几十层计算可忽略，且连续内存更利于 SIMD/GPU 顺序访存。
    //   输出沿用源 type_（量化表仍按块拷贝）；仅支持二阶源，axis ∈ {0,1}，ids 不得越界。
    // ----------------------------------------------------------------------------
    inline std::unique_ptr<Matrix> Tensor::gather(const std::vector<size_t>& ids, int axis) const {
        if (rank() != 2)
            throw std::invalid_argument("gather: 仅支持二阶源（如 Embedding 权重表 [vocab, dim]）");
        if (axis < 0 || axis > 1)
            throw std::invalid_argument("gather: axis 越界（仅支持 0/1）");
        const shape_type& sd = dims();
        for (size_t id : ids)
            if (id >= sd[axis])
                throw std::out_of_range("gather: ids 中存在越界下标");

        shape_type sh = sd;
        sh[axis] = ids.size();
        auto out = std::make_unique<Matrix>(sh[0], sh[1], compute_type{}, type());

        // 一次性物化：输出 (i,j) <- 源（沿 axis 映射后的下标）。映射只发生在这里（构造期一次），
        // 不进 get/set 热路径；out 是普通 Matrix，写回走基类非虚 set，与任何稠密张量同一条路径。
        for (size_t i = 0; i < sh[0]; ++i)
            for (size_t j = 0; j < sh[1]; ++j) {
                index_type s{ i, j };
                s[axis] = ids[s[axis]];
                out->set({ i, j }, this->get(s));
            }
        return out;
    }

    // 物化辅助：按 shape 构造对应阶数的独立稠密张量（rank 0..4）
    inline std::unique_ptr<Tensor> makeDense(const Tensor::shape_type& shape, ggml_type t) {
        switch (shape.size()) {
        case 0: return std::make_unique<Scalar>(Tensor::compute_type{}, t);
        case 1: return std::make_unique<Vector>(shape[0], Tensor::compute_type{}, t);
        case 2: return std::make_unique<Matrix>(shape[0], shape[1], Tensor::compute_type{}, t);
        case 3: return std::make_unique<Tensor3>(shape[0], shape[1], shape[2], Tensor::compute_type{}, t);
        case 4: return std::make_unique<Tensor4>(shape[0], shape[1], shape[2], shape[3], Tensor::compute_type{}, t);
        default: throw std::invalid_argument("makeDense: 暂不支持 rank > 4");
        }
    }

    // 索引迭代器：把 idx 当作 odometer 自增；溢出回绕返回 false（遍历结束）
    inline bool advanceIndex(Tensor::shape_type& idx, const Tensor::shape_type& shape) {
        for (size_t k = idx.size(); k-- > 0; ) {
            if (++idx[k] < shape[k]) return true;
            idx[k] = 0;
        }
        return false;
    }

    // ----------------------------------------------------------------------------
    // A.1 一元逐元素运算内核（成员模板定义，须放在 makeDense/advanceIndex 完整声明之后）
    // ----------------------------------------------------------------------------
    template <typename F>
    inline std::unique_ptr<Tensor> Tensor::unaryMap(F f) const {
        auto out = makeDense(shape_, GGML_TYPE_F32);
        index_type idx(shape_.size(), 0);
        do { out->set(idx, static_cast<compute_type>(f(this->get(idx)))); }
        while (advanceIndex(idx, shape_));
        return out;
    }
    template <typename F>
    inline void Tensor::unaryMapInPlace(F f) {
        index_type idx(shape_.size(), 0);
        do { this->set(idx, static_cast<compute_type>(f(this->get(idx)))); }
        while (advanceIndex(idx, shape_));
    }

    // ----------------------------------------------------------------------------
    // A.2 二元逐元素运算内核（成员模板定义，须放在 makeDense/advanceIndex 完整声明之后）
    // ----------------------------------------------------------------------------
    template <typename F>
    inline std::unique_ptr<Tensor> Tensor::binaryMap(const Tensor& b, F f) const {
        // 1) NumPy 式广播：形状右对齐比较，某维为 1 或“缺失”（阶数较低一方）可拉伸到对方。
        const shape_type& sa = this->dims();
        const shape_type& sb = b.dims();
        const size_t ra = sa.size(), rb = sb.size();
        const size_t rr = std::max(ra, rb);
        shape_type outShape(rr, 1);
        for (size_t p = 0; p < rr; ++p) {            // p：从右往左的轴序号（0 = 最右维）
            const size_t da = (p < ra) ? sa[ra - 1 - p] : 1;
            const size_t db = (p < rb) ? sb[rb - 1 - p] : 1;
            if (da != db && da != 1 && db != 1)
                throw std::invalid_argument("binaryMap: 形状不可广播（两维不等且均 >1）");
            outShape[rr - 1 - p] = std::max(da, db);
        }
        // 2) 迭代广播后形状；广播维在源里取 0（拉伸），非广播维取结果索引。
        auto out = makeDense(outShape, GGML_TYPE_F32);   // 结果一律 F32
        index_type idx(rr, 0);
        do {
            index_type ia(ra, 0), ib(rb, 0);
            for (size_t p = 0; p < rr; ++p) {
                const size_t da = (p < ra) ? sa[ra - 1 - p] : 1;
                const size_t db = (p < rb) ? sb[rb - 1 - p] : 1;
                // 仅当该轴存在于对应源时才写入索引；缺失一方（阶数较低）本轴恒为 1（拉伸）。
                if (p < ra) {
                    if (da == 1) ia[ra - 1 - p] = 0;
                    else         ia[ra - 1 - p] = idx[rr - 1 - p];
                }
                if (p < rb) {
                    if (db == 1) ib[rb - 1 - p] = 0;
                    else         ib[rb - 1 - p] = idx[rr - 1 - p];
                }
            }
            // 量化操作数经 get 自动 dequant 到 float，结果再写入 F32 张量；访问走非虚 get（offset 纯算术）。
            out->set(idx, static_cast<compute_type>(f(this->get(ia), b.get(ib))));
        } while (advanceIndex(idx, outShape));
        return out;
    }

    // A.2 二元算子统一入口：按 op 分派到对应 lambda，经 binaryMap 执行广播 + 逐元素计算。
    inline std::unique_ptr<Tensor> Tensor::applyBinary(const Tensor& b, BinaryOp op) const {
        switch (op) {
        case BinaryOp::Add: return binaryMap(b, [](float x, float y){ return x + y; });
        case BinaryOp::Sub: return binaryMap(b, [](float x, float y){ return x - y; });
        case BinaryOp::Mul: return binaryMap(b, [](float x, float y){ return x * y; });
        case BinaryOp::Div: return binaryMap(b, [](float x, float y){ return x / y; });
        case BinaryOp::Pow: return binaryMap(b, [](float x, float y){ return std::pow(x, y); });
        case BinaryOp::Max: return binaryMap(b, [](float x, float y){ return std::max(x, y); });
        case BinaryOp::Min: return binaryMap(b, [](float x, float y){ return std::min(x, y); });
        }
        throw std::invalid_argument("applyBinary: 未知 BinaryOp");
    }

    // —— 二元逐元素（张量形式）：z_i = op(a_i, b_i)，b 经 NumPy 式广播对齐到本张量 ——
    //   返回新建 F32 张量（形状 = 广播后形状）。
    inline std::unique_ptr<Tensor> Tensor::add(const Tensor& b) const { return applyBinary(b, BinaryOp::Add); }
    inline std::unique_ptr<Tensor> Tensor::sub(const Tensor& b) const { return applyBinary(b, BinaryOp::Sub); }
    inline std::unique_ptr<Tensor> Tensor::mul(const Tensor& b) const { return applyBinary(b, BinaryOp::Mul); }
    inline std::unique_ptr<Tensor> Tensor::div(const Tensor& b) const { return applyBinary(b, BinaryOp::Div); }
    inline std::unique_ptr<Tensor> Tensor::pow(const Tensor& b) const { return applyBinary(b, BinaryOp::Pow); }
    inline std::unique_ptr<Tensor> Tensor::max(const Tensor& b) const { return applyBinary(b, BinaryOp::Max); }
    inline std::unique_ptr<Tensor> Tensor::min(const Tensor& b) const { return applyBinary(b, BinaryOp::Min); }

    // —— 二元逐元素（标量重载）：z_i = a_i op s（s 为常数）。走 unaryMap 单操作数路径，避免广播索引计算 ——
    inline std::unique_ptr<Tensor> Tensor::add(float s) const { return unaryMap([s](float x){ return x + s; }); }
    inline std::unique_ptr<Tensor> Tensor::sub(float s) const { return unaryMap([s](float x){ return x - s; }); }
    inline std::unique_ptr<Tensor> Tensor::mul(float s) const { return unaryMap([s](float x){ return x * s; }); }
    inline std::unique_ptr<Tensor> Tensor::div(float s) const { return unaryMap([s](float x){ return x / s; }); }
    inline std::unique_ptr<Tensor> Tensor::pow(float s) const { return unaryMap([s](float x){ return std::pow(x, s); }); }
    inline std::unique_ptr<Tensor> Tensor::max(float s) const { return unaryMap([s](float x){ return std::max(x, s); }); }
    inline std::unique_ptr<Tensor> Tensor::min(float s) const { return unaryMap([s](float x){ return std::min(x, s); }); }

    // ----------------------------------------------------------------------------
    // A.3 标量辅助：in-place / 新建 实现
    //   scale / scaled / addScalar 复用 unaryMap / unaryMapInPlace 内核（与 A.1/A.2 同）；
    //   addBias / withBias 用专用“最后维广播”循环（b 为 1 维 [out_dim]，加在 idx.back() 处），
    //   不依赖 A.2 的 NumPy 广播（后者对任意维右对齐，这里语义固定为“最后维通道偏置”）。
    // ----------------------------------------------------------------------------
    inline void Tensor::scale(float s) {
        unaryMapInPlace([s](float x){ return x * s; });
    }
    inline std::unique_ptr<Tensor> Tensor::scaled(float s) const {
        return unaryMap([s](float x){ return x * s; });   // 等价于 A.2 mul(s)，独立命名
    }
    inline void Tensor::addScalar(float s) {
        unaryMapInPlace([s](float x){ return x + s; });
    }
    inline void Tensor::addBias(const Tensor& b) {
        // 校验：本张量须有最后维；b 须为 1 维且长度 == 最后维尺寸
        const shape_type& sh = dims();
        if (sh.empty())
            throw std::invalid_argument("addBias: 本张量为 0 阶，无“最后维”可广播");
        const size_t lastDim = sh.back();
        if (b.dims().size() != 1 || b.dims()[0] != lastDim)
            throw std::invalid_argument("addBias: b 须为 1 维且长度等于本张量最后维尺寸");
        index_type idx(sh.size(), 0);
        do {
            const size_t c = idx.back();                 // 最后维坐标 -> 偏置索引
            this->set(idx, static_cast<compute_type>(this->get(idx) + b.get(c)));
        } while (advanceIndex(idx, sh));
    }
    inline std::unique_ptr<Tensor> Tensor::withBias(const Tensor& b) const {
        const shape_type& sh = dims();
        if (sh.empty())
            throw std::invalid_argument("withBias: 本张量为 0 阶，无“最后维”可广播");
        const size_t lastDim = sh.back();
        if (b.dims().size() != 1 || b.dims()[0] != lastDim)
            throw std::invalid_argument("withBias: b 须为 1 维且长度等于本张量最后维尺寸");
        auto out = makeDense(sh, GGML_TYPE_F32);         // 结果一律 F32
        index_type idx(sh.size(), 0);
        do {
            const size_t c = idx.back();
            out->set(idx, static_cast<compute_type>(this->get(idx) + b.get(c)));
        } while (advanceIndex(idx, sh));
        return out;
    }

    // ----------------------------------------------------------------------------
    // B 类 · 归约实现
    //   reduceDimTo：沿 dim 塌缩归约的通用内核（sum/mean/max/norm/var 复用）。
    //   reduceAll：整张量 → 标量。argmax/softmax：专用（索引 / 稳定归一化）。
    // ----------------------------------------------------------------------------
    template <typename Acc, typename Comb, typename Final>
    inline std::unique_ptr<Tensor> Tensor::reduceDimTo(int dim, Acc init, Comb comb, Final fin) const {
        const shape_type& sh = dims();
        const int R = static_cast<int>(sh.size());
        if (dim < 0 || dim >= R)
            throw std::invalid_argument("reduceDim: dim 越界");
        shape_type osh = sh;
        osh[dim] = 1;                       // 该维塌缩为 1
        auto out = makeDense(osh, GGML_TYPE_F32);
        index_type oidx(static_cast<size_t>(R), 0);
        do {
            Acc acc = init;
            const size_t L = sh[dim];
            for (size_t j = 0; j < L; ++j) {
                index_type iidx = oidx;     // 拷贝输出多索引
                iidx[dim] = j;              // 在归约维上滑动
                acc = comb(acc, this->get(iidx));
            }
            out->set(oidx, static_cast<compute_type>(fin(acc)));
        } while (advanceIndex(oidx, osh));
        return out;
    }

    inline Tensor::compute_type Tensor::reduceAll(ReductionOp op) const {
        const shape_type& sh = dims();
        compute_type acc;
        switch (op) {
        case ReductionOp::Sum:   acc = 0; break;
        case ReductionOp::Mean:  acc = 0; break;
        case ReductionOp::L2:    acc = 0; break;
        case ReductionOp::Prod:  acc = 1; break;
        case ReductionOp::Max:   acc = std::numeric_limits<compute_type>::lowest(); break;
        case ReductionOp::Min:   acc = std::numeric_limits<compute_type>::max();   break;
        default: throw std::invalid_argument("reduceAll: 未知 ReductionOp");
        }
        size_t n = 0;
        index_type idx(sh.size(), 0);
        do {
            compute_type v = this->get(idx);
            switch (op) {
            case ReductionOp::Sum:  acc += v; break;
            case ReductionOp::Mean: acc += v; break;
            case ReductionOp::Prod: acc *= v; break;
            case ReductionOp::Max:  acc = std::max(acc, v); break;
            case ReductionOp::Min:  acc = std::min(acc, v); break;
            case ReductionOp::L2:   acc += v * v; break;
            }
            ++n;
        } while (advanceIndex(idx, sh));
        if (op == ReductionOp::Mean) acc = (n > 0) ? acc / static_cast<compute_type>(n) : 0;
        if (op == ReductionOp::L2)   acc = std::sqrt(acc);
        return acc;
    }

    inline std::unique_ptr<Tensor> Tensor::sum(int dim) const {
        return reduceDimTo(dim, compute_type{0},
            [](float a, float b) { return a + b; },
            [](float a) { return a; });
    }
    inline std::unique_ptr<Tensor> Tensor::mean(int dim) const {
        const size_t n = dims()[dim];
        return reduceDimTo(dim, compute_type{0},
            [](float a, float b) { return a + b; },
            [n](float a) { return a / static_cast<compute_type>(n); });
    }
    inline std::unique_ptr<Tensor> Tensor::max(int dim) const {
        return reduceDimTo(dim, std::numeric_limits<compute_type>::lowest(),
            [](float a, float b) { return std::max(a, b); },
            [](float a) { return a; });
    }
    inline std::unique_ptr<Tensor> Tensor::norm(int dim) const {
        return reduceDimTo(dim, compute_type{0},
            [](float a, float b) { return a + b * b; },
            [](float a) { return std::sqrt(a); });
    }
    inline std::unique_ptr<Tensor> Tensor::var(int dim) const {
        // 总体方差：(1/N)Σ(x-μ)² = (1/N)Σx² - μ²，单趟累加 sum 与 sumsq。
        struct Acc { float s; float s2; };
        const size_t n = dims()[dim];
        return reduceDimTo(dim, Acc{0, 0},
            [](Acc a, float b) { a.s += b; a.s2 += b * b; return a; },
            [n](Acc a) {
                const float m = a.s / static_cast<compute_type>(n);
                float v = a.s2 / static_cast<compute_type>(n) - m * m;
                return v < 0 ? 0.0f : v;   // 浮点负数归零
            });
    }

    inline std::unique_ptr<Tensor> Tensor::argmax(int dim) const {
        const shape_type& sh = dims();
        const int R = static_cast<int>(sh.size());
        if (dim < 0 || dim >= R)
            throw std::invalid_argument("argmax: dim 越界");
        shape_type osh = sh;
        osh[dim] = 1;                       // 该维塌缩为 1
        auto out = makeDense(osh, GGML_TYPE_F32);   // 整数索引以 float 承载
        index_type oidx(static_cast<size_t>(R), 0);
        do {
            float best = std::numeric_limits<float>::lowest();
            size_t bestIdx = 0;
            const size_t L = sh[dim];
            for (size_t j = 0; j < L; ++j) {
                index_type iidx = oidx;
                iidx[dim] = j;
                const float v = this->get(iidx);
                if (j == 0 || v > best) { best = v; bestIdx = j; }
            }
            out->set(oidx, static_cast<compute_type>(bestIdx));
        } while (advanceIndex(oidx, osh));
        return out;
    }

    inline std::unique_ptr<Tensor> Tensor::softmax(int dim) const {
        const shape_type& sh = dims();
        const int R = static_cast<int>(sh.size());
        if (dim < 0 || dim >= R)
            throw std::invalid_argument("softmax: dim 越界");
        auto out = makeDense(sh, GGML_TYPE_F32);   // 同形，不塌缩
        index_type oidx(static_cast<size_t>(R), 0);
        do {
            const size_t L = sh[dim];
            // 1) 该切片最大值（数值稳定）
            float mx = std::numeric_limits<float>::lowest();
            for (size_t j = 0; j < L; ++j) {
                index_type iidx = oidx; iidx[dim] = j;
                const float v = this->get(iidx);
                if (j == 0 || v > mx) mx = v;
            }
            // 2) Σ exp(x - mx)
            float sum = 0;
            for (size_t j = 0; j < L; ++j) {
                index_type iidx = oidx; iidx[dim] = j;
                sum += std::exp(this->get(iidx) - mx);
            }
            // 3) 写回 exp(x - mx) / sum
            for (size_t j = 0; j < L; ++j) {
                index_type iidx = oidx; iidx[dim] = j;
                out->set(iidx, static_cast<compute_type>(std::exp(this->get(iidx) - mx) / sum));
            }
        } while (advanceIndex(oidx, sh));
        return out;
    }

    // C.1 matvec —— 向量 × 矩阵：y = W·x（this 视为 [M, N]，x 为 [N] 向量，返回 [M]）
    // 三路径：量化融合（vec_dot 现场 dequant 累加）/ F32 连续快路径 / 通用逐元素兜底（视图安全）。
    inline std::unique_ptr<Tensor> Tensor::matvec(const Tensor& x) const 
    {
        if (rank() != 2)
            throw std::invalid_argument("matvec: 权重须为 2 阶 [M,N]（this 视为权重矩阵 W）");
        if (x.rank() != 1)
            throw std::invalid_argument("matvec: 输入 x 须为 1 阶向量 [N]");
        const size_t M = shape_[0];
        const size_t N = shape_[1];
        if (x.capacity() != N)
            throw std::invalid_argument("matvec: 输入 x 长度须等于权重列数 N");
        const auto& q = traitsOf(type_);
        if (q.blck_size > 1 && N % q.blck_size != 0)
            throw std::invalid_argument("matvec: 量化权重列数 N 须为 blck_size 的整数倍（大模型词表/权重常 32 对齐）");

        // x 统一读成 F32（x 本身可能量化，get 自动 dequant 到 float）
        std::vector<float> xf(N);
        for (size_t j = 0; j < N; ++j) xf[j] = x.get(j);

        auto y = makeDense(Tensor::shape_type{ M }, GGML_TYPE_F32);   // 结果 [M]，F32（中间结果不回量化）
        float* yp = static_cast<float*>(y->data());

        const size_t rowBytes  = bufferBytes(N, type_);
        // 量化下 nb_[0] 以“块字节”为单位（nb_[0] = IN * blck_bytes），物理行步长须除以 blck_size 才等于
        // 实际一行字节数 rowBytes；F32（blck_size=1）下 nb_[0]==rowBytes，无回归。修正后量化 2D 权重
        // 才能进入 vec_dot 融合路径（否则永远退化为逐元素 get 慢路径）。
        const size_t rowStride = (q.blck_size > 1) ? nb_[0] / q.blck_size : nb_[0];
        const bool   rowContig = (rowStride == rowBytes);   // 行在缓冲中连续（稠密矩阵 / 恒等视图）

        if (q.vec_dot != nullptr && rowContig) {
            // —— 量化融合路径：逐行现场 dequant 累加，绝不物化整张 F32 权重矩阵（呼应第 12 节）——
            const uint8_t* base = static_cast<const uint8_t*>(data_);
            for (size_t i = 0; i < M; ++i)
                yp[i] = q.vec_dot(base + i * rowBytes, xf.data(), N);
        } else if (type_ == GGML_TYPE_F32 && rowContig) {
            // —— F32 快路径：float* 行指针 + x 浮点指针累加（连续行，逐行顺序访存）——
            const float* base = static_cast<const float*>(data_);
            for (size_t i = 0; i < M; ++i) {
                const float* wp = base + i * (nb_[0] / 4);   // nb_[0] == N*4，整行连续 F32
                float s = 0.0f;
                for (size_t j = 0; j < N; ++j) s += wp[j] * xf[j];
                yp[i] = s;
            }
        } else {
            // —— 通用正确路径（标量非 F32 / 非连续视图）：逐元素 get（访问层零虚面，视图安全）——
            //   注：量化张量走此兜底时会逐元素 dequant（未走融合内核），仅作非连续场景的安全退路。
            for (size_t i = 0; i < M; ++i) {
                float s = 0.0f;
                for (size_t j = 0; j < N; ++j) s += get({ i, j }) * xf[j];
                yp[i] = s;
            }
        }
        return y;
    }

    // C.2 matmul —— 矩阵 × 矩阵：C = A·B（this = A:[M,K]，B = [K,N]，返回 C:[M,N] F32）
    // 三路径：量化融合（拆成 N 次 GEMV，逐列 vec_dot 现场 dequant）/ F32 直算快路径 / 通用逐元素兜底（视图安全）。
    inline std::unique_ptr<Tensor> Tensor::matmul(const Tensor& B) const {
        if (rank() != 2)
            throw std::invalid_argument("matmul: A 须为 2 阶 [M,K]（this 视为左矩阵 A）");
        if (B.rank() != 2)
            throw std::invalid_argument("matmul: B 须为 2 阶 [K,N]");
        const size_t M = shape_[0];
        const size_t K = shape_[1];
        if (B.shape_[0] != K)
            throw std::invalid_argument("matmul: A 列数(K) 须等于 B 行数(K)");
        const size_t N = B.shape_[1];
        const auto& q = traitsOf(type_);
        if (q.blck_size > 1 && K % q.blck_size != 0)
            throw std::invalid_argument("matmul: 量化 A 的内维 K 须为 blck_size 的整数倍（大模型权重常 32 对齐）");

        auto C = makeDense(Tensor::shape_type{ M, N }, GGML_TYPE_F32);   // 结果 [M,N]，F32（中间结果不回量化）
        float* Cp = static_cast<float*>(C->data());

        const size_t aRowBytes = bufferBytes(K, type_);
        const size_t aStride    = (q.blck_size > 1) ? nb_[0] / q.blck_size : nb_[0];   // 物理行步长（量化下除以 blck_size）
        const bool  aContig    = (aStride == aRowBytes);   // A 行连续（稠密矩阵 / 恒等视图）
        const size_t bRowBytes = bufferBytes(N, B.type_);
        const bool  bContig    = (B.nb_[0] == bRowBytes); // B 行连续

        if (q.vec_dot != nullptr && aContig) {
            // —— 量化融合路径：matmul 拆成 N 次 GEMV（逐输出列取 x = B 的第 j 列）——
            //   每列 x 仅提取一次（可量化 B 经 get 自动 dequant 到 float）；对 A 每一行块调 vec_dot 现场累加，
            //   不物化整张 F32 权重矩阵（呼应第 12 节，与 matvec 同内核）。
            const uint8_t* Abase = static_cast<const uint8_t*>(data_);
            std::vector<float> xf(K);
            for (size_t j = 0; j < N; ++j) {
                for (size_t k = 0; k < K; ++k) xf[k] = B.get({ k, j });   // B 第 j 列（F32；B 量化时 get 自动 dequant）
                for (size_t i = 0; i < M; ++i)
                    Cp[i * N + j] = q.vec_dot(Abase + i * aRowBytes, xf.data(), K);
            }
        } else if (type_ == GGML_TYPE_F32 && B.type_ == GGML_TYPE_F32 && aContig && bContig) {
            // —— F32 直算快路径：连续行 + float* 指针三循环（i 外层 / k 中层 / j 内层，cache 友好）——
            const float* Af = static_cast<const float*>(data_);
            const float* Bf = static_cast<const float*>(B.data_);
            for (size_t i = 0; i < M; ++i) {
                const float* Ar = Af + i * K;          // A 第 i 行（连续）
                float* Cr = Cp + i * N;                // C 第 i 行（连续）
                for (size_t k = 0; k < K; ++k) {
                    const float a = Ar[k];
                    const float* Bk = Bf + k * N;      // B 第 k 行（连续）
                    for (size_t j = 0; j < N; ++j) Cr[j] += a * Bk[j];
                }
            }
        } else {
            // —— 通用兜底（标量非 F32 / 非连续视图 / B 量化等）：逐元素 get 三循环（视图安全，结果 F32）——
            for (size_t i = 0; i < M; ++i)
                for (size_t j = 0; j < N; ++j) {
                    float s = 0.0f;
                    for (size_t k = 0; k < K; ++k) s += get({ i, k }) * B.get({ k, j });
                    Cp[i * N + j] = s;
                }
        }
        return C;
    }

    // D.1 bmm —— 批矩阵乘（多头注意力核心）：C = A·B，A:[B,M,K] × B:[B,K,N] → [B,M,N] F32。
    // 三路径（与 matmul 同内核，按批拆成 GEMV/GEMM）：量化融合（逐批 N 次 GEMV，vec_dot 现场 dequant）/
    //   F32 直算快路径 / 通用逐元素兜底（视图安全）。Q 权重同样走 vec_dot 融合。
    inline std::unique_ptr<Tensor> Tensor::bmm(const Tensor& B) const {
        if (rank() != 3)
            throw std::invalid_argument("bmm: this 须为 3 阶 [B,M,K]（视为批权重 A）");
        if (B.rank() != 3)
            throw std::invalid_argument("bmm: B 须为 3 阶 [B,K,N]");
        const size_t Ba = shape_[0], M = shape_[1], K = shape_[2];
        const size_t Bb = B.shape_[0], Kb = B.shape_[1], N = B.shape_[2];
        if (Ba != Bb)
            throw std::invalid_argument("bmm: 批维度须一致（A 轴0 == B 轴0）");
        if (K != Kb)
            throw std::invalid_argument("bmm: A 列(K) 须等于 B 行(K)");
        const auto& q = traitsOf(type_);
        if (q.blck_size > 1 && K % q.blck_size != 0)
            throw std::invalid_argument("bmm: 量化 A 的内维 K 须为 blck_size 的整数倍");

        auto C = makeDense(Tensor::shape_type{ Ba, M, N }, GGML_TYPE_F32);   // 结果 [B,M,N]，F32
        float* Cp = static_cast<float*>(C->data());

        const size_t aRowBytes  = bufferBytes(K, type_);   // A 单行(K)物理字节数
        const size_t aRowStride   = (q.blck_size > 1) ? nb_[1] / q.blck_size : nb_[1];   // 物理行步长（轴1）
        const size_t aBatchStride = (q.blck_size > 1) ? nb_[0] / q.blck_size : nb_[0];   // 物理批步长（轴0）
        // 完全连续（批/行均连续）方可走快路径/融合路径：批步长须 == M×行字节，行步长须 == 行字节。
        const bool   aContig    = (aRowStride == aRowBytes) && (aBatchStride == M * aRowBytes);
        const size_t bRowBytes  = bufferBytes(N, B.type_);
        const bool   bContig    = (B.nb_[0] == K * bRowBytes) && (B.nb_[1] == bRowBytes);

        if (q.vec_dot != nullptr && aContig) {
            // —— 量化融合路径：逐批拆 N 次 GEMV，A 每行块调 vec_dot 现场 dequant 累加，不物化整张 F32 ——
            const uint8_t* Abase = static_cast<const uint8_t*>(data_);
            const size_t aBatchBytes = aBatchStride;   // 物理批间字节步长（== M × aRowBytes，已校验）
            std::vector<float> xf(K);
            for (size_t b = 0; b < Ba; ++b) {
                for (size_t n = 0; n < N; ++n) {
                    for (size_t k = 0; k < K; ++k) xf[k] = B.get({ b, k, n });  // B 第 n 列（可量化，get 自动 dequant）
                    for (size_t m = 0; m < M; ++m)
                        Cp[(b * M + m) * N + n] = q.vec_dot(Abase + b * aBatchBytes + m * aRowBytes, xf.data(), K);
                }
            }
        } else if (type_ == GGML_TYPE_F32 && B.type_ == GGML_TYPE_F32 && aContig && bContig) {
            // —— F32 直算快路径：float* 四循环（b / m / n / k，连续访存）——
            const float* Af = static_cast<const float*>(data_);
            const float* Bf = static_cast<const float*>(B.data_);
            for (size_t b = 0; b < Ba; ++b) {
                for (size_t m = 0; m < M; ++m) {
                    for (size_t n = 0; n < N; ++n) {
                        float s = 0.0f;
                        for (size_t k = 0; k < K; ++k)
                            s += Af[(b * M + m) * K + k] * Bf[(b * K + k) * N + n];
                        Cp[(b * M + m) * N + n] = s;
                    }
                }
            }
        } else {
            // —— 通用兜底（标量非 F32 / 非连续视图 / B 量化等）：逐元素 get 三循环（视图安全，结果 F32）——
            for (size_t b = 0; b < Ba; ++b)
                for (size_t m = 0; m < M; ++m)
                    for (size_t n = 0; n < N; ++n) {
                        float s = 0.0f;
                        for (size_t k = 0; k < K; ++k) s += get({ b, m, k }) * B.get({ b, k, n });
                        Cp[(b * M + m) * N + n] = s;
                    }
        }
        return C;
    }

    // D.2 gather —— 索引取片（Embedding 查表原语）：沿 axis 按 indices 取值。
    //   输出形状 = this.shape[0..axis-1] ++ indices.shape ++ this.shape[axis+1..]（与 tf.gather 一致）；
    //   输出 (o_prefix, i_idx, o_suffix) = this (o_prefix, g, o_suffix)，g = indices[i_idx]（整数下标）。
    //   一次性物化为独立缓冲（与 ggml_get_rows 同为算子而非 view；非等距重排故物化，不进 get/set 热路径，
    //   呼应访问层零虚面红线）。输出沿用源 type_（量化表仍按块拷）；indices 越界抛 std::out_of_range。
    inline std::unique_ptr<Tensor> Tensor::gather(const Tensor& indices, int axis) const {
        const shape_type& sd = dims();
        const int R = static_cast<int>(sd.size());
        if (R == 0)
            throw std::invalid_argument("gather: 源张量不可为 0 阶");
        if (axis < 0 || axis >= R)
            throw std::invalid_argument("gather: axis 越界");
        const shape_type& id = indices.dims();
        const size_t S = id.size();
        if (S == 0)
            throw std::invalid_argument("gather: indices 不可为 0 阶");

        // 输出形状 = 前缀(this[0..axis-1]) ++ indices.shape ++ 后缀(this[axis+1..])
        shape_type out_shape;
        out_shape.reserve(R - 1 + S);
        for (int k = 0; k < axis; ++k) out_shape.push_back(sd[k]);
        for (size_t v : id) out_shape.push_back(v);
        for (int k = axis + 1; k < R; ++k) out_shape.push_back(sd[k]);

        auto out = makeDense(out_shape, type());
        const size_t axisDim = sd[axis];

        index_type out_idx(out_shape.size(), 0);
        index_type o_pre(axis, 0);
        index_type i_idx(S, 0);
        index_type o_suf(R - axis - 1, 0);
        index_type src(R, 0);
        do {
            // 拆 out_idx -> (o_pre [axis], i_idx [S], o_suf [R-axis-1])
            for (int k = 0; k < axis; ++k) o_pre[k] = out_idx[k];
            for (size_t k = 0; k < S; ++k) i_idx[k] = out_idx[axis + k];
            for (int k = 0; k < (R - axis - 1); ++k) o_suf[k] = out_idx[axis + S + k];
            const size_t g = static_cast<size_t>(std::lround(indices.get(i_idx)));
            if (g >= axisDim)
                throw std::out_of_range("gather: indices 中存在越界下标");
            // 拼源下标 = o_pre ++ [g] ++ o_suf
            src[axis] = g;
            for (int k = 0; k < axis; ++k) src[k] = o_pre[k];
            for (int k = 0; k < (R - axis - 1); ++k) src[axis + 1 + k] = o_suf[k];
            out->set(out_idx, this->get(src));
        } while (advanceIndex(out_idx, out_shape));
        return out;
    }

    // D.3 dequantize —— 量化桥：Q → 新 F32 张量（整张解量化）。
    //   经基类非虚 get（Q 类型自动 dequant 到 float）逐元素拷入新建 F32 稠密张量；
    //   对视图/别名也正确（get 走 offset 纯算术）。F32/标量源等价返回 F32 副本。
    inline std::unique_ptr<Tensor> Tensor::dequantize() const {
        auto out = makeDense(shape_, GGML_TYPE_F32);   // 同形 F32 副本
        index_type idx(shape_.size(), 0);
        do { out->set(idx, this->get(idx)); } while (advanceIndex(idx, shape_));
        return out;
    }

    // D.4 quantizeTo —— 量化桥：任意源 → 目标 Q 类型（逐块量化）。
    //   新建目标类型 t 的稠密张量（形状同 this），逐块（每 blck_size 个元素、按元素序）调 QuantTraits::quant
    //     写入；对视图/别名输入也正确（get 把任意源布局归一到元素序，输出写入元素序的密集缓冲）。
    //   t 须为已适配的量化类型（否则 traitsOf 抛错）；元素数须为 t.blck_size 整数倍（否则抛 std::invalid_argument）。
    inline std::unique_ptr<Tensor> Tensor::quantizeTo(ggml_type t) const {
        const auto& qt = traitsOf(t);
        if (qt.blck_size == 1)
            throw std::invalid_argument("quantizeTo: 目标类型非量化类型（blck_size==1）");
        const size_t n = count_;
        if (n % qt.blck_size != 0)
            throw std::invalid_argument("quantizeTo: 元素数须为目标块大小的整数倍");
        auto out = makeDense(shape_, t);          // 目标类型、按块分配缓冲
        float buf[QK_MAX];
        uint8_t* outp = static_cast<uint8_t*>(out->data());
        size_t e = 0, blk = 0;
        index_type idx(shape_.size(), 0);
        do {
            buf[e % qt.blck_size] = static_cast<float>(this->get(idx));
            if ((e + 1) % qt.blck_size == 0) {     // 填满一块 -> 量化写入
                qt.quant(buf, outp + blk * qt.blck_bytes);
                ++blk;
            }
            ++e;
        } while (advanceIndex(idx, shape_));
        return out;
    }

// Tensor::permute 默认实现：构造 PermuteView（定义在 PermuteView 完整类型之后）
inline std::unique_ptr<Tensor> Tensor::permute(const index_type& perm) {
    return std::make_unique<PermuteView>(this, perm);
}

// ============================================================================
// 【实验性】GatherMatrixView —— 独立的「按行 gather」只读视图（零拷贝、无基类）
//
// 与之前删除的 GatherView 的本质区别：
//   * 不从 Matrix / Tensor 派生，也没有任何基类；是一个【完全独立】的轻量视图类。
//   * 构造时接收一个 const Matrix& 与一个「行号列表」ids：
//       - 内部 const Matrix* src_ 引用 Matrix（只读别名其数据块，零拷贝、不分配缓冲）；
//       - 维护一个【可变】的 std::vector<size_t> row_ids_，row_ids_[i] 表示
//         第 i 个“逻辑行”对应 Matrix 的【物理行】row_ids_[i]。
//   * 行访问：本视图提供两种行访问形态——
//       (a) 按元素：get(i,j) / operator()(i,j) 经 Matrix::get 直接定位 (row_ids_[i], j)；
//       (b) 整行视图：operator()(i) 返回指向物理行 row_ids_[i] 的 VectorView（零拷贝别名）。
//       VectorView 强制 owns_data_ = false，析构绝不会释放被引用 Matrix 的行数据（消除
//       “别名误删源”风险）；其底层仍是 Matrix 的 stride 布局，行独立、不交叉。
//       整行视图仅在“行长恰为块对齐（大模型词表 32 对齐）”时可零拷贝别名，否则 Matrix::row 抛错。
//   * 访问（全部只读）：
//       - operator()(i)      一元：返回第 i 个逻辑行的 VectorView 行视图（零拷贝只读，不拥有缓冲）；
//       - operator()(i, j)   二元：返回 (i 逻辑行, j 列) 元素的只读值（float）；
//       - get(i, j)          读取元素（与 operator()(i,j) 同语义，提供 get 形式的只读访问）；
//       - 【不提供 set()】：这是只读别名，写回会破坏被引用的 Matrix，故刻意不提供。
//   * 数据类型自适应：整行视图委托 Matrix::row（按 type_ 别名整行字节），
//       元素访问委托 Matrix::get（经 Tensor 既有 readElem 逻辑），
//       因此 F32 / F16 / 标量 / 6 种量化类型均可正确读出。
//   * 行列表可变：构造后可经 setRowIds() / rowId(i) / remap() / Add 修改映射（例如在线重排 token 顺序），
//       无需重新分配，修改后立即反映到下一次 get(i,j) / operator()(i,j) 的返回值。
//
// 注意：本类刻意独立于 Tensor 体系，仅为实验「零拷贝 gather 视图」语义而存在；
//       它不属于推理主链路的 Tensor 访问层，因此不触及“访问层零虚面、非虚 get/set”的设计红线。
//       其只读别名特性意味着：被引用 Matrix 必须在视图存活期间保持有效，且不可被移动/重分配。
// ============================================================================
class GatherMatrixView {
public:
    using compute_type = float;   // 与 Tensor::compute_type 保持一致（宿主计算标量）

    // 构造：引用一个 Matrix，并给出一个行号列表（每个元素是被 gather 的“物理行”）。
    // 要求：每个 id 必须 < src.rows()，否则抛 std::out_of_range。
    // 前置：Matrix 行主序、按坐标 pure 算术定位（offset 经 nb_ 字节步长）；
    //       读元素统一走 get({row_ids_[i], j})，F32 / 标量 / 量化类型均经 readElem 正确读出。
    GatherMatrixView(const Matrix& src, const std::vector<size_t>& rowIds)
        : src_(&src)
    {
        row_ids_.reserve(rowIds.size());
        for (size_t id : rowIds) {
            if (id >= src.rows())
                throw std::out_of_range("GatherMatrixView: 行号越界（>= 源行数）");
            row_ids_.push_back(id);
        }
    }

    // 逻辑行数 = 行号列表长度；列数 = 引用 Matrix 的列数
    size_t rows() const { return row_ids_.size(); }
    size_t cols() const { return src_->cols(); }

    // —— 一元：返回第 i 个逻辑行的只读“行视图”VectorView（零拷贝别名，不拥有缓冲）——
    // 直接复用 Matrix::row 返回的 VectorView：指向 src_ 物理行 row_ids_[i] 的字节，不做拷贝。
    // 该 VectorView 在构造时捕获物理行号，故本次调用后改 row_ids_ 不影响已返回的视图读值。
    VectorView operator()(size_t i) const {
        if (i >= row_ids_.size())
            throw std::out_of_range("GatherMatrixView::operator(): 逻辑行越界");
        return src_->row(row_ids_[i]);
    }

    // —— 二元：返回 (i 逻辑行, j 列) 的只读元素值（数据类型自适应）——
    compute_type operator()(size_t i, size_t j) const {
        return get(i, j);
    }

    // 只读 get()：与 operator()(i,j) 同语义（用户要求“可重写 get()”）。
    // 委托 Matrix::get，F32/标量/量化统一正确；本类独立，不覆盖任何基类虚函数。
    compute_type get(size_t i, size_t j) const {
        if (i >= row_ids_.size())
            throw std::out_of_range("GatherMatrixView::get: 逻辑行越界");
        if (j >= src_->cols())
            throw std::out_of_range("GatherMatrixView::get: 列越界");
        return src_->get({ row_ids_[i], j });
    }

    // —— 行列表可变接口（构造后可在线改映射，无需重分配）——
    const std::vector<size_t>& rowIds() const { return row_ids_; }
    size_t& rowId(size_t i) { return row_ids_[i]; }        // 直接改某一项
    void remap(size_t i, size_t physRow) {                 // 把逻辑行 i 改指物理行 physRow
        if (physRow >= src_->rows())
            throw std::out_of_range("GatherMatrixView::remap: 物理行越界");
        row_ids_[i] = physRow;
    }
    void setRowIds(const std::vector<size_t>& ids) {       // 整体替换（重校验）
        if (ids.size() != row_ids_.size())
            throw std::invalid_argument("GatherMatrixView::setRowIds: 新列表长度须与原列表一致");
        for (size_t id : ids)
            if (id >= src_->rows())
                throw std::out_of_range("GatherMatrixView::setRowIds: 行号越界");
        row_ids_ = ids;
    }
    void Add(const size_t idx) {                                  // 追加一条物理行号，逻辑行数 +1
        if (idx >= src_->rows())
            throw std::out_of_range("GatherMatrixView::Add: 物理行越界");
        row_ids_.push_back(idx);
    }

    // 只读别名查看：直接看到被引用 Matrix 的数据块与类型
    const void* data()  const { return src_->data(); }
    ggml_type   type()  const { return src_->type(); }

    // 注意：本类【不提供 set / writeElem】。写回会破坏被引用的 Matrix，属未定义行为。

private:
    const Matrix*          src_;        // 被引用 Matrix（只读别名其数据块）
    std::vector<size_t>    row_ids_;    // 【可变】行映射表：row_ids_[i] = 第 i 逻辑行对应的物理行
};

} // namespace wb
