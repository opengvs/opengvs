#pragma once
// ============================================================================
// tensor10.h —— Tensor 类层次结构示例（裸指针 + 内存池友好 + ggml_type 类型标签）
// 与上一版的差别：表示tensor类的1.0版本
//   * 引入 ggml 的 enum ggml_type，作为“张量存储数据类型”的格式标签。
//   * 基类新增 type_ 成员与 type() 访问器；各子类构造时均可指定 ggml_type。
//   * 提供 ggml_type_name() 打印枚举名、ggml_type_size() 取单元素字节数，
//     与 ggml 的 API 命名保持一致，便于后续对接 llama.cpp。
// 设计说明：
//   * 这里 data_ 是 compute_type(当前为 float/F32) 的计算缓冲（方便 operator() 直接返回引用）；
//     type_ 记录“声明/序列化时的数据类型”，用于量化格式识别、GGUF 读写、
//     以及与 ggml_tensor 互转。若要做到“真正按该类型存字节”，需把 data_
//     改为 void* 并提供按类型的访问器（见文末说明，可下一步做）。
// ============================================================================
#include <vector>
#include <stdexcept>
#include <memory>
#include <string>
#include <initializer_list>
#include <cstddef>
#include <cstdint>
#include <sstream>
#include <array>

namespace wb {

    // ----------------------------------------------------------------------------
    // ggml_type：张量元素的存储数据类型（与 llama.cpp/ggml 保持一致）
    // 如项目已 #include "ggml.h"，可删除本枚举并写 `using ::ggml_type;`
    // ----------------------------------------------------------------------------
    enum ggml_type {
        GGML_TYPE_F32 = 0,
        GGML_TYPE_F16 = 1,
        GGML_TYPE_Q4_0 = 2,
        GGML_TYPE_Q4_1 = 3,
        // GGML_TYPE_Q4_2 = 4, support has been removed
        // GGML_TYPE_Q4_3 = 5, support has been removed
        GGML_TYPE_Q5_0 = 6,
        GGML_TYPE_Q5_1 = 7,
        GGML_TYPE_Q8_0 = 8,
        GGML_TYPE_Q8_1 = 9,
        GGML_TYPE_Q2_K = 10,
        GGML_TYPE_Q3_K = 11,
        GGML_TYPE_Q4_K = 12,
        GGML_TYPE_Q5_K = 13,
        GGML_TYPE_Q6_K = 14,
        GGML_TYPE_Q8_K = 15,
        GGML_TYPE_IQ2_XXS = 16,
        GGML_TYPE_IQ2_XS = 17,
        GGML_TYPE_IQ3_XXS = 18,
        GGML_TYPE_IQ1_S = 19,
        GGML_TYPE_IQ4_NL = 20,
        GGML_TYPE_IQ3_S = 21,
        GGML_TYPE_IQ2_S = 22,
        GGML_TYPE_IQ4_XS = 23,
        GGML_TYPE_I8 = 24,
        GGML_TYPE_I16 = 25,
        GGML_TYPE_I32 = 26,
        GGML_TYPE_I64 = 27,
        GGML_TYPE_F64 = 28,
        GGML_TYPE_IQ1_M = 29,
        GGML_TYPE_BF16 = 30,
        // GGML_TYPE_Q4_0_4_4 = 31, support has been removed from gguf files
        // GGML_TYPE_Q4_0_4_8 = 32,
        // GGML_TYPE_Q4_0_8_8 = 33,
        GGML_TYPE_TQ1_0 = 34,
        GGML_TYPE_TQ2_0 = 35,
        // GGML_TYPE_IQ4_NL_4_4 = 36,
        // GGML_TYPE_IQ4_NL_4_8 = 37,
        // GGML_TYPE_IQ4_NL_8_8 = 38,
        GGML_TYPE_MXFP4 = 39, // MXFP4 (1 block)
        GGML_TYPE_NVFP4 = 40, // NVFP4 (4 blocks, E4M3 scale)
        GGML_TYPE_Q1_0 = 41,
        GGML_TYPE_Q2_0 = 42,
        GGML_TYPE_COUNT = 43,
    };

    // 枚举名 -> 字符串（C++ 枚举无内建名字反射）
    inline const char* ggml_type_name(ggml_type t) {
        switch (t) {
        case GGML_TYPE_F32:     return "F32";
        case GGML_TYPE_F16:     return "F16";
        case GGML_TYPE_Q4_0:    return "Q4_0";
        case GGML_TYPE_Q4_1:    return "Q4_1";
        case GGML_TYPE_Q5_0:    return "Q5_0";
        case GGML_TYPE_Q5_1:    return "Q5_1";
        case GGML_TYPE_Q8_0:    return "Q8_0";
        case GGML_TYPE_Q8_1:    return "Q8_1";
        case GGML_TYPE_Q2_K:    return "Q2_K";
        case GGML_TYPE_Q3_K:    return "Q3_K";
        case GGML_TYPE_Q4_K:    return "Q4_K";
        case GGML_TYPE_Q5_K:    return "Q5_K";
        case GGML_TYPE_Q6_K:    return "Q6_K";
        case GGML_TYPE_Q8_K:    return "Q8_K";
        case GGML_TYPE_IQ2_XXS: return "IQ2_XXS";
        case GGML_TYPE_IQ2_XS:  return "IQ2_XS";
        case GGML_TYPE_IQ3_XXS: return "IQ3_XXS";
        case GGML_TYPE_IQ1_S:   return "IQ1_S";
        case GGML_TYPE_IQ4_NL:  return "IQ4_NL";
        case GGML_TYPE_IQ3_S:   return "IQ3_S";
        case GGML_TYPE_IQ2_S:   return "IQ2_S";
        case GGML_TYPE_IQ4_XS:  return "IQ4_XS";
        case GGML_TYPE_I8:      return "I8";
        case GGML_TYPE_I16:     return "I16";
        case GGML_TYPE_I32:     return "I32";
        case GGML_TYPE_I64:     return "I64";
        case GGML_TYPE_F64:     return "F64";
        case GGML_TYPE_IQ1_M:   return "IQ1_M";
        case GGML_TYPE_BF16:    return "BF16";
        case GGML_TYPE_TQ1_0:   return "TQ1_0";
        case GGML_TYPE_TQ2_0:   return "TQ2_0";
        case GGML_TYPE_MXFP4:   return "MXFP4";
        case GGML_TYPE_NVFP4:   return "NVFP4";
        case GGML_TYPE_Q1_0:    return "Q1_0";
        case GGML_TYPE_Q2_0:    return "Q2_0";
        case GGML_TYPE_COUNT:   return "COUNT";
        default:                return "UNKNOWN";
        }
    }

    // 单元素字节数（仅标量类型准确；量化类型按块存储，其 block size 见 ggml.c:ggml_type_size）
    inline size_t ggml_type_size(ggml_type t) {
        switch (t) {
        case GGML_TYPE_F32: return 4;
        case GGML_TYPE_F16: return 2;
        case GGML_TYPE_BF16: return 2;
        case GGML_TYPE_F64: return 8;
        case GGML_TYPE_I8:  return 1;
        case GGML_TYPE_I16: return 2;
        case GGML_TYPE_I32: return 4;
        case GGML_TYPE_I64: return 8;
        default:            return 0; // 量化 / MXFP4 / NVFP4 等：块结构，需查 ggml.c
        }
    }

    // ----------------------------------------------------------------------------
    // Axis：张量命名轴（代替裸数字下标，使转置 / 轴重排更直观）
    //   枚举值即轴序号：axisX=0, axisY=1, axisZ=2, axisW=3
    //   在生成 PermuteView 视图时优先用命名轴，可读性更好：
    //     矩阵转置        = permute({axisY, axisX})
    //     三阶轴轮转      = permute({axisZ, axisX, axisY})
    //     四阶后两块提前  = permute({axisZ, axisY, axisX, axisW})
    //   注意：更高维可继续扩展（如 axisV=4 ...），上限受 GGML_MAX_DIMS=4 约束。
    // ----------------------------------------------------------------------------
    enum Axis : size_t {
        axisX = 0,
        axisY = 1,
        axisZ = 2,
        axisW = 3,
    };

    // ----------------------------------------------------------------------------
    class Tensor {
    public:
        using compute_type = float;    // 宿主标量类型：F32(32-bit float)，上转后参与运算/接口用的类型（与 ggml_type 存储格式区分）
        using shape_type = std::vector<size_t>;   // 各维尺寸，如 [m, n]
        using index_type = std::vector<size_t>;   // 多索引，如 {r, c}

        // ---- Rule of Five：持有裸指针必须自己管理资源 ----
        explicit Tensor(ggml_type t = GGML_TYPE_F32) : type_(t) {}
        virtual ~Tensor() { if (owns_data_) freeBuffer(data_); }

        // 深拷贝
        Tensor(const Tensor& other)
            : type_(other.type_), shape_(other.shape_), stride_(other.stride_), count_(other.count_) {
            data_ = allocBuffer(count_);
            owns_data_ = true;
            for (size_t i = 0; i < count_; ++i) data_[i] = other.data_[i];
        }
        Tensor& operator=(const Tensor& other) {
            if (this != &other) {
                if (owns_data_) freeBuffer(data_);
                type_ = other.type_;
                shape_ = other.shape_;
                stride_ = other.stride_;
                count_ = other.count_;
                data_ = allocBuffer(count_);
                owns_data_ = true;        // 深拷贝得到独立缓冲，归本对象所有
                for (size_t i = 0; i < count_; ++i) data_[i] = other.data_[i];
            }
            return *this;
        }
        // 移动（搬运指针，零拷贝）
        Tensor(Tensor&& other) noexcept
            : data_(other.data_), type_(other.type_),
            shape_(other.shape_), stride_(other.stride_), count_(other.count_),
            owns_data_(other.owns_data_) {
            other.data_ = nullptr;
            other.count_ = 0;
            other.owns_data_ = false;
            other.shape_.clear();
        }
        Tensor& operator=(Tensor&& other) noexcept {
            if (this != &other) {
                if (owns_data_) freeBuffer(data_);
                data_ = other.data_;
                type_ = other.type_;
                shape_ = other.shape_;
                stride_ = other.stride_;
                count_ = other.count_;
                owns_data_ = other.owns_data_;
                other.data_ = nullptr;
                other.count_ = 0;
                other.owns_data_ = false;
                other.shape_.clear();
            }
            return *this;
        }

        // ---- 子类必须实现的接口 ----
        virtual size_t rank() const = 0;            // 阶 / 秩
        virtual const shape_type& dims() const = 0; // 各维尺寸
        const shape_type& strides() const { return stride_; } // 各维元素步长（与 ggml nb[] 同构，单位=元素）
        virtual const char* typeName() const = 0;   // 运行时类型名

        // ---- 基类统一提供的接口 ----
        ggml_type type() const { return type_; }     // 存储数据类型标签

        size_t size() const {                        // 元素总数
            size_t n = 1;
            for (size_t d : dims()) n *= d;
            return n;
        }

        // 通用访问：通过索引向量，运行时做维度/越界检查
        compute_type get(const index_type& idx) const {
            checkIndex(idx);
            return data_[offset(idx)];
        }
        void set(const index_type& idx, compute_type v) {
            checkIndex(idx);
            data_[offset(idx)] = v;
        }

        // 深拷贝（子类返回具体类型，外部统一收为 unique_ptr<Tensor>）
        virtual std::unique_ptr<Tensor> clone() const = 0;

        // 任意轴 permute 视图：返回共享本对象 data_ 的 PermuteView（零拷贝）。
        // perm[k] 表示“新轴 k 取源的第 perm[k] 轴”；矩阵转置 = permute({1,0})，
        // 三阶轴轮转 = permute({2,0,1})。视图不拥有内存，源须比视图活得久。
        virtual std::unique_ptr<Tensor> permute(const index_type& perm);

        // 命名轴重载（可读性更好，推荐）：t.permute({axisY, axisX}) 等价于 permute({1,0})。
        // 例：矩阵转置 = permute({axisY, axisX})；
        //     三阶轴轮转 = permute({axisZ, axisX, axisY})；
        //     四阶重排 = permute({axisW, axisZ, axisY, axisX})。
        // 内部仅把命名轴转成下标向量，再转发到上面的虚函数，保证多态语义一致。
        std::unique_ptr<Tensor> permute(std::initializer_list<Axis> perm) {
            return permute(index_type(perm.begin(), perm.end()));
        }

        // 全视图（identity 排列）：返回共享本对象 data_ 的 PermuteView，供多维访问替代
        // 已移除的链式 operator[]。用法：auto v = t.view(); v->get({i,j,...}) / v->operator()(i,j,...)。
        std::unique_ptr<Tensor> view() {
            index_type perm(rank());
            for (size_t k = 0; k < rank(); ++k) perm[k] = k;
            return permute(perm);
        }

        // 统一的元素访问虚入口：固定 4 个下标，基类全带默认值 0（保证经 Tensor* 多态调用时
        // 用户不必填写多余下标）。各派生类「本阶实际用到的下标」为真实索引（不带默认，直接调具体
        // 对象时必须提供），超出本阶的下标默认 =0 并被忽略。因签名（类型）在派生类间一致，可经 Tensor* 多态分发。
        virtual compute_type& operator()(size_t a = 0, size_t b = 0,
            size_t c = 0, size_t d = 0) = 0;
        virtual const compute_type& operator()(size_t a = 0, size_t b = 0,
            size_t c = 0, size_t d = 0) const = 0;

        void fill(compute_type v) {
            for (size_t i = 0; i < count_; ++i) data_[i] = v;
        }

        // 原始数据访问（对接 C / Eigen / ggml / 内存池统计等）
        const compute_type* raw() const { return data_; }
        compute_type* raw() { return data_; }
        const compute_type* data() const { return data_; }
        compute_type* data() { return data_; }
        size_t            capacity() const { return count_; } // 已分配元素个数

        // 描述信息，便于调试打印
        virtual std::string describe() const {
            std::ostringstream os;
            os << typeName()
                << " [type=" << ggml_type_name(type_)
                << ", rank=" << rank() << ", dims=";
            for (size_t i = 0; i < dims().size(); ++i) {
                if (i) os << "x";
                os << dims()[i];
            }
            os << ", size=" << size() << "]";
            return os.str();
        }

    protected:
        compute_type* data_ = nullptr;  // 计算缓冲（行主序），裸指针
        ggml_type   type_ = GGML_TYPE_F32; // 存储数据类型标签
        shape_type  shape_;           // 各维尺寸；标量可保持为空
        shape_type  stride_;          // 各维元素步长（与 ggml 的 nb[] 字节步长同构，
        // 只是单位为“元素”而非“字节”）；视图可重排
        size_t      count_ = 0;       // 已分配元素个数（便于 fill / 调试）
        bool        owns_data_ = true;// 视图/别名对象置 false：析构时不释放共享缓冲

        // 行主序元素步长：shape {d0,d1,d2} -> {d1*d2, d2, 1}
        static shape_type makeStrides(const shape_type& sh) {
            shape_type s(sh.size(), 1);
            size_t st = 1;
            for (size_t k = sh.size(); k-- > 0; ) { s[k] = st; st *= sh[k]; }
            return s;
        }

        // 按给定 shape 分配并清零（同步计算 stride_）
        void allocate(const shape_type& sh) {
            shape_ = sh;
            stride_ = makeStrides(sh);
            size_t n = 1;
            for (size_t d : sh) n *= d;
            data_ = allocBuffer(n);
            count_ = n;
        }

        // 索引 -> 位置：sum_k idx[k]*stride_[k]。
        // 设为 virtual，使视图/别名类可重写“索引->位置”映射（转置 / 任意轴 permute）。
        // 普通稠密张量由 allocate() 设定标准行主序 stride_，无需重写；
        // 视图则通过重排 stride_ 实现零拷贝的重排。
        virtual size_t offset(const index_type& idx) const {
            size_t off = 0;
            for (size_t k = 0; k < stride_.size(); ++k)
                off += (k < idx.size() ? idx[k] : 0) * stride_[k];
            return off;
        }

        void checkIndex(const index_type& idx) const {
            if (idx.size() != shape_.size())
                throw std::invalid_argument(std::string(typeName()) + ": 索引维数与阶不符");
            for (size_t i = 0; i < idx.size(); ++i)
                if (idx[i] >= shape_[i])
                    throw std::out_of_range(std::string(typeName()) + ": 索引越界");
        }

        // ---- 内存池接入点：将来只改这两个静态函数 ----
        static compute_type* allocBuffer(size_t n) {
            // 内存池版本示例：
            //   return static_cast<compute_type*>(MemPool::instance().allocate(n * sizeof(compute_type)));
            return new compute_type[n]();   // 值初始化为 0
        }
        static void freeBuffer(compute_type* p) {
            // 内存池版本示例：
            //   if (p) MemPool::instance().deallocate(p); return;
            delete[] p;
        }
    };

    // ----------------------------------------------------------------------------
    // 数组式链式 operator[] 已移除：多维访问统一改用视图（View）——
    //   auto v = t.view();            // 返回共享 t 的 data_ 的 PermuteView（identity 排列）
    //   v->get({i, j, ...});          // 索引向量访问
    //   v->operator()(i, j, ...);     // 函数式访问
    // 以及矩阵转置 t.transpose()、三/四阶轴交换 t3.swapaxes(a,b) / t4.swapaxes(a,b)。
    // 视图按 stride[]（与 ggml 的 nb[] 同构）重排索引映射，零拷贝共享存储。
    // ----------------------------------------------------------------------------

    // ----------------------------------------------------------------------------
    // 标量 Scalar —— 0 阶
    // ----------------------------------------------------------------------------
    class Scalar : public Tensor {
    public:
        explicit Scalar(compute_type v = compute_type{}, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            data_ = allocBuffer(1);   // 标量只存 1 个元素；shape_ 保持空，rank=0
            count_ = 1;
            data_[0] = v;
        }
        size_t rank() const override { return 0; }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "Scalar"; }

        compute_type value() const { return data_[0]; }
        void setValue(compute_type v) { data_[0] = v; }

        // 统一虚入口（4 参数，全部默认 0；标量只有 data_[0]，多余参数忽略）
        compute_type& operator()(size_t = 0, size_t = 0, size_t = 0, size_t = 0) override {
            return data_[0];
        }
        const compute_type& operator()(size_t = 0, size_t = 0, size_t = 0, size_t = 0) const override {
            return data_[0];
        }

        std::unique_ptr<Tensor> clone() const override {
            return std::make_unique<Scalar>(*this);
        }
    };

    // ----------------------------------------------------------------------------
    // 矢量 Vector —— 1 阶
    // ----------------------------------------------------------------------------
    class Vector : public Tensor {
    public:
        explicit Vector(size_t n = 0, compute_type v = compute_type{}, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            allocate({ n }); if (v != compute_type{}) fill(v);
        }
        Vector(std::initializer_list<compute_type> list, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            allocate({ list.size() });
            size_t i = 0;
            for (compute_type x : list) data_[i++] = x;
        }
        size_t rank() const override { return 1; }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "Vector"; }

        size_t length() const { return shape_.empty() ? 0 : shape_[0]; }

        compute_type get(size_t i) const { check1(i); return data_[i]; }
        void set(size_t i, compute_type v) { check1(i); data_[i] = v; }

        // 统一虚入口：a 为本阶实际索引（不带默认），b/c/d 超出阶数默认 0 并忽略
        compute_type& operator()(size_t a, size_t = 0, size_t = 0, size_t = 0) override {
            check1(a); return data_[a];
        }
        const compute_type& operator()(size_t a, size_t = 0, size_t = 0, size_t = 0) const override {
            check1(a); return data_[a];
        }

        std::unique_ptr<Tensor> clone() const override {
            return std::make_unique<Vector>(*this);
        }
    private:
        void check1(size_t i) const {
            if (i >= length()) throw std::out_of_range("Vector: 越界");
        }
    };

    // ----------------------------------------------------------------------------
    // 矩阵 Matrix —— 2 阶
    // ----------------------------------------------------------------------------
    class TransposeView;   // 前向声明：Matrix::transpose() 返回 unique_ptr<TransposeView>
    class Matrix : public Tensor {
    public:
        Matrix(size_t rows = 0, size_t cols = 0, compute_type v = compute_type{}, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            allocate({ rows, cols }); if (v != compute_type{}) fill(v);
        }
        Matrix(std::initializer_list<std::initializer_list<compute_type>> init, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            if (init.size() == 0) { allocate({ 0, 0 }); return; }
            size_t r = init.size();
            size_t c = init.begin()->size();
            allocate({ r, c });
            size_t i = 0;
            for (const auto& row : init) {
                if (row.size() != c) throw std::invalid_argument("Matrix: 行长度不一致");
                size_t j = 0;
                for (compute_type x : row) data_[i * c + j++] = x;
                ++i;
            }
        }

        // 仅供视图/别名派生类（如 TransposeView）：仅设类型、不分配缓冲，
        // 由派生类接管 data_ / shape_ / owns_data_。
        explicit Matrix(ggml_type t) : Tensor(t) {}

        size_t rank() const override { return 2; }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "Matrix"; }

        size_t rows() const { return shape_.size() < 1 ? 0 : shape_[0]; }
        size_t cols() const { return shape_.size() < 2 ? 0 : shape_[1]; }

        // 统一虚入口：a,b 为本阶实际索引（不带默认），c/d 超出阶数默认 0 并忽略
        compute_type& operator()(size_t a, size_t b, size_t = 0, size_t = 0) override {
            check2(a, b); return data_[offset({ a, b })];
        }
        const compute_type& operator()(size_t a, size_t b, size_t = 0, size_t = 0) const override {
            check2(a, b); return data_[offset({ a, b })];
        }

        compute_type get(size_t r, size_t c) const { check2(r, c); return data_[offset({ r, c })]; }
        void set(size_t r, size_t c, compute_type v) { check2(r, c); data_[offset({ r, c })] = v; }

        std::unique_ptr<Tensor> clone() const override {
            return std::make_unique<Matrix>(*this);
        }

        // 转置视图：返回共享本对象 data_ 的 TransposeView（零拷贝）。
        // 注意：视图不拥有内存，本 Matrix 必须比视图活得久（典型 view 语义）。
        std::unique_ptr<TransposeView> transpose();

    private:
        void check2(size_t r, size_t c) const {
            if (r >= rows() || c >= cols())
                throw std::out_of_range("Matrix: 越界");
        }
    };

    // 注：TransposeView / PermuteView / 物化辅助 的完整定义见文件末尾
    //     （需所有派生类（含 Tensor4）完整类型，故放在 namespace 关闭前）。

    // ----------------------------------------------------------------------------
    // 三阶张量 Tensor3 —— 3 阶
    // ----------------------------------------------------------------------------
    class Tensor3 : public Tensor {
    public:
        Tensor3(size_t d0 = 0, size_t d1 = 0, size_t d2 = 0, compute_type v = compute_type{}, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            allocate({ d0, d1, d2 }); if (v != compute_type{}) fill(v);
        }
        size_t rank() const override { return 3; }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "Tensor3"; }

        size_t dim(size_t i) const { return shape_.size() <= i ? 0 : shape_[i]; }

        compute_type& at(size_t i, size_t j, size_t k) { check3(i, j, k); return data_[offset({ i, j, k })]; }
        const compute_type& at(size_t i, size_t j, size_t k) const { check3(i, j, k); return data_[offset({ i, j, k })]; }

        compute_type get(size_t i, size_t j, size_t k) const { check3(i, j, k); return data_[offset({ i, j, k })]; }
        void set(size_t i, size_t j, size_t k, compute_type v) { check3(i, j, k); data_[offset({ i, j, k })] = v; }

        // 统一虚入口：a,b,c 为本阶实际索引（不带默认），d 超出阶数默认 0 并忽略
        compute_type& operator()(size_t a, size_t b, size_t c, size_t = 0) override {
            check3(a, b, c); return data_[offset({ a, b, c })];
        }
        const compute_type& operator()(size_t a, size_t b, size_t c, size_t = 0) const override {
            check3(a, b, c); return data_[offset({ a, b, c })];
        }

        // 轴交换视图：交换轴 a 与轴 b（其余不变），返回共享 data_ 的 PermuteView（零拷贝）。
        // 例：swapaxes(0,2) 把 (i,j,k) 重排为 (k,j,i)；形状随之交换。视图不拥有内存，源须比视图活得久。
        std::unique_ptr<Tensor> swapaxes(size_t a, size_t b) {
            if (a >= 3 || b >= 3) throw std::out_of_range("Tensor3::swapaxes: 轴越界");
            index_type perm{ 0, 1, 2 };
            size_t tmp = perm[a]; perm[a] = perm[b]; perm[b] = tmp;
            return permute(perm);
        }

        // 命名轴重载：t3.swapaxes(axisX, axisZ) 等价于 swapaxes(0,2)（把 (i,j,k) 重排为 (k,j,i)）。
        std::unique_ptr<Tensor> swapaxes(Axis a, Axis b) {
            return swapaxes(size_t(a), size_t(b));
        }

        std::unique_ptr<Tensor> clone() const override {
            return std::make_unique<Tensor3>(*this);
        }
    private:
        void check3(size_t i, size_t j, size_t k) const {
            if (i >= dim(0) || j >= dim(1) || k >= dim(2))
                throw std::out_of_range("Tensor3: 越界");
        }
    };

    // ----------------------------------------------------------------------------
    // 四阶张量 Tensor4 —— 4 阶
    // ----------------------------------------------------------------------------
    class Tensor4 : public Tensor {
    public:
        Tensor4(size_t d0 = 0, size_t d1 = 0, size_t d2 = 0, size_t d3 = 0,
            compute_type v = compute_type{}, ggml_type t = GGML_TYPE_F32)
            : Tensor(t) {
            allocate({ d0, d1, d2, d3 }); if (v != compute_type{}) fill(v);
        }
        size_t rank() const override { return 4; }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "Tensor4"; }

        size_t dim(size_t i) const { return shape_.size() <= i ? 0 : shape_[i]; }

        compute_type& at(size_t i, size_t j, size_t k, size_t l) { check4(i, j, k, l); return data_[offset({ i, j, k, l })]; }
        const compute_type& at(size_t i, size_t j, size_t k, size_t l) const { check4(i, j, k, l); return data_[offset({ i, j, k, l })]; }

        compute_type get(size_t i, size_t j, size_t k, size_t l) const { check4(i, j, k, l); return data_[offset({ i, j, k, l })]; }
        void set(size_t i, size_t j, size_t k, size_t l, compute_type v) { check4(i, j, k, l); data_[offset({ i, j, k, l })] = v; }

        // 统一虚入口：a,b,c,d 均为本阶实际索引（不带默认）
        compute_type& operator()(size_t a, size_t b, size_t c, size_t d) override {
            check4(a, b, c, d); return data_[offset({ a, b, c, d })];
        }
        const compute_type& operator()(size_t a, size_t b, size_t c, size_t d) const override {
            check4(a, b, c, d); return data_[offset({ a, b, c, d })];
        }

        // 轴交换视图：交换轴 a 与轴 b（其余不变），返回共享 data_ 的 PermuteView（零拷贝）。
        // 例：swapaxes(1,3) 把 (i,j,k,l) 重排为 (i,l,k,j)；形状随之交换。视图不拥有内存，源须比视图活得久。
        std::unique_ptr<Tensor> swapaxes(size_t a, size_t b) {
            if (a >= 4 || b >= 4) throw std::out_of_range("Tensor4::swapaxes: 轴越界");
            index_type perm{ 0, 1, 2, 3 };
            size_t tmp = perm[a]; perm[a] = perm[b]; perm[b] = tmp;
            return permute(perm);
        }

        // 命名轴重载：t4.swapaxes(axisY, axisW) 等价于 swapaxes(1,3)（把 (i,j,k,l) 重排为 (i,l,k,j)）。
        std::unique_ptr<Tensor> swapaxes(Axis a, Axis b) {
            return swapaxes(size_t(a), size_t(b));
        }

        std::unique_ptr<Tensor> clone() const override {
            return std::make_unique<Tensor4>(*this);
        }
    private:
        void check4(size_t i, size_t j, size_t k, size_t l) const {
            if (i >= dim(0) || j >= dim(1) || k >= dim(2) || l >= dim(3))
                throw std::out_of_range("Tensor4: 越界");
        }
    };

    // ----------------------------------------------------------------------------
    // PermuteView 相关辅助（前向声明；完整定义见下方）
    // ----------------------------------------------------------------------------
    std::unique_ptr<Tensor> makeDense(const Tensor::shape_type& shape, ggml_type t = GGML_TYPE_F32);
    bool advanceIndex(Tensor::shape_type& idx, const Tensor::shape_type& shape);

    // ----------------------------------------------------------------------------
    // PermuteView —— 任意轴重排视图（共享源 Tensor 的 data_，零拷贝）
    //   基于 stride[]（与 ggml 的 nb[] 字节步长同构，单位为“元素”）实现：
    //   新视图轴 k 的元素步长 = 源“第 perm[k] 轴”的元素步长；形状同理重排。
    //   因此 view(i,j,k) 自动映射到源的正确位置，且不搬任何数据。
    //   不拥有内存（owns_data_ = false），故“源 Tensor 必须比视图活得久”（典型 view 语义）。
    //   非连续/重排布局下链式 operator[] 语义错位，故 PermuteView 不提供 operator[]，
    //   请改用 view(i,j,...) / view.get({i,j,...})。
    // ----------------------------------------------------------------------------
    class PermuteView : public Tensor {
    public:
        // src：被观察的张量（不拥有其内存）；perm：轴重排，长度须 == src.rank()，
        //      如矩阵转置 = {1,0}，三阶轴轮转 = {2,0,1}。
        PermuteView(Tensor* src, const index_type& perm) : Tensor(src->type()) {
            if (perm.size() != src->rank())
                throw std::invalid_argument("PermuteView: perm 长度必须等于源阶数");
            std::vector<char> seen(perm.size(), 0);
            for (size_t p : perm) {
                if (p >= perm.size() || seen[p])
                    throw std::invalid_argument("PermuteView: perm 必须是 0..rank-1 的合法排列");
                seen[p] = 1;
            }
            const auto& sh = src->dims();
            const auto& st = src->strides();
            shape_.resize(perm.size());
            stride_.resize(perm.size());
            for (size_t k = 0; k < perm.size(); ++k) {
                shape_[k] = sh[perm[k]];     // 形状按新轴顺序重排
                stride_[k] = st[perm[k]];     // 步长按新轴顺序重排
            }
            data_ = src->data(); // 共享源缓冲（浅拷贝，零拷贝）
            owns_data_ = false;          // 析构时不释放共享缓冲
            count_ = src->capacity();
            source_ = src;
        }

        size_t rank() const override { return shape_.size(); }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "PermuteView"; }

        // 统一虚入口：按本视图阶数做越界检查，经 offset()（stride 映射）定位
        compute_type& operator()(size_t a, size_t b = 0, size_t c = 0, size_t d = 0) override {
            checkRank(a, b, c, d);
            return data_[offset({ a, b, c, d })];
        }
        const compute_type& operator()(size_t a, size_t b = 0, size_t c = 0, size_t d = 0) const override {
            checkRank(a, b, c, d);
            return data_[offset({ a, b, c, d })];
        }

        // 物化：返回独立稠密张量（按视图形状逐元素拷出，脱离源仍可存活）
        std::unique_ptr<Tensor> clone() const override {
            auto dst = makeDense(shape_, type());
            index_type idx(shape_.size(), 0);
            do { dst->set(idx, this->get(idx)); } while (advanceIndex(idx, shape_));
            return dst;
        }

        const Tensor* source() const { return source_; }

        // 注意：describe() 在基类非 virtual，此处仅为“具体对象直接调用”时给出别名信息；
        // 经 Tensor* 调用仍走基类 describe()，但 typeName() 为 virtual，类型名正确。
        std::string describe() const {
            std::ostringstream os;
            os << typeName() << " [type=" << ggml_type_name(type())
                << ", rank=" << rank() << ", dims=";
            for (size_t i = 0; i < dims().size(); ++i) {
                if (i) os << "x";
                os << dims()[i];
            }
            os << ", size=" << size() << ", 别名视图, 源=" << source_->typeName() << "]";
            return os.str();
        }

    protected:
        const Tensor* source_ = nullptr;

        size_t offset(const index_type& idx) const override {
            size_t o = 0;
            for (size_t k = 0; k < stride_.size(); ++k)
                o += (k < idx.size() ? idx[k] : 0) * stride_[k];
            return o;
        }

        void checkRank(size_t a, size_t b, size_t c, size_t d) const {
            const size_t idx[4] = { a, b, c, d };
            for (size_t k = 0; k < shape_.size(); ++k)
                if (idx[k] >= shape_[k])
                    throw std::out_of_range(std::string(typeName()) + ": 越界");
        }
    };

    // ----------------------------------------------------------------------------
    // TransposeView —— 矩阵转置视图（共享源 Matrix 的 data_，零拷贝）
    //   直接继承 Tensor，自带转置的“索引 -> 位置”实现（重写 offset()），
    //   不依赖 PermuteView，与 v11 原始实现一致。view(i,j) 实际访问源 M(j,i)
    //   -> offset = j * srcCols + i。
    //   不拥有内存（owns_data_ = false），故“源 Matrix 必须比视图活得久”（典型 view 语义）。
    //   与 ggml 的 nb[] 字节步长视图是同一思路：只改变映射，不搬数据。
    // ----------------------------------------------------------------------------
    class TransposeView : public Tensor {
    public:
        explicit TransposeView(Matrix& src) : Tensor(src.type()) {
            source_ = &src;
            data_ = src.data();        // 共享源缓冲（浅拷贝指针，零拷贝）
            owns_data_ = false;             // 析构时不释放共享缓冲
            shape_ = { src.cols(), src.rows() };  // 形状交换：视图为 (C, R)
            stride_ = { 1, src.cols() }; // 视图轴0 步长1，轴1 步长=源列数（仅供 strides() 查看）
            count_ = src.cols() * src.rows();
        }

        size_t rank() const override { return 2; }
        const shape_type& dims() const override { return shape_; }
        const char* typeName() const override { return "TransposeView"; }

        size_t rows() const { return shape_.size() < 1 ? 0 : shape_[0]; }  // = 源 cols
        size_t cols() const { return shape_.size() < 2 ? 0 : shape_[1]; }  // = 源 rows

        // 统一虚入口：a,b 为本阶实际索引（不带默认），c/d 超出阶数默认 0 并忽略
        compute_type& operator()(size_t a, size_t b, size_t = 0, size_t = 0) override {
            check2(a, b); return data_[offset({ a, b })];
        }
        const compute_type& operator()(size_t a, size_t b, size_t = 0, size_t = 0) const override {
            check2(a, b); return data_[offset({ a, b })];
        }

        compute_type get(size_t r, size_t c) const { check2(r, c); return data_[offset({ r, c })]; }
        void set(size_t r, size_t c, compute_type v) { check2(r, c); data_[offset({ r, c })] = v; }

        // 物化：返回独立 Matrix，把转置后的数据拷进自有缓冲（可脱离源独立存活）
        std::unique_ptr<Tensor> clone() const override {
            auto m = std::make_unique<Matrix>(dims()[0], dims()[1], compute_type{}, type());
            for (size_t i = 0; i < dims()[0]; ++i)
                for (size_t j = 0; j < dims()[1]; ++j)
                    (*m)(i, j) = (*this)(i, j);  // 经本视图的转置 offset 取值
            return m;
        }

        const Matrix* source() const { return source_; }

        // 具体对象直接调用时给出别名信息（经 Tensor* 调用走基类 describe，类型名仍正确）
        std::string describe() const {
            std::ostringstream os;
            os << typeName() << " [type=" << ggml_type_name(type())
                << ", rank=" << rank() << ", dims=";
            for (size_t i = 0; i < dims().size(); ++i) {
                if (i) os << "x";
                os << dims()[i];
            }
            os << ", size=" << size() << ", 别名视图, 源=" << source_->typeName() << "]";
            return os.str();
        }

    protected:
        Matrix* source_ = nullptr;

        // 转置偏移：view(i,j) -> 源 M(j,i) -> offset = j * srcCols + i
        size_t offset(const index_type& idx) const override {
            size_t i = idx[0], j = idx[1];      // 视图 (i=行, j=列)
            return j * source_->cols() + i;     // 源里：行 = j, 列 = i
        }

        void check2(size_t r, size_t c) const {
            if (r >= rows() || c >= cols())
                throw std::out_of_range("TransposeView: 越界");
        }
    };

    // Matrix::transpose() 定义放在 TransposeView 完整类型之后
    inline std::unique_ptr<TransposeView> Matrix::transpose() {
        return std::make_unique<TransposeView>(*this);
    }

    // 物化辅助：按 shape 构造对应阶数的独立稠密张量（rank 0..4）
    inline std::unique_ptr<Tensor> makeDense(const Tensor::shape_type& shape, ggml_type t) {
        switch (shape.size()) {
        case 0: return std::make_unique<Scalar>(Tensor::compute_type{}, t);
        case 1: return std::make_unique<Vector>(shape[0], Tensor::compute_type{}, t);
        case 2: return std::make_unique<Matrix>(shape[0], shape[1], Tensor::compute_type{}, t);
        case 3: return std::make_unique<Tensor3>(shape[0], shape[1], shape[2], Tensor::compute_type{}, t);
        case 4: return std::make_unique<Tensor4>(shape[0], shape[1], shape[2], shape[3], Tensor::compute_type{}, t);
        default: throw std::invalid_argument("makeDense: 暂不支持 rank > 4");
        }
    }

    // 索引迭代器：把 idx 当作 odometer 自增；溢出回绕返回 false（遍历结束）
    inline bool advanceIndex(Tensor::shape_type& idx, const Tensor::shape_type& shape) {
        for (size_t k = idx.size(); k-- > 0; ) {
            if (++idx[k] < shape[k]) return true;
            idx[k] = 0;
        }
        return false;
    }

// Tensor::permute 默认实现：构造 PermuteView（定义在 PermuteView 完整类型之后）
inline std::unique_ptr<Tensor> Tensor::permute(const index_type& perm) {
    return std::make_unique<PermuteView>(this, perm);
}

} // namespace wb#pragma once
