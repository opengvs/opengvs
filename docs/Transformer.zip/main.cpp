// ============================================================================
// main.cpp —— 推理演示入口（仅推理，不含模型模拟生成）
//  (1) 从「实际的 GGUF 模型文件」加载权重（model/virtual_model_f32.gguf），
//      对算式 "3+4=" 做一次自回归生成，并打印每一步的推理过程（trace）。
//      权重来自文件中的真实 GGUF 权重，非随机模拟。
//  (2) 模型结构核查：打印 GUFFHeadInfor / EmbeddingInfor / 各 LayerInfor 摘要。
//
// 注：早期的「模拟生成并落盘 GGUF 模型文件」逻辑（simulateGUFF 模块）已从本工程
//      移除；GGUF 文件格式层（guff.h）与模型组件层（layers.h）也已合并进
//      Transformer/Transformer.h（namespace trans）。本工程仅保留推理部分。
//
// 编译：g++ -std=c++17 -Wall -Wextra main.cpp -o demo.exe
// ============================================================================
#include "Transformer/Transformer.h"   // trans::Transformer + 全部依赖（经本文件内 #include 传递引入）
#include <cstdio>
// Windows 控制台 API
#if defined(_WIN32)
#include <windows.h>
#endif

int main() {
    // 在 Windows 控制台启用 UTF-8 输出，避免中文乱码
#if defined(_WIN32)
    ::SetConsoleOutputCP(CP_UTF8);
    ::SetConsoleCP(CP_UTF8);
#endif
    // ---- (1) Transformer 推理演示：从实际 GGUF 文件加载权重 ----
    trans::Transformer model;                   // 默认构造（无权重）
    const char* modelPath = "D:/Tool/BitNet-main/bin/models/ggml-model-f32.gguf";//"model/virtual_model_f32.gguf"; //
    if (!model.LoadFormFile(modelPath)) {       // 纯 FILE* 字节流读取，不依赖 GUFFFile 库
        std::cout << "模型加载失败，未找到 GGUF 模型文件： "
                  << modelPath << "\n";
        return 1;
    }

    // ---- (2) 打印加载后的模型结构（四个信息/推理类）----
    std::cout << "=== 模型结构（GUFFHeadInfor / EmbeddingInfor / LayerInfor）===\n";
    model.headInfor.print();
    model.embeddingInfor.print();
    std::cout << "  layers: " << model.layers.size() << " 层\n";
    for (const auto& li : model.layers) li.print();
    size_t totParams = 0;
    for (const auto& li : model.layers) totParams += li.paramCount();
    std::cout << "  逐层参数合计: " << totParams << " (不含 embedding / LM head)\n\n";

    std::cout << "=== Transformer 演示（加载真实 GGUF 权重 · vocab=12 · d=32 · layers=3 · heads=4）===\n";
    std::cout << "目标：展示大模型语言推理的前向/生成流程（权重来自文件，非模拟）\n\n";

    std::string prompt = "3+4=";
    std::string out = model.generate(prompt, 8, /*trace=*/true);

    std::cout << "\n输入: " << prompt << "\n生成: " << out << "\n";

    return 0;
}
