#pragma once
// ============================================================================
// calculations.h —— 模型层「结构知识」算子（不再重复 tensor20.h 的数值原语）
//
// 设计红线（沿用 tensor20.h 笔记）：结构无关的数值原语只属于 tensor20.h，且以
// 成员函数形式提供：matvec / matmul / bmm / add / sub / mul / div / silu /
// softmax(dim) / gather(ids,axis) / clone 等。本文件只保留「含模型结构知识」
// 的配方，避免两份实现：
//   - rmsNorm       ：RMSNorm = x/rms × γ（选 RMSNorm、配可学习 γ 是 LLM 知识）
//   - applyRoPEToRow：RoPE 按位置频率旋转（位置编码是 Transformer 结构知识）
//   - Linear        ：线性/仿射变换 y = W·x（无偏置），注意力投影 / SwiGLU / LM 头共用
// 其余计算在 layers.h / guff.h 中直接调用 tensor20.h 成员函数完成，例如
//   W.matvec(x) / A.matmul(B) / A.bmm(B) / X.add(b) / X.silu() / X.softmax(1)
//   / table.gather(ids, 0)，不再于此处重新实现。
//
// 本文件同时定义「含模型结构知识」的六个类（均位于 namespace ops，与 Linear 同级）：
//   Linear / RMSNorm / RoPE / MultiHeadAttention / FeedForward / Sampler
// 它们的前向直接调用上方 rmsNorm/applyRoPEToRow 与 Tensor 的成员函数；类本身只持有
// 权重句柄（MultiHeadAttention/FeedForward/Sampler 中的 Linear 为原生驻留权重）与超参。
//
// 空间内用 using namespace wb; 让 Matrix/Vector/Tensor 可见（仅作用于本命名空间）。
// 注：本文件位于 calculations/ 子目录，tensor20.h 用相对路径 "../tensor/tensor20.h"。
// ============================================================================
#include "../tensor/tensor20.h"
#include <vector>
#include <cmath>
#include <memory>      // Linear / Sampler 用到 shared_ptr / unique_ptr

namespace ops {

using namespace wb;   // 让 tensor20.h(wb) 的 Matrix/Vector/Tensor 在此命名空间内可见

// RMSNorm：y = (x / sqrt(mean(x^2)+eps)) * w ，沿最后一维
inline std::unique_ptr<Matrix> rmsNorm(const Matrix& X, const Vector& w, float eps) {
    size_t R = X.rows(), Cc = X.cols();
    auto Y = std::make_unique<Matrix>(R, Cc);
    for (size_t i = 0; i < R; ++i) {
        float ss = 0.0f;
        for (size_t j = 0; j < Cc; ++j) ss += X(i, j) * X(i, j);
        float rms = std::sqrt(ss / (float)Cc + eps);
        for (size_t j = 0; j < Cc; ++j) (*Y)(i, j) = (X(i, j) / rms) * w(j);
    }
    return Y;
}

// RoPE：对单行（一个 token 的隐藏向量）按位置 pos 做按对旋转
// 频率表 invFreq[k] = 1 / base^(2k/d)，d 为隐藏维度（偶数）
inline void applyRoPEToRow(Matrix& X, size_t row, size_t pos, const std::vector<float>& invFreq) {
    size_t d = X.cols();
    for (size_t k = 0; k < d / 2; ++k) {
        float theta = (float)pos * invFreq[k];
        float c = std::cos(theta), s = std::sin(theta);
        float a = X(row, 2 * k), b = X(row, 2 * k + 1);
        X(row, 2 * k)     = a * c - b * s;
        X(row, 2 * k + 1) = a * s + b * c;
    }
}

// ============================================================================
// Linear —— 一层线性（仿射）变换 y = x·W ，无偏置（保持 demo 简洁）
//
// 定位 / 角色
// ----------
// 整个 Transformer 推理引擎里最基础、复用最广的「矩阵-向量 / 矩阵-矩阵」单元。
// 它把「权重矩阵 W」封装成一个可复用的算子，被三处共用（见下方「组合位置」）：
//   * MultiHeadAttention 的 Q/K/V 投影与输出投影（Wq/Wk/Wv/Wo）
//   * FeedForward（SwiGLU）的 gate/up 投影与降维（up/up2/down）
//   * EmbeddingInfor 的 LM 头（lmHead），把隐状态映射到词表 logits
// 可以说：模型里所有「矩阵乘」最终都收敛到 Linear。
//
// 设计要点（与 A+B 原生驻留改造的关系）
// -----------------------------------------
// 成员 W 是 shared_ptr<Tensor>，权重按 GGUF *原始类型*（F32/F16/BF16/Q8_0/Q4_0…）
// 常驻内存，而不是改造前的 Matrix（加载即反量化成 F32、量化模型内存膨胀 4~8×）。
// Linear 自身 **不实现任何乘加**，只做「维度记账 + 调用 W->matvec」；真正的计算在
// Tensor::matvec 的三路径里（F32 快路径 / 量化融合 vec_dot / 通用 get 路径），由 W
// 的实际类型决定。因此换量化权重时 Linear 代码一行不用改——这正是「原生驻留、
// 计算时反量化」能成立的原因。tied-embedding 时 lmHead.W = embedding（同一指针
// 零拷贝共享）也得益于此设计。
//
// 维度约定
// --------
// 权重 W 在 GGUF 里以 [OUT, IN] 存储（loadTensorMatrix 中 M = makeDense({OUT, IN}, ...)，
// 即 dims[0]=IN、dims[1]=OUT）。matvec 把 [IN] 向量映射为 [OUT] 向量，故
//   inDim = IN（输入维），outDim = OUT（输出维）。
// 例如 LM 头：W = [vocab, d_model]，输入 [d_model]、输出 [vocab]（logits）。
//
// 返回值
// ------
// 两个 forward 均返回 unique_ptr（新分配的结果张量，调用方取得所有权），保持「无副作用、
// 不改权重」的纯函数风格。
// ============================================================================
class Linear {
public:
    size_t inDim  = 0;   // 输入维度 = W 的列数 IN（matvec 输入向量长度）
    size_t outDim = 0;   // 输出维度 = W 的行数 OUT（matvec 输出向量长度）
    // 权重（原生类型驻留）。F32 时为稠密 Matrix；量化时为 makeDense 构造的 Tensor。
    // 计算时由 Tensor::matvec 透明反量化（量化路径走 vec_dot 融合内核，不物化整张 F32）。
    std::shared_ptr<Tensor> W;

    Linear() = default;
    // 构造器只记录维度，**不预分配 F32 矩阵**；W 由 loadTensorMatrix 在加载阶段按原生类型填充。
    // 区别于改造前：曾经是 Matrix W（立即分配 F32），现已改为 shared_ptr<Tensor> 惰性填充。
    Linear(size_t in_, size_t out_) : inDim(in_), outDim(out_) {}

    // ---- 单 token 前向：y = W · x（矩阵-向量乘）----------------------------------
    // x 为长度 inDim 的列向量，返回长度 outDim 的列向量。内部直接委托 W->matvec。
    std::unique_ptr<Vector> forward(const Vector& x) const {
        // matvec 返回 unique_ptr<Tensor>（实为 Vector 子类），release 后转回 Vector* 交调用方所有。
        return std::unique_ptr<Vector>(static_cast<Vector*>(W->matvec(x).release()));
    }

    // ---- 批前向：对输入 [seq, inDim] 的每一行独立做 matvec，拼成 [seq, outDim] -----
    // 写法为「整序列重算、未启用 KV 缓存增量」模式下最简单朴素的实现：每行一次 matvec，
    // 中间用 Vector xi(inDim) 逐元素取出该行、再把结果写回 Y。两次逐元素拷贝是为清晰/与重算
    // 模式一致而写，非性能最优（若走 KV 缓存增量或对 Matrix 做行切片视图可省去）。
    std::unique_ptr<Matrix> forwardBatch(const Matrix& X) const {
        size_t seq = X.rows();
        std::unique_ptr<Matrix> Y = std::make_unique<Matrix>(seq, outDim);
        for (size_t i = 0; i < seq; ++i) {
            Vector xi(inDim);
            for (size_t j = 0; j < inDim; ++j) xi.set(j, X(i, j));
            std::unique_ptr<Vector> yi =
                std::unique_ptr<Vector>(static_cast<Vector*>(W->matvec(xi).release()));
            for (size_t j = 0; j < outDim; ++j) (*Y)(i, j) = (*yi)(j);
        }
        return Y;
    }
};

// ============================================================================
// RMSNorm —— 预归一化（pre-norm）归一化层（可学习 gamma 权重）
//
// 位置
// ----
// Transformer 块中「注意力子层」与「前馈子层」各自的入口（attn_norm / ffn_norm），
// 以及模型末尾的 finalNorm（output_norm）。属于「逐层 / 模型级非逐层」的可学习权重，
// 本类只持有 gamma 向量 w，前向委托上方 rmsNorm（x/rms × γ 配方）。
//
// 数学
// ----
// y = (x / sqrt(mean(x²) + eps)) * w ，沿最后一维（特征维）逐行计算。
// 仅用 gamma、无 beta —— 这是 RMSNorm 的标准做法（区别于带 beta 的 LayerNorm）。
//
// 权重
// ----
// w 为 [d_model] 的 F32 向量（RMSNorm 归一化权重保持 F32，不参与量化驻留），
// 默认构造全 1（恒等起点），加载时由 loadTensorVector 填充真实 gamma。
// ============================================================================
class RMSNorm {
public:
    size_t dim;       // 特征维度 d_model（= w 的长度）
    Vector w;         // 可学习缩放权重 gamma [d_model]，加载时填充；默认构造全 1
    RMSNorm() : dim(0), w(0) {}   // 默认构造：空，权重由 loadFromFile 填充
    explicit RMSNorm(size_t d) : dim(d), w(d) {
        for (size_t j = 0; j < d; ++j) w.set(j, 1.0f);  // gamma 初始化为 1（恒等起点）
    }
    // 前向：对整张 [seq, d] 输入沿特征维做 RMSNorm，返回新矩阵（调用方所有）
    std::unique_ptr<Matrix> forward(const Matrix& X, float eps) const {
        return rmsNorm(X, w, eps);   // 委托本命名空间内的 rmsNorm（x/rms × γ）
    }
};

// ============================================================================
// RoPE —— 旋转位置编码（Rotary Position Embedding）
//
// 作用
// ----
// 用「按位置频率的旋转」给 token 注入位置信息，替代绝对/相对位置嵌入。
// 相比可学习位置嵌入，RoPE 在长度外推与相对位置保持上更优（llama 系列采用）。
//
// 频率表
// ------
// invFreq[k] = 1 / base^(2k/d)，k = 0..d/2-1；base 默认 10000（llama 系列取值）。
// 预计算后存于 invFreq，避免每次前向重复算 pow。
//
// 施加方式
// --------
// 对单行（一个 token 的隐藏向量）按「偶数-奇数对」做 2D 旋转，旋转角 θ = pos * invFreq[k]。
// 整张 [seq, d] 矩阵按「行号 = 位置」逐行施加（第 i 行用位置 i 的旋转角）。
// 委托：apply() 内部调用上方 applyRoPEToRow（结构算子，位于本文件顶部）。
// ============================================================================
class RoPE {
public:
    std::vector<float> invFreq;   // 预计算频率表 1/base^(2k/d)，长度 d/2
    size_t d;                      // 隐藏维度（偶数）；同时也是旋转作用维度
    RoPE() : d(0) {}   // 默认构造：空旋转表
    explicit RoPE(size_t d_, float base = 10000.0f) : d(d_) {
        invFreq.resize(d / 2);
        double b = base;
        for (size_t k = 0; k < d / 2; ++k)
            invFreq[k] = (float)(1.0 / std::pow(b, (double)(2 * k) / (double)d));
    }
    // 对整张 [seq,d] 矩阵按「行号=位置」施加旋转（第 i 行用位置 i 的旋转角）
    void apply(Matrix& X) const {
        for (size_t i = 0; i < X.rows(); ++i)
            applyRoPEToRow(X, i, i, invFreq);
    }
};

// ============================================================================
// MultiHeadAttention —— 多头因果自注意力
//                        （QKV 投影 + 缩放点积注意力 + 因果掩码 + 输出投影）
//
// 组成（4 个 Linear，权重原生驻留、计算经 Tensor::matvec 反量化）
// ----------------------------------------------------------------
//   Wq/Wk/Wv：把 [d_model] 投影到 [d_model]（内含 n_heads 个头，head_dim = d_model/n_heads）
//   Wo      ：把拼接后的上下文 [d_model] 再投影回 [d_model]
//
// 计算流程（forward）
// ------------------
//   1) Q/K/V = Wq/Wk/Wv.forwardBatch(X)        // 每个 [seq, d_model]
//   2) 逐头(h)、逐查询(i)：对 key j 算点积 score = Σ Q(i,·)·K(j,·) * scale（scale = 1/√head_dim）
//        * 因果掩码：j > i 时 score 置 -1e30（看不到未来 token）
//        * softmax 得注意力权重，对 V 加权求和 → 该头上下文
//   3) 所有头拼接成 [seq, d_model]，再过 Wo 输出投影
//
// 复杂度：O(n_heads · seq² · head_dim)。当前为「整序列重算」朴素实现（未用 KV 缓存增量）。
// 注：demo 用缩放点积注意力（无 QK-norm、无 GQA 分组），与 base Transformer / llama 一致。
// ============================================================================
class MultiHeadAttention {
public:
    size_t d_model, n_heads, head_dim;
    Linear Wq, Wk, Wv, Wo;   // 四个投影，原生驻留权重（同命名空间内省略 ops::）
    MultiHeadAttention() : d_model(0), n_heads(0), head_dim(0), Wq(0,0), Wk(0,0), Wv(0,0), Wo(0,0) {}
    MultiHeadAttention(size_t d_model_, size_t n_heads_, size_t head_dim_)
        : d_model(d_model_), n_heads(n_heads_), head_dim(head_dim_),
          Wq(d_model_, d_model_), Wk(d_model_, d_model_), Wv(d_model_, d_model_), Wo(d_model_, d_model_) {}

    std::unique_ptr<Matrix> forward(const Matrix& X) const {
        std::unique_ptr<Matrix> Q = Wq.forwardBatch(X);
        std::unique_ptr<Matrix> K = Wk.forwardBatch(X);
        std::unique_ptr<Matrix> V = Wv.forwardBatch(X);
        size_t seq = X.rows();
        std::unique_ptr<Matrix> ctx = std::make_unique<Matrix>(seq, d_model);
        float scale = 1.0f / std::sqrt((float)head_dim);   // 缩放点积注意力：除以 √head_dim
        for (size_t h = 0; h < n_heads; ++h) {
            size_t off = h * head_dim;   // 第 h 个头在 [seq, d_model] 中的特征偏移
            for (size_t i = 0; i < seq; ++i) {
                std::vector<float> scores(seq, 0.0f);
                float mx = -1e30f;
                for (size_t j = 0; j < seq; ++j) {
                    float s = 0.0f;
                    for (size_t c = 0; c < head_dim; ++c)
                        s += (*Q)(i, off + c) * (*K)(j, off + c);
                    s *= scale;
                    if (j > i) s = -1e30f;          // 因果：看不到未来
                    scores[j] = s;
                    if (s > mx) mx = s;             // 记录最大值，供 softmax 数值稳定
                }
                float sum = 0.0f;
                for (size_t j = 0; j < seq; ++j) { scores[j] = std::exp(scores[j] - mx); sum += scores[j]; }  // 减最大值防溢出
                for (size_t j = 0; j < seq; ++j) scores[j] /= sum;   // 归一化得注意力权重
                for (size_t c = 0; c < head_dim; ++c) {
                    float acc = 0.0f;
                    for (size_t j = 0; j < seq; ++j) acc += scores[j] * (*V)(j, off + c);  // 对 V 加权求和
                    (*ctx)(i, off + c) = acc;
                }
            }
        }
        return Wo.forwardBatch(*ctx);   // 输出投影：拼接上下文 → [seq, d_model]
    }
};

// ============================================================================
// FeedForward —— SwiGLU 前馈网络
//                 （对应 llama.cpp 的 ffn_gate.weight / ffn_up.weight / ffn_down.weight 三件套）
//
// 公式：y = down( silu(gate(x)) ⊙ up(x) )
//   gate = up(x) 经 SiLU 激活；up 为第二路升维；二者逐元素乘（门控）；
//   down 把门控结果降维回 [d_model]。
//
// 三个 Linear（原生驻留权重）
// --------------------------
//   up  ：gate 投影 [d_model → d_ff]
//   up2 ：up   投影 [d_model → d_ff]（同维，与 gate 逐元素乘）
//   down：降维投影 [d_ff → d_model]
//
// 注：llama 用 SwiGLU（两路 + 门控），区别于原始 Transformer 的单一 ReLU 两层 FFN。
// ============================================================================
class FeedForward {
public:
    Linear up, up2, down;   // gate / up / down（同命名空间内省略 ops::）
    FeedForward() : up(0,0), up2(0,0), down(0,0) {}
    FeedForward(size_t d_model_, size_t d_ff_)
        : up(d_model_, d_ff_), up2(d_model_, d_ff_), down(d_ff_, d_model_) {}
    std::unique_ptr<Matrix> forward(const Matrix& X) const {
        std::unique_ptr<Matrix> g = up.forwardBatch(X);                                  // gate   [seq, ff]
        std::unique_ptr<Matrix> u = up2.forwardBatch(X);                                 // up     [seq, ff]
        std::unique_ptr<Matrix> a = std::unique_ptr<Matrix>(static_cast<Matrix*>(g->silu().release()));   // silu(gate)
        std::unique_ptr<Matrix> z = std::unique_ptr<Matrix>(static_cast<Matrix*>(a->mul(*u).release()));  // silu(gate) ⊙ up
        return down.forwardBatch(*z);
    }
};

// ============================================================================
// Sampler —— 解码策略（当前：贪心 argmax；温度采样 / top-p / 重复惩罚可后续扩展）
//
// 输入：logits 矩阵 [seq, vocab]，取第 row 行（通常 row = 最后一行 = 当前预测位置）。
// 输出：argmax 选中的 token id（概率最大者）。
//
// 已知局限（见设计报告 §10.4）：纯贪心下模型可能陷入「重复 token 死循环」，
// 后续可加 temperature 采样 + repetition penalty 打破。本类设计为无状态（不持有成员），
// 每次 generate 时局部构造即可。
// ============================================================================
class Sampler {
public:
    // 贪心：取第 row 行中 logits 最大者对应的 token id
    size_t argmax(const Matrix& logits, size_t row) const {
        size_t best = 0; float bv = -1e30f;
        for (size_t v = 0; v < logits.cols(); ++v) {
            float lv = logits(row, v);
            if (lv > bv) {
                bv = lv;
                best = v;
            }
        }
        return best;
    }
};

} // namespace ops
