﻿namespace $safeprojectname$
{
    partial class OpenTKMainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            openglView = new OpenGLObject.OpenGLView();
            timer1 = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // openglView
            // 
            openglView.API = OpenTK.Windowing.Common.ContextAPI.OpenGL;
            openglView.APIVersion = new Version(3, 3, 0, 0);
            openglView.Flags = OpenTK.Windowing.Common.ContextFlags.Default;
            openglView.IsEventDriven = true;
            openglView.Location = new Point(14, 13);
            openglView.Margin = new Padding(5, 4, 5, 4);
            openglView.Name = "openglView";
            openglView.Profile = OpenTK.Windowing.Common.ContextProfile.Core;
            openglView.SharedContext = null;
            openglView.Size = new Size(1268, 834);
            openglView.TabIndex = 0;
            openglView.Paint += openglView_Paint;
            openglView.Resize += openglView_Resize;
            // 
            // timer1
            // 
            timer1.Interval = 50;
            timer1.Tick += timer1_Tick;
            // 
            // OpenTKMainForm
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1296, 860);
            Controls.Add(openglView);
            Name = "OpenTKMainForm";
            Text = "OpenTKMainForm";
            FormClosed += OpenTKMainForm_FormClosed;
            Load += OpenTKMainForm_Load;
            ResumeLayout(false);
        }

        #endregion

        private OpenGLObject.OpenGLView openglView;
        private System.Windows.Forms.Timer timer1;
    }
}
