///////////////////////////////////////////////////////////////////////////////
//  GLContextUseGLFW3.hpp  ʹ��GLFW3�����ڹ���Window���ڵ�OpenGLӦ�ó�����
// ��ͷ�ļ���һ��������ͷ�ļ���ʵ���˵���ͷ�ļ�����OpenGL���ڳ���
//  ��Ȩ����        ������    2025-2�� ��˫����
///////////////////////////////////////////////////////////////////////////////

#ifndef  __GLCONTEXTUSEGLFW3_HPP__
#define  __GLCONTEXTUSEGLFW3_HPP__
#include <SDKDDKVer.h>
#define WIN32_LEAN_AND_MEAN             // �� Windows ͷ�ļ����ų�����ʹ�õ�����
// Windows ͷ�ļ�
#include <windows.h>
#include <stdarg.h>
#include <vadefs.h>
// C ����ʱͷ�ļ�
//#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <DebugApi.h>

#include "glad.h"
#include <gl/GL.h>
#include <gl/glu.h>			// Header File For The GLu32 Library
#include <vector>
#define GLFW_INCLUDE_NONE
#include "glfw3.h"
#define GLFW_EXPOSE_NATIVE_WIN32
#define GLFW_EXPOSE_NATIVE_WGL

//#define GLFW_NATIVE_INCLUDE_NONE
#include "glfw3native.h"
//#include "linmath.h"

#pragma comment(lib,"opengl32.lib")
#pragma comment(lib,"glu32.lib")
#pragma comment(lib,"glfw3.lib")

void TRACE(_TCHAR* lpszFmt, ...)
{
#ifdef _DEBUG
	va_list args;
	va_start(args, lpszFmt);
	int len = _vsctprintf(lpszFmt, args) + 1;
	TCHAR* lpszBuf = (TCHAR*)_alloca(len * sizeof(TCHAR));//ջ�з���, ����Ҫ�ͷ�
	_vstprintf_s(lpszBuf, len, lpszFmt, args);
	va_end(args);
	OutputDebugString(lpszBuf);
#endif // _DEBUG
}

struct GL_Channel
{
	HWND           parentHWND;
	GLFWwindow* windows;
};

//#define GL_Channel GLFWwindow*

class GLContext
{
protected:
	std::vector<GL_Channel>   m_GLChannels;

	BOOL    _GladIsLoad = FALSE;

public:
	GLContext() {}

	~GLContext()
	{
		shutdown();
	}


	bool CreateGLContent(HWND hWnd, const float c_GLVersion = 3.2f);

	//���� EGL
	void shutdown();

	//����������
	void swapBuffer();

	void WindowResize();

	virtual void UserInitialize() {};

	virtual void PreDrawProcess(GL_Channel& _channel) {};
	virtual void GLDrawProcess(GL_Channel& _channel) {};

	virtual void UserDestroy() {};
private:

	static HMODULE _InsideHModleInstance(HMODULE _HModule = NULL, int _Release = false)
	{
		static HMODULE s_lModleInst = NULL;
		if (_HModule != NULL)
		{
			s_lModleInst = _HModule;
		}
		else
		{
			if (_Release == true)
			{
				FreeLibrary(s_lModleInst);
				s_lModleInst = NULL;
			}
		}
		return s_lModleInst;
	}

	static void* cWGLGetProcAddr(const char* name)
	{
		auto ret = wglGetProcAddress(name);
		if (ret == NULL)
		{
			ret = GetProcAddress(_InsideHModleInstance(), name);
		}
		return ret;
	}
public:
	static bool initgladFuncAddr() noexcept
	{
		//assert(wglGetCurrentContext() != NULL);     // ��֤wgl�к��ʵ�������
		HMODULE glInst = LoadLibraryA("opengl32.dll");
		_InsideHModleInstance(glInst);
		if (gladLoadGLLoader(cWGLGetProcAddr) == 0)
		{
			return false;
		}
		if (_InsideHModleInstance() != NULL)
		{
			_InsideHModleInstance(NULL, true);
		}
		return true;
	}
};

inline bool GLContext::CreateGLContent(HWND parentWnd, const float c_GLVersion)
{
	RECT rect;
	::GetClientRect(parentWnd, &rect);
	GL_Channel t_Channel;
	if (!glfwInit())
		exit(EXIT_FAILURE);

	int  InsideGLVersion = (int)(c_GLVersion * 10);
	int  tempGLMajorVersion = InsideGLVersion * 0.1;
	int  tempGLMinorVersion = InsideGLVersion - tempGLMajorVersion * 10;

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, tempGLMajorVersion);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, tempGLMinorVersion);

	if ((InsideGLVersion > 30) && (InsideGLVersion < 32))
		glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_COMPAT_PROFILE);
	else
		if (InsideGLVersion > 33)
			glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);


	t_Channel.windows = glfwCreateWindow(rect.right - rect.left, rect.bottom - rect.top,
		"OpenGLWindow", NULL, NULL);
	if (!t_Channel.windows)
	{
		glfwTerminate();
		exit(EXIT_FAILURE);
	}
	t_Channel.parentHWND = parentWnd;

	glfwMakeContextCurrent(t_Channel.windows);

	if (_GladIsLoad == FALSE)
	{
		initgladFuncAddr();
		_GladIsLoad = TRUE;
	}
	glfwSwapInterval(1);

	//SDL2�� SDL_GetWindowWMInfo()�������������ͨ�����߾ȹ��õ����ھ����glfw���鷳�㡣
//���glfw�����Ĵ��ھ��
	HWND hWnd = (HWND)glfwGetWindowHandle(t_Channel.windows);//glfwGetWin32Window(window);//WindowFromDC(wglGetCurrentDC());

	//���õ��Լ��Ĵ����У����˲�����ɣ����Կ���Ч����
	::SetParent(hWnd, parentWnd);
	::SetWindowLongPtr(hWnd, GWL_STYLE, WS_CHILD | WS_VISIBLE);
	::SetWindowLongPtr(hWnd, GWLP_WNDPROC, NULL);// reinterpret_cast<LONG>(MyWndProc));

	//int menuHeight = GetSystemMetrics(SM_CYMENU); // ��ȡ�˵����߶�
	::MoveWindow(hWnd, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, TRUE);

	m_GLChannels.emplace_back(t_Channel);

	UserInitialize();



	return true;
}

inline void GLContext::shutdown()
{
	UserDestroy();
	auto pIt = m_GLChannels.begin();
	while (pIt != m_GLChannels.end())
	{
		GL_Channel& p = *pIt;
		glfwDestroyWindow(p.windows);

		m_GLChannels.erase(pIt);

		pIt = m_GLChannels.begin();
	}
	glfwTerminate();
}

inline void GLContext::WindowResize()
{
	auto pIt = m_GLChannels.begin();
	while (pIt != m_GLChannels.end())
	{
		RECT rect;
		::GetClientRect(pIt->parentHWND, &rect);

		HWND _hWnd = (HWND)glfwGetWindowHandle(pIt->windows);
		::MoveWindow(_hWnd, rect.left, rect.top, rect.right - rect.left,
			rect.bottom - rect.top, TRUE);
		pIt++;
	}
}

//˫���� ���н���
inline void GLContext::swapBuffer()
{
	int tSize = m_GLChannels.size();
	if (tSize == 1)
	{
		int width, height;
		glfwGetFramebufferSize(m_GLChannels[0].windows, &width, &height);
		//const float ratio = width / (float)height;

		glViewport(0, 0, width, height);
		glClear(GL_COLOR_BUFFER_BIT);

		PreDrawProcess(m_GLChannels[0]);
		GLDrawProcess(m_GLChannels[0]);

		glfwSwapBuffers(m_GLChannels[0].windows);
	}
	else
	{
		for (int i = 0; i < tSize; i++)
		{
			glfwMakeContextCurrent(m_GLChannels[i].windows);

			int width, height;
			glfwGetFramebufferSize(m_GLChannels[0].windows, &width, &height);
			glViewport(0, 0, width, height);
			glClear(GL_COLOR_BUFFER_BIT);

			PreDrawProcess(m_GLChannels[i]);
			GLDrawProcess(m_GLChannels[i]);

			glfwSwapBuffers(m_GLChannels[i].windows);
		}
	}
}

#endif
