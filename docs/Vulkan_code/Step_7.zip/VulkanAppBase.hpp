#pragma once
#define  VK_USE_PLATFORM_WIN32_KHR
#include "VulkanAppCore.hpp"
#include <windows.h>
#include <chrono>

#define GLM_FORCE_RADIANS
#define GLM_FORCE_DEPTH_ZERO_TO_ONE
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <array>

const int MAX_FRAMES_IN_FLIGHT = 2;
//https://zhuanlan.zhihu.com/p/558543232

struct Vertex {
    glm::vec3 pos;
    glm::vec3 color;

    static VkVertexInputBindingDescription getBindingDescription()
    {
        VkVertexInputBindingDescription bindingDescription = {};

        bindingDescription.binding = 0;
        bindingDescription.stride = sizeof(Vertex);
        bindingDescription.inputRate = VK_VERTEX_INPUT_RATE_VERTEX;

        return bindingDescription;
    }
    static VkVertexInputBindingDescription2EXT getBindingDescription2EXT()
    {
        VkVertexInputBindingDescription2EXT bindingDescription2EXT = {};
        bindingDescription2EXT.sType = VK_STRUCTURE_TYPE_VERTEX_INPUT_BINDING_DESCRIPTION_2_EXT;
        bindingDescription2EXT.pNext = nullptr;
        bindingDescription2EXT.binding = 0;
        bindingDescription2EXT.stride = sizeof(Vertex);
        bindingDescription2EXT.inputRate = VK_VERTEX_INPUT_RATE_VERTEX;
        bindingDescription2EXT.divisor = 1;
        return bindingDescription2EXT;
    }
    static std::array<VkVertexInputAttributeDescription, 2> getAttributeDescriptions()
    {
        std::array<VkVertexInputAttributeDescription, 2> attributeDescriptions = {};
        attributeDescriptions[0].binding = 0;
        attributeDescriptions[0].location = 0;
        attributeDescriptions[0].format = VK_FORMAT_R32G32_SFLOAT;
        attributeDescriptions[0].offset = offsetof(Vertex, pos);

        attributeDescriptions[1].binding = 0;
        attributeDescriptions[1].location = 1;
        attributeDescriptions[1].format = VK_FORMAT_R32G32B32_SFLOAT;
        attributeDescriptions[1].offset = offsetof(Vertex, color);

        return attributeDescriptions;
    }
    static std::array<vk::VertexInputAttributeDescription2EXT, 2> getAttributeDescriptions2EXT()
    {
        std::array<vk::VertexInputAttributeDescription2EXT, 2> attributeDescriptions2EXT = {};
        //attributeDescriptions2EXT[0].sType = VK_STRUCTURE_TYPE_VERTEX_INPUT_ATTRIBUTE_DESCRIPTION_2_EXT;
        attributeDescriptions2EXT[0].pNext = nullptr;
        attributeDescriptions2EXT[0].binding = 0;
        attributeDescriptions2EXT[0].location = 0;
        attributeDescriptions2EXT[0].format = vk::Format::eR32G32B32A32Sfloat;//VK_FORMAT_R32G32B32_SFLOAT;
        attributeDescriptions2EXT[0].offset = offsetof(Vertex, pos);
        //attributeDescriptions2EXT[1].sType = VK_STRUCTURE_TYPE_VERTEX_INPUT_ATTRIBUTE_DESCRIPTION_2_EXT;
        attributeDescriptions2EXT[1].pNext = nullptr;
        attributeDescriptions2EXT[1].binding = 0;
        attributeDescriptions2EXT[1].location = 1;
        attributeDescriptions2EXT[1].format = vk::Format::eR32G32B32A32Sfloat; //VK_FORMAT_R32G32B32_SFLOAT;
        attributeDescriptions2EXT[1].offset = offsetof(Vertex, color);

        return attributeDescriptions2EXT;
    }
    static uint32_t getVertiesSize()
    {
        return sizeof(Vertex);
    }
};

const std::vector<Vertex> vertices = {
    {{1.0f, 0.0f,  -1.0f}, {1.0f, 0.0f, 0.0f}},
    {{1.0f, 0.0f,  1.0f}, {0.0f, 1.0f, 0.0f}},
    {{-1.0f, 0.0f,  1.0f}, {0.0f, 0.0f, 1.0f}},
   
    {{1.0f, 0.0f,  -1.0f}, {0.0f, 0.0f, 1.0f}},
    { {1.0f, 0.0f,  1.0f }, {1.0f, 0.0f, 0.0f} },
    {{0.0f, 1.0f,  0.0f}, {1.0f, 0.0f, 0.0f}},

    { {1.0f, 0.0f,  1.0f}, {0.0f, 0.0f, 1.0f} },
    { {-1.0f, 0.0f,  1.0f }, {1.0f, 0.0f, 0.0f} },
    { {0.0f, 1.0f,  0.0f}, {1.0f, 0.0f, 0.0f}},

    { { -1.0f, 0.0f,  1.0f}, {0.0f, 0.0f, 1.0f} },
    { {1.0f, 0.0f,  -1.0f}, {1.0f, 0.0f, 0.0f} },
    { {0.0f, 1.0f,  0.0f}, {1.0f, 0.0f, 0.0f}}
};

struct UniformBufferObject {
    glm::mat4 model;
    glm::mat4 view;
    glm::mat4 proj;
};

class VulkanAppBase : public VulkanAppCore
{
protected:
	vk::SwapchainKHR swapChain;  //����������
	std::vector<vk::Image> swapChainImages;       //�������п��Թ�����ʹ�õ�ͼ��
	vk::Format swapChainImageFormat;              //��������ͼ��ĸ�ʽ

    std::vector<vk::ImageView> swapChainImageViews;//�뽻������ͼ��һһ��Ӧ��ͼ�����ͼ���󣬳���ֻ��ͨ��VkImageView������ܷ���VkImage����
 
    vk::RenderPass renderPass;

    std::vector<vk::Framebuffer> swapChainFramebuffers;//��������ͼ���֡�������֡�����������Ⱦ������Ŀ����󣬳���ֻ��ͨ��VkFramebuffer������ܷ���VkImageView����

    vk::PipelineLayout     pipelineLayout; //����VkPipeLine����ɫ���������ݵĲ�ṹLayout����
    vk::Pipeline           graphicsPipeline;//����VkPipeline����

    vk::CommandPool                 commandPool;
    vk::CommandBuffer               commandBuffer;
    VulkanVertexBuffer<Vertex,2>  vertexBufferObject;

    vk::Semaphore imageAvailableSemaphore;
    vk::Semaphore renderFinishedSemaphore;
    vk::Fence     inFlightFence;

public:
    VkExtent2D swapChainExtent;                 //��������ͼ����Ϣ����չ��һ����ͼ��Ĵ�С�����ڵĴ�С��
	void initVulkan()
	{
		VulkanAppCore::initVulkan();
		//�����к������ӳ�ʼ������
        createSwapChain();
        createImageViews();
        createCommandPool();
        createCommandBuffer();

        createDepthResources();

        createRenderPass();
        createFramebuffers();

        createDescriptorSetLayout();
        createUniformBuffer();
        createDescriptorPool();
        createDescriptorSet();

        createGraphicsPipeline();

        vertexBufferObject.Initialize(physicalDevice, logicDevice, vertices);
        

        createSyncObjects();

	}
	void cleanup()
	{
        vkDeviceWaitIdle(logicDevice);
        if (renderFinishedSemaphore != VK_NULL_HANDLE)
        {
            vkDestroySemaphore(logicDevice, renderFinishedSemaphore, nullptr);
            renderFinishedSemaphore = VK_NULL_HANDLE;
        }
        if (imageAvailableSemaphore != VK_NULL_HANDLE)
        {
            vkDestroySemaphore(logicDevice, imageAvailableSemaphore, nullptr);
            imageAvailableSemaphore = VK_NULL_HANDLE;
        }
        if (inFlightFence != VK_NULL_HANDLE)
        {
            vkDestroyFence(logicDevice, inFlightFence, nullptr);
            inFlightFence = VK_NULL_HANDLE;
        }

        vertexBufferObject.Destory();
        if (commandBuffer != VK_NULL_HANDLE)
        {
			logicDevice.freeCommandBuffers(commandPool, 1, &commandBuffer);
           // vkFreeCommandBuffers(logicDevice, commandPool, 1, &commandBuffer);
            commandBuffer = VK_NULL_HANDLE;
        }

        if (commandPool != VK_NULL_HANDLE)
        {
            vkDestroyCommandPool(logicDevice, commandPool, nullptr);
            commandPool = VK_NULL_HANDLE;
        }
        // ����ͼ�ιܵ�
        if (graphicsPipeline != nullptr)
        {
            vkDestroyPipeline(logicDevice, graphicsPipeline, nullptr);
            graphicsPipeline = nullptr;
        }
        // �ͷŹܵ�����
        if (pipelineLayout != nullptr)
        {
            vkDestroyPipelineLayout(logicDevice, pipelineLayout, nullptr);
            pipelineLayout = nullptr;
        }
        for (auto framebuffer : swapChainFramebuffers) {
            vkDestroyFramebuffer(logicDevice, framebuffer, nullptr);
        }

        if (renderPass != VK_NULL_HANDLE)
        {
            vkDestroyRenderPass(logicDevice, renderPass, nullptr);
            renderPass = VK_NULL_HANDLE;
        }
        if (depthImageView != VK_NULL_HANDLE)
        {
            vkDestroyImageView(logicDevice, depthImageView, nullptr);
            depthImageView = VK_NULL_HANDLE;
        }
       
        if (depthImage != VK_NULL_HANDLE)
        {
            vkDestroyImage(logicDevice, depthImage, nullptr);
            depthImage = VK_NULL_HANDLE;
        }
        
        if (depthImageMemory != VK_NULL_HANDLE)
        {
            vkFreeMemory(logicDevice, depthImageMemory, nullptr);
            depthImageMemory = VK_NULL_HANDLE;
        }
        for (auto imageView : swapChainImageViews)
        {
            vkDestroyImageView(logicDevice, imageView, nullptr);
        }
        if (swapChain != nullptr)
        {
            vkDestroySwapchainKHR(logicDevice, swapChain, nullptr);
            swapChain = nullptr;
        }

        if (descriptorPool != nullptr)
        {
            vkDestroyDescriptorPool(logicDevice, descriptorPool, nullptr);
            descriptorPool = nullptr;
        }
        if (descriptorSetLayout != nullptr)
        {
            vkDestroyDescriptorSetLayout(logicDevice, descriptorSetLayout, nullptr);
            descriptorSetLayout = nullptr;
        }
        if (uniformBuffer != nullptr)
        {
            vkDestroyBuffer(logicDevice, uniformBuffer, nullptr);
            uniformBuffer = nullptr;
        }
        if (uniformBufferMemory != nullptr)
        {
            vkFreeMemory(logicDevice, uniformBufferMemory, nullptr);
            uniformBufferMemory = nullptr;
        }
		//������ǰ���������ٴ���
		VulkanAppCore::cleanup();
	}

    void drawFrame();

    void cleanupSwapChain()
    {
        // �ͷ����е�֡������
        for (auto framebuffer : swapChainFramebuffers)
        {
            vkDestroyFramebuffer(logicDevice, framebuffer, nullptr);
        }
        // �ͷ�ָ�����
        // ���Դ�ͷ���´�������أ����൱�˷ѡ�����ѡ��ʹ��vkFreeCommandBuffers�����������е����������
        // ���������������еĳ��������µ����������
        //vkFreeCommandBuffers(logicDevice, commandPool,
        //	static_cast<uint32_t>(commandBuffers.size()), commandBuffers.data());
        if (commandBuffer != nullptr)
        {
			logicDevice.freeCommandBuffers(commandPool, 1, &commandBuffer);
            //vkFreeCommandBuffers(logicDevice, commandPool, 1, &commandBuffer);
            commandBuffer = nullptr;
        }
        // ����ͼ�ιܵ�
        if (graphicsPipeline != nullptr)
        {
            vkDestroyPipeline(logicDevice, graphicsPipeline, nullptr);
            graphicsPipeline = nullptr;
        }
        // �ͷŹܵ�����
        if (pipelineLayout != nullptr)
        {
            vkDestroyPipelineLayout(logicDevice, pipelineLayout, nullptr);
            pipelineLayout = nullptr;
        }
        // �ͷ���Ⱦͨ��
        if (renderPass != nullptr)
        {
            vkDestroyRenderPass(logicDevice, renderPass, nullptr);
            renderPass = nullptr;
        }
        if (depthImageView != VK_NULL_HANDLE)
        {
            vkDestroyImageView(logicDevice, depthImageView, nullptr);
            depthImageView = VK_NULL_HANDLE;
        }
        if (depthImage != VK_NULL_HANDLE)
        {
            vkDestroyImage(logicDevice, depthImage, nullptr);
            depthImage = VK_NULL_HANDLE;
        }

        if (depthImageMemory != VK_NULL_HANDLE)
        {
            vkFreeMemory(logicDevice, depthImageMemory, nullptr);
            depthImageMemory = VK_NULL_HANDLE;
        }
        // �ͷŽ�������Ӧ��ͼ����ͼ
        for (auto imageView : swapChainImageViews) {
            vkDestroyImageView(logicDevice, imageView, nullptr);
        }
        // �ͷŽ�����
        if (swapChain != nullptr)
        {
            vkDestroySwapchainKHR(logicDevice, swapChain, nullptr);
            swapChain = nullptr;
        }

    }
    void recreateSwapChain()
    {
        //����С������ʱ���õ��Ĵ��ڴ�С��0, ��������������֡��������СҲӦ����0��
        // ��������Ҫ��Ⱦ�������������һ����ѭ�����ȵ������ٴ���ʾ
        int width = 0, height = 0;
        while (width == 0 || height == 0) 
        {
            RECT  rect;
            ::GetWindowRect((HWND)hWnd, &rect);
			width = rect.right - rect.left;
			height = rect.bottom - rect.top;
        }
        vkDeviceWaitIdle(logicDevice);
        //����vkDeviceWaitIdle��ȷ��������Դ�Ѿ���ʹ�����
        vkDeviceWaitIdle(logicDevice);
        //�����뽻������������Դ����
        cleanupSwapChain();
        //�ؽ������������������������
        createSwapChain();
        createImageViews();
        //createCommandPool();//����û���ؽ������
        createCommandBuffer();//ʹ��ԭ��������ش����������
        createDepthResources();

        createRenderPass();
        createFramebuffers();
        createGraphicsPipeline();

    }

protected:
    void createSwapChain();

    vk::SurfaceFormatKHR chooseSwapSurfaceFormat(const std::vector<vk::SurfaceFormatKHR>& availableFormats);

 
    vk::PresentModeKHR chooseSwapPresentMode(const std::vector<vk::PresentModeKHR>& availablePresentModes);
  
    vk::Extent2D chooseSwapExtent(const vk::SurfaceCapabilitiesKHR& capabilities);

    void createImageViews();
    void createRenderPass();
    void createFramebuffers();

    void createGraphicsPipeline();

    void createCommandPool();

    //��commandPool�ϴ��������������
    void createCommandBuffer();
    void recordCommandBuffer(vk::CommandBuffer& commandBuffer, uint32_t imageIndex);
    void createSyncObjects();
protected:
    //https://guide.vulkan.net.cn/docs/chapter-3/depth_buffer/
    vk::Image          depthImage;
    vk::DeviceMemory   depthImageMemory;
    vk::ImageView      depthImageView;
    //����һ�����ͼ�����൱ֱ�ӵġ���Ӧ�þ�������ɫ������ͬ�ķֱ��ʣ��ɽ������ķ�Χ���壬
    //�ʺ�����ȸ�����ͼ��ʹ�ã���ѵ�ƽ�̺��豸�����ڴ�
    void createDepthResources()
    {
        vk::Format depthFormat = findDepthFormat();
        createImage(swapChainExtent.width, swapChainExtent.height,
            depthFormat,
            vk::ImageTiling::eOptimal,
            vk::ImageUsageFlagBits::eDepthStencilAttachment,
            vk::MemoryPropertyFlagBits::eDeviceLocal,
            depthImage, depthImageMemory);
        depthImageView = createImageView(depthImage, depthFormat,
            vk::ImageAspectFlagBits::eDepth);

        // ����Ⱦ���̿�ʼ�����Ȼ������ȸ����е����ݣ�����Ҫ�������ݵ����ͼ���С�������Ҫ��ͼ�񲼾ֽ��б任���������ʺ���Ϊ��ȸ���ʹ�á�
       // ��Ϊ���ǲ���Ҫ���ͼ��֮ǰ�����ݣ���������ʹ��VK_IMAGE_LAYOUT_UNDEFINED��Ϊ���ͼ��ĳ�ʼ���֡�
       // transitionImageLayout(depthImage, static_cast<VkFormat>(depthFormat), VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL);

    }
    vk::ImageView createImageView(vk::Image& image, const vk::Format& format, const vk::ImageAspectFlags& aspectFlags)
    {
        vk::ImageViewCreateInfo createInfo;
        createInfo.image = image;
        createInfo.viewType = vk::ImageViewType::e2D;//VK_IMAGE_VIEW_TYPE_2D;

        createInfo.format = format;
        createInfo.components.r = vk::ComponentSwizzle::eIdentity; //VK_COMPONENT_SWIZZLE_IDENTITY;
        createInfo.components.g = vk::ComponentSwizzle::eIdentity; //
        createInfo.components.b = vk::ComponentSwizzle::eIdentity; //
        createInfo.components.a = vk::ComponentSwizzle::eIdentity; //
        createInfo.subresourceRange.aspectMask = aspectFlags;//vk::ImageAspectFlagBits::eColor; //VK_IMAGE_ASPECT_COLOR_BIT;
        createInfo.subresourceRange.baseMipLevel = 0;
        createInfo.subresourceRange.levelCount = 1;
        createInfo.subresourceRange.baseArrayLayer = 0;
        createInfo.subresourceRange.layerCount = 1;

        vk::ImageView _ImageView;
        vk::Result result = logicDevice.createImageView(&createInfo , nullptr, &_ImageView);
        if (result != vk::Result::eSuccess)
        {
            throw std::runtime_error("failed to create image views!");
        }
        return _ImageView;
    }
    void createImage(uint32_t width, uint32_t height, vk::Format format, vk::ImageTiling tiling, vk::ImageUsageFlags usage, vk::MemoryPropertyFlags properties, vk::Image& image, vk::DeviceMemory& imageMemory)
    {
        vk::ImageCreateInfo imageInfo;
        //imageInfo.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
        imageInfo.imageType = vk::ImageType::e2D; //VK_IMAGE_TYPE_2D;
        imageInfo.extent.width = width;
        imageInfo.extent.height = height;
        imageInfo.extent.depth = 1;
        imageInfo.mipLevels = 1;
        imageInfo.arrayLayers = 1;
        imageInfo.format = format;
        imageInfo.tiling = tiling;
        imageInfo.initialLayout = vk::ImageLayout::eUndefined;  //VK_IMAGE_LAYOUT_UNDEFINED;
        imageInfo.usage = usage;
        imageInfo.samples = vk::SampleCountFlagBits::e1; //VK_SAMPLE_COUNT_1_BIT;
        imageInfo.sharingMode = vk::SharingMode::eExclusive; //VK_SHARING_MODE_EXCLUSIVE;
        auto result = logicDevice.createImage(imageInfo);// , nullptr, & image);
        if (result.result != vk::Result::eSuccess)
        {
            throw std::runtime_error("failed to create image!");
        }
        image = result.value;


        vk::MemoryRequirements memRequirements;
        logicDevice.getImageMemoryRequirements(image, &memRequirements);

        vk::MemoryAllocateInfo allocInfo;
        //allocInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
        allocInfo.allocationSize = memRequirements.size;
        allocInfo.memoryTypeIndex = findMemoryType(memRequirements.memoryTypeBits, properties);


        auto result1 = logicDevice.allocateMemory(allocInfo);// , nullptr, & imageMemory);
        if (result1.result != vk::Result::eSuccess)
        {
            throw std::runtime_error("failed to allocate image memory!");
        }
        imageMemory = result1.value;

        auto result2 = logicDevice.bindImageMemory(image, imageMemory, 0);
        if (result2 != vk::Result::eSuccess)
        {
            throw std::runtime_error("failed to bind image memory!");
        }
    }
    uint32_t findMemoryType(uint32_t typeFilter, vk::MemoryPropertyFlags& properties)
    {
        vk::PhysicalDeviceMemoryProperties memProperties;

        //vkGetPhysicalDeviceMemoryProperties(physicalDevice, &memProperties);
        physicalDevice.getMemoryProperties(&memProperties);
        for (uint32_t i = 0; i < memProperties.memoryTypeCount; i++)
        {
            if ((typeFilter & (1 << i)) && (memProperties.memoryTypes[i].propertyFlags & properties) == properties)
            {
                return i;
            }
        }

        throw std::runtime_error("failed to find suitable memory type!");
    }
    vk::Format findSupportedFormat(const std::vector<vk::Format>& candidates, vk::ImageTiling tiling, vk::FormatFeatureFlags features)
    {
        for (vk::Format format : candidates)
        {
            vk::FormatProperties props;
            physicalDevice.getFormatProperties(format, &props);
           
            if ((tiling == vk::ImageTiling::eLinear) && (props.linearTilingFeatures & features) == features)
            {
                return format;
            }
            else if ((tiling == vk::ImageTiling::eOptimal) && (props.optimalTilingFeatures & features) == features)
            {
                return format;
            }
        }

        throw std::runtime_error("failed to find supported format!");
    }
    vk::Format findDepthFormat()
    {
        return findSupportedFormat(
            { vk::Format::eD32Sfloat, vk::Format::eD32SfloatS8Uint,vk::Format::eD24UnormS8Uint },
            vk::ImageTiling::eOptimal,
            vk::FormatFeatureFlagBits::eDepthStencilAttachment
        );
    }
    //����һ���򵥵ĸ�������������������ѡ�����ȸ�ʽ�Ƿ����ģ�����:

    bool hasStencilComponent(const VkFormat& format)
    {
        return format ==  VK_FORMAT_D32_SFLOAT_S8_UINT || format == VK_FORMAT_D24_UNORM_S8_UINT;
    }
    /*
    VkCommandBuffer beginSingleTimeCommands()
    {
        VkCommandBufferAllocateInfo allocInfo = {};
        allocInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
        allocInfo.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
        allocInfo.commandPool = commandPool;
        allocInfo.commandBufferCount = 1;

        VkCommandBuffer tempCommandBuffer;
        vkAllocateCommandBuffers(logicDevice, &allocInfo, &tempCommandBuffer);

        VkCommandBufferBeginInfo beginInfo = {};
        beginInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
        beginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;

        vkBeginCommandBuffer(tempCommandBuffer, &beginInfo);

        return tempCommandBuffer;
    }
    void            endSingleTimeCommands(VkCommandBuffer commandBuffer) 
    {
        vkEndCommandBuffer(commandBuffer);

        VkSubmitInfo submitInfo = {};
        submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
        submitInfo.commandBufferCount = 1;
        submitInfo.pCommandBuffers = &commandBuffer;

        vkQueueSubmit(graphicsQueue, 1, &submitInfo, VK_NULL_HANDLE);
        vkQueueWaitIdle(graphicsQueue);

        vkFreeCommandBuffers(logicDevice, commandPool, 1, &commandBuffer);
    
    }
    void transitionImageLayout(VkImage image, VkFormat format, VkImageLayout oldLayout, VkImageLayout newLayout)
    {
        VkCommandBuffer commandBuffer = beginSingleTimeCommands();

        VkImageMemoryBarrier barrier = {};
        barrier.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
        barrier.oldLayout = oldLayout;
        barrier.newLayout = newLayout;
        barrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        barrier.image = image;
        //barrier.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        barrier.subresourceRange.baseMipLevel = 0;
        barrier.subresourceRange.levelCount = 1;
        barrier.subresourceRange.baseArrayLayer = 0;
        barrier.subresourceRange.layerCount = 1;

        if (newLayout == VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL) {
            barrier.subresourceRange.aspectMask = VK_IMAGE_ASPECT_DEPTH_BIT;

            if (hasStencilComponent(format)) {
                barrier.subresourceRange.aspectMask |= VK_IMAGE_ASPECT_STENCIL_BIT;
            }
        }
        else {
            barrier.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        }

        VkPipelineStageFlags sourceStage;
        VkPipelineStageFlags destinationStage;

        if (oldLayout == VK_IMAGE_LAYOUT_UNDEFINED && newLayout == VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL) {
            barrier.srcAccessMask = 0;
            barrier.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;

            sourceStage = VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT;
            destinationStage = VK_PIPELINE_STAGE_TRANSFER_BIT;
        }
        else if (oldLayout == VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL && newLayout == VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL) {
            barrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
            barrier.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;

            sourceStage = VK_PIPELINE_STAGE_TRANSFER_BIT;
            destinationStage = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
        }
        else if (oldLayout == VK_IMAGE_LAYOUT_UNDEFINED && newLayout == VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL) {
            barrier.srcAccessMask = 0;
            barrier.dstAccessMask = VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_READ_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;

            sourceStage = VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT;
            destinationStage = VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
        }
        else {
            throw std::invalid_argument("unsupported layout transition!");
        }


        vkCmdPipelineBarrier(
            commandBuffer,
            sourceStage, destinationStage,
            0,
            0, nullptr,
            0, nullptr,
            1, &barrier
        );

        endSingleTimeCommands(commandBuffer);
    }
    */
public: //uniform
    VkDescriptorSetLayout       descriptorSetLayout = VK_NULL_HANDLE;

    VkBuffer         uniformBuffer = VK_NULL_HANDLE;
    VkDeviceMemory   uniformBufferMemory = VK_NULL_HANDLE;

    VkDescriptorPool descriptorPool = VK_NULL_HANDLE;
    VkDescriptorSet  descriptorSet = nullptr;

    void createDescriptorSetLayout()
    {
        VkDescriptorSetLayoutBinding uboLayoutBinding = {};
        uboLayoutBinding.binding = 0;//��ӦShader�� "layout(binding = 0) uniform UBO" ��bindingֵ
        uboLayoutBinding.descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;//UNIFORM_BUFFERָ��������������Ϊͳһ������
        uboLayoutBinding.descriptorCount = 1;
        uboLayoutBinding.stageFlags = VK_SHADER_STAGE_VERTEX_BIT;//stageFLags��ʾ����������ڶ��㻺����ʹ��
        uboLayoutBinding.pImmutableSamplers = nullptr;

        VkDescriptorSetLayoutCreateInfo layoutInfo = {};
        layoutInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
        layoutInfo.bindingCount = 1;
        layoutInfo.pBindings = &uboLayoutBinding;

        if (vkCreateDescriptorSetLayout(logicDevice, &layoutInfo, nullptr, &descriptorSetLayout) != VK_SUCCESS) {
            throw std::runtime_error("failed to create descriptor set layout!");
        }
    }

    void createUniformBuffer()
    {

        VkDeviceSize bufferSize = sizeof(UniformBufferObject);

        createBuffer(bufferSize, VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, uniformBuffer, uniformBufferMemory);

    }
    void updateUniformBuffer(uint32_t currentImage)
    {
         static auto startTime = std::chrono::high_resolution_clock::now();

         auto currentTime = std::chrono::high_resolution_clock::now();
         float time = std::chrono::duration<float, std::chrono::seconds::period>(currentTime - startTime).count();

        UniformBufferObject ubo{};
       // ubo.model = glm::mat4(1.0f); //glm::rotate(glm::mat4(1.0f), 1 * glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
       // ubo.view = glm::mat4(1.0f); //glm::lookAt(glm::vec3(2.0f, 2.0f, 2.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
       // ubo.proj = glm::mat4(1.0f); //glm::perspective(glm::radians(45.0f), swapChainExtent.width / (float)swapChainExtent.height, 0.1f, 10.0f);
        
        //
        ubo.model = glm::rotate(glm::mat4(1.0f), time * glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        ubo.view = glm::lookAt(glm::vec3(2.0f, 2.0f, 2.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        ubo.proj = glm::perspective(glm::radians(45.0f), swapChainExtent.width / (float)swapChainExtent.height, 0.1f, 10.0f);
		ubo.proj[1][1] *= -1; // OpenGL��Y�������ϵģ���Vulkan��Y�������µģ�������Ҫ��Y�ᷭת

        void* data;
        vkMapMemory(logicDevice, uniformBufferMemory, 0, sizeof(ubo), 0, &data);
        memcpy(data, &ubo, sizeof(ubo));
        vkUnmapMemory(logicDevice, uniformBufferMemory);
    }
    void createDescriptorPool()
    {
        //���ͼ�������������
        std::array<VkDescriptorPoolSize, 1> poolSizes = {};
        poolSizes[0].type = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
        poolSizes[0].descriptorCount = 1;
        // poolSizes[1].type = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
       //  poolSizes[1].descriptorCount = 1;

        VkDescriptorPoolCreateInfo poolInfo = {};
        poolInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
        poolInfo.poolSizeCount = static_cast<uint32_t>(poolSizes.size());
        poolInfo.pPoolSizes = poolSizes.data();
        poolInfo.maxSets = 1;

        if (vkCreateDescriptorPool(logicDevice, &poolInfo, nullptr, &descriptorPool) != VK_SUCCESS) {
            throw std::runtime_error("failed to create descriptor pool!");
        }
    }
    void createDescriptorSet()
    {
        VkDescriptorSetLayout layouts[] = { descriptorSetLayout };
        VkDescriptorSetAllocateInfo allocInfo = {};
        allocInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
        allocInfo.descriptorPool = descriptorPool;
        allocInfo.descriptorSetCount = 1;
        allocInfo.pSetLayouts = layouts;
        if (vkAllocateDescriptorSets(logicDevice, &allocInfo, &descriptorSet) != VK_SUCCESS) {
            throw std::runtime_error("failed to allocate descriptor set!");
        }

        VkDescriptorBufferInfo bufferInfo = {};
        bufferInfo.buffer = uniformBuffer;
        bufferInfo.offset = 0;
        bufferInfo.range = sizeof(UniformBufferObject);

        // VkDescriptorImageInfo imageInfo = {};
        // imageInfo.imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
        // imageInfo.imageView = textureImageView;
        // imageInfo.sampler = textureSampler;
        std::array<VkWriteDescriptorSet, 1> descriptorWrites = {};

        descriptorWrites[0].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
        descriptorWrites[0].dstSet = descriptorSet;
        descriptorWrites[0].dstBinding = 0;
        descriptorWrites[0].dstArrayElement = 0;
        descriptorWrites[0].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
        descriptorWrites[0].descriptorCount = 1;
        descriptorWrites[0].pBufferInfo = &bufferInfo;

        // descriptorWrites[1].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
        // descriptorWrites[1].dstSet = descriptorSet;
        // descriptorWrites[1].dstBinding = 1;
        // descriptorWrites[1].dstArrayElement = 0;
        // descriptorWrites[1].descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
        // descriptorWrites[1].descriptorCount = 1;
        // descriptorWrites[1].pImageInfo = &imageInfo;

        vkUpdateDescriptorSets(logicDevice, static_cast<uint32_t>(descriptorWrites.size()), descriptorWrites.data(), 0, nullptr);

    }

    public:

        //����������
        void createBuffer(VkDeviceSize size, VkBufferUsageFlags usage, VkMemoryPropertyFlags properties, VkBuffer& buffer, VkDeviceMemory& bufferMemory)
        {
           // VkBufferCreateInfo bufferInfo = {};
          //  bufferInfo.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
          //  bufferInfo.size = sizeof(UniformBufferObject);
          //  bufferInfo.usage = VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT;
          //  bufferInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;

            //VkBuffer uniformBuffer;
          //  vkCreateBuffer(logicDevice, &bufferInfo, nullptr, &uniformBuffer);

            //����������
            VkBufferCreateInfo bufferInfo = {};
            bufferInfo.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
            bufferInfo.size = size;
            bufferInfo.usage = usage;
            bufferInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
            auto result = vkCreateBuffer(logicDevice, &bufferInfo, nullptr, &uniformBuffer);
            if (result != VkResult::VK_SUCCESS)
            {
                throw std::runtime_error("failed to create buffer!");
            }


            //�ڴ�����
            VkMemoryRequirements memRequirements;

            vkGetBufferMemoryRequirements(logicDevice, buffer, &memRequirements);

            //�ڴ����
            VkMemoryAllocateInfo allocInfo = {};
            allocInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
            allocInfo.allocationSize = memRequirements.size;
            vk::MemoryPropertyFlags tempproperties = static_cast<vk::MemoryPropertyFlags>(properties);
            allocInfo.memoryTypeIndex = findMemoryType(memRequirements.memoryTypeBits, tempproperties);

            auto result1 = logicDevice.allocateMemory(allocInfo);// , nullptr, &bufferMemory);
            if (result1.result != vk::Result::eSuccess)
            {
                throw std::runtime_error("failed to allocate buffer memory!");
            }
            bufferMemory = result1.value;


            //���ڴ������������
            if (logicDevice.bindBufferMemory(buffer, bufferMemory, 0) != vk::Result::eSuccess)
            {
                throw std::runtime_error("failed to bind buffer memory!");
            }
            // vkBindBufferMemory(logicDevice, buffer, bufferMemory, 0);
        }
};
