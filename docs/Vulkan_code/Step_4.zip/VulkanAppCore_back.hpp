﻿#pragma warning(disable: 4996)
#pragma once
#if defined(VK_USE_PLATFORM_XLIB_KHR) || defined(VK_USE_PLATFORM_XCB_KHR)
#include <X11/Xutil.h>
#elif defined(VK_USE_PLATFORM_WAYLAND_KHR)
#include <linux/input.h>
#include "xdg-shell-client-header.h"
#include "xdg-decoration-client-header.h"
#endif  

import <cassert>;
import <cinttypes>;
import <cstdio>;
import <cstdlib>;
import <cstring>;
import <csignal>;

import <sstream>;
import <iostream>;
import <memory>;
import <stdexcept>;
import <vector>;
import <optional>;
import <set>;


#define VULKAN_HPP_DISPATCH_LOADER_DYNAMIC 1
#define VULKAN_HPP_NO_EXCEPTIONS
#define VULKAN_HPP_TYPESAFE_CONVERSION 1
#define NOMINMAX
#define VK_NO_PROTOTYPES
#include <vulkan/vulkan.hpp>

#include <vulkan/vulkan_structs.hpp>

#define VOLK_IMPLEMENTATION
#include "volk/volk.h"

VULKAN_HPP_DEFAULT_DISPATCH_LOADER_DYNAMIC_STORAGE

#include "TraceMsg.h"

// 
//通过程序应用需要的库文件
//#pragma comment( lib,"vulkan-1.lib" )


#ifndef NDEBUG
#define VERIFY(x)  assert(x)
inline  const bool enableValidationLayers = true;
#else
inline const bool enableValidationLayers = false;
#define VERIFY(x) ((void)(x))
#endif


#ifdef _WIN32
#define ERR_EXIT(err_msg, err_class)                                          \
    do {                                                                      \
        if (!suppress_popups) MessageBox(nullptr, err_msg, err_class, MB_OK); \
        exit(1);                                                              \
    } while (0)
#else
#define ERR_EXIT(err_msg, err_class) \
    do {                             \
        printf("%s\n", err_msg);     \
        fflush(stdout);              \
        exit(1);                     \
    } while (0)
#endif


inline const std::vector<const char*> deviceExtensions = {
    VK_KHR_SWAPCHAIN_EXTENSION_NAME,
    VK_EXT_VERTEX_INPUT_DYNAMIC_STATE_EXTENSION_NAME,
    VK_KHR_MAINTENANCE_1_EXTENSION_NAME,
    VK_KHR_VERTEX_ATTRIBUTE_DIVISOR_EXTENSION_NAME,
    VK_EXT_CUSTOM_BORDER_COLOR_EXTENSION_NAME
};
//在显卡GPU驱动设计过程中，图形队列族并不一定能够将所拥有的图形信息传输到显示设备上，
// Vulkan还设计了显示队列族，图形队列族和显示队列族可以是同一个队列族，也可以是不同的队列族。
struct QueueFamilyIndices
{
    std::optional<uint32_t>      graphicsFamily;   //图形队列族索引
    std::optional<uint32_t>      presentFamily;    //显示队列族索引
    bool isComplete()
    {
        return graphicsFamily.has_value() && presentFamily.has_value();
    }
};
struct SwapChainSupportDetails
{
    VkSurfaceCapabilitiesKHR           capabilities;
    std::vector<VkSurfaceFormatKHR>    formats;
    std::vector<VkPresentModeKHR>      presentModes;
};

static inline int validation_error = 0;

class VulkanAppCore
{
private:
    vk::Bool32 PlateformSurfaceExtChech(const char* extensionName);
    void PlatformSurfaceExtFoundError();
protected:
    std::vector<const char*> enabled_layers;
    std::vector<const char*> enabled_instance_extensions;
    std::vector<VkExtensionProperties> m_VkDeviceExtensionPropertis;
    std::vector<const char*> enabled_device_extensions;

protected:
    bool suppress_popups = false;
    bool use_debug_messenger = false;

    const uint32_t WIDTH = 800;
    const uint32_t HEIGHT = 600;


    HINSTANCE hInstance = nullptr;//GetModuleHandle(NULL);
    HWND      hwnd = nullptr;

    vk::Instance inst;
    vk::DebugUtilsMessengerEXT debug_messenger;
    vk::SurfaceKHR             surface;
    vk::PhysicalDevice         physicalDevice;
    vk::Device                 logicDevice;
public:
    std::string ApplicationName = "VULKAN_APPLICATION";
public:
    VulkanAppCore()
    {

    }
    VulkanAppCore(const std::string& _ApplicationName)
    {
        ApplicationName = _ApplicationName;
    }
    ~VulkanAppCore()
    {
        cleanup();
    }


    void init_vulkan(HWND _hwnd);
    void cleanup()
    {
        if (logicDevice != nullptr)
        {
            logicDevice.destroy();
            logicDevice = nullptr;
        }

        if (physicalDevice != nullptr)
        {
           
        }
            if (surface != nullptr)
            {
                inst.destroySurfaceKHR(surface);
                surface = nullptr;
            }
            if (use_debug_messenger)
            {
                if (debug_messenger != nullptr)
                {
                    inst.destroyDebugUtilsMessengerEXT(debug_messenger);
                    debug_messenger = nullptr;
                }  
            }
            if (inst != nullptr)
            {
                inst.destroy();
                inst = nullptr;
            }
            

            volkFinalize();

    }
    void create_surface(HWND _hwnd);
    void createLogicalDevice();
protected:
    vk::Bool32 check_layers(const std::vector<const char*>& check_names, const std::vector<vk::LayerProperties>& layers) {
        for (const auto& name : check_names) {
            vk::Bool32 found = VK_FALSE;
            for (const auto& layer : layers) {
                if (!strcmp(name, layer.layerName)) {
                    found = VK_TRUE;
                    break;
                }
            }
            if (!found) {
                fprintf(stderr, "Cannot find layer: %s\n", name);
                return 0;
            }
        }
        return VK_TRUE;
    }
    static VKAPI_ATTR VkBool32 VKAPI_CALL debug_messenger_callback(VkDebugUtilsMessageSeverityFlagBitsEXT messageSeverity,
        VkDebugUtilsMessageTypeFlagsEXT messageType,
        const VkDebugUtilsMessengerCallbackDataEXT* pCallbackData,
        void* pUserData);

    bool isDeviceSuitable(VkPhysicalDevice _physicaldevice);
    QueueFamilyIndices findQueueFamilies(VkPhysicalDevice _physicalDevice);
    bool CheckPhysicalDeviceExtensionSupport(VkPhysicalDevice _physicaldevice,
                         const std::vector<const char*>& _AppNeedPhysicalDeviceExtensions);
    std::vector<VkExtensionProperties>  getAvailableExtensionsProperties(VkPhysicalDevice _physicalDevice);
    SwapChainSupportDetails    querySwapChainSupport(VkPhysicalDevice device);

};
inline void VulkanAppCore::init_vulkan(HWND _hwnd)
{
	hwnd = _hwnd;

    VkResult err = volkInitialize();
    if (err != VK_SUCCESS) 
    {
        ERR_EXIT(
            L"Unable to find the Vulkan runtime on the system.\n\n This likely indicates that no Vulkan capable drivers are installed.",
            L"Installation Failure");
    }
    
    VULKAN_HPP_DEFAULT_DISPATCHER.init(vkGetInstanceProcAddr);

    std::vector<char const*> instance_validation_layers = { "VK_LAYER_KHRONOS_validation" };

    vk::Bool32  validation_found = vk::False;
    auto layers = vk::enumerateInstanceLayerProperties();
    VERIFY(layers.result == vk::Result::eSuccess);
    if (enableValidationLayers == true)
    {
        validation_found = check_layers(instance_validation_layers, layers.value);
        if (validation_found == vk::True) 
        {
            enabled_layers.push_back("VK_LAYER_KHRONOS_validation");
        }
        else 
        {
            ERR_EXIT(
                L"vkEnumerateInstanceLayerProperties failed to find required validation layer.\n\n Please look at the Getting Started guide for additional information.\n",
                L"vkCreateInstance Failure");
        }
    }
    vk::Bool32 surfaceExtFound = VK_FALSE;
    vk::Bool32 platformSurfaceExtFound = VK_FALSE;
    bool portabilityEnumerationActive = false;

    auto instance_extensions_return = vk::enumerateInstanceExtensionProperties();
    VERIFY(instance_extensions_return.result == vk::Result::eSuccess);

    for (const auto& extension : instance_extensions_return.value)
    {
        if (!strcmp(VK_KHR_GET_PHYSICAL_DEVICE_PROPERTIES_2_EXTENSION_NAME, extension.extensionName))
        {
            enabled_instance_extensions.push_back(VK_KHR_GET_PHYSICAL_DEVICE_PROPERTIES_2_EXTENSION_NAME);
        }
        else if (!strcmp(VK_EXT_DEBUG_UTILS_EXTENSION_NAME, extension.extensionName))
        {
            use_debug_messenger = true;
            enabled_instance_extensions.push_back(VK_EXT_DEBUG_UTILS_EXTENSION_NAME);
        }
        else if (!strcmp(VK_KHR_PORTABILITY_ENUMERATION_EXTENSION_NAME, extension.extensionName))
        {
            //检测VK_KHR_portability_subset扩展，该扩展允许在支撑Vulkan最小化子集的系统中运行程序，
            portabilityEnumerationActive = true;
            enabled_instance_extensions.push_back(VK_KHR_PORTABILITY_ENUMERATION_EXTENSION_NAME);
        }
        else if (!strcmp(VK_KHR_SURFACE_EXTENSION_NAME, extension.extensionName))
        {
            surfaceExtFound = 1;
            enabled_instance_extensions.push_back(VK_KHR_SURFACE_EXTENSION_NAME);
        }
        else
        {
            if (PlateformSurfaceExtChech(extension.extensionName) == vk::True)
            {
                platformSurfaceExtFound = 1;
                enabled_instance_extensions.push_back(extension.extensionName);
            }
        }
    }

    if (!surfaceExtFound) 
    {
            std::string tempStr = "vkEnumerateInstanceExtensionProperties failed to find the ";
            tempStr += std::string(VK_KHR_SURFACE_EXTENSION_NAME);
            tempStr += " extension.\n\n";
            tempStr += "Do you have a compatible Vulkan installable client driver (ICD) installed?\n";
            tempStr += "Please look at the Getting Started guide for additional information.\n";
            std::wstring tempWStr = String2WString(tempStr);
            ERR_EXIT(tempWStr.c_str(),L"vkCreateInstance Failure");
    }

    if (!platformSurfaceExtFound) 
    {
            PlatformSurfaceExtFoundError();
    }
   // createInfo.messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_VERBOSE_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT;
   // createInfo.messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT;
    vk::DebugUtilsMessageSeverityFlagsEXT severityFlags(vk::DebugUtilsMessageSeverityFlagBitsEXT::eInfo|
                   vk::DebugUtilsMessageSeverityFlagBitsEXT::eWarning |
                   vk::DebugUtilsMessageSeverityFlagBitsEXT::eError|
                   vk::DebugUtilsMessageSeverityFlagBitsEXT::eVerbose);
   
    vk::DebugUtilsMessageTypeFlagsEXT messageTypeFlags(vk::DebugUtilsMessageTypeFlagBitsEXT::eGeneral |
        vk::DebugUtilsMessageTypeFlagBitsEXT::ePerformance |
        vk::DebugUtilsMessageTypeFlagBitsEXT::eValidation|
        vk::DebugUtilsMessageTypeFlagBitsEXT::eDeviceAddressBinding);

    auto debug_utils_create_info = vk::DebugUtilsMessengerCreateInfoEXT({}, severityFlags, messageTypeFlags,
                      &debug_messenger_callback, static_cast<void*>(this));

    auto const app = vk::ApplicationInfo()
        .setPApplicationName( ApplicationName.c_str() )
        .setApplicationVersion(0)
        .setPEngineName( ApplicationName.c_str())
        .setEngineVersion(0)
        .setApiVersion(VK_API_VERSION_1_0);

    auto const inst_info = vk::InstanceCreateInfo()
        .setFlags(portabilityEnumerationActive ? vk::InstanceCreateFlagBits::eEnumeratePortabilityKHR
            : static_cast<vk::InstanceCreateFlagBits>(0))
        .setPNext(((use_debug_messenger==true) && (enableValidationLayers==true)) ? &debug_utils_create_info : nullptr)
        .setPApplicationInfo(&app)
        .setPEnabledLayerNames(enabled_layers)
        .setPEnabledExtensionNames(enabled_instance_extensions);

    auto instance_result = vk::createInstance(inst_info);
    if (instance_result.result == vk::Result::eErrorIncompatibleDriver) 
    {
        ERR_EXIT(
            L"Cannot find a compatible Vulkan installable client driver (ICD).\n\n \
              Please look at the Getting Started guide for additional information.\n",
            L"vkCreateInstance Failure");
    }
    else if (instance_result.result == vk::Result::eErrorExtensionNotPresent) {
        ERR_EXIT(
            L"Cannot find a specified extension library.\n \
              Make sure your layers path is set appropriately.\n",
            L"vkCreateInstance Failure");
    }
    else if (instance_result.result != vk::Result::eSuccess) {
        ERR_EXIT(
            L"vkCreateInstance failed.\n\n \
              Do you have a compatible Vulkan installable client driver (ICD) installed?\n \
              Please look at the Getting Started guide for additional information.\n",
            L"vkCreateInstance Failure");
    }
    inst = instance_result.value;
    volkLoadInstance(inst);
   // volkLoadInstanceOnly(inst);


    VULKAN_HPP_DEFAULT_DISPATCHER.init(inst);
    if (use_debug_messenger) 
    {
        auto create_debug_messenger_return = inst.createDebugUtilsMessengerEXT(debug_utils_create_info);
        VERIFY(create_debug_messenger_return.result == vk::Result::eSuccess);
        debug_messenger = create_debug_messenger_return.value;
    }

    create_surface(_hwnd);

    auto physical_device_return = inst.enumeratePhysicalDevices();
    VERIFY(physical_device_return.result == vk::Result::eSuccess);
    auto physical_devices = physical_device_return.value;

    if (physical_devices.size() <= 0) 
    {
        ERR_EXIT(
            L"vkEnumeratePhysicalDevices reported zero accessible devices.\n\n \
              Do you have a compatible Vulkan installable client driver (ICD) installed?\n \
              Please look at the Getting Started guide for additional information.\n",
            L"vkEnumeratePhysicalDevices Failure");
    }
    //if (invalid_gpu_selection || (gpu_number >= 0 && !(static_cast<uint32_t>(gpu_number) < physical_devices.size()))) 
   // {
   //     fprintf(stderr, "GPU %d specified is not present, GPU count = %zu\n", gpu_number, physical_devices.size());
   //     ERR_EXIT("Specified GPU number is not present", "User Error");
   // }
    for (const auto& device : physical_devices)
    {
        //std::vector<VULKAN_HPP_NAMESPACE::PhysicalDevice, PhysicalDeviceAllocator>
        vk::PhysicalDevice   _device = device;
        if (isDeviceSuitable(device))
        {
            physicalDevice = device;
            m_VkDeviceExtensionPropertis = getAvailableExtensionsProperties(physicalDevice);
            break;
        }
    }
    if (physicalDevice == VK_NULL_HANDLE) 
    {
        ERR_EXIT(L"failed to find a suitable GPU!",
            L"pickPhysicalDevice");
    }
    createLogicalDevice();
}

inline void VulkanAppCore::create_surface(HWND _hwnd) 
{
    // Create a WSI surface for the window:
#if defined(VK_USE_PLATFORM_WIN32_KHR)
    {
        if (hInstance == NULL)
        {
            hInstance = GetModuleHandle(NULL);
        }
        auto const createInfo = vk::Win32SurfaceCreateInfoKHR().setHinstance(hInstance).setHwnd(_hwnd);

        auto result = inst.createWin32SurfaceKHR(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);

    }
#elif defined(VK_USE_PLATFORM_WAYLAND_KHR)
    {
        auto const createInfo = vk::WaylandSurfaceCreateInfoKHR().setDisplay(display).setSurface(window);

        auto result = inst.createWaylandSurfaceKHR(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);
    }
#elif defined(VK_USE_PLATFORM_XLIB_KHR)
    {
        auto const createInfo = vk::XlibSurfaceCreateInfoKHR().setDpy(display).setWindow(xlib_window);

        auto result = inst.createXlibSurfaceKHR(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);
    }
#elif defined(VK_USE_PLATFORM_XCB_KHR)
    {
        auto const createInfo = vk::XcbSurfaceCreateInfoKHR().setConnection(connection).setWindow(xcb_window);

        auto result = inst.createXcbSurfaceKHR(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);
    }
#elif defined(VK_USE_PLATFORM_DIRECTFB_EXT)
    {
        auto const createInfo = vk::DirectFBSurfaceCreateInfoEXT().setDfb(dfb).setSurface(window);

        auto result = inst.createDirectFBSurfaceEXT(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);
    }
#elif defined(VK_USE_PLATFORM_METAL_EXT)
    {
        auto const createInfo = vk::MetalSurfaceCreateInfoEXT().setPLayer(static_cast<CAMetalLayer*>(caMetalLayer));

        auto result = inst.createMetalSurfaceEXT(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);
    }
#elif defined(VK_USE_PLATFORM_DISPLAY_KHR)
    {
        auto result = create_display_surface();
        VERIFY(result == vk::Result::eSuccess);
    }
#elif defined(VK_USE_PLATFORM_SCREEN_QNX)
    {
        auto const createInfo = vk::ScreenSurfaceCreateInfoQNX().setContext(screen_context).setWindow(screen_window);

        auto result = inst.createScreenSurfaceQNX(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);
    }
#endif
}

inline void VulkanAppCore::createLogicalDevice()
{
    //❶ 指定要创建的队列
      //创建逻辑设备需要VkDeviceQueueCreateInfo结构体，这一结构体描述了针对一个队列族我们所需的队列数量，
      // 目前我们使用带有图形能力的队列族和显示队列族。
    QueueFamilyIndices   indices = findQueueFamilies(physicalDevice);

    //我们需要一个队列列表，保存需要创建的逻辑设备一同创建的队列族类型
    std::vector<VkDeviceQueueCreateInfo> queueCreateInfos;
    //从indices结构中检索出我们需要的队列族放到集合中
    std::set<uint32_t> uniqueQueueFamilies = { indices.graphicsFamily.value(), indices.presentFamily.value() };

    //Vulkan需要我们赋予队列一个0.0到1.0之间的浮点数来控制队列优先级。即使只有一个队列，也要显式地赋予队列优先级：
    float queuePriority = 1.0f;

    std::vector<vk::DeviceQueueCreateInfo>    queues;
    for (uint32_t queueFamily : uniqueQueueFamilies) //根据集合中的队列信息设置VkDeviceQueueCreateInfo列表
    {
        VkDeviceQueueCreateInfo queueCreateInfo{};
        queueCreateInfo.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
        queueCreateInfo.queueFamilyIndex = queueFamily;
        queueCreateInfo.queueCount = 1;
        queueCreateInfo.pQueuePriorities = &queuePriority;

        queueCreateInfos.push_back(queueCreateInfo);
        queues.push_back(vk::DeviceQueueCreateInfo(queueCreateInfo));
    }
     
    /*
    queues.push_back(vk::DeviceQueueCreateInfo()
                     .setQueueFamilyIndex(indices.graphicsFamily.value())
                     .setQueuePriorities(queuePriority));
    //if (separate_present_queue) 
    if(indices.graphicsFamily != indices.presentFamily)
    {
        queues.push_back(
            vk::DeviceQueueCreateInfo()
            .setQueueFamilyIndex(indices.presentFamily.value())
            .setQueuePriorities(queuePriority));
    }*/

    auto deviceInfo = vk::DeviceCreateInfo();
    deviceInfo.setQueueCreateInfos(queues);
    deviceInfo.setPEnabledExtensionNames(enabled_device_extensions);

    auto device_return = physicalDevice.createDevice(deviceInfo);
    VERIFY(device_return.result == vk::Result::eSuccess);
    logicDevice = device_return.value;
    //volkLoadInstance(inst);
    //volkLoadDevice(logicDevice);
    //VULKAN_HPP_DEFAULT_DISPATCHER.init(logicDevice);
    
}
inline vk::Bool32  VulkanAppCore::PlateformSurfaceExtChech(const char* extensionName)
{
    vk::Bool32 platformSurfaceExtFound = VK_FALSE;
#if defined(VK_USE_PLATFORM_WIN32_KHR)
        if (!strcmp(VK_KHR_WIN32_SURFACE_EXTENSION_NAME, extensionName)) {
            platformSurfaceExtFound = VK_TRUE;
            enabled_instance_extensions.push_back(VK_KHR_WIN32_SURFACE_EXTENSION_NAME);
        }
#elif defined(VK_USE_PLATFORM_XLIB_KHR)
        if (!strcmp(VK_KHR_XLIB_SURFACE_EXTENSION_NAME, extension.extensionName)) {
            platformSurfaceExtFound = VK_TRUE;
            enabled_instance_extensions.push_back(VK_KHR_XLIB_SURFACE_EXTENSION_NAME);
        }
#elif defined(VK_USE_PLATFORM_XCB_KHR)
        if (!strcmp(VK_KHR_XCB_SURFACE_EXTENSION_NAME, extension.extensionName)) {
            platformSurfaceExtFound = VK_TRUE;
            enabled_instance_extensions.push_back(VK_KHR_XCB_SURFACE_EXTENSION_NAME);
        }
#elif defined(VK_USE_PLATFORM_WAYLAND_KHR)
        if (!strcmp(VK_KHR_WAYLAND_SURFACE_EXTENSION_NAME, extension.extensionName)) {
            platformSurfaceExtFound = VK_TRUE;
            enabled_instance_extensions.push_back(VK_KHR_WAYLAND_SURFACE_EXTENSION_NAME);
        }
#elif defined(VK_USE_PLATFORM_DIRECTFB_EXT)
        if (!strcmp(VK_EXT_DIRECTFB_SURFACE_EXTENSION_NAME, extension.extensionName)) {
            platformSurfaceExtFound = VK_TRUE;
            enabled_instance_extensions.push_back(VK_EXT_DIRECTFB_SURFACE_EXTENSION_NAME);
        }
#elif defined(VK_USE_PLATFORM_DISPLAY_KHR)
        if (!strcmp(VK_KHR_DISPLAY_EXTENSION_NAME, extension.extensionName)) {
            platformSurfaceExtFound = VK_TRUE;
            enabled_instance_extensions.push_back(VK_KHR_DISPLAY_EXTENSION_NAME);
        }
#elif defined(VK_USE_PLATFORM_METAL_EXT)
        if (!strcmp(VK_EXT_METAL_SURFACE_EXTENSION_NAME, extension.extensionName)) {
            platformSurfaceExtFound = VK_TRUE;
            enabled_instance_extensions.push_back(VK_EXT_METAL_SURFACE_EXTENSION_NAME);
        }
#elif defined(VK_USE_PLATFORM_SCREEN_QNX)
        if (!strcmp(VK_QNX_SCREEN_SURFACE_EXTENSION_NAME, extension.extensionName)) {
            platformSurfaceExtFound = VK_TRUE;
            enabled_instance_extensions.push_back(VK_QNX_SCREEN_SURFACE_EXTENSION_NAME);
        }
#endif
        return platformSurfaceExtFound;
}
inline void VulkanAppCore::PlatformSurfaceExtFoundError()
{
#if defined(VK_USE_PLATFORM_WIN32_KHR)
    std::string tempStr = "vkEnumerateInstanceExtensionProperties failed to find the ";
    tempStr += VK_KHR_WIN32_SURFACE_EXTENSION_NAME;
    tempStr += " extension.\n\n";
    tempStr += "Do you have a compatible Vulkan installable client driver (ICD) installed?\n";
    tempStr += "Please look at the Getting Started guide for additional information.\n";
    std::wstring tempWStr = String2WString(tempStr);
    ERR_EXIT(tempWStr.c_str(), L"vkCreateInstance Failure");
#elif defined(VK_USE_PLATFORM_XCB_KHR)
    std::string tempStr = "vkEnumerateInstanceExtensionProperties failed to find the ";
    tempStr += VK_KHR_XCB_SURFACE_EXTENSION_NAME;
    tempStr += " extension.\n\n";
    tempStr += "Do you have a compatible Vulkan installable client driver (ICD) installed?\n";
    tempStr += "Please look at the Getting Started guide for additional information.\n";
    std::wstring tempWStr = String2WString(tempStr);
    ERR_EXIT(tempWStr.c_str(), L"vkCreateInstance Failure");
#elif defined(VK_USE_PLATFORM_WAYLAND_KHR)
    std::string tempStr = "vkEnumerateInstanceExtensionProperties failed to find the ";
    tempStr += VK_KHR_WAYLAND_SURFACE_EXTENSION_NAME;
    tempStr += " extension.\n\n";
    tempStr += "Do you have a compatible Vulkan installable client driver (ICD) installed?\n";
    tempStr += "Please look at the Getting Started guide for additional information.\n";
    std::wstring tempWStr = String2WString(tempStr);
    ERR_EXIT(tempWStr.c_str(), L"vkCreateInstance Failure");
#elif defined(VK_USE_PLATFORM_XLIB_KHR)
    std::string tempStr = "vkEnumerateInstanceExtensionProperties failed to find the ";
    tempStr += VK_KHR_XLIB_SURFACE_EXTENSION_NAME;
    tempStr += " extension.\n\n";
    tempStr += "Do you have a compatible Vulkan installable client driver (ICD) installed?\n";
    tempStr += "Please look at the Getting Started guide for additional information.\n";
    std::wstring tempWStr = String2WString(tempStr);
    ERR_EXIT(tempWStr.c_str(), L"vkCreateInstance Failure");
#elif defined(VK_USE_PLATFORM_DIRECTFB_EXT)
    std::string tempStr = "vkEnumerateInstanceExtensionProperties failed to find the ";
    tempStr += VK_EXT_DIRECTFB_SURFACE_EXTENSION_NAME;
    tempStr += " extension.\n\n";
    tempStr += "Do you have a compatible Vulkan installable client driver (ICD) installed?\n";
    tempStr += "Please look at the Getting Started guide for additional information.\n";
    std::wstring tempWStr = String2WString(tempStr);
    ERR_EXIT(tempWStr.c_str(), L"vkCreateInstance Failure");
#elif defined(VK_USE_PLATFORM_DISPLAY_KHR)
    std::string tempStr = "vkEnumerateInstanceExtensionProperties failed to find the ";
    tempStr += VK_KHR_DISPLAY_EXTENSION_NAME;
    tempStr += " extension.\n\n";
    tempStr += "Do you have a compatible Vulkan installable client driver (ICD) installed?\n";
    tempStr += "Please look at the Getting Started guide for additional information.\n";
    std::wstring tempWStr = String2WString(tempStr);
    ERR_EXIT(tempWStr.c_str(), L"vkCreateInstance Failure");
#elif defined(VK_USE_PLATFORM_METAL_EXT)
    std::string tempStr = "vkEnumerateInstanceExtensionProperties failed to find the ";
    tempStr += VK_EXT_METAL_SURFACE_EXTENSION_NAME;
    tempStr += " extension.\n\n";
    tempStr += "Do you have a compatible Vulkan installable client driver (ICD) installed?\n";
    tempStr += "Please look at the Getting Started guide for additional information.\n";
    std::wstring tempWStr = String2WString(tempStr);
    ERR_EXIT(tempWStr.c_str(), L"vkCreateInstance Failure");
#elif defined(VK_USE_PLATFORM_SCREEN_QNX)
    std::string tempStr = "vkEnumerateInstanceExtensionProperties failed to find the ";
    tempStr += VK_QNX_SCREEN_SURFACE_EXTENSION_NAME;
    tempStr += " extension.\n\n";
    tempStr += "Do you have a compatible Vulkan installable client driver (ICD) installed?\n";
    tempStr += "Please look at the Getting Started guide for additional information.\n";
    std::wstring tempWStr = String2WString(tempStr);
    ERR_EXIT(tempWStr.c_str(), L"vkCreateInstance Failure");
#endif
}

VKAPI_ATTR VkBool32 VKAPI_CALL VulkanAppCore::debug_messenger_callback(
                VkDebugUtilsMessageSeverityFlagBitsEXT messageSeverity,
                    VkDebugUtilsMessageTypeFlagsEXT messageType,
                   const VkDebugUtilsMessengerCallbackDataEXT* pCallbackData,
                         void* pUserData) 
{
    std::ostringstream message;
    VulkanAppCore& demo = *static_cast<VulkanAppCore*>(pUserData);

    message << vk::to_string(vk::DebugUtilsMessageSeverityFlagBitsEXT(messageSeverity));
    message << " : " + vk::to_string(vk::DebugUtilsMessageTypeFlagsEXT(messageType));

    if (vk::DebugUtilsMessageTypeFlagsEXT(messageType) & vk::DebugUtilsMessageTypeFlagBitsEXT::eValidation) 
    {
        validation_error = 1;
    }

    message << " - Message Id Number: " << std::to_string(pCallbackData->messageIdNumber);
    message << " | Message Id Name: " << (pCallbackData->pMessageIdName == nullptr ? "" : pCallbackData->pMessageIdName) << "\n\t"
        << pCallbackData->pMessage << "\n";

    if (pCallbackData->objectCount > 0) 
    {
        message << "\n\tObjects - " << pCallbackData->objectCount << "\n";
        for (uint32_t object = 0; object < pCallbackData->objectCount; ++object) 
        {
            message << "\t\tObject[" << object << "] - "
                << vk::to_string(vk::ObjectType(pCallbackData->pObjects[object].objectType)) << ", Handle ";

            // Print handle correctly if it is a dispatchable handle - aka a pointer
            VkObjectType t = pCallbackData->pObjects[object].objectType;
            if (t == VK_OBJECT_TYPE_INSTANCE || t == VK_OBJECT_TYPE_PHYSICAL_DEVICE || t == VK_OBJECT_TYPE_DEVICE ||
                t == VK_OBJECT_TYPE_COMMAND_BUFFER || t == VK_OBJECT_TYPE_QUEUE) {
                message << reinterpret_cast<void*>(static_cast<uintptr_t>(pCallbackData->pObjects[object].objectHandle));
            }
            else 
            {
                message << pCallbackData->pObjects[object].objectHandle;
            }
            if (NULL != pCallbackData->pObjects[object].pObjectName && strlen(pCallbackData->pObjects[object].pObjectName) > 0) {
                message << ", Name \"" << pCallbackData->pObjects[object].pObjectName << "\"\n";
            }
            else {
                message << "\n";
            }
        }
    }
    if (pCallbackData->cmdBufLabelCount > 0) {
        message << "\n\tCommand Buffer Labels - " << pCallbackData->cmdBufLabelCount << "\n";
        for (uint32_t cmd_buf_label = 0; cmd_buf_label < pCallbackData->cmdBufLabelCount; ++cmd_buf_label) {
            message << "\t\tLabel[" << cmd_buf_label << "] - " << pCallbackData->pCmdBufLabels[cmd_buf_label].pLabelName << " { "
                << pCallbackData->pCmdBufLabels[cmd_buf_label].color[0] << ", "
                << pCallbackData->pCmdBufLabels[cmd_buf_label].color[1] << ", "
                << pCallbackData->pCmdBufLabels[cmd_buf_label].color[2] << ", "
                << pCallbackData->pCmdBufLabels[cmd_buf_label].color[2] << "}\n";
        }
    }

#ifdef _WIN32
   // std::wstring tempWMsg = String2WString(message.str());
    //TraceMsg(tempWMsg.c_str());
    std::cerr << pCallbackData->pMessage << std::endl;
#elif defined(ANDROID)

    if (messageSeverity & VK_DEBUG_UTILS_MESSAGE_SEVERITY_INFO_BIT_EXT) {
        __android_log_print(ANDROID_LOG_INFO, APP_SHORT_NAME, "%s", message.str());
    }
    else if (messageSeverity & VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT) {
        __android_log_print(ANDROID_LOG_WARN, APP_SHORT_NAME, "%s", message.str());
    }
    else if (messageSeverity & VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT) {
        __android_log_print(ANDROID_LOG_ERROR, APP_SHORT_NAME, "%s", message.str());
    }
    else if (messageSeverity & VK_DEBUG_UTILS_MESSAGE_SEVERITY_VERBOSE_BIT_EXT) {
        __android_log_print(ANDROID_LOG_VERBOSE, APP_SHORT_NAME, "%s", message.str());
    }
    else {
        __android_log_print(ANDROID_LOG_INFO, APP_SHORT_NAME, "%s", message.str());
    }

#else
    std::cout << message.str() << std::endl;  // use endl to force a flush
#endif
    return false;  // Don't bail out, but keep going.
}
inline QueueFamilyIndices VulkanAppCore::findQueueFamilies(VkPhysicalDevice _physicalDevice)
{
    QueueFamilyIndices indices;

    uint32_t queueFamilyCount = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(_physicalDevice, &queueFamilyCount, nullptr);
    //VULKAN_HPP_DEFAULT_DISPATCHER.vkGetPhysicalDeviceQueueFamilyProperties(_physicalDevice, &queueFamilyCount, nullptr);
    std::vector<VkQueueFamilyProperties> queueFamilies(queueFamilyCount);
    //VULKAN_HPP_DEFAULT_DISPATCHER.vkGetPhysicalDeviceQueueFamilyProperties(_physicalDevice, &queueFamilyCount, queueFamilies.data());
    vkGetPhysicalDeviceQueueFamilyProperties(_physicalDevice, &queueFamilyCount, queueFamilies.data());
    
    for (int i = 0; i < queueFamilies.size(); i++)
    {
        const VkQueueFamilyProperties& queueFamily = queueFamilies[i];
        if (queueFamily.queueFlags & VK_QUEUE_GRAPHICS_BIT) //判定支持VK_QUEUE_GRAPHICS_BIT类型的队列族
        {
            indices.graphicsFamily = i;
        }

        VkBool32 presentSupport = false;
       // VULKAN_HPP_DEFAULT_DISPATCHER.vkGetPhysicalDeviceSurfaceSupportKHR(_physicalDevice, i, surface, &presentSupport);
        vkGetPhysicalDeviceSurfaceSupportKHR(_physicalDevice, i, surface, &presentSupport);

        if (presentSupport)
        {
            indices.presentFamily = i;
        }

        if (indices.isComplete()) 
        {
            break;
        }
    }

    return indices;
}
inline bool VulkanAppCore::isDeviceSuitable(VkPhysicalDevice _physicaldevice)
{
    QueueFamilyIndices indices = findQueueFamilies(_physicaldevice);
    bool isPhysicalDeviceExtension = CheckPhysicalDeviceExtensionSupport(_physicaldevice,
        deviceExtensions);

    //对isDeviceSuitable函数进行补充，检测交换链的能力是否满足需求。这里只需要交换链至少支持一种图像格式和一种窗口表面的呈现模式即可：
    bool swapChainAdequate = false;
    if (isPhysicalDeviceExtension)
    {
        SwapChainSupportDetails swapChainSupport = querySwapChainSupport(_physicaldevice);
        swapChainAdequate = !swapChainSupport.formats.empty() && !swapChainSupport.presentModes.empty();
    }

    return indices.isComplete() && isPhysicalDeviceExtension && swapChainAdequate;
}

bool VulkanAppCore::CheckPhysicalDeviceExtensionSupport(VkPhysicalDevice _physicaldevice,
    const std::vector<const char*>& _AppNeedPhysicalDeviceExtensions)
{
    std::vector<VkExtensionProperties>  availableExtensions = getAvailableExtensionsProperties(_physicaldevice);
    bool  hResult = true;
    for (int i = 0; i < _AppNeedPhysicalDeviceExtensions.size(); i++)
    {
        std::string tempExtensionName = _AppNeedPhysicalDeviceExtensions[i];
        bool  bFind = false;
        for (int j = 0; j < availableExtensions.size(); j++)
        {
            if (tempExtensionName == availableExtensions[j].extensionName)
            {
                bFind = true;
                break;
            }
        }
        if (bFind == false)
        {
            hResult = false;
            std::cerr << "没有找到需要的扩展属性" << tempExtensionName << std::endl;
            break;
        }
    }
    return hResult;
}

SwapChainSupportDetails VulkanAppCore::querySwapChainSupport(VkPhysicalDevice device)
{
    SwapChainSupportDetails details;
    //❶ 调用下面的函数查询基础表面功能：
    vkGetPhysicalDeviceSurfaceCapabilitiesKHR(device, surface, &details.capabilities);
    //❷ 查询表面支持的格式。查询结果是一个结构体列表，函数调用2次，首先查询格式数量，然后分配数组保存结果：
    uint32_t formatCount;
    vkGetPhysicalDeviceSurfaceFormatsKHR(device, surface, &formatCount, nullptr);
    if (formatCount != 0)
    {
        details.formats.resize(formatCount);
        vkGetPhysicalDeviceSurfaceFormatsKHR(device, surface, &formatCount, details.formats.data());
    }
    //❸调用vkGetPhysicalDeviceSurfacePresentModesKHR查询支持的显示模式：
    uint32_t presentModeCount;
    vkGetPhysicalDeviceSurfacePresentModesKHR(device, surface, &presentModeCount, nullptr);

    if (presentModeCount != 0) {
        details.presentModes.resize(presentModeCount);
        vkGetPhysicalDeviceSurfacePresentModesKHR(device, surface, &presentModeCount, details.presentModes.data());
    }
    return details;
}
/*
SwapChainSupportDetails VulkanAppCore::querySwapChainSupport(vk::PhysicalDevice _physicalDevice)
{
    SwapChainSupportDetails details;
    //❶ 调用下面的函数查询基础表面功能：
	_physicalDevice.getSurfaceCapabilitiesKHR(surface, &details.capabilities);
    
    //❷ 查询表面支持的格式。查询结果是一个结构体列表，函数调用2次，首先查询格式数量，然后分配数组保存结果：
    uint32_t formatCount;
	_physicalDevice.getSurfaceFormatsKHR(surface, &formatCount, nullptr);
    if (formatCount != 0)
    {
        details.formats.resize(formatCount);
		VULKAN_HPP_DEFAULT_DISPATCHER.vkGetPhysicalDeviceSurfaceFormatsKHR(_physicalDevice, surface, &formatCount, details.formats.data());
        //_physicalDevice.getSurfaceFormatsKHR(surface, &formatCount, details.formats.data());
    }
    //❸调用vkGetPhysicalDeviceSurfacePresentModesKHR查询支持的显示模式：
    uint32_t presentModeCount;
	_physicalDevice.getSurfacePresentModesKHR(surface, &presentModeCount, nullptr);

    if (presentModeCount != 0) {
        details.presentModes.resize(presentModeCount);
		VULKAN_HPP_DEFAULT_DISPATCHER.vkGetPhysicalDeviceSurfacePresentModesKHR(_physicalDevice, surface, &presentModeCount, details.presentModes.data());
		//_physicalDevice.getSurfacePresentModesKHR(surface, &presentModeCount, details.presentModes.data());
    }
    return details;
}*/

//获得设备支持的所有Device类型的扩展属性列表
std::vector<VkExtensionProperties>  VulkanAppCore::getAvailableExtensionsProperties(VkPhysicalDevice _physicalDevice)
{
    uint32_t extensionCount;
   // VULKAN_HPP_DEFAULT_DISPATCHER.vkEnumerateDeviceExtensionProperties(_physicalDevice, nullptr, &extensionCount, nullptr);
    vkEnumerateDeviceExtensionProperties(_physicalDevice, nullptr, &extensionCount, nullptr);
    std::vector<VkExtensionProperties>      extensions(extensionCount);
    if (extensionCount == 0) {
        throw std::runtime_error("No extensions found!");
    }
    //VULKAN_HPP_DEFAULT_DISPATCHER.vkEnumerateDeviceExtensionProperties(_physicalDevice, nullptr, &extensionCount, extensions.data());
    vkEnumerateDeviceExtensionProperties(_physicalDevice, nullptr, &extensionCount, extensions.data());
    return extensions;
}

template<typename T, size_t N = 2>
class VulkanVertexBuffer
{
    vk::Device          logicDevice;
public:
    vk::Buffer          vertexBuffer;
    vk::DeviceMemory    vertexBufferMemory;
    int               bufferSize = 0;
    VulkanVertexBuffer() = default;
    ~VulkanVertexBuffer()
    {
        Destory();
        logicDevice = nullptr;
    }

    void Initialize(vk::PhysicalDevice& _physicalDevice, vk::Device& _logicDevice, const std::vector<T>& _vertexData)
    {
        logicDevice = _logicDevice;
        vk::BufferCreateInfo bufferInfo;
        //bufferInfo.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
        bufferInfo.size = sizeof(_vertexData[0]) * _vertexData.size();
        bufferInfo.usage = vk::BufferUsageFlagBits::eVertexBuffer;  //VK_BUFFER_USAGE_VERTEX_BUFFER_BIT;
        bufferInfo.sharingMode = VULKAN_HPP_NAMESPACE::SharingMode::eExclusive; //VK_SHARING_MODE_EXCLUSIVE;
        
        auto vertexBuffer_return = logicDevice.createBuffer(bufferInfo);
        VERIFY(vertexBuffer_return.result == vk::Result::eSuccess);
        vertexBuffer = vertexBuffer_return.value;

       // if (vkCreateBuffer(logicDevice, &bufferInfo, nullptr, &vertexBuffer) != VK_SUCCESS) {
        //    throw std::runtime_error("failed to create vertex buffer!");
       // }
        bufferSize = bufferInfo.size;

        vk::MemoryRequirements memRequirements = logicDevice.getBufferMemoryRequirements(vertexBuffer);
        //vkGetBufferMemoryRequirements(logicDevice, vertexBuffer, &memRequirements);

        vk::MemoryAllocateInfo allocInfo;
        //allocInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
        allocInfo.allocationSize = memRequirements.size;
        allocInfo.memoryTypeIndex = findMemoryType(_physicalDevice, memRequirements.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);

        auto result = logicDevice.allocateMemory(&allocInfo, nullptr, &vertexBufferMemory);
        VERIFY(result == vk::Result::eSuccess);

        //if (vkAllocateMemory(logicDevice, &allocInfo, nullptr, &vertexBufferMemory) != VK_SUCCESS) {
        //    throw std::runtime_error("failed to allocate vertex buffer memory!");
       // }
        result = logicDevice.bindBufferMemory(vertexBuffer, vertexBufferMemory, 0);
        VERIFY(result == vk::Result::eSuccess);
        //vkBindBufferMemory(logicDevice, vertexBuffer, vertexBufferMemory, 0);

        void* data;
        //logicDevice.mapMemory(vertexBufferMemory, 0, bufferInfo.size, 0, &data);
        
        vkMapMemory(logicDevice, vertexBufferMemory, 0, bufferInfo.size,
            0, &data);
        //VkResult(VKAPI_PTR * PFN_vkMapMemory)(VkDevice device, VkDeviceMemory memory,
        // VkDeviceSize offset, VkDeviceSize size, VkMemoryMapFlags flags, void** ppData);


        memcpy(data, _vertexData.data(), (size_t)bufferInfo.size);
        logicDevice.unmapMemory(vertexBufferMemory);
       // vkUnmapMemory(logicDevice, vertexBufferMemory);
    }
    void Destory(vk::Device _logicDevide = nullptr)
    {
        if (_logicDevide != nullptr)
        {
            logicDevice = _logicDevide;
        }
        if (vertexBuffer != nullptr)
        {
            vkDestroyBuffer(logicDevice, vertexBuffer, nullptr);
            vertexBuffer = nullptr;
        }
        if (vertexBufferMemory != nullptr)
        {
            vkFreeMemory(logicDevice, vertexBufferMemory, nullptr);
            vertexBufferMemory = nullptr;
        }
        logicDevice = nullptr;
    }
    int GetVertexBufferSize()
    {
        return bufferSize;
    }

    VkVertexInputBindingDescription getBindingDescription()
    {
        return T::getBindingDescription();
    }

    std::array<VkVertexInputAttributeDescription, N> getAttributeDescriptions()
    {
        return T::getAttributeDescriptions();
    }
    //为要分配的buffer找到正确的合适的显存类型
    // Find a memory in `memoryTypeBitsRequirement` that includes all of `requiredProperties`
   /* int32_t findProperties(vk::PhysicalDevice& _physicalDevice,
                            uint32_t memoryTypeBitsRequirement,
                            VkMemoryPropertyFlags requiredProperties)
    {
        vk::PhysicalDeviceMemoryProperties    memProperties;
        _physicalDevice.getMemoryProperties(&memProperties);

        const uint32_t memoryCount = pMemoryProperties->memoryTypeCount;
        for (uint32_t memoryIndex = 0; memoryIndex < memoryCount; ++memoryIndex) {
            const uint32_t memoryTypeBits = (1 << memoryIndex);
            const bool isRequiredMemoryType = memoryTypeBitsRequirement & memoryTypeBits;

            const VkMemoryPropertyFlags properties =
                pMemoryProperties->memoryTypes[memoryIndex].propertyFlags;
            const bool hasRequiredProperties =
                (properties & requiredProperties) == requiredProperties;

            if (isRequiredMemoryType && hasRequiredProperties)
                return static_cast<int32_t>(memoryIndex);
        }

        // failed to find memory type
        return -1;
    }*/
    uint32_t findMemoryType(VkPhysicalDevice _physicalDevice, uint32_t typeFilter, VkMemoryPropertyFlags properties)
    {
        //查询所有可用的内存类型
        VkPhysicalDeviceMemoryProperties memProperties;
        vkGetPhysicalDeviceMemoryProperties(_physicalDevice, &memProperties);
        //找到buffer适合的内存类型
        for (uint32_t i = 0; i < memProperties.memoryTypeCount; i++)
        {
            if ( (typeFilter & (1 << i) ) && ( (memProperties.memoryTypes[i].propertyFlags & properties) == properties) )
            {
                return i;
            }
        }

        throw std::runtime_error("failed to find suitable memory type!");
    }
 
};


