﻿#define  VK_USE_PLATFORM_WIN32_KHR
#define VK_NO_PROTOTYPES
#define VOLK_IMPLEMENTATION
#include "volk/volk.h"

//#define VULKAN_HPP_DISPATCH_LOADER_DYNAMIC 1
#include "VulkanAppCore.hpp"

VULKAN_HPP_DEFAULT_DISPATCH_LOADER_DYNAMIC_STORAGE

#include <Windows.h>

void VulkanAppCore::initVulkan()
{
    VkResult err = volkInitialize();
    if (err != VK_SUCCESS)
    {
        throw std::runtime_error("Unable to find the Vulkan runtime on the system.\n\n This likely indicates that no Vulkan capable drivers are installed.");
    }
    VULKAN_HPP_DEFAULT_DISPATCHER.init(vkGetInstanceProcAddr);
    createInstance();

    volkLoadInstance(instance);

   // CreateVkDebugUtilsMessengerEXT();

    createSurface();
    pickPhysicalDevice();
    createLogicalDevice();
}
void VulkanAppCore::createInstance()
{
    if (enableValidationLayers && !checkValidationLayerSupport())
    {  //如果需要校验层，而系统检测不到校验层，需要退出
        throw std::runtime_error("应用程序需要设置校验层, 而我们检测不到需要的校验，程序退出!");
    }

	vk::ApplicationInfo appInfo;
	appInfo.setPApplicationName("Hello Triangle");
	appInfo.setApplicationVersion(VK_MAKE_VERSION(1, 4, 0));
	appInfo.setPEngineName("No Engine");
	appInfo.setEngineVersion(VK_MAKE_VERSION(1, 4, 0));
	appInfo.setApiVersion(VK_API_VERSION_1_4);

    VkApplicationInfo tempApplicationInfo = appInfo;

    vk::InstanceCreateInfo createInfo;
	createInfo.setPApplicationInfo(&appInfo);
    std::vector<const char*> extensions = getRequiredExtensions(enableValidationLayers);
	createInfo.setPEnabledExtensionNames(extensions);
    const std::vector<const char*> _InvalidationLayers = getValidationLayersExtensions(enableValidationLayers);
    createInfo.enabledLayerCount = (uint32_t)_InvalidationLayers.size();
    //系统允许的Layer层数量
  
    vk::DebugUtilsMessageSeverityFlagsEXT severityFlags(/*vk::DebugUtilsMessageSeverityFlagBitsEXT::eInfo |*/
        vk::DebugUtilsMessageSeverityFlagBitsEXT::eWarning |
        vk::DebugUtilsMessageSeverityFlagBitsEXT::eError |
        vk::DebugUtilsMessageSeverityFlagBitsEXT::eVerbose);

    vk::DebugUtilsMessageTypeFlagsEXT messageTypeFlags(vk::DebugUtilsMessageTypeFlagBitsEXT::eGeneral |
        vk::DebugUtilsMessageTypeFlagBitsEXT::ePerformance |
        vk::DebugUtilsMessageTypeFlagBitsEXT::eValidation |
        vk::DebugUtilsMessageTypeFlagBitsEXT::eDeviceAddressBinding);

    vk::DebugUtilsMessengerCreateInfoEXT debug_utils_create_info = vk::DebugUtilsMessengerCreateInfoEXT({}, severityFlags, messageTypeFlags,
                  &debug_messenger_callback, static_cast<void*>(this));

    //配置调试信息输出的相关设置
    if (createInfo.enabledLayerCount > 0)
    {
        createInfo.ppEnabledLayerNames = _InvalidationLayers.data();  //指向Lager层名称数组的指针，一般为二维数组
        createInfo.pNext = (VkDebugUtilsMessengerCreateInfoEXT*)&debug_utils_create_info;
    }
    else
    {
        createInfo.ppEnabledLayerNames = nullptr;  //指向Lager层名称数组的指针，一般为二维数组
        createInfo.pNext = nullptr;//一般情况下用于指向校验层结构体的指针，这里先设为nullptr
    }

    vk::Result result = vk::createInstance(&createInfo , nullptr, & instance);
    if (result != vk::Result::eSuccess)
    {
		std::runtime_error("failed to create instance!");
    }
    
    VULKAN_HPP_DEFAULT_DISPATCHER.init(instance);
    vk::Result result1 = instance.createDebugUtilsMessengerEXT(&debug_utils_create_info, nullptr, &debugMessenger);
	if (result1 != vk::Result::eSuccess)
	{
		std::runtime_error("failed to create debug messenger!");
	}

}




std::vector<vk::ExtensionProperties>  VulkanAppCore::getPhysicalDeviceSupportExtensionsProperties(vk::PhysicalDevice& _physicalDevice)
{
    uint32_t extensionCount;
    vk::Result result = _physicalDevice.enumerateDeviceExtensionProperties(nullptr, &extensionCount, nullptr);
    if (result != vk::Result::eSuccess)
    {
        throw std::runtime_error("failed to get device extension properties!");
    }
    //vkEnumerateDeviceExtensionProperties(_physicalDevice, nullptr, &extensionCount, nullptr);
    std::vector<vk::ExtensionProperties>      extensions(extensionCount);
    if (extensionCount == 0) {
        throw std::runtime_error("No extensions found!");
    }
    result = _physicalDevice.enumerateDeviceExtensionProperties(nullptr, &extensionCount, extensions.data());
    if (result != vk::Result::eSuccess)
    {
        throw std::runtime_error("failed to get device extension properties!");
    }
    //vkEnumerateDeviceExtensionProperties(_physicalDevice, nullptr, &extensionCount, extensions.data());
    return extensions;
}


void VulkanAppCore::createSurface()
{
    // Create a WSI surface for the window:
#if defined(VK_USE_PLATFORM_WIN32_KHR)
    {
		HINSTANCE hAppInstance = GetModuleHandle(NULL);
		vk::Win32SurfaceCreateInfoKHR createInfo;
		//createInfo.sType = VK_STRUCTURE_TYPE_WIN32_SURFACE_CREATE_INFO_KHR;
		createInfo.hinstance = hAppInstance;
		createInfo.hwnd = (HWND)hWnd;
		
        vk::Result Result = instance.createWin32SurfaceKHR(&createInfo, nullptr, &surface);
        if (Result != vk::Result::eSuccess)
        {
            throw std::runtime_error("failed to create window surface!");
        }

    }
#elif defined(VK_USE_PLATFORM_WAYLAND_KHR)
    {
        auto const createInfo = vk::WaylandSurfaceCreateInfoKHR().setDisplay(display).setSurface(window);

        auto result = inst.createWaylandSurfaceKHR(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);
    }
#elif defined(VK_USE_PLATFORM_XLIB_KHR)
    {
        auto const createInfo = vk::XlibSurfaceCreateInfoKHR().setDpy(display).setWindow(xlib_window);

        auto result = inst.createXlibSurfaceKHR(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);
    }
#elif defined(VK_USE_PLATFORM_XCB_KHR)
    {
        auto const createInfo = vk::XcbSurfaceCreateInfoKHR().setConnection(connection).setWindow(xcb_window);

        auto result = inst.createXcbSurfaceKHR(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);
    }
#elif defined(VK_USE_PLATFORM_DIRECTFB_EXT)
    {
        auto const createInfo = vk::DirectFBSurfaceCreateInfoEXT().setDfb(dfb).setSurface(window);

        auto result = inst.createDirectFBSurfaceEXT(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);
    }
#elif defined(VK_USE_PLATFORM_METAL_EXT)
    {
        auto const createInfo = vk::MetalSurfaceCreateInfoEXT().setPLayer(static_cast<CAMetalLayer*>(caMetalLayer));

        auto result = inst.createMetalSurfaceEXT(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);
    }
#elif defined(VK_USE_PLATFORM_DISPLAY_KHR)
    {
        auto result = create_display_surface();
        VERIFY(result == vk::Result::eSuccess);
    }
#elif defined(VK_USE_PLATFORM_SCREEN_QNX)
    {
        auto const createInfo = vk::ScreenSurfaceCreateInfoQNX().setContext(screen_context).setWindow(screen_window);

        auto result = inst.createScreenSurfaceQNX(&createInfo, nullptr, &surface);
        VERIFY(result == vk::Result::eSuccess);
    }
#endif
}

void VulkanAppCore::pickPhysicalDevice()
{
    uint32_t _VkPhysicaldeviceCount = 0;
    instance.enumeratePhysicalDevices(&_VkPhysicaldeviceCount, nullptr);
	if (_VkPhysicaldeviceCount == 0) //如果显示设备GPU的数量为您报错退出
	{
		throw std::runtime_error("没有发现 GPUs设备，程序退出！");
	}
    std::vector<vk::PhysicalDevice> _VkPhysicaldevices(_VkPhysicaldeviceCount);
	instance.enumeratePhysicalDevices(&_VkPhysicaldeviceCount, _VkPhysicaldevices.data()); 
   
    for ( vk::PhysicalDevice&  device : _VkPhysicaldevices)
    {
        if (isDeviceSuitable(device))
        {
			physicalDevice = device;
			m_VkDeviceExtensionPropertis = getPhysicalDeviceSupportExtensionsProperties(physicalDevice);
			break;
        }
    }

}

const std::vector<const char*>  VulkanAppCore::getValidationLayersExtensions(bool _enableValidationLayers)
{
    if (_enableValidationLayers == true)
    {
        return validationLayers;
    }
    else
    {
        std::vector<const char*>  tempValidationLayers;
        return tempValidationLayers;
    }
}
bool VulkanAppCore::checkValidationLayerSupport()
{
    uint32_t layerCount;
    vkEnumerateInstanceLayerProperties(&layerCount, nullptr);

    std::vector<VkLayerProperties> availableLayers(layerCount);
    vkEnumerateInstanceLayerProperties(&layerCount, availableLayers.data());

    for (const char* layerName : validationLayers)
    {
        bool layerFound = false;

        for (const VkLayerProperties& layerProperties : availableLayers)
        {
            if (strcmp(layerName, layerProperties.layerName) == 0)
            {
                layerFound = true;
                break;
            }
        }

        if (!layerFound) {
            return false;
        }
    }

    return true;
}


void VulkanAppCore::createLogicalDevice()
{
    //❶ 指定要创建的队列
    //创建逻辑设备需要VkDeviceQueueCreateInfo结构体，这一结构体描述了针对一个队列族我们所需的队列数量，
    // 目前我们使用带有图形能力的队列族和显示队列族。
    QueueFamilyIndices   indices = findQueueFamilies(physicalDevice);

    //我们需要一个队列列表，保存需要创建的逻辑设备一同创建的队列族类型
    std::vector<vk::DeviceQueueCreateInfo> queueCreateInfos;

    //从indices结构中检索出我们需要的队列族放到集合中
    std::set<uint32_t> uniqueQueueFamilies = { indices.graphicsFamily.value(), indices.presentFamily.value() };

    //Vulkan需要我们赋予队列一个0.0到1.0之间的浮点数来控制队列优先级。即使只有一个队列，也要显式地赋予队列优先级：
    float queuePriority = 1.0f;
    for (uint32_t queueFamily : uniqueQueueFamilies) //根据集合中的队列信息设置VkDeviceQueueCreateInfo列表
    {
        vk::DeviceQueueCreateInfo queueCreateInfo;
        queueCreateInfo.queueFamilyIndex = queueFamily;
        queueCreateInfo.queueCount = 1;
        queueCreateInfo.pQueuePriorities = &queuePriority;
        queueCreateInfos.push_back(queueCreateInfo);
    }



    //❷ 指定设备特性
    //我们要指定应用程序使用的设备特性，这些是在vkGetPhysicalDeviceFeatures查询出的设备支持的功能，例如几何着色器。
    //暂时先不填写，之后再回来填写：

    vk::PhysicalDeviceProperties props = { 0 };

    bool supportDeviceProperties2 = false;
    physicalDevice.getProperties(&props);
	if (props.apiVersion >= VK_MAKE_VERSION(1, 1, 0)) {
		supportDeviceProperties2 = true;
	}

    vk::PhysicalDeviceVertexAttributeDivisorFeatures  VertexAttributeDivisorFeatures;
    VertexAttributeDivisorFeatures.vertexAttributeInstanceRateDivisor = VK_TRUE;
    VertexAttributeDivisorFeatures.vertexAttributeInstanceRateZeroDivisor = VK_TRUE;
    VertexAttributeDivisorFeatures.pNext = nullptr;

    vk::PhysicalDeviceVertexInputDynamicStateFeaturesEXT vertexInputDynamicStateFeature;
    vertexInputDynamicStateFeature.pNext = &VertexAttributeDivisorFeatures;

    // VK_EXT_custom_border_color feature
    vk::PhysicalDeviceCustomBorderColorFeaturesEXT customBorderColorFeature;
        // This is the last node
   customBorderColorFeature.pNext = &vertexInputDynamicStateFeature;


    vk::PhysicalDeviceSubgroupSizeControlFeaturesEXT subgroupSizeControlFeature;
        // link to customBorderColorFeature node
    subgroupSizeControlFeature.pNext = &customBorderColorFeature;



    // physical device feature 2
    vk::PhysicalDeviceFeatures2 features2;
        // link to subgroupSizeControlFeature node
    features2.pNext = &subgroupSizeControlFeature;


    // If VK_KHR_get_physical_device_properties2 is not supported, fallback to general feature settings
    vk::PhysicalDeviceFeatures features = { 0 };

    // Query all above features
    if (supportDeviceProperties2)
    {
		physicalDevice.getFeatures2(&features2);
    }
    else 
    {
		physicalDevice.getFeatures(&features);
    }


    // ❸ 创建逻辑设备
    vk::DeviceCreateInfo createInfo;
    //设置随逻辑设备创建时一同创建的队列族信息
    createInfo.queueCreateInfoCount = static_cast<uint32_t>(queueCreateInfos.size());
    createInfo.pQueueCreateInfos = queueCreateInfos.data();

    //设备特征
    if (supportDeviceProperties2 == true)
    {
        createInfo.pNext = &features2;
        createInfo.pEnabledFeatures = nullptr;
    }
    else
    {
        createInfo.pEnabledFeatures = &features;
        createInfo.pNext = nullptr;
    }


    //我们可以对设备和Vulkan实例使用相同地校验层，在检索物理设备时已经验证了需要的扩展
    createInfo.enabledExtensionCount = deviceExtensions.size();
    createInfo.ppEnabledExtensionNames = deviceExtensions.data();

    if (enableValidationLayers) {
        createInfo.enabledLayerCount = static_cast<uint32_t>(validationLayers.size());
        createInfo.ppEnabledLayerNames = validationLayers.data();
    }
    else {
        createInfo.enabledLayerCount = 0;
    }


    //vkCreateDevice函数的参数包括要连接的物理设备、需要使用的队列、可选的分配器回调，以及用来存储逻辑设备句柄的指针。
    //逻辑设备并不直接与Vulkan实例交互，所以创建逻辑设备时不需要使用Vulkan实例作为参数。
	vk::Result result = physicalDevice.createDevice(&createInfo, nullptr, &logicDevice);
	if (result != vk::Result::eSuccess)
	{
		//与Vulkan实例对象的创建函数类似，在启用不存在的扩展或指定不支持的功能时，会返回错误码。
		throw std::runtime_error("failed to create logical device!");
	}
    VULKAN_HPP_DEFAULT_DISPATCHER.init(logicDevice);
    //❹ 获取队列句柄 ----创建逻辑设备时指定的队列会同时被创建，为了方便，我们添加了一个VkQueue类成员变量来存储图形队列的句柄：
    //vkGetDeviceQueue获取指定队列族的队列句柄,参数依次是逻辑设备，队列族索引，队列索引和存储返回的队列句柄的指针。
    // 因为我们只创建了一个队列，所以可以直接使用索引0：
    graphicsQueue = logicDevice.getQueue(indices.graphicsFamily.value(), 0);
    //graphicsQueue逻辑设备相关联的队列句柄是随着physicalDevice创建自动生成的，他会会随着逻辑设备的销毁自动销毁，所以不需要在cleanup函数中进行队列的销毁操作
    // 获得显示队列住族句柄
    presentQueue = logicDevice.getQueue(indices.presentFamily.value(), 0);
}
QueueFamilyIndices VulkanAppCore::findQueueFamilies(vk::PhysicalDevice& _physicalDevice)
{
    QueueFamilyIndices indices;

    uint32_t queueFamilyCount = 0;
	_physicalDevice.getQueueFamilyProperties(&queueFamilyCount, nullptr); //获取物理设备支持的队列族数量

    std::vector<vk::QueueFamilyProperties> queueFamilies(queueFamilyCount);
	_physicalDevice.getQueueFamilyProperties(&queueFamilyCount, queueFamilies.data()); //获取物理设备支持的队列族属性

    for (int i = 0; i < queueFamilies.size(); i++)
    {
        const VkQueueFamilyProperties& queueFamily = queueFamilies[i];
        if (queueFamily.queueFlags & VK_QUEUE_GRAPHICS_BIT) //判定支持VK_QUEUE_GRAPHICS_BIT类型的队列族
        {
            indices.graphicsFamily = i;
        }

        VkBool32 presentSupport = false;
		_physicalDevice.getSurfaceSupportKHR(i, surface, &presentSupport); //判断是否支持显示队列族
     
        if (presentSupport)
        {
            indices.presentFamily = i;
        }

        if (indices.isComplete()) {
            break;
        }
    }

    return indices;

}
bool VulkanAppCore::isDeviceSuitable(vk::PhysicalDevice& _physicaldevice)
{
    QueueFamilyIndices indices = findQueueFamilies(_physicaldevice);
    bool isPhysicalDeviceExtension = CheckPhysicalDeviceExtensionSupport(_physicaldevice,
        deviceExtensions);

    //对isDeviceSuitable函数进行补充，检测交换链的能力是否满足需求。这里只需要交换链至少支持一种图像格式和一种窗口表面的呈现模式即可：
    bool swapChainAdequate = false;
    if (isPhysicalDeviceExtension)
    {
        SwapChainSupportDetails swapChainSupport = querySwapChainSupport(_physicaldevice);
        swapChainAdequate = !swapChainSupport.formats.empty() && !swapChainSupport.presentModes.empty();
    }

    return indices.isComplete() && isPhysicalDeviceExtension && swapChainAdequate;

}
SwapChainSupportDetails VulkanAppCore::querySwapChainSupport(vk::PhysicalDevice& physicalDevice)
{
    SwapChainSupportDetails details;
    //❶ 调用下面的函数查询基础表面功能：
    vk::Result result = physicalDevice.getSurfaceCapabilitiesKHR(surface,&details.capabilities);
    if(result != vk::Result::eSuccess)
	{
		throw std::runtime_error("failed to get surface capabilities!");
	}

    // vkGetPhysicalDeviceSurfaceCapabilitiesKHR(device, surface, &details.capabilities);
    //❷ 查询表面支持的格式。查询结果是一个结构体列表，函数调用2次，首先查询格式数量，然后分配数组保存结果：
    uint32_t formatCount;
	physicalDevice.getSurfaceFormatsKHR(surface, &formatCount, nullptr);
    //vkGetPhysicalDeviceSurfaceFormatsKHR(device, surface, &formatCount, nullptr);
    if (formatCount != 0)
    {
        details.formats.resize(formatCount);
        physicalDevice.getSurfaceFormatsKHR(surface, &formatCount, details.formats.data());
    }
    //❸调用vkGetPhysicalDeviceSurfacePresentModesKHR查询支持的显示模式：
    uint32_t presentModeCount;
    physicalDevice.getSurfacePresentModesKHR(surface, &presentModeCount, nullptr);

    if (presentModeCount != 0) {
        details.presentModes.resize(presentModeCount);
		physicalDevice.getSurfacePresentModesKHR(surface, &presentModeCount, details.presentModes.data());
    }
    return details;
}
bool VulkanAppCore::CheckPhysicalDeviceExtensionSupport(vk::PhysicalDevice& _physicaldevice,
    const std::vector<const char*>& _AppNeedPhysicalDeviceExtensions)
{
    std::vector<vk::ExtensionProperties>  availableExtensions = getPhysicalDeviceSupportExtensionsProperties(_physicaldevice);
    bool  hResult = true;
    for (int i = 0; i < _AppNeedPhysicalDeviceExtensions.size(); i++)
    {
        std::string tempExtensionName = _AppNeedPhysicalDeviceExtensions[i];
        bool  bFind = false;
        for (int j = 0; j < availableExtensions.size(); j++)
        {
            if (tempExtensionName == availableExtensions[j].extensionName)
            {
                bFind = true;
                break;
            }
        }
        if (bFind == false)
        {
            hResult = false;
            std::cerr << "没有找到需要的扩展属性" << tempExtensionName << std::endl;
            break;
        }
    }
    return hResult;
}
