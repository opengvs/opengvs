﻿// Step_5.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
//#define  VK_USE_PLATFORM_WIN32_KHR
#include <iostream>
#include "VulkanAppBase.hpp"

//通过GLFW_INCLUDE_VULKAN宏定义，在glfw3.h头文件中自动包含Vulkan/vulkan.h头文件
#define GLFW_INCLUDE_VULKAN
#include <GLFW/glfw3.h>
#define GLFW_EXPOSE_NATIVE_WIN32
#include "GLFW/glfw3native.h"


#pragma comment( lib,"glfw3.lib" )



GLFWwindow* window = nullptr;
const int WIDTH = 800;
const int HEIGHT = 600;
// VulkanAppCore app;
VulkanAppBase app;
static void onWindowResized(GLFWwindow* window, int width, int height)
{
    if (width == 0 || height == 0) return;
    //获得类本身的对象
    VulkanAppBase* app = reinterpret_cast<VulkanAppBase*>(glfwGetWindowUserPointer(window));
    if (width == app->swapChainExtent.width && height == app->swapChainExtent.height)
    {
        return;//如果窗口大小与原交换链中保存的相同，返回
    }
    //重构交换链
    app->recreateSwapChain();
}

void initWindow()
{
    glfwInit();

    glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);

    window = glfwCreateWindow(WIDTH, HEIGHT, "Vulkan", nullptr, nullptr);

    glfwSetWindowUserPointer(window, &app);
    glfwSetWindowSizeCallback(window, onWindowResized);
}

int main()
{
    initWindow();
    try {
		HWND _hwnd = glfwGetWin32Window(window);

        app.InitWindow((void*)_hwnd );
        app.initVulkan();  
        while ( !glfwWindowShouldClose(window) )
        {
            glfwPollEvents();
            app.drawFrame();
        }
        app.cleanup();
        glfwDestroyWindow(window);

        glfwTerminate();
    }
    catch (const std::exception& e) 
    {
        std::cerr << e.what() << std::endl;
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}

