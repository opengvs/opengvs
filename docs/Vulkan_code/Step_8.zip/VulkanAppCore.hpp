﻿#pragma warning(disable: 4996)
#pragma once
#define   VK_USE_PLATFORM_WIN32_KHR


#define   VK_NO_PROTOTYPES
#include "volk/volk.h"

#define VULKAN_HPP_DISPATCH_LOADER_DYNAMIC 1
#define VULKAN_HPP_NO_EXCEPTIONS
#define VULKAN_HPP_TYPESAFE_CONVERSION 1
#define NOMINMAX
//#define VK_NO_PROTOTYPES
#include <vulkan/vulkan.hpp>
#include <vulkan/vulkan_structs.hpp>


#include <iostream>
#include <fstream>
#include <stdexcept>
#include <vector>
#include <optional>
#include <set>

#ifdef NDEBUG
inline const bool enableValidationLayers = false;
inline const std::vector<const char*> instanceExtensions = {
    VK_KHR_SURFACE_EXTENSION_NAME,
    VK_KHR_WIN32_SURFACE_EXTENSION_NAME
};
#else
inline  const bool enableValidationLayers = true;
inline const std::vector<const char*> instanceExtensions = {
    VK_KHR_SURFACE_EXTENSION_NAME,
    VK_EXT_DEBUG_UTILS_EXTENSION_NAME,
    VK_KHR_WIN32_SURFACE_EXTENSION_NAME
};
#endif

//LunarG Vulkan SDK允许我们通过 VK_LAYER_KHRONOS_validation 来隐式地开启所有可用的校验层
inline const std::vector<const char*> validationLayers = {
    "VK_LAYER_KHRONOS_validation",
};

//VK_KHR_SWAPCHAIN_EXTENSION_NAME 是Vulkan SDK中定义的一个宏，表示交换链扩展名称
inline const std::vector<const char*> deviceExtensions = {
    VK_KHR_SWAPCHAIN_EXTENSION_NAME,
    VK_EXT_VERTEX_INPUT_DYNAMIC_STATE_EXTENSION_NAME,
    VK_KHR_MAINTENANCE_1_EXTENSION_NAME,
    VK_KHR_VERTEX_ATTRIBUTE_DIVISOR_EXTENSION_NAME,
    VK_EXT_CUSTOM_BORDER_COLOR_EXTENSION_NAME
};

//在显卡GPU驱动设计过程中，图形队列族并不一定能够将所拥有的图形信息传输到显示设备上，
// Vulkan还设计了显示队列族，图形队列族和显示队列族可以是同一个队列族，也可以是不同的队列族。
struct QueueFamilyIndices 
{
    std::optional<uint32_t>      graphicsFamily;   //图形队列族索引
    std::optional<uint32_t>      presentFamily;    //显示队列族索引
    bool isComplete() 
    {
        return graphicsFamily.has_value() && presentFamily.has_value();
    }
};

struct SwapChainSupportDetails
{
    vk::SurfaceCapabilitiesKHR          capabilities; //交换链的能力
    std::vector<vk::SurfaceFormatKHR>   formats; //交换链支持的表面格式
    std::vector<vk::PresentModeKHR>    presentModes; //交换链支持的显示模式
};


class VulkanAppCore 
{
protected:
    void* hWnd = nullptr;
    vk::Instance instance = nullptr;
    vk::DebugUtilsMessengerEXT debugMessenger = VK_NULL_HANDLE;

    vk::SurfaceKHR surface = VK_NULL_HANDLE;

    vk::PhysicalDevice physicalDevice = VK_NULL_HANDLE;
    vk::Device         logicDevice = VK_NULL_HANDLE;

    vk::Queue          graphicsQueue = VK_NULL_HANDLE;
    vk::Queue          presentQueue =  VK_NULL_HANDLE;

public:
    VulkanAppCore()
    {

    }
    
	void InitWindow(void* _hwnd)
	{
		hWnd = _hwnd;
	}

    void initVulkan();


    void cleanup() 
    {

        if (logicDevice != nullptr)
        {
            //vkDestroyDevice(logicDevice, nullptr);
            logicDevice.destroy();
            logicDevice = nullptr;
        }

        if (enableValidationLayers)
        {
            if (debugMessenger != nullptr)
            {
				instance.destroyDebugUtilsMessengerEXT(debugMessenger, nullptr);
				debugMessenger = nullptr;
            }
            
        }
        if (surface != nullptr)
        {
			instance.destroySurfaceKHR(surface, nullptr);
            surface = nullptr;
        }
        if (instance != nullptr)
        {
            vkDestroyInstance(instance, nullptr);
            instance = nullptr;
        }
        volkFinalize();
    }

private:
    void createInstance();


    void createSurface();

    void pickPhysicalDevice();
   

    void createLogicalDevice();
 

    bool isDeviceSuitable(vk::PhysicalDevice& _physicaldevice);

protected:
    QueueFamilyIndices findQueueFamilies(vk::PhysicalDevice& _physicalDevice);
protected:
    std::vector<const char*>  m_VkInstanceExtensions;
    std::vector<const char*>  m_VkValidationLayers;
    std::vector<vk::ExtensionProperties> m_VkDeviceExtensionPropertis;

    SwapChainSupportDetails querySwapChainSupport(vk::PhysicalDevice& physicalDevice);

    bool CheckPhysicalDeviceExtensionSupport(vk::PhysicalDevice& _physicaldevice,
        const std::vector<const char*>& _AppNeedPhysicalDeviceExtensions);

    std::vector<vk::ExtensionProperties>  getPhysicalDeviceSupportExtensionsProperties(vk::PhysicalDevice& _physicalDevice);
    std::vector<const char*> getRequiredExtensions(bool _enableValidationLayers=false) 
    {
        std::vector<const char*> extensions;
        extensions.push_back("VK_KHR_surface");
		extensions.push_back("VK_KHR_win32_surface");

        if (_enableValidationLayers) 
        {
            extensions.push_back(VK_EXT_DEBUG_UTILS_EXTENSION_NAME);
        }

        return extensions;
    }

    const std::vector<const char*>  getValidationLayersExtensions(bool _enableValidationLayers = true);
    bool checkValidationLayerSupport();

    public:
 
        static std::vector<char> readFile(const std::string& filename) {
            std::ifstream file(filename, std::ios::ate | std::ios::binary);

            if (!file.is_open()) {
                throw std::runtime_error("failed to open file!");
            }

            size_t fileSize = (size_t)file.tellg();
            std::vector<char> buffer(fileSize);

            file.seekg(0);
            file.read(buffer.data(), fileSize);

            file.close();

            return buffer;
        }
    static VKAPI_ATTR VkBool32 VKAPI_CALL debugCallback(VkDebugUtilsMessageSeverityFlagBitsEXT messageSeverity, VkDebugUtilsMessageTypeFlagsEXT messageType, const VkDebugUtilsMessengerCallbackDataEXT* pCallbackData, void* pUserData)
    {
        std::cerr << "validation layer: " << pCallbackData->pMessage << std::endl;

        return VK_FALSE;
    }
    static  VKAPI_ATTR VkBool32 VKAPI_CALL debug_messenger_callback(
        vk::DebugUtilsMessageSeverityFlagBitsEXT messageSeverity,
        vk::DebugUtilsMessageTypeFlagsEXT messageType,
        const vk::DebugUtilsMessengerCallbackDataEXT* pCallbackData,
        void* pUserData)
    {
        
            std::cerr << "validation layer: " << pCallbackData->pMessage << std::endl;
            return VK_FALSE;
    }
};

class VulkanShaderModule
{
    vk::ShaderModule     shaderModule;
    vk::Device           logicDevide;
public:
    VulkanShaderModule() = default;
    ~VulkanShaderModule()
    {
        if (logicDevide != nullptr)
        {
           // Destory(logicDevide);
            logicDevide = nullptr;
        }
    }
	vk::ShaderModule& GetShaderModule()
	{
		return shaderModule;
	}
    vk::ShaderModule& Initialize(vk::Device& _logicDevide, const std::string& _shaderFileName)
    {
       const std::vector<uint32_t> _shadeCode = LoadShader(_shaderFileName);

       return Initialize(_logicDevide, _shadeCode);
    }
    vk::ShaderModule& Initialize(vk::Device& _logicDevide, const std::vector<uint32_t>& _shaderCode)  
    {  
       logicDevide = _logicDevide;  
       vk::ShaderModuleCreateInfo createInfo{};  
       createInfo.codeSize = _shaderCode.size() * sizeof(uint32_t);  
       createInfo.pCode = _shaderCode.data();  
       
	 
       vk::ResultValue<vk::ShaderModule> result = logicDevide.createShaderModule(createInfo);// , nullptr, & shaderModule);
       if (result.result != vk::Result::eSuccess)
       {
           throw std::runtime_error("failed to create shader module!");
       }
	   shaderModule = result.value;
 
       return shaderModule;  
    }

    void Destory()
    {
        if (shaderModule != nullptr)
        {
            if (logicDevide != nullptr)
            {
				logicDevide.destroyShaderModule(shaderModule, nullptr);
				shaderModule = nullptr;
            }

        }
    }
    // 读取SPIR-V字节码文件
    std::vector<uint32_t> LoadShader(const std::string& filePath) 
    {
        std::ifstream file(filePath, std::ios::ate | std::ios::binary);
        if (!file.is_open()) {
            throw std::runtime_error("failed to open shader file!");
        }

        size_t fileSize = (size_t)file.tellg();
        std::vector<uint32_t> buffer(fileSize / sizeof(uint32_t));

        file.seekg(0);
        file.read(reinterpret_cast<char*>(buffer.data()), fileSize);
        file.close();

        return buffer;
    }
    
};

template<typename T, size_t N = 2>
class VulkanVertexBuffer
{
    vk::Device          logicDevice;
public:
	vk::Buffer          vertexBuffer;
	vk::DeviceMemory    vertexBufferMemory;
    int                  bufferSize = 0;

public: //索引缓冲区
    vk::Buffer indexBuffer;
    vk::DeviceMemory indexBufferMemory;
    int              indexBufferSize = 0;


	VulkanVertexBuffer() = default;
	~VulkanVertexBuffer()
	{
        Destory();
        logicDevice = nullptr;
	}
    void CreateVertexBuffer(vk::PhysicalDevice& _physicalDevice, vk::Device& _logicDevice, const std::vector<T>& _vertexData)
    {
        logicDevice = _logicDevice;
        vk::BufferCreateInfo bufferInfo;
        bufferInfo.size = sizeof(_vertexData[0]) * _vertexData.size();
        bufferInfo.usage = vk::BufferUsageFlagBits::eVertexBuffer; //VK_BUFFER_USAGE_VERTEX_BUFFER_BIT;
        bufferInfo.sharingMode = vk::SharingMode::eExclusive; //VK_SHARING_MODE_EXCLUSIVE;
        auto result = logicDevice.createBuffer(bufferInfo);// , nullptr, & vertexBuffer);
		if (result.result != vk::Result::eSuccess)
		{
			throw std::runtime_error("failed to create vertex buffer!");
		}
		vertexBuffer = result.value;

        bufferSize = bufferInfo.size;

        vk::MemoryRequirements memRequirements;
        logicDevice.getBufferMemoryRequirements(vertexBuffer , & memRequirements);

        vk::MemoryAllocateInfo allocInfo;
        allocInfo.allocationSize = memRequirements.size;
        allocInfo.memoryTypeIndex = findMemoryType(_physicalDevice, memRequirements.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
        auto result2 = logicDevice.allocateMemory(allocInfo);//, nullptr, & vertexBufferMemory);
        if (result2.result != vk::Result::eSuccess)
        {
			throw std::runtime_error("failed to allocate vertex buffer memory!");
        }
		vertexBufferMemory = result2.value;
		auto result3 = logicDevice.bindBufferMemory(vertexBuffer, vertexBufferMemory, 0);
        if (result3 != vk::Result::eSuccess)
        {
            throw std::runtime_error("failed to bind vertex buffer memory!");
        }
        void* data;
        
        auto result4  = logicDevice.mapMemory(vertexBufferMemory, 0, bufferInfo.size, vk::MemoryMapFlags(),
            & data);
        if (result4 != vk::Result::eSuccess)
        {
			throw std::runtime_error("failed to map vertex buffer memory!");
        }
        memcpy(data, _vertexData.data(), (size_t)bufferInfo.size);
		logicDevice.unmapMemory(vertexBufferMemory);
    }
    void Destory(const vk::Device& _logicDevide=nullptr)
    {
        if (_logicDevide != nullptr)
        {
            logicDevice = _logicDevide;
        }
        if (vertexBuffer != nullptr)
        {
            vkDestroyBuffer(logicDevice, vertexBuffer, nullptr);
			vertexBuffer = nullptr;
        } 
        if (vertexBufferMemory != nullptr)
        {
            vkFreeMemory(logicDevice, vertexBufferMemory, nullptr);
            vertexBufferMemory = nullptr;
        }

        if (indexBuffer != nullptr)
        {
            vkDestroyBuffer(logicDevice, indexBuffer, nullptr);
            indexBuffer = nullptr;
        }
        if (indexBufferMemory != nullptr)
        {
            vkFreeMemory(logicDevice, indexBufferMemory, nullptr);
            indexBufferMemory = nullptr;
        }
    }
    int GetVertexBufferSize()
    {
        return bufferSize;
    }

    VkVertexInputBindingDescription getBindingDescription()
    {
        return T::getBindingDescription();
    }
    VkVertexInputBindingDescription2EXT getBindingDescription2EXT()
    {
        return T::getBindingDescription2EXT();
    }

    std::array<VkVertexInputAttributeDescription, N> getAttributeDescriptions()
    {
        return T::getAttributeDescriptions();
    }
    std::array<vk::VertexInputAttributeDescription2EXT, N> getAttributeDescriptions2EXT()
    {
        return T::getAttributeDescriptions2EXT();
    }
    //为要分配的buffer找到正确的合适的显存类型
    uint32_t findMemoryType(vk::PhysicalDevice _physicalDevice,uint32_t typeFilter, VkMemoryPropertyFlags properties)
    {
        //查询所有可用的内存类型
        vk::PhysicalDeviceMemoryProperties memProperties = _physicalDevice.getMemoryProperties();
        //找到buffer适合的内存类型
        for (uint32_t i = 0; i < memProperties.memoryTypeCount; i++)
        {
            uint32_t  a = static_cast<uint32_t>( memProperties.memoryTypes[i].propertyFlags);
			uint32_t  b = static_cast<uint32_t>(properties);
            //if (typeFilter & (1 << i) && (memProperties.memoryTypes[i].propertyFlags & properties) == properties)
            if((typeFilter & (1 << i))&&((a & b) == properties))
            {
                return i;
            }
        }

        throw std::runtime_error("failed to find suitable memory type!");
    }

    void CreateIndexBuffer(VkPhysicalDevice _physicalDevice, VkDevice _logicDevice, const std::vector<uint16_t>& _indices)
    {
        VkDeviceSize tBufferSize = sizeof(_indices[0]) * _indices.size();

        VkBufferCreateInfo bufferInfo{};
        bufferInfo.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
        bufferInfo.size = tBufferSize;
        bufferInfo.usage = VK_BUFFER_USAGE_INDEX_BUFFER_BIT;
        bufferInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        VkBuffer  tempBuffer;
        if (vkCreateBuffer(_logicDevice, &bufferInfo, nullptr, &tempBuffer) != VK_SUCCESS) {
            throw std::runtime_error("failed to create index buffer!");
        }
        indexBuffer = tempBuffer;
        VkMemoryRequirements memRequirements;
        vkGetBufferMemoryRequirements(_logicDevice, indexBuffer, &memRequirements);

        VkMemoryAllocateInfo allocInfo{};
        allocInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
        allocInfo.allocationSize = memRequirements.size;
        allocInfo.memoryTypeIndex = findMemoryType(vk::PhysicalDevice(_physicalDevice), memRequirements.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
        VkDeviceMemory tempMemory;
        if (vkAllocateMemory(_logicDevice, &allocInfo, nullptr, &tempMemory) != VK_SUCCESS) {
            throw std::runtime_error("failed to allocate index buffer memory!");
        }
        indexBufferMemory = tempMemory;

        vkBindBufferMemory(_logicDevice, indexBuffer, indexBufferMemory, 0);

        void* data;
        vkMapMemory(_logicDevice, indexBufferMemory, 0, tBufferSize, 0, &data);
        memcpy(data, _indices.data(), (size_t)tBufferSize);
        vkUnmapMemory(_logicDevice, indexBufferMemory);
		indexBufferSize = tBufferSize;
    }
};

