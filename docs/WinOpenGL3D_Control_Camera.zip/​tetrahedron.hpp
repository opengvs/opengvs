﻿//FileName tetrahedron.hpp( triangular pyramid​s)三角锥的头文件定义，tetrahedron单词更专业
#ifndef __TETRAHEDRON_HPP__
#define __TETRAHEDRON_HPP__
#include "VAOWithVBOandEBO.hpp"

static float triangularvertdata[] = {
                1.0f, 0.0f,  -1.0f,//1
                1.0f, 0.0f,  1.0f,//2
                -1.0f, 0.0f,  1.0f,//3
                0.0f, 1.0f,  0.0f,//4

};
static float triangularcolordata[] = {1.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 1.0f,
        0.0f,  1.0f, 0.0f,
        1.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 1.0f,

};
 static unsigned int triangularindicedata[] = {
        0, 1, 2,
        0, 1, 3,

        1, 2, 3,
        2, 0, 3,

};
 class Tetrahedron
 {
     VAOWithVBOandEBO   m_TriangularPyramid​s;
 public:
     Tetrahedron()
     {

     }
     ~Tetrahedron()
     {

     }
     void InitializeData()
     {
         m_TriangularPyramid​s.AddVBOandEBO(
             { triangularvertdata ,triangularcolordata }, 
             { 12,12 }, BufferUsageHint::StaticDraw,
             { {3},{3} },
             std::vector<GLuint>(triangularindicedata, triangularindicedata + 12));
     }
     void Draw()
     {
         m_TriangularPyramid​s.DrawElements(PrimitiveType::Triangles, 12);
     }
 };

#endif
