//FileName:CubeObjectwithColor.hpp
#pragma once
#include "VAOWithVBOandEBO.hpp"

float cubevertdata[] = {
        -0.8f, -0.8f,  -0.8f,//1
        0.8f, -0.8f,  -0.8f,//2
        0.8f, 0.8f,  -0.8f,//3
       -0.8f, 0.8f,  -0.8f,//4
       -0.8f, -0.8f,  0.8f,//5
        0.8f, -0.8f,  0.8f,//6
        0.8f, 0.8f,  0.8f,//7
       -0.8f, 0.8f,  0.8f //8
};
float cubecolordata[] = { 1.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 1.0f,
        0.0f,  1.0f, 0.0f,
        1.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 1.0f,
        0.0f,  1.0f, 0.0f,
        1.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 1.0f
};
int cubeindicedata[] = {
    //left
    0, 2, 1,
    0, 3, 2,
    //back
    1, 2, 6,
    6, 5, 1,
    //right
    4, 5, 6,
    6, 7, 4,
    //top
    2, 3, 6,
    6, 3, 7,
    //front
    0, 7, 3,
    0, 4, 7,
    //bottom
    0, 1, 5,
    0, 5, 4
};

class CubeObjectWithColor
{
    VAOWithVBOandEBO   m_VaoWithVBOandEBO;
public:
    CubeObjectWithColor()
    {

    }
    ~CubeObjectWithColor()
    {

    }
    void InitializeData()
    {
        m_VaoWithVBOandEBO.AddVBOandEBO(
            { cubevertdata ,cubecolordata },
            { 24,24 }, BufferUsageHint::StaticDraw,
            { {3},{3} },
            std::vector<GLuint>(cubeindicedata, cubeindicedata + 36));
    }
    void Draw()
    {
        m_VaoWithVBOandEBO.DrawElements(PrimitiveType::Triangles, 36);
    }
};