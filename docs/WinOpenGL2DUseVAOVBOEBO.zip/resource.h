﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 WinMainApp.rc 使用
//
#define IDC_MYICON                      2
#define IDD_MAINDIALOG                  101
#define IDD_WINMAINAPP_DIALOG           102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_WINMAINAPP                  107
#define IDI_SMALL                       108
#define IDC_WINMAINAPP                  109
#define IDR_MAINFRAME                   128
#define IDC_OPENGLVIEW                  1002
#define IDC_GLVIEW2                     1004
#define Mat3X3                          1005
#define IDC_MAT00                       1006
#define IDC_MAT01                       1007
#define IDC_MAT02                       1008
#define IDC_MAT10                       1009
#define IDC_MAT11                       1010
#define IDC_MAT12                       1011
#define IDC_MAT20                       1012
#define IDC_MAT21                       1013
#define IDC_MAT22                       1014
#define IDC_AUTORATATION                1015
#define IDC_ROTATIONEDIT                1017
#define IDC_ROTATIONBUTTON              1018
#define IDC_MOVEX_SPIN                  1019
#define IDC_MOVEY_SPIN                  1020
#define IDC_SCALE_X_EDIT                1021
#define IDC_SCALE_Y_EDIT                1022
#define IDC_SCALE_X_SLIDER              1023
#define IDC_SLIDER2                     1024
#define IDC_SCALE_Y_SLIDER              1024
#define IDC_RADIO1                      1025
#define IDC_RADIO2                      1026
#define IDC_RADIO3                      1027
#define IDC_RADIO4                      1028
#define IDC_RADIO5                      1029
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
