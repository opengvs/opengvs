﻿// WinMainApp.cpp : 定义应用程序的入口点。
//
/*
 * Either define WIN32_LEAN_AND_MEAN, or one or more of NOCRYPT,
 * NOSERVICE, NOMCX and NOIME, to decrease compile time (if you
 * don't need these defines -- see windows.h).
 */

#define WIN32_LEAN_AND_MEAN
 /* #define NOCRYPT */
 /* #define NOSERVICE */
 /* #define NOMCX */
 /* #define NOIME */
#include "framework.h"
#include <windowsx.h>
#include "WinMainApp.h"
#include "WinForm.hpp"
#include <vector>

#include "commctrl.h" //高级控件都要加该头文件 
#include <tchar.h>
#include <stdio.h>
#pragma comment(lib, "Comctl32.lib")

#define MAX_LOADSTRING 100

// 全局变量:
HINSTANCE hInst;                                // 当前实例
WCHAR szTitle[MAX_LOADSTRING];                  // 标题栏文本
WCHAR szWindowClass[MAX_LOADSTRING];            // 主窗口类名
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

class TabPage1 : public Win::TabPage
{
public:
    virtual VOID TabPage_OnCommand(HWND hwnd, INT id, HWND hwndCtl, UINT codeNotify)
    {
        if (id == CMD_CLICK_1)
        {
            ::MessageBox(hwnd, L"CMD_CLICK_1", L"信息提示", MB_OKCANCEL);
        }
    }
};
class TabPage2 : public Win::TabPage
{
public:
    virtual VOID TabPage_OnCommand(HWND hwnd, INT id, HWND hwndCtl, UINT codeNotify)
    {
        if (id == CMD_CLICK_22)
        {
            ::MessageBox(hwnd, L"CMD_CLICK_22", L"信息提示", MB_OKCANCEL);
        }
    }
};
class TabPage3 : public Win::TabPage
{
public:
    virtual VOID TabPage_OnCommand(HWND hwnd, INT id, HWND hwndCtl, UINT codeNotify)
    {
        if (id == CMD_CLICK_22)
        {
            ::MessageBox(hwnd, L"CMD_CLICK_22", L"信息提示", MB_OKCANCEL);
        }
    }
};
class TabPage4 : public Win::TabPage
{
public:
    virtual VOID TabPage_OnCommand(HWND hwnd, INT id, HWND hwndCtl, UINT codeNotify)
    {
        if (id == CMD_CLICK_22)
        {
            ::MessageBox(hwnd, L"CMD_CLICK_22", L"信息提示", MB_OKCANCEL);
        }
    }
};
class  TestWinForm :public Win::WinForm
{
public:
    Win::Picture  m_Picture;
    TestWinForm() : Win::WinForm()
    {

    };
    virtual ~TestWinForm()
    {

    }
    virtual void Init_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        m_Picture.set(hDlg, IDC_PICTURESTATIC);
        HBITMAP  hBitmap = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP1));
       m_Picture.setImage(hBitmap);
       m_Picture.show();
    }
};
TestWinForm  g_TestWinForm;
class  WindowsForm :public Win::WinForm
{
private:
    Win::Button  m_AboutButton;
    Win::Button  m_CloseButton;
    Win::TabControl  m_TabControl_1;
    TabPage1         m_TabPage_1;
    TabPage2     m_TabPage_2;
    Win::TabControl  m_TabControl_2;
    TabPage3     m_TabPage_3;
    TabPage4     m_TabPage_4;
public:
    WindowsForm() :Win::WinForm()
    {

    };
    virtual ~WindowsForm()
    {

    }
    virtual void Init_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        HWND hWnd = hDlg;// ::GetDlgItem(hDlg, IDC_OPENGLVIEW);
        m_AboutButton.set(hDlg, IDD_ABOUTBOX);
        m_CloseButton.set(hDlg, IDM_EXIT);
        
        m_TabControl_1.set(hDlg, TAB_CONTROL_1, 2);
        m_TabPage_1.set(&m_TabControl_1, (const LPWSTR)L"_tabName_1", TAB_CONTROL_1_PAGE_1);
        m_TabPage_2.set(&m_TabControl_1, (const LPWSTR)L"_tabName_2", TAB_CONTROL_1_PAGE_2);
       
        m_TabControl_2.set(hDlg, TAB_CONTROL_2, 2);
        m_TabPage_3.set(&m_TabControl_2, (const LPWSTR)L"_tabName_3", TAB_CONTROL_1_PAGE_3);
        m_TabPage_4.set(&m_TabControl_2, (const LPWSTR)L"_tabName_4", TAB_CONTROL_1_PAGE_4);
       
        return;
    };

    virtual void Command_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        int wmId = LOWORD(wParam);
        if (wmId == IDD_ABOUTBOX)
        {
            //Win::WinForm::ShowModelDialog(IDD_ABOUTBOX, hDlg, About);// Win::WinForm::DialogWindowProc);
            g_TestWinForm.Show();
        }
        else if (wmId == IDM_EXIT)
        {
            ::SendMessageW(hDlg, WM_DESTROY, 0, 0);
        }
    }
    ////////////////////////////////////////////////////////
    virtual void Notify_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    {
        if (((INT)wParam == TAB_CONTROL_1) || ((INT)wParam == TAB_CONTROL_2)) //这里也可以用一个NMHDR *nm = (NMHDR *)lParam这个指针来获取 句柄和事件
        {					//读者可自行查找NMHDR结构
            Win::TabControl::TabControl_Notify(hDlg, message, wParam, lParam);
        }   
    }
    virtual void Resize_Event(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) 
    {
        m_TabControl_1.TabControl_OnSize(hDlg, wParam, LOWORD(lParam), HIWORD(lParam));
        m_TabControl_1.TabControl_OnSize(hDlg, wParam, LOWORD(lParam), HIWORD(lParam));
    }

    ///////////////////////////////////////////////////////////
};

WindowsForm  g_WinForm;



int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 在此处放置代码。
     // Initialize common controls. Also needed for MANIFEST's.
    InitCommonControls();
    // 初始化全局字符串
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WINMAINAPP, szWindowClass, MAX_LOADSTRING);
   
    g_WinForm.CreateWindowFromReSource(hInstance, IDD_MAINDIALOG);// , FormMain_DlgProc);
    g_TestWinForm.CreateWindowFromReSource(hInstance, IDD_DIALOG1);
    return g_WinForm.Run(); 
    //g_pForm.CreateWindowFromReSource(hInstance, IDD_MAINDIALOG, FormMain_DlgProc);
    //return   g_pForm.Run();
}

// “关于”框的消息处理程序。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
    {
         return (INT_PTR)TRUE;
    }
        break;
    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}





