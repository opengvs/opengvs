﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 WinMainApp.rc 使用
//
#define IDC_MYICON                      2
#define IDD_MAINDIALOG                  101
#define IDD_WINMAINAPP_DIALOG           102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_WINMAINAPP                  107
#define IDI_SMALL                       108
#define IDC_WINMAINAPP                  109
#define IDR_MAINFRAME                   128
#define TAB_CONTROL_1_PAGE_1            129
#define TAB_CONTROL_1_PAGE_2            130
#define TAB_CONTROL_1_PAGE_3            131
#define TAB_CONTROL_1_PAGE_4            132
#define IDD_DIALOG1                     133
#define IDB_BITMAP1                     134
#define TAB_CONTROL_1                   1002
#define IDC_TAB1                        1003
#define TAB_CONTROL_2                   1004
#define CMD_CLICK_1                     1005
#define CMD_CLICK_2                     1005
#define CMD_CLICK_22                    1008
#define IDC_PICTURESTATIC               1009
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
