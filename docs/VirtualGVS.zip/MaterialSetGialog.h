#if !defined(AFX_MATERIALSETGIALOG_H__93478E22_8F03_4481_B329_CF1304BDC7DE__INCLUDED_)
#define AFX_MATERIALSETGIALOG_H__93478E22_8F03_4481_B329_CF1304BDC7DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MaterialSetGialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMaterialSetGialog dialog
//class  GMaterial;
class CMaterialSetGialog : public CDialog
{
// Construction
public:
	CMaterialSetGialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMaterialSetGialog)
	enum { IDD = IDD_MATERIALDIALOG };
	CSliderCtrl	m_RSlider;
	CSliderCtrl	m_GSlider;
	CSliderCtrl	m_BSlider;
	CSliderCtrl	m_ASlider;
	int		m_CheckRadio;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMaterialSetGialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMaterialSetGialog)
	virtual void OnOK();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	virtual BOOL OnInitDialog();
	afx_msg void OnCustomdrawRgbaRslider(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCustomdrawRgbaGslider(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCustomdrawRgbaBslider(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCustomdrawRgbaAslider(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnAnbientradio();
	afx_msg void OnDiffuseradio();
	afx_msg void OnSpecularradio();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
    GV_Material  m_pMaterial;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MATERIALSETGIALOG_H__93478E22_8F03_4481_B329_CF1304BDC7DE__INCLUDED_)
