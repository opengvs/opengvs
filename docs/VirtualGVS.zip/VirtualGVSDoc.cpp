// VirtualGVSDoc.cpp : implementation of the CVirtualGVSDoc class
//

#include "stdafx.h"
#include "VirtualGVS.h"

#include "VirtualGVSDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVirtualGVSDoc

IMPLEMENT_DYNCREATE(CVirtualGVSDoc, CDocument)

BEGIN_MESSAGE_MAP(CVirtualGVSDoc, CDocument)
	//{{AFX_MSG_MAP(CVirtualGVSDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVirtualGVSDoc construction/destruction

CVirtualGVSDoc::CVirtualGVSDoc()
{
	// TODO: add one-time construction code here

}

CVirtualGVSDoc::~CVirtualGVSDoc()
{
}

BOOL CVirtualGVSDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CVirtualGVSDoc serialization

void CVirtualGVSDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CVirtualGVSDoc diagnostics

#ifdef _DEBUG
void CVirtualGVSDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CVirtualGVSDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CVirtualGVSDoc commands
