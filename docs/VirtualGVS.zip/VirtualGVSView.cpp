// VirtualGVSView.cpp : implementation of the CVirtualGVSView class
//

#include "stdafx.h"
#include "VirtualGVS.h"

#include "VirtualGVSDoc.h"
#include "VirtualGVSView.h"
//#include  "OpenGVS\TVGVSAppFrame.h"
#include  "OpenGVS\TGVSApp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVirtualGVSView

IMPLEMENT_DYNCREATE(CVirtualGVSView, CView)

BEGIN_MESSAGE_MAP(CVirtualGVSView, CView)
	//{{AFX_MSG_MAP(CVirtualGVSView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVirtualGVSView construction/destruction

CVirtualGVSView::CVirtualGVSView()
{
	// TODO: add construction code here

}

CVirtualGVSView::~CVirtualGVSView()
{
}

BOOL CVirtualGVSView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CVirtualGVSView drawing

void CVirtualGVSView::OnDraw(CDC* pDC)
{
	CVirtualGVSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CVirtualGVSView diagnostics

#ifdef _DEBUG
void CVirtualGVSView::AssertValid() const
{
	CView::AssertValid();
}

void CVirtualGVSView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CVirtualGVSDoc* CVirtualGVSView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CVirtualGVSDoc)));
	return (CVirtualGVSDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CVirtualGVSView message handlers

LRESULT CVirtualGVSView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	if( TGVSAppFrame::GVSGetApp() != NULL )
         TGVSAppFrame::GVSGetApp()->ProcessMessage(message,wParam,lParam );
	
	return CView::DefWindowProc(message, wParam, lParam);
}
