// VirtualGVSView.h : interface of the CVirtualGVSView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_VIRTUALGVSVIEW_H__F2BE8501_4983_4B52_8ACB_FBA2C8FB26FB__INCLUDED_)
#define AFX_VIRTUALGVSVIEW_H__F2BE8501_4983_4B52_8ACB_FBA2C8FB26FB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CVirtualGVSView : public CView
{
protected: // create from serialization only
	CVirtualGVSView();
	DECLARE_DYNCREATE(CVirtualGVSView)

// Attributes
public:
	CVirtualGVSDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVirtualGVSView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CVirtualGVSView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CVirtualGVSView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in VirtualGVSView.cpp
inline CVirtualGVSDoc* CVirtualGVSView::GetDocument()
   { return (CVirtualGVSDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VIRTUALGVSVIEW_H__F2BE8501_4983_4B52_8ACB_FBA2C8FB26FB__INCLUDED_)
