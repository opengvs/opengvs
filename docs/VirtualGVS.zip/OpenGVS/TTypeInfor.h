//#include <TTypeInfor.h>

#ifndef  __TTYPEINFOR_HPP__
#define  __TTYPEINFOR_HPP__

#pragma warning(disable:4786)
#include <set>
#include <map>
#include <list>
#include <vector>

using namespace std;

enum TTypeKind { tkInteger=0, tkChar, tkEnumeration, tkFloat, tkString, tkSet,tkStruct,tkObject };

struct TTypeInfo;
typedef TTypeInfo *PTypeInfo;
typedef PTypeInfo *PPTypeInfo;

#ifndef  GVSNAME_MAXLENGTH
#define  GVSNAME_MAXLENGTH   32
#endif


#pragma pack(push, 1)
struct TTypeInfo
{
	TTypeKind Kind;
	char    Name[GVSNAME_MAXLENGTH];
} ;
#pragma pack(pop)

#ifdef __cplusplus
extern "C" {
#endif

typedef void ( *PropertyDataCallbackForFloatSet)(void* self,float  Data );
typedef void ( *PropertyDataCallbackForFloatGet)(void* self,float*  Data );

typedef void ( *PropertyDataCallbackForIntergerSet)(void* self,int  Data );
typedef void ( *PropertyDataCallbackForIntergerGet)(void* self,int*  Data );

typedef void ( *PropertyDataCallbackForByteSet)(void* self,BYTE  Data );
typedef void ( *PropertyDataCallbackForByteGet)(void* self,BYTE*  Data );

typedef void ( *PropertyDataCallbackForStringSet)(void* self,char*  str);
typedef void ( *PropertyDataCallbackForStringGet)(void* self,char**  str );

typedef void ( *PropertyDataCallbackForEnumSet)(void* self,int  Data );
typedef void ( *PropertyDataCallbackForEnumGet)(void* self,int* Data );

typedef void ( *PropertyDataCallbackForObjectSet)(void* self,void* pData );
typedef void ( *PropertyDataCallbackForObjectGet)(void* self,void* pData );


#ifdef __cplusplus
}
#endif



struct  PropertyStr
{
  PropertyStr();
  ~PropertyStr();

  char                m_Name[GVSNAME_MAXLENGTH];
  char                m_TypeName[GVSNAME_MAXLENGTH];
  TTypeKind           m_PropertyType;
  
  union  {
	  int     iData;
	  float   fData;
      int     eData;//Enum
	  char*   sData;//string  
  }   PropertyData;

  union  {
      PropertyDataCallbackForFloatSet      FloatSet;
      PropertyDataCallbackForIntergerSet   IntergerSet;
	  PropertyDataCallbackForByteSet       ByteSet;
	  PropertyDataCallbackForStringSet     StringSet;
      PropertyDataCallbackForEnumSet       EnumSet;
	  PropertyDataCallbackForObjectSet     ObjectSet;
  }  SetDataCallbackFunction;

  union  {
        PropertyDataCallbackForFloatGet       FloatGet;
        PropertyDataCallbackForIntergerGet    IntergerGet;
        PropertyDataCallbackForByteGet        ByteGet;
  	    PropertyDataCallbackForStringGet      StringGet;
        PropertyDataCallbackForEnumGet        EnumGet;
		PropertyDataCallbackForObjectGet      ObjectGet;
  }  GetDataCallbackFunction;

  int  ListCtrlIndex;
  vector<PropertyStr*>  m_ChildList;
  bool  IsExpand;
  bool  IsChild;

  void  AddChildProperty(PropertyStr*  pChild);
};

typedef  map<int,PropertyStr*,less<int> >  INT2PROPERTY;
typedef  vector<PropertyStr*>   PROPETTYSTRLIST;

/////////////////////////////////////////////////////////////////////////////

inline void  PropertyStr::AddChildProperty(PropertyStr*  pChild)
{
  pChild->IsChild = true;
  m_ChildList.push_back( pChild );
}

///////////////����ö��������ص����ݽṹ
struct  EnumInforObject
{
   char  name[GVSNAME_MAXLENGTH];

   char*  GetName() { return name;};
   virtual  int  GetValue(char*  tempStr)=0;
   virtual  char*  GetValueName(int eNum )=0;
   virtual  int   GetValueNumber(void) = 0;
};

struct  TRegesterEnum
{
static  Initialise(void);
static  Destroy(void);
static  EnumInforObject*  FindEnum( char* eNum );
  
};

template <class T>
struct EnumInfor : public EnumInforObject 
{
  EnumInfor(char* str ){ strcpy(name,str);};
  map<T,char*,less<T> >  DataMap;

  virtual int  GetValue(char*  tempStr);
  virtual  char*  GetValueName(int eNum );
  virtual  int   GetValueNumber(void){return DataMap.size();};
  void  insert(T  t,char*  str){ DataMap.insert(map<T,char*,less<T> >::value_type(t,str) );};
};


/////////////////////////////////////////////////////////////////////////////////

template <class T> inline  int  EnumInfor<T>::GetValue(char*  tempStr)
{
	map<T,char*,less<T> >::iterator  pIt = DataMap.begin();
	while( pIt != DataMap.end() )
	{
		if( pIt->second == tempStr )
			break;
		pIt++;
	}
	if( pIt != DataMap.end() )
		return pIt->first;
  return -1;
}

template <class T>  inline char*  EnumInfor<T>::GetValueName(int eNum )
{
	char*  str = "";
	map<T,char*,less<T> >::iterator  pIt = DataMap.begin();
	while( pIt != DataMap.end() )
	{
		if( ((int)pIt->first) == eNum )
			break;
		pIt++;
	}
	if( pIt != DataMap.end() )
		str = pIt->second;

	return  str;
}


//////////////////////////GVSϵͳ�нṹ��صĶ���//////////////////////////
struct  GVS_StructInfor
{
	char  m_TypeName[GVSNAME_MAXLENGTH];
	char  m_MemberStr[8*GVSNAME_MAXLENGTH];
    GVS_StructInfor(const char*  typeName,const char* memberStr)
	{
		strcpy(m_TypeName,typeName);
		strcpy(m_MemberStr,memberStr);
	};
};
struct  GVS_Struct
{
	static  list<GVS_StructInfor>    m_GVSStructInfor_List;
	static  void   Initialize(void);
	static  char*  GetStructString(const char*  typeName);
};


#endif