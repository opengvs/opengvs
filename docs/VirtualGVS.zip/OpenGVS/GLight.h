/********************************************************************
FileName:     GLight.h
descript:     ���ڶ����Դ��
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/
#ifndef   __GLIGHT_H_
#define   __GLIGHT_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef struct GV_light_source_s * GV_Light ;

#ifdef __cplusplus
}
#endif

class GLight  
{
protected:
	GV_Light  m_InsideLight;

	GLight();
public:
    GLight(GV_Light pLight);
	virtual ~GLight();

    int Set_ambient( const GV_Rgba *ambient_in);
    int Get_ambient( GV_Rgba *ambient_out);

	int Set_diffuse( const GV_Rgba *diffuse_in);
    int Get_diffuse( GV_Rgba *diffuse_out);

    int Set_specular( const GV_Rgba *specular_in);
    int Get_specular( GV_Rgba *specular_out);

    int Set_direction( const G_Vector3 *dir_in);
    int Get_direction( G_Vector3 *dir_out);

    int Set_position( const G_Position *pos_in);
    int Get_position( G_Position *pos_out);

    int Set_spot_direction(const G_Vector3 *dir_in);
    int Get_spot_direction( G_Vector3 *dir_out);

    int Set_spot_exponent( float exponent_in );
    int Get_spot_exponent( float *exponent_out );

    int Set_spot_cutoff( float angle_in );
    int Get_spot_cutoff( float *angle_out );

    int Set_attenuation( GLenum a_type, GLfloat atten_in);
    int Get_attenuation( GLenum a_type, GLfloat *atten_out);

    int Get_type( GV_Lsr_type * lsr_type );

public:
	static GLight*  CreateGLight(char*  name_in );
	static GLight*  CreateGLight( GV_Light  pLight);
	GV_light_source_s**  Get_light(){return &m_InsideLight; };
};


#endif