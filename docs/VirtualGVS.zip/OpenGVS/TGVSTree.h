// TGVSTree.h: interface for the TGVSTree class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TGVSTREE_H__DA58F993_5FD2_4CA7_BBD3_E86D390B9248__INCLUDED_)
#define AFX_TGVSTREE_H__DA58F993_5FD2_4CA7_BBD3_E86D390B9248__INCLUDED_

#include "TGVSBaseClass.h"

#pragma warning(disable:4786)
#include <vector>
#include <list>
using namespace std;


enum  NodeType { TopNode = 0,ListNode,ChildNode };

//�������ͽṹ--�ڵ�����
struct  TTreeNode
{
	char  m_NodeName[GVSNAME_MAXLENGTH];
    NodeType   m_NodeType;
	void  *pHTREEITEM;
    TTreeNode( NodeType  tNodeType ){m_NodeType=m_NodeType;pHTREEITEM = NULL;};
    ~TTreeNode();
};

struct  TGVSNode : public  TTreeNode
{
	TGVSNode(const char*  pNodeName):TTreeNode(ChildNode) { pNode=NULL; strcpy(m_NodeName,pNodeName); };
    ~TGVSNode(){if( pNode!= NULL ) { pNode=NULL;} };
	TGVSBaseClass  *pNode;
};


struct  TGVSListNode : public  TTreeNode
{
    TGVSListNode(const char*  pNodeName):TTreeNode(ListNode) {strcpy(m_NodeName,pNodeName);};
	~TGVSListNode();
    list<TGVSNode*>  m_pGVSObjectList;
};

class TGVSTree : public  TTreeNode  
{
 
public:
	TGVSTree(const char* pNodeName);
	~TGVSTree();
	list<TGVSNode*>         m_pGVSObjectList;
	list<TGVSListNode*>     m_GVSListNode;
public:
    TGVSListNode*     AddGVSListNode( const char*  ListName );
    TGVSNode*         AddGVSObject(const char*  ParentName,TGVSBaseClass*  pGVSObject);
	TGVSNode*         AddGVSObject(TGVSBaseClass*  pGVSObject,TGVSListNode*  pParentNode=NULL);
};


#endif // !defined(AFX_TGVSTREE_H__DA58F993_5FD2_4CA7_BBD3_E86D390B9248__INCLUDED_)
