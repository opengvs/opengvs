/********************************************************************
FileName:     GScene.h
descript:     ���ڶ���Virtual  GVSϵͳ��Ҫ�ĳ�����
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/

#ifndef   __GSCENE_H__
#define   __GSCENE_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct GV_scene_s * GV_Scene ;

#ifdef __cplusplus
}
#endif

class  GLight;
class  GObi;
class  GTerrain;

class  GScene
{
protected:
   GV_Scene   m_pInsideData;
protected:
	GScene(){m_pInsideData=NULL;};
public:
	virtual ~GScene(){m_pInsideData=NULL;};

   static  GScene*   CreateScene(const char*  name);
   GV_Scene*  GetGVScene(void){ return  &m_pInsideData; };
   void  AddLight(GLight*  pLight);

   int  Add_obi(GObi*  pObi);  
   int  Add_terrain( GTerrain*  pTerrain);

   int  Remove_object( GObi*  pObi) ;
   int  Remove_terrain(GTerrain*  pTerrain);
   int  Remove_all_objects( void ) ;

};

int  Remove_object_from_all_scene( GObi*  pObi );

#endif  //__GSCENE_H__