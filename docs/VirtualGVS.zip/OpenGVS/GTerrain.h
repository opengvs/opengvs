/********************************************************************
FileName:     GTerrain.h
descript:     ���ڶ�����������������
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/
#ifndef  __TERRAIN_H__
#define  __TERRAIN_H__

#include "GObi.h"
#include "GScene.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef int (*Terrain_def_callback)( void * pvd);

#ifdef __cplusplus
}
#endif


class GComposition
{
private:
	GV_Geo_composition  m_InsideComposition;
public:
    GComposition(void);
	GComposition(const char*  name);
	~GComposition(void);

	GV_Geo_composition*  GetInsidecomposition(void){ return  &m_InsideComposition;};
    int Set_composition_mask( const G_Mask cmask ) ;
    int Get_composition_mask( G_Mask * p_cmask ) ;

    int Set_composition_name( const G_Name gname ) ;
    int Get_composition_name( G_Name gname ) ;

   static int Create_composition( const char*  gname,GComposition*  p_geocom );
   static int Get_composition_by_name(const char*  name, GComposition* p_geocom ) ;


};

class  GFace
{
private:
  GV_Geo_face  m_InsideFace;
public:
	GFace(){m_InsideFace = NULL; };
	~GFace(){m_InsideFace = NULL;};

  GV_Geo_face*  GetInsideFace(void){return  &m_InsideFace;};
  bool IsWithinFace( float x, float z );

  int  Get_face_vertices( G_Vector3 vtx[3] );
  int  Get_face_normal( G_Vector3 *face_normal );
  int  Get_face_elevation( float x, float z, float *y);
  int  Get_face_orientation( float roty,  float *rotx, float *rotz );

  int  Set_face_composition( GComposition geocom ) ;

  int  Get_face_composition( GComposition * p_geocom ) ;

  int  Get_face_object_def( GV_Obd * obdhdl_out ) ;

};

class  GObd;
class  GTerrain
{
protected:
    GV_Geometry   m_InsideTerrain;
	GObd*         m_pObd;
	GObi*         m_pObi;

	GTerrain(const char*  name);	
public:
    GTerrain();
	virtual ~GTerrain();
     
	//��������
	static  GTerrain*  CreateTerrain(const char* name);
    static  GTerrain*  Defineterrain(const char* name,Terrain_def_callback  callback_function );
    static  int   Obtain_terrain_by_name(const char* name,GTerrain*  terrain_out);

    GV_Geometry*  GetInsideTerrain(void){return &m_InsideTerrain;};
    GObi*  Get_obi(void);
	GObd*  Get_obd(void);
		
    //��������
    int Get_face( GFace  last_face, float x, float z, GFace *face_out);
    int Get_face_below( const G_Position * pos_in, GFace * face_out );
    int Set_name( const G_Name gname );
    int Get_name( G_Name gname );

    int Set_rotation( const G_Rotation *rotation );
    int Get_rotation( G_Rotation *rotation );

    int Set_position( const G_Position *position );
    int Get_position( G_Position *position );

    int Set_scaling( const G_Vector3 *scaling );
    int Get_scaling( G_Vector3 *scaling );

    /* Routines to store faces within a geometry database */
    static void Terrain_face_begin(GTerrain*  pTerrain);
    static void Terrain_face_begin_mode(GTerrain*  pTerrain, GLenum mode );
    static void Terrain_face_add_vertex(GTerrain*  pTerrain, const float vtx[3] );
    static void Terrain_face_end(GTerrain*  pTerrain);

    int Set_composition_current( GComposition geocom ) ;
    int Get_composition_current( GComposition * p_geocom ) ;

	int Set_object_def_cur( GV_Obd obdhdl_in ) ;
    int Get_object_def_cur( GV_Obd * obdhdl_out ) ;

};

#ifdef __cplusplus
extern "C" {
#endif

int Obtain_scene_Terrain_face( GScene* scnhdl,
    float x, float z, GFace * face_out ) ;

int Obtain_scene_Terrain_face_below( GScene* scnhdl,
    const G_Position * pos_in, GFace * face_out ) ;

/*  Intersection functions: */
int Obtain_intersection( GV_Scene cur_scene, const G_Vector3 *v0,
    const G_Vector3 *v1, GV_Geo_isc_control_mask isc_mask,
    G_Mask exclusion_mask, GV_Geo_isc_data * p_iscdat ) ;

int Obtain_intersection_d( GV_Scene cur_scene, const G_Vector3_d *v0,
    const G_Vector3_d *v1, GV_Geo_isc_control_mask isc_mask,
    G_Mask exclusion_mask, GV_Geo_isc_data_d * p_iscdat ) ;

int Obtain_point_in_frustum( const G_Vector3 *v0,
    const GV_Frustum *p_frustum, GV_Geo_isc_result * p_result);

int Obtain_line_in_frustum( const G_Vector3 *v0, const G_Vector3 *v1,
    const GV_Frustum *p_frustum, GV_Geo_isc_control_mask isc_mask,
    G_Vector3 *v_out, GV_Geo_isc_result * p_result);

int Obtain_geo_inq_line_in_sphere( const G_Vector3 *x0, float r,
    const G_Vector3 *v1, const G_Vector3 *v2, G_Boolean * p_result );

/*  Deprecated functions: */

int Obtain_inq_face( GTerrain* geohdl, GV_Geo_face last_face, 
    float x, float z, GFace *face_out);

int Obtain_inq_face_below( GTerrain* geohdl, const G_Position * pos_in,
    GFace * face_out );

int Obtain_obi_collision( GV_Obi obihdl1, GV_Obi obihdl2,G_Boolean * p_bool);

int Obtain_group_parent( GV_Geometry geohdl, GV_Geometry * GeoParent ) ;

int Obtain_group_child( GV_Geometry geohdl, GV_Geometry * GeoChild ) ;

int Obtain_inq_group_next( GV_Geometry geohdl, GV_Geometry * GeoNext ) ;

int Terrain_group_prev( GV_Geometry geohdl, GV_Geometry * GeoPrev ) ;

int Terrain_group_detach( GV_Geometry GeoParent, GV_Geometry GeoChild ) ;

int Terrain_group_attach( GV_Geometry GeoParent, GV_Geometry GeoChild ) ;

void      AddTerrain2GVSPanel(GTerrain* pTerrain,TGVSListNode*  pParentNode);

#ifdef __cplusplus
}
#endif


#endif