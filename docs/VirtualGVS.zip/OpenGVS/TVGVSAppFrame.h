//FileName:  TVGVSAppFrame.h

#ifndef  __TVGVSAPPFRAME_HPP__
#define  __TVGVSAPPFRAME_HPP__
#include <gv_sys.h>


class   TGVSToolPane;
class   GChannel;
class   GScene;
class   GCamera;
class   GLight;
struct  TTreeNode;
struct  TGVSListNode;
class   TGVSBaseClass;

#ifdef __cplusplus
extern "C" {
#endif
/*  Must be before channel.h */
typedef struct GV_frame_buffer_s * GV_Fbf ;
#ifdef __cplusplus
}
#endif

class  TGVSAppFrame
{
public:
    HWND           m_hWnd;
    GV_Sys_mode    system_mode ;

    TGVSToolPane*         m_pGVSToolPane;
    GV_Fbf                m_pFrameBuffer;
    GChannel*             m_pMainChannel;
	GScene*               m_pMainScene;
    GLight*               m_pSunLight;
	GCamera*              m_pMainCamera;
public:
	virtual int GVS_user_pre_import( void)=0;
    virtual int GVS_user_init( void )=0;
    virtual int GVS_user_proc( void )=0;
	virtual int GVS_user_proc_post( void )=0;
    virtual int GVS_user_shutdown( void )=0;
	virtual int EventProcess(UINT   message,WPARAM  wParam,LPARAM  lParam )=0;
public:
    TGVSAppFrame();
	virtual ~TGVSAppFrame();

    static  TGVSAppFrame*   GVSGetApp(void);
public:

	void Initialize( HWND tHwnd);
	void GVSRun(void);
	void GVSShutdown(void);
	void ProcessMessage(UINT   message,WPARAM  wParam,LPARAM  lParam );
	 

	void  ShowToolPane(void);
	void  HideToolPane(void);

    bool  IsRun();
public:
    TTreeNode*  GetGVSAppNode(void);
	TTreeNode*  AddGVSListNode(const char*  NodeName);
	TTreeNode*  AddGVSObiNode(TGVSBaseClass*  pGVSObject,TGVSListNode*   pParentNode=NULL);
};

extern TGVSAppFrame*   g_InsideGVSApp;

#endif  //__TVGVSAPPFRAME_HPP__