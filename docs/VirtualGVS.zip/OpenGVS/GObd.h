
#ifndef  __GOBD_H__
#define  __GOBD_H__

#ifdef __cplusplus
extern "C" {
#endif

/*  These handles must be declared before including the other header files. */
typedef struct GV_obd_s * GV_Obd;
typedef struct GV_obi_s * GV_Obi;

typedef int (*GVS_Obd_define_callback)( void * pvd);

#ifdef __cplusplus
}
#endif

class  GObd
{
protected:
	GV_Obd   m_InsideObd;

	
public:
	GObd();
	virtual ~GObd();

	static GObd*  CreateObd_by_name(const char* name);
	static GObd*  CreateObd_by_import(const char* name,const char* importStr);
    static GObd*  DirectDefineObd(const char*  name,GVS_Obd_define_callback  define_callback);
    GV_Obd*  Get_obd(void){return  &m_InsideObd;};

    int Get_path( int namdim, char * fname, int * length);
    int Get_position_granularity( G_Position * g_out ) ;
    int Set_position_granularity( const G_Position * g_in ) ;
    int Get_rotation_granularity( G_Rotation * g_out ) ;
    int Set_rotation_granularity( const G_Rotation * g_in ) ;
    int Get_scaling_granularity( G_Vector3 * g_out ) ;
    int Set_scaling_granularity( const G_Vector3 * g_in ) ;

    int Set_text_string( const char * ptext );
    int  Get_text_string( char** p_text );

    int  Set_template_type( GV_Obj_template_type ttype);
    int  Get_template_type( GV_Obj_template_type * p_ttype);


    int  Set_template_axis( const G_Vector3 *axis);
    int  Get_template_axis( G_Vector3 *axis);


    int  Set_template_point( const G_Position *point);
    int  Get_template_point( G_Position *point);


    int  Set_lod_transition_range( float transition_in ) ;
    int  Get_lod_transition_range( float * transition_out ) ;


    int  Set_name( const G_Name name);
    int  Get_name( G_Name name);


    //int  Get_by_name_relative( const char * rel_name, GV_Obd * p_obdhdl );

    int  Attach_child( GV_Obd child_obdhdl);

    int  Detach_child( GV_Obd obdhdl);

    //int  GV_obd_free( GV_Obd obdhdl);
    //int  GV_obd_free_all( void );

    int  Get_attribute_float( GV_Obj_attr oattr, float * aval);
    int  Set_attribute_float( GV_Obj_attr oattr, float aval );

    int  Get_attribute( GV_Obj_attr oattr,     int  * aval );
    int  Set_attribute( GV_Obj_attr oattr,     int  aval );



    //int  Get_root_first( GV_Obd * p_obdhdl );
    //int  Get_root_last( GV_Obd * p_obdhdl );
    //int  Get_root_next( GV_Obd obdhdl, GV_Obd * p_obdhdl );
    //int  Get_root_previous( GV_Obd obdhdl, GV_Obd * p_obdhdl );

    //int  Get_root( GV_Obd obdhdl, GV_Obd * p_obdhdl );
    //int  Get_child( GV_Obd obdhdl, GV_Obd * p_obdhdl );
    //int  Get_next( GV_Obd obdhdl, GV_Obd * p_obdhdl );
    //int  Get_parent( GV_Obd obdhdl, GV_Obd * p_obdhdl );
    //int  Get_previous( GV_Obd obdhdl, GV_Obd * p_obdhdl );

    int  Get_valid(  G_Boolean * p_gstate );

    int  Set_origin_offset( const G_Position *voffset);
    int  Get_origin_offset(  G_Position *offset);

    int  Set_gfx_offset_state(  G_State ostate_in );
    int  Get_gfx_offset_state(  G_State * ostate_out );

    int  Set_lod_scaling_mode( GV_Obj_lod_scaling_mode lsmode_in ) ;

    int  Get_lod_scaling_mode( GV_Obj_lod_scaling_mode * lsmode_out ) ;



    int  Set_position(  const G_Position *vpos);
    int  Get_position(  G_Position *position);

    int  Set_position_x(  float position);
    int  Get_position_x(  float * p_posx);

    int  Set_position_y(  float position);
    int  Get_position_y( float * p_posy);

    int  Set_position_z(  float position);
    int  Get_position_z( float * p_posz);

    int  Set_rotation( const G_Rotation *angles);
    int  Get_rotation(  G_Rotation *rotation);

    int  Set_rotation_x( float angle);
    int  Get_rotation_x(  float * p_rotx);

    int  Set_rotation_y(  float angle);
    int  Get_rotation_y(  float * p_roty);

    int  Set_rotation_z(  float angle);
    int  Get_rotation_z( float * p_rotz);

    int  Set_pos_rot( const G_Position *pos, const G_Rotation *rots);


    int  Get_pos_rot_world( G_Position *opos, G_Rotation *orot);

    int  Get_SRT_world( G_Scaling * scaling_out,G_Rotation * rotation_out, G_Position * position_out ) ;



    int  Set_scaling( const G_Vector3 *scales);
    int  Get_scaling( G_Vector3 *scales);

    int  Get_radius( float * radius_out ) ;

    int  Get_bbox_local( GV_Bbox *bbox,GV_Bbox_status * p_bbstat);

    int  Set_bbox_local( const GV_Bbox *bbox);

    int  Get_bbox_local_status( GV_Bbox_status * p_bbstat);

    int  Set_bbox_local_status( GV_Bbox_status bbstat );



    int  Get_bbox_full( GV_Bbox *bbox,GV_Bbox_status * p_bbstat);

    int  Set_bbox_full( const GV_Bbox *bbox);


    int  Get_bbox_full_status( GV_Bbox_status * p_bbstat);
    int  Set_bbox_full_status( GV_Bbox_status bbstat );



    int  Set_coordinate_system( GV_Coord_sys csys);
    int  Get_coordinate_system( GV_Coord_sys * p_csys);


    int  Set_gfx_state( G_State gstate_in);
    int  Get_gfx_state( G_State * gstate_out);

    int  Set_drawing_order( int  drawing_order_in);
    int  Get_drawing_order( int  * drawing_order_out);

    int  Set_traversal_type( GV_Obj_traversal_type ttype);
    int  Get_traversal_type( GV_Obj_traversal_type * p_ttype);

    int  Set_lod_range( float fnear, float ffar);
    int  Get_lod_range( float *fnear, float *ffar );

    int  Set_lod_state( G_State lod_state );
    int  Get_lod_state( G_State * p_lod_state );

    int  Set_culling_mode( GV_Obj_culling_mode cmode_in);
    int  Get_culling_mode( GV_Obj_culling_mode * cmode_out);

    int  Set_culling_state( G_State cstate_in);
    int  Get_culling_state( G_State * cstate_out);

    int  Get_transparency_state( G_Tristate * p_tstate);
    int  Set_transparency_state( G_Tristate mode);

    int  Get_alpha_method( GV_Obj_alpha_method * AlphaMethodOut );
    int  Set_alpha_method( GV_Obj_alpha_method AlphaMethodIn);

    int  Set_gfx_data( int  nbytes, void * pdata );
    int  Get_gfx_data( int  * nbytes, void ** pdata );

    int  Set_gfx_callback( GV_Obi_callback gfunc);
    int  Get_gfx_callback( GV_Obi_callback * p_gfunc);

    int  Set_gfx_post_callback( GV_Obi_callback gfunc);
    int  Get_gfx_post_callback( GV_Obi_callback * p_gfunc);

    int  Set_sim_data( int  nbytes, void * pdata );
    int  Get_sim_data( int  * nbytes, void ** pdata );

     int Set_sim_callback( GV_Obi_callback sfunc);
    int  Get_sim_callback( GV_Obi_callback * p_sfunc);


    int  Add_count( GV_Obj_count gltype_in, int count_in );
    int  Set_count( GV_Obj_count gltype_in, int count_in );

    int  Get_count_local( GV_Obj_count gltype_in, int *count_out );
    int  Get_count_global( GV_Obj_count gltype_in, int *count_out );

    int  Set_composition_mask( G_Mask cmask);
    int  Get_composition_mask( G_Mask * cmask);

    int  Set_lod_scale( float lod_scale_factor );
    int  Get_lod_scale( float * p_lod_scale_factor );

    int  Set_position_limit_min( const G_Position *vecmin );
    int  Get_position_limit_min( G_Position *vecmin );

    int  Get_rotation_limit_min( G_Rotation *vecmin );
    int  Set_rotation_limit_min( const G_Rotation *vecmin );

    int  Get_scaling_limit_min( G_Vector3 *vecmin );
    int  Set_scaling_limit_min( const G_Vector3 *vecmin );

    int  Set_position_limit_max( const G_Position *vecmax );
    int  Get_position_limit_max( G_Position *vecmax);

    int  Get_rotation_limit_max( G_Rotation *vecmax );
    int  Set_rotation_limit_max( const G_Rotation *vecmax );

    int  Get_scaling_limit_max( G_Vector3 *vecmax );
    int  Set_scaling_limit_max( const G_Vector3 *vecmax );


    int  Set_geo( const GV_Geometry geo_db);
    int  Get_geo( GV_Geometry *geo_db);


    int  Set_centroid( const G_Position * centroid_in ) ;
    int  Get_centroid( G_Position * centroid_out ) ;


    int  Get_comment_count( int * num_comments_out ) ;

    int  Get_comment( int comment_index_in, int buf_dim, char * buf_out, int * num_bytes_out ) ;

    int  Set_comment( int comment_index_in, int buf_dim, const char * buf_in ) ;

    int  Add_comment( int buf_dim, const char * buf_in, int * comment_index_out ) ;

    int  Free_comment( int comment_index_in) ;

    int  Free_comments_all() ;



    int  Set_switch_table( int nmasks_in,int  Words_per_mask_in, const GV_Obj_switch_mask * mask_in ) ;

/*  Get_switch_table -- Returns the number of switch
    masks for this object.  Also, if mask_out is not NULL:
    1.  returns the masks (up to min(tdim_in,nmasks_out)).
    2.  Gives failure return if tdim_in < nmasks_out.
    Parameters, input:
	obdhdl -- object handle
	tdim_in -- dimension of mask_out.  If all is well, this will
	    be the product (nmasks_out * words_per_mask_out).
	nmasks_out -- receives number of masks for the object.
	words_per_mask_out -- Number of 32-bit words for each mask.
	mask_out -- Pointer to table of dimension tdim_in
    */
    int  Get_switch_table( int tdim_in, int * nmasks_out,int * words_per_mask_out, GV_Obj_switch_mask * mask_out ) ;


/*  GV_obi_inq_switch_table -- Returns the number of switch
    masks for this object.  Also, if mask_out is not NULL:
    1.  returns the masks (up to min(tdim_in,nmasks_out)).
    2.  Gives failure return if tdim_in < nmasks_out.
    Parameters, input:
	obihdl --
	tdim_in -- dimension of mask_out
	nmasks_out -- receives number of masks for the object.
	mask_out -- Pointer to table of dimension tdim_in
    */


    int  Set_switch_current( int switch_cur_in ) ;
    int  Get_switch_current( int * switch_cur_out ) ;

    int  Recompute_bbox_full(  ) ;

    int  Set_bbox_full_recompute_state( G_State rcs_in ) ;
    int  Get_bbox_full_recompute_state( G_State * rcs_out ) ;

};

int GVS_obj_free_lookaside_lists(void) ;

int GVS_obj_inq_alpha_method_default( GV_Obj_alpha_method * AlphaMethodOut ) ;
int GVS_obj_set_alpha_method_default( GV_Obj_alpha_method AlphaMethodIn ) ;

#endif  //__GOBD_H__