/********************************************************************
FileName:     GCameraImp.cpp
descript:     ���ڶ����������
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/
#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include  "GCameraImp.h"



char   TGVSPersistent<GCameraImp>::m_ClassName[GVSNAME_MAXLENGTH];
int    TGVSPersistent<GCameraImp>::m_ObjectCount = 0;  //����ϵͳ�д���GLight���������
vector<PropertyStr*>    TGVSPersistent<GCameraImp>::m_PropertyStr_List;  //������Ҫ�������������ʾ�������б�


GCameraImp::GCameraImp(const char* name):TGVSPersistent<GCameraImp>(name)
{  

 m_CurrentPlatForm = 0;
 pos_x = 0.0f;
 pos_y = 0.0f;
 pos_z = 0.0f;
 m_Prj_Mode = GV_CAM_PROJECTION_MODE_PERSP;
}

GCameraImp::~GCameraImp()
{

}


static void __cdecl Get_current_platform(void*  self, int   *platform )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  *platform = p->m_CurrentPlatForm;
}

static void __cdecl Set_current_platform(void*  self, int    platform )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  p->m_CurrentPlatForm = platform;  
}

static  G_Position   Camera_Inside_Position;
static void __cdecl  Get_position_x(void*  self, float* x )
{
 
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);

  GV_cam_inq_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(Camera_Inside_Position) );
  *x = Camera_Inside_Position.x;
}

static void __cdecl Set_position_x(void*  self, float  x )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  GV_cam_inq_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(Camera_Inside_Position) );  
  Camera_Inside_Position.x = x;
  GV_cam_set_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(Camera_Inside_Position) );  

}

static void __cdecl Get_position_y(void*  self, float* y )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  GV_cam_inq_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(Camera_Inside_Position) );
  *y = Camera_Inside_Position.y;

}

static void __cdecl Set_position_y(void*  self, float  y )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  GV_cam_inq_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(Camera_Inside_Position) );  
  Camera_Inside_Position.y = y;
  GV_cam_set_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(Camera_Inside_Position) );  
}

static void __cdecl Get_position_z(void*  self, float* z )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  GV_cam_inq_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(Camera_Inside_Position) );
  *z = Camera_Inside_Position.z;

}

static void __cdecl Set_position_z(void*  self, float  z )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  GV_cam_inq_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(Camera_Inside_Position) );  
  Camera_Inside_Position.z = z;
  GV_cam_set_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(Camera_Inside_Position) );  
  
}

static  void __cdecl GetPrjMode(void* self,int*  mode )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  GV_cam_inq_projection_mode(*(p->Get_camera()), &(p->m_Prj_Mode));

  *mode = (int)p->m_Prj_Mode;
}

static  void __cdecl SetPriMode(void*  self,int mode)
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  p->m_Prj_Mode = (GV_Cam_projection_mode)mode;
  GV_cam_set_projection_mode(*(p->Get_camera()), p->m_Prj_Mode);
}


static void __cdecl Get_rotation_x(void*  self, float* x )
{
 
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  static  float  pos_x;
  GV_cam_inq_rotation_x( *(p->Get_camera()),p->m_CurrentPlatForm,&(pos_x) );
  *x = pos_x;
}

static void __cdecl Set_rotation_x(void*  self, float  x )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  GV_cam_inq_rotation( *(p->Get_camera()),p->m_CurrentPlatForm,&(p->cam_rot) );
  //static  G_Position  tPos;
  //GV_cam_inq_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(tPos) );
  p->cam_rot.x = x;
  //GV_cam_set_position_x( *(p->Get_camera()),p->m_CurrentPlatForm,x );
  GV_cam_set_rotation_x( *(p->Get_camera()),p->m_CurrentPlatForm,x );
  

}

static void __cdecl  Get_rotation_y(void*  self, float* y )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  GV_cam_inq_rotation( *(p->Get_camera()),p->m_CurrentPlatForm,&(p->cam_rot) );
  *y = p->cam_rot.y;

}

static void __cdecl Set_rotation_y(void*  self, float  y )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  GV_cam_inq_rotation( *(p->Get_camera()),p->m_CurrentPlatForm,&(p->cam_rot) );  
  p->cam_rot.y = y;
  //GV_cam_set_rotation( *(p->Get_camera()),p->m_CurrentPlatForm,&(p->cam_rot) );  
}

static void __cdecl Get_rotation_z(void*  self, float* z )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  GV_cam_inq_rotation( *(p->Get_camera()),p->m_CurrentPlatForm,&(p->cam_rot) );
  *z = p->cam_rot.z;

}

static void __cdecl Set_rotation_z(void*  self, float  z )
{
  GCameraImp*  p = dynamic_cast<GCameraImp*>((TGVSBaseClass*)self);
  GV_cam_inq_rotation( *(p->Get_camera()),p->m_CurrentPlatForm,&(p->cam_rot) );  
  p->cam_rot.z = z;
  //GV_cam_set_rotation( *(p->Get_camera()),p->m_CurrentPlatForm,&(p->cam_rot) );  
  
}

static  void __cdecl Get_cam_color(void*  self,void* color)
{

}

static void __cdecl Set_cam_color(void* self,void* color)
{
  CColorDialog   colorDlg;
  colorDlg.DoModal();
}

void  GCameraImp::InitializePropertyStr(void)
{
  PropertyStr*  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"Platform" );
  strcpy(t_PropertyStr->m_TypeName,"int" ); //typeid(float).name;
  t_PropertyStr->m_PropertyType = tkInteger;
  t_PropertyStr->GetDataCallbackFunction.IntergerGet = Get_current_platform;
  t_PropertyStr->SetDataCallbackFunction.IntergerSet = Set_current_platform;
  m_PropertyStr_List.push_back( t_PropertyStr );


  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"pos_x");
  strcpy(t_PropertyStr->m_TypeName,"float");//typeid(float).name;
  t_PropertyStr->m_PropertyType = tkFloat;
  t_PropertyStr->GetDataCallbackFunction.FloatGet = ::Get_position_x;
  t_PropertyStr->SetDataCallbackFunction.FloatSet = ::Set_position_x;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name, "pos_y");
  strcpy(t_PropertyStr->m_TypeName,"float");//typeid(float).name;
  t_PropertyStr->m_PropertyType = tkFloat;
  t_PropertyStr->GetDataCallbackFunction.FloatGet = ::Get_position_y;
  t_PropertyStr->SetDataCallbackFunction.FloatSet = ::Set_position_y;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"pos_z");
  strcpy(t_PropertyStr->m_TypeName,"float");//typeid(float).name;
  t_PropertyStr->m_PropertyType = tkFloat;
  t_PropertyStr->GetDataCallbackFunction.FloatGet = ::Get_position_z;
  t_PropertyStr->SetDataCallbackFunction.FloatSet = ::Set_position_z;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"m_Prj_Mode");
  strcpy(t_PropertyStr->m_TypeName,"GV_Cam_projection_mode");
  t_PropertyStr->m_PropertyType = tkEnumeration;
  t_PropertyStr->GetDataCallbackFunction.EnumGet = GetPrjMode;
  t_PropertyStr->SetDataCallbackFunction.EnumSet = SetPriMode;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"m_Rotation");
  strcpy(t_PropertyStr->m_TypeName,"G_Rotation");
  t_PropertyStr->m_PropertyType = tkStruct;
  t_PropertyStr->GetDataCallbackFunction.StringGet = NULL;
  t_PropertyStr->SetDataCallbackFunction.StringSet = NULL;
  //t_PropertyStr->PropertyData.sData = GVS_Struct::GetStructString("G_Position");
  t_PropertyStr->IsExpand = false;
  {
     PropertyStr* t_PropertyStr1 = new PropertyStr();
     strcpy(t_PropertyStr1->m_Name,"rotation_x");
     strcpy(t_PropertyStr1->m_TypeName,"float");
     t_PropertyStr1->m_PropertyType = tkFloat;
     t_PropertyStr1->GetDataCallbackFunction.FloatGet = ::Get_rotation_x;
     t_PropertyStr1->SetDataCallbackFunction.FloatSet = ::Set_rotation_x;
     t_PropertyStr->AddChildProperty(t_PropertyStr1);

     t_PropertyStr1 = new PropertyStr();
     strcpy(t_PropertyStr1->m_Name,"rotation_y");
     strcpy(t_PropertyStr1->m_TypeName,"float");
     t_PropertyStr1->m_PropertyType = tkFloat;
     t_PropertyStr1->GetDataCallbackFunction.FloatGet = ::Get_rotation_y;
     t_PropertyStr1->SetDataCallbackFunction.FloatSet = ::Set_rotation_y;
     t_PropertyStr->AddChildProperty(t_PropertyStr1);
	 
     t_PropertyStr1 = new PropertyStr();
     strcpy(t_PropertyStr1->m_Name,"rotation_z");
     strcpy(t_PropertyStr1->m_TypeName,"float");
     t_PropertyStr1->m_PropertyType = tkFloat;
     t_PropertyStr1->GetDataCallbackFunction.FloatGet = ::Get_rotation_z;
     t_PropertyStr1->SetDataCallbackFunction.FloatSet = ::Set_rotation_z;
     t_PropertyStr->AddChildProperty(t_PropertyStr1);
  }
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"m_cam_color");
  strcpy(t_PropertyStr->m_TypeName,"CColor");
  t_PropertyStr->m_PropertyType = tkObject;
  t_PropertyStr->GetDataCallbackFunction.ObjectGet = Get_cam_color;
  t_PropertyStr->SetDataCallbackFunction.ObjectSet = Set_cam_color;
  m_PropertyStr_List.push_back( t_PropertyStr );

}

