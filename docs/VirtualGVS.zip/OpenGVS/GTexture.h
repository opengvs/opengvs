/********************************************************************
FileName:     GTexture.h
descript:     ���ڶ���GTexture��
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/

#ifndef  __GTEXTURE_H__
#define  __GTEXTURE_H__

#ifndef  GV_TXR_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct GV_texture_s * GV_Texture ;


#define GV_TXR_DETAIL_TARGET        0x8095
#define GV_TXR_DETAIL_MAG_FILTER    0x8097
#define GV_TXR_DETAIL_LEVEL         0x809A
#define GV_TXR_DETAIL_ENV_MODE      0x809B    

typedef enum {
    GV_TXR_ATTR_TARGET,
    GV_TXR_ATTR_CONTOUR_THRESHOLD_STATE,
    GV_TXR_ATTR_CONTOUR_OPACITY_STATE,
    GV_TXR_ATTR_FILTER_NEAREST
} GV_Txr_attr ;

typedef enum {
    GV_TXR_ATTR_DetailTexFuncSGIS,
    GV_TXR_ATTR_DetailTexFunc=0,
    GV_TXR_ATTR_FILTER4_SGIS,
    GV_TXR_ATTR_SharpenTexFuncSGIS,
    GV_TXR_ATTR_CONTOUR_THRESHOLD,
    GV_TXR_ATTR_CONTOUR_OPACITY
} GV_Txr_attr_f ;


#ifdef __cplusplus
}
#endif


#endif  //GV_TXR_H

class  GTexture
{
protected:
   GV_Texture    m_pInsideTxr;
public:
	GTexture(){m_pInsideTxr=NULL;};
    GTexture( const char*  name);
	GTexture(const char* name,const char*  filename);	

	~GTexture();
    GV_Texture*  Get_txr(void){return  &m_pInsideTxr;};

    int Texture_define( );
    int Texture_undefine( void );

    int Set_env( GLfloat env_mode_in );
    int Get_env( GLfloat *env_mode_out );

/*  GV_txr_set_format -- Set the internal format to be used
    for a particular texture.
    The format_in may be anything that is legal as the "components"
    parameter of function glTexImage2D, such as:  1, 2, 3, 4,
    GL_RGB4_EXT, GL_RGBA4_EXT, etc.

    A no-operation unless OpenGL extension "GL_EXT_texture" is present.
    */
    int Set_format( int format_in ) ;
    int Get_format( int * format_out ) ;


    int Remove_property(GLenum pname ) ;
    int Reset_properties(void);

	int Set_property( GLenum pname, GLfloat param );
    int Set_property_v( GLenum pname,int nparams, const GLfloat parray[] ) ;

    int Get_property_v( GLenum pname,int attr_dim, int *attr_count, GLfloat parray_out[] ) ;
    int Get_property( GLenum pname, GLfloat * pvalue ) ;

    int Remove_env_property( GLenum pname ) ;
    int Reset_env_properties(void);
    int Set_env_property(  GLenum pname, GLfloat param );
    int Set_env_property_v(  GLenum pname,int nparams, const GLfloat parray[] ) ;

    int Get_env_property_v( GLenum pname,int attr_dim, int *attr_count, GLfloat parray_out[] ) ;
    int Get_env_property( GLenum pname, GLfloat * pvalue);


    //int GV_txr_free( GV_Texture txrhdl);

    //int GV_txr_free_all(void);

    int Get_bind_name(  GLuint * txr_bind_name_out ) ;

    int Set_filename( const char *filename_in);
    int Get_filename(  char *filename_out);
    int Get_filename_full(  char *filename_out);

    int Set_name( const G_Name name_in);
    int Get_name(  G_Name name_out);

    int Set_components( int num_comps_in);
    int Get_components(  int * num_comps_out);

    int Set_retain_state(  G_State rstate_in );
    int Get_retain_state(  G_State *rstate_out );

    int Set_state(  G_State state_in );
    int Get_state(  G_State * state_out );

    int Get_transparency(  G_Boolean *mode_out );
    int Get_gl_list(  GLuint * gl_list);


    int Set_attribute( GV_Txr_attr attr, int value_in );
    int Get_attribute(  GV_Txr_attr attr, int * value_out);

    int Set_attribute_fv(  GV_Txr_attr_f attrfa,int nfloats_in, const float * values_in ) ;
    int  Get_attribute_fv(  GV_Txr_attr_f attrfa, int vdim, int * nfloats_out, float * values_out ) ;

    int Set_detail( GTexture*    dtxhdl ) ;
    int Get_detail( GTexture* p_dtxhdl ) ;

    int Set_current_with_detail( GTexture*  dtxhdl ) ;

/*  GV_txr_set_image_data -- Allow specification of an in-memory
    image to be used as the texture.  The image is described by the
    same structure as is returned by standard image importers.
    When this function is called, OpenGVS copies all of the
    specified image data so that as far as OpenGVS is concerned,
    the caller does not need to retain data itself.

    OpenGVS's copy of the image data may be freed by OpenGVS after the
    texture has been defined.  (However, see GV_txr_set_retain_state).
    */
   int Set_image_data( const GV_Imp_img_data_out * imgdat_in ) ;

/*  GV_txr_inq_image_data -- Returns current image info.
    If image memory has been released, then pointers will be
    returned as NULL.
    */
   int Get_image_data( GV_Imp_img_data_out * imgdat_out ) ;

   int Set_opacity_map_file( const char* filename_in );
   int Get_opacity_map_file(  char *filename_out );

/*  Begin -- Functions intentionally not documented in man pages: */

/*  GV_txr_inq_dimension -- Return the x and y sizes of a texture and
    the number of bits per component.
    This function is subject to change.
    Deficiencies:
    --  nbits_per_component is always returned as 8.
    --  no information is returned about mipmaps levels.
    */
   int Get_dimension( int * size_x, int * size_y, int * nbits_per_component );

/*  GV_txr_inq_size_bytes -- Return the total memory required
    to store a texture image in the hardware.
    This function is subject to change.
    Deficiencies:
    --  Uses GV_txr_inq_dimension, so has all of its weaknesses.
    */
    int Get_size_bytes(  int * nbytes );

/* prototype function- adding support for cube map processing */
   int Set_cube_map_image_data(  GLenum cube_face, const GV_Imp_img_data_out * imgdat_in ) ;

   int Set_auxiliary_call_list(  GLuint call_list_in );
   int Get_auxiliary_call_list(  GLuint *call_list_out );

/*  End -- Functions intentionally not documented */

};

#ifdef __cplusplus
extern "C" {
#endif

int GVS_txr_set_state_system( G_State state_sys_in );
int GVS_txr_inq_state_system( G_State * state_sys_out );

int GVS_txr_define_pending( void );

/*  GV_txr_set_format_default -- Set the default internal format
    to be used for a texture with a given number of components.
    The format_in may be anything that is legal as the "components"
    parameter of function glTexImage2D, such as:  1, 2, 3, 4,
    GL_RGB4_EXT, GL_RGBA4_EXT, etc.
    A no-operation unless OpenGL extension "GL_EXT_texture" is present.
    Parameters:
	ncomps -- Ranges from 1 to 4.  Number of components of textures
	    whose default is set by this function.
	format_in -- The internal format to be used by default for a
	    texture with the specified number of components.
    The built-in defaults are:
	GV_txr_set_format_default( 1, 1 ) ;
	GV_txr_set_format_default( 2, 2 ) ;
	GV_txr_set_format_default( 3, 3 ) ;
	GV_txr_set_format_default( 4, 4 ) ;
    This sequence of calls would set defaults for textures with 1, 2, 3,
    or 4 components, respectively:
	GV_txr_set_format_default( 1, GL_LUMINANCE16_EXT ) ;
	GV_txr_set_format_default( 2, GL_LUMINANCE12_ALPHA12_EXT ) ;
	GV_txr_set_format_default( 3, GL_RGB5_EXT ) ;
	GV_txr_set_format_default( 4, GL_RGB5_A1_EXT ) ;
    At one time, OpenGVS used the following defaults:
	GV_txr_set_format_default( 1, GL_LUMINANCE4_EXT ) ;
	GV_txr_set_format_default( 2, GL_LUMINANCE4_ALPHA4_EXT ) ;
	GV_txr_set_format_default( 3, GL_RGB5_EXT ) ;
	GV_txr_set_format_default( 4, GL_RGBA8_EXT ) ;
    */
int GVS_txr_set_format_default( int ncomps, int format_in ) ;
int GVS_txr_inq_format_default( int ncomps, int * format_out ) ;

int GVS_txr_set_current( GTexture* txrhdl );
int GVS_txr_inq_current( GTexture * p_txrhdl );

#ifdef __cplusplus
}
#endif

#endif