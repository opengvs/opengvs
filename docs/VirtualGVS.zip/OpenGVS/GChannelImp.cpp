/********************************************************************
FileName:     GChannelImp.cpp
descript:     ���ڶ���ͨ�����ʵ����
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/

#include "stdafx.h"
#include "GChannel.h"
#include "GChannelImp.h"

char   TGVSPersistent<GChannelImp>::m_ClassName[GVSNAME_MAXLENGTH];
int    TGVSPersistent<GChannelImp>::m_ObjectCount = 0;  
vector<PropertyStr*>    TGVSPersistent<GChannelImp>::m_PropertyStr_List;  


GChannelImp::GChannelImp(const char* name):TGVSPersistent<GChannelImp>(name)
{
}

GChannelImp::~GChannelImp()
{

}


static void  Get_position_x(void*  self, int* x )
{
  GChannel*  p = (GChannel*)self;
  //GV_cam_inq_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(p->m_Position) );
  //*x = p->m_Position.x;
}

static void  Set_position_x(void*  self, int  x )
{
/*  GCamera*  p = (GCamera*)self;
  GV_cam_inq_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(p->m_Position) );  
  p->m_Position.x = x;
  GV_cam_set_position( *(p->Get_camera()),p->m_CurrentPlatForm,&(p->m_Position) );  
*/
}

void  GChannelImp::InitializePropertyStr(void)
{
  PropertyStr*  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"x" );
  strcpy(t_PropertyStr->m_TypeName,"int" ); //typeid(float).name;
  t_PropertyStr->m_PropertyType = tkInteger;
  t_PropertyStr->GetDataCallbackFunction.IntergerGet = Get_position_x;
  t_PropertyStr->SetDataCallbackFunction.IntergerSet = Set_position_x;
  m_PropertyStr_List.push_back( t_PropertyStr );

}

