// OceanWave.cpp: implementation of the COceanWave class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <math.h>
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>

#include "OceanWave.h"
#include  "TVGVSAppFrame.h"
#include  "GChannel.h"
#include  "GScene.h"
#include  "GCamera.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

COceanWave::COceanWave()
{
 coord_table = NULL;
 tex_table = NULL;
 dy_cindex = NULL;
 st_cindex4 = NULL;
 st_cindex2 = NULL;
 st_cindex3 = NULL;
 norm_index0 = NULL;
 st_norm_index2 = NULL;
 st_norm_index3 = NULL;
 st_norm_index4 = NULL;
 col_index0 = NULL;
 st_col_index2 = NULL;  //color
 st_col_index3 = NULL;
 st_col_index4 = NULL;
 lengths = NULL;
 st_lengths = NULL;

 tex_table = NULL;//�м�������������궨��
 tex_index = NULL;
 tex_index2 = NULL;
 tex_index3 = NULL;
 tex_index3 = NULL;

 m_bUseAttrFile = true;
 m_bMeteralState = true;  //�����Ƿ�ʹ�ò�������
 m_bTextureState = true;  //�����Ƿ�ʹ����������
 m_bNormalState = true;   //�����Ƿ��Զ����������η���
 m_bFullSea = true;  // �����Ƿ����������������
 m_bFadeLayer = true;//�����Ƿ�ʹ�õ�������
 m_bDiffColours = false;//�����Ƿ�ʹ�ù������ȼ���  false
 m_bRempTexture = false;  //  �����Ƿ�ʹ�� REMAP_TEXTURE  false
 TxtFileNumber = NULL;


 m_Obd = NULL;
 m_Obi = NULL;

}

COceanWave::~COceanWave()
{
  Destroy_DynSee();
}

void  COceanWave::Destroy_DynSee(void)
{

	if (coord_table)
    {
	G_free( coord_table ) ;
	coord_table = NULL ;
    }

    if (dy_cindex)
    {
	G_free( dy_cindex ) ;
	dy_cindex = NULL ;
    }

    if (st_cindex4)
    {
	G_free( st_cindex4 ) ;
	st_cindex4 = NULL ;
    }

    if (st_cindex2)
    {
	G_free( st_cindex2 ) ;
	st_cindex2 = NULL ;
    }

    if (st_cindex3)
    {
	G_free( st_cindex3 ) ;
	st_cindex3 = NULL ;
    }

    if (norm_index0)
    {
	G_free( norm_index0 ) ;
	norm_index0 = NULL ;
    }

    if (st_norm_index2)
    {
	G_free( st_norm_index2 ) ;
	st_norm_index2 = NULL ;
    }

    if (st_norm_index3)
    {
	G_free( st_norm_index3 ) ;
	st_norm_index3 = NULL ;
    }

    if (st_norm_index4)
    {
	G_free( st_norm_index4 ) ;
	st_norm_index4 = NULL ;
    }

    if (col_index0)
    {
	G_free( col_index0 ) ;
	col_index0 = NULL ;
    }

    if (st_col_index2)
    {
	G_free( st_col_index2 ) ;
	st_col_index2 = NULL ;
    }

    if (st_col_index3)
    {
	G_free( st_col_index3 ) ;
	st_col_index3 = NULL ;
    }

    if (st_col_index4)
    {
	G_free( st_col_index4 ) ;
	st_col_index4 = NULL ;
    }

    if (lengths)
    {
	G_free( lengths ) ;
	lengths = NULL ;
    }

    if (st_lengths)
    {
	G_free( st_lengths ) ;
	st_lengths = NULL ;
    }

    if (tex_table)
    {
	G_free( tex_table ) ;
	tex_table = NULL ;
    }

    if (tex_index)
    {
	G_free( tex_index ) ;
	tex_index = NULL ;
    }

    if (tex_index2)
    {
	G_free( tex_index2 ) ;
	tex_index2 = NULL ;
    }

    if (tex_index3)
    {
	G_free( tex_index3 ) ;
	tex_index3 = NULL ;
    }

    if (tex_index4)
    {
	G_free( tex_index4 ) ;
	tex_index4 = NULL ;
    }



}

static void update_bbox(float xc, float yc, float zc, GV_Bbox *bbox)
{
	if( xc < bbox->xmin )
	    bbox->xmin = xc;
    else if( xc > bbox->xmax )
	     bbox->xmax = xc;

    if( yc < bbox->ymin )
	     bbox->ymin = yc;
    else if( yc > bbox->ymax )
	     bbox->ymax = yc;

    if( zc < bbox->zmin )
	     bbox->zmin = zc;
    else if( zc > bbox->zmax )
	     bbox->zmax = zc;

}


void  COceanWave::Initialize( )
{
	/*
#ifdef _DEBUG
	m_font.Create();
	m_font.SetLineCount(1);
#endif
*/
   G_State tstate;

   int   i, j;
   int   nbytes;
   int   num_tris, num_quads, num_ind_dy, num_vtx_in_strip;
   int   row, col;
   int   this_row_index, next_row_index;
   float y, x;
   int   num_ind_st2, num_ind_st3, num_ind_fade;
   
   float join_x, join_y;

   int   this_row_end_ind;
   int   next_row_end_ind;
   int   next_next_row_end_ind;
   int   top_row_ind;
   int   this_row_start_ind;
   int   next_row_start_ind;
   int   next_next_row_start_ind;

   G_Name name;


   //GV_Obd sea_def;

   /* SeaState */
   SetOceanState( 4 );//Sea_state  //���ú��˵ȼ�
   //dyn_sea = (Dynamic_sea *) G_calloc( 1, sizeof( Dynamic_sea) );

   //GV_cmd_service("setenv TXTPATH ./txr");
   //if( !dyn_sea )
   //    return NULL;

   /* Initialize the sea state model */
   DynSea_init();


   if (rot_tex)//������ת�ĽǶ���
   {
      cos_tex_rot = cosf(tex_rot* G_DEG_TO_RAD);
      sin_tex_rot = sinf(tex_rot* G_DEG_TO_RAD);
   }

   //���㶯̬�����x,y�������������
   n = (int) ((dyn_range_x / step_x) + 0.5);
   m = (int) ((dyn_range_y / step_y) + 0.5);


   //������ҪΪ�˱�֤���������ı�������
   num_coord_x = 2*n + 1;
   num_coord_y = 2*m + 1;

   dy_num_coord = num_coord_x * num_coord_y;

 //#if FULL_SEA
   /* Need extra 16 vertices to extend sea surface (this will
      NOT give continuity of heights but is just a starting point)
      (only need 12 if we share the points that join the moving section) */

   num_coord = dy_num_coord + 16;

   //#if FADE1_LAYER
   num_coord += (2*n + 2*m + 4 + 4);
   //#endif

/* #else
   num_coord = dy_num_coord;
 #endif
*/

   //���������ζ���������ڴ�
   total_num_coords = num_coord;
   coord_table = (vec3 *) G_calloc(1, num_coord * sizeof(vec3) );
   

/********************************************************************** 
Row 2m      ---------------------
            |  . |  . |  . |  . |
            |.   |.   |.   |.   |
            ---------------------
            |  . |  . |  . |  . |
            |.   |.   |.   |.   |
            ---------------------
            |  . |  . |  . |  . |
            |.   |.   |.   |.   |
Row 1   2n+1----2n+2------------2n + 2n+1
            |  . |  . |  . |  . |
            |.   |.   |.   |.   |
Row 0       ---------------------
           0     1              2n
*************************************************************************/

   // Type vec3 (defined as array of 3 floats), in order xyz in db coordinates
   // The coordinates of the sea mesh centered about a local
   //   origin are set up and stored in the coord_table 

   
   //coord_table = dyn_sea->coord_table;

   //��̬������̬�仯�ĺ�ƽ��
   i = 0;
   for (row = -m; row <= m; row++)  //��
   {
      y = row * step_y;  //x������
      for (col = -n; col <= n; col++) //��
      {
         coord_table[i][X_IND] = col * step_x;
         coord_table[i][Y_IND] = y;
         coord_table[i][Z_IND] = 0.0;
         i++;
      }
   }
   
   //#if FULL_SEA
   /* Index of next coordinate is dy_num_coord */

   //#if FADE1_LAYER

   start_fade_index = dy_num_coord;
   
   /* Fade layer at bottom: number of these coordinates is n+1 */
   y = -(m + 10) * step_y;
   for (col = -n; col <= n; col += 2)
   {
      coord_table[i][X_IND] = col * step_x;
      coord_table[i][Y_IND] = y;
      coord_table[i][Z_IND] = 0.0;
      i++;
   }

   /* Fade layer at right: number of these coordinates is m+1 */
   x = (n + 10) * step_x;
   join_x = x;
   for (row = -m; row <= m; row += 2)
   {
      coord_table[i][X_IND] = x;
      coord_table[i][Y_IND] = row * step_y;
      coord_table[i][Z_IND] = 0.0;
      i++;
   }

   /* Fade layer at top: number of these coordinates is n+1 */
   y = (m + 10) * step_y;
   join_y = y;
   for (col = -n; col <= n; col += 2)
   {
      coord_table[i][X_IND] = col * step_x;
      coord_table[i][Y_IND] = y;
      coord_table[i][Z_IND] = 0.0;
      i++;
   }

   /* Fade layer at left: number of these coordinates is m+1 */
   x = -(n + 10) * step_x;
   for (row = -m; row <= m; row += 2)
   {
      coord_table[i][X_IND] = x;
      coord_table[i][Y_IND] = row * step_y;
      coord_table[i][Z_IND] = 0.0;
      i++;
   }
   /* So total number of level 1 fade coordinates is 2m + 2n + 4 */

   /* Need 4 extra coordinates to fill in the corners */
   start_corner_index = i;  //��Ե�ı��ζ�������
   
   /* SW */
   coord_table[i][X_IND] = -join_x;
   coord_table[i][Y_IND] = -join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* SE */
   coord_table[i][X_IND] = join_x;
   coord_table[i][Y_IND] = -join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* NE */
   coord_table[i][X_IND] = join_x;
   coord_table[i][Y_IND] = join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* NW */
   coord_table[i][X_IND] = -join_x;
   coord_table[i][Y_IND] = join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;


   //��Χ��չ��������䣬��Ҫ����16��������
   start_outer_region = i;
   /* South west corner */
   /* k0 */
   coord_table[i][X_IND] = -sea_range_x;
   coord_table[i][Y_IND] = -sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* k1 */
   coord_table[i][X_IND] = -join_x;
   coord_table[i][Y_IND] = -sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k2 */
   coord_table[i][X_IND] = -sea_range_x;
   coord_table[i][Y_IND] = -join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k3 */
   coord_table[i][X_IND] = -join_x;    /* Same as coord[0], 
                                          or coord[start_corner_index] */
   coord_table[i][Y_IND] = -join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* South east corner */
   /* k4 */
   coord_table[i][X_IND] = join_x;
   coord_table[i][Y_IND] = -sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* k5 */
   coord_table[i][X_IND] = sea_range_x;
   coord_table[i][Y_IND] = -sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k6 */
   coord_table[i][X_IND] = join_x;     /* Same as coord[2n], 
   					   or coord[start_corner_index+1] */
   coord_table[i][Y_IND] = -join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k7 */
   coord_table[i][X_IND] = sea_range_x;
   coord_table[i][Y_IND] = -join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* North west corner */
   /* k8 */
   coord_table[i][X_IND] = -sea_range_x;
   coord_table[i][Y_IND] = join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* k9 */
   coord_table[i][X_IND] = -join_x;   /* Same as coord[2m * (2n+1)], or 
                                           coord[start_corner_index+2] */
   coord_table[i][Y_IND] = join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k10 */
   coord_table[i][X_IND] = -sea_range_x;
   coord_table[i][Y_IND] = sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k11 */
   coord_table[i][X_IND] = -join_x;
   coord_table[i][Y_IND] = sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* North east corner */
   /* k12 */
   coord_table[i][X_IND] = join_x;   /* Same as coord[2m * (2n+1) + 2n], 
                                          or coord[start_corner_index+3] */
   coord_table[i][Y_IND] = join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* k13 */
   coord_table[i][X_IND] = sea_range_x;
   coord_table[i][Y_IND] = join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k14 */
   coord_table[i][X_IND] = join_x;
   coord_table[i][Y_IND] = sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k15 */
   coord_table[i][X_IND] = sea_range_x;
   coord_table[i][Y_IND] = sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
 //#endif  #if FULL_SEA 


  //����Ի�����������������˶��壬������Ҫ��������������

   /* Now that all the different coordinates have been set up, need to
      set up indices into this coord_table to control which coordinates
      form part of which drawing primitive */
      
   num_quads = 2*n * 2*m;  //��̬�仯�Ĳ��ֵ��ı���������
   num_tris = num_quads * 2; //��̬�仯�Ĳ��ֵ�����������

   /* Each row becomes a single tristrip.
      For each row, num_indices = 2 + num_tris in row */

   num_strips = 2*m;   /* = number of rows */
   
   num_vtx_in_strip = 2 + 2*n*2;//ÿһ���н��������λ�����Ҫ������������

   num_ind_dy = num_vtx_in_strip * num_strips;  //�ܹ���Ҫ����������������

   dy_cindex = (int *) G_malloc( num_ind_dy  * sizeof( int ) );//Ϊ���������������ڴ�

   /* Order for tristips */
   i = 0;
   this_row_index = 0;
   for (row = 0; row < 2*m; row++)   /* Do NOT go to last row */
   {
      next_row_index = (row+1) * (2*n + 1);//very Good!
      
      for (col = 0; col <= 2*n; col++)   /* DO go to last column */
      {
         dy_cindex[i++] = next_row_index + col;
         dy_cindex[i++] = this_row_index + col;
      }
      this_row_index = next_row_index;
   }
   //�õ�ÿһ��������������Ϊn n+1 n+2

//�Ѿ����е�����
 //#if FULL_SEA

   //#if FADE1_LAYER
   //������ɴ�����������
   num_fade_tri = 2 * ( (3 * n) + (3 * m) ) + 8;
   num_ind_fade = 3 * num_fade_tri;

   st_cindex4 = (int *) G_malloc( num_ind_fade  * sizeof( int ) );
   //st_cindex4 = dyn_sea->st_cindex4 ;


   // Unconnected triangles
   j = 0;   /* Index in to new coordinates created for the fade regions */
   i = 0;
   
   /* Base */
   for (col = 0; col < 2*n; col += 2)
   {
      /* Three triangles per column pair */
      
      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = col + 1;
      st_cindex4[i++] = col;

      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = start_fade_index + j + 1;
      st_cindex4[i++] = col + 1;

      st_cindex4[i++] = start_fade_index + j + 1;
      st_cindex4[i++] = col + 2;
      st_cindex4[i++] = col + 1;
      j++;
   }

   /* Right */
   j++;   /* Skip last fade coordinate along base */
   for (row = 0; row < 2*m; row += 2)
   {
      /* Three triangles per row pair */

      this_row_end_ind = row * (2*n + 1) + 2*n;
      next_row_end_ind = this_row_end_ind + (2*n + 1);
      next_next_row_end_ind = next_row_end_ind + (2*n + 1);
      
      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = next_row_end_ind;
      st_cindex4[i++] = this_row_end_ind;

      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = start_fade_index + j + 1;
      st_cindex4[i++] = next_row_end_ind;

      st_cindex4[i++] = start_fade_index + j + 1;
      st_cindex4[i++] = next_next_row_end_ind;
      st_cindex4[i++] = next_row_end_ind;
      j++;
   }
   
   /* Top. NB. Order changed compared with base */
   j++;   /* Skip last fade coordinate along right */
   top_row_ind = 2*m * (2*n + 1);
   for (col = 0; col < 2*n; col += 2)
   {
      /* Three triangles per column pair */
      
      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = top_row_ind + col;
      st_cindex4[i++] = top_row_ind + col + 1;

      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = top_row_ind + col + 1;
      st_cindex4[i++] = start_fade_index + j + 1;

      st_cindex4[i++] = start_fade_index + j + 1;
      st_cindex4[i++] = top_row_ind + col + 1;
      st_cindex4[i++] = top_row_ind + col + 2;
      j++;
   }

   /* Left. NB. Order changed compared with right */
   j++;   /* Skip last fade coordinate on top */
   for (row = 0; row < 2*m; row += 2)
   {
      /* Three triangles per row pair */

      this_row_start_ind = row * (2*n + 1);
      next_row_start_ind = this_row_start_ind + (2*n + 1);
      next_next_row_start_ind = next_row_start_ind + (2*n + 1);
      
      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = this_row_start_ind;
      st_cindex4[i++] = next_row_start_ind;

      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = next_row_start_ind;
      st_cindex4[i++] = start_fade_index + j + 1;

      st_cindex4[i++] = start_fade_index + j + 1;
      st_cindex4[i++] = next_row_start_ind;
      st_cindex4[i++] = next_next_row_start_ind;
      j++;
   }

   /* Now do the corners. Could make these 2 triangle tristrips but
      that would mean making them a separate geoset, so stick to
      isolated triangles. */
      
   /* SW corner */
   st_cindex4[i++] = start_corner_index;
   st_cindex4[i++] = start_fade_index;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1 + n + 1;

   st_cindex4[i++] = 0;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1 + n + 1;
   st_cindex4[i++] = start_fade_index;
   
   /* SE corner */
   st_cindex4[i++] = start_corner_index + 1;
   st_cindex4[i++] = start_fade_index + n + 1;
   st_cindex4[i++] = start_fade_index + n;

   st_cindex4[i++] = 2 * n;
   st_cindex4[i++] = start_fade_index + n;
   st_cindex4[i++] = start_fade_index + n + 1;
   
   /* NE corner */
   st_cindex4[i++] = start_corner_index + 2;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1 + n;
   st_cindex4[i++] = start_fade_index + n + 1 + m;

   st_cindex4[i++] = 2*m * (2*n + 1) + 2*n;
   st_cindex4[i++] = start_fade_index + n + 1 + m;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1 + n;
   
   /* NW corner */
   st_cindex4[i++] = start_corner_index + 3;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1 + n + 1 + m;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1;

   st_cindex4[i++] = 2*m * (2*n + 1);
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1 + n + 1 + m;
   
  //#endif   /* Of FADE */

   /* The 4 corners use 4 vertices each */
   num_st_strips = 4;
   num_ind_st2 = 16;
   
   st_cindex2 = (int *) G_malloc( num_ind_st2  * sizeof( int ) );
   //st_cindex2 = dyn_sea->st_cindex2 ;

   /* Order for tristips for the corners*/

   /* If FADE1_LAYER,
      SW, k3 =  start_corner_index,
      SE, k6 =  start_corner_index + 1,
      NW, k9 =  start_corner_index + 2,
      NE, k12 = start_corner_index + 3 */
      
   st_cindex2[0] = start_outer_region;
   st_cindex2[1] = start_outer_region + 1;
   st_cindex2[2] = start_outer_region + 2;


    st_cindex2[3] = start_corner_index;


   st_cindex2[4] = start_outer_region + 4;
   st_cindex2[5] = start_outer_region + 5;

   st_cindex2[6] = start_corner_index + 1;

   st_cindex2[7] = start_outer_region + 7;

   st_cindex2[8] = start_outer_region + 8;

   st_cindex2[9] = start_corner_index + 3;   /* Careful. */
 
   st_cindex2[10] = start_outer_region + 10;
   st_cindex2[11] = start_outer_region + 11;

   st_cindex2[12] = start_corner_index + 2;   /* Careful. */
      /* For some reason, the corners go SW, SE, NE, NW, unlike others */

   st_cindex2[13] = start_outer_region + 13;
   st_cindex2[14] = start_outer_region + 14;
   st_cindex2[15] = start_outer_region + 15;

   //��������ı��λ���
   /* The 4 side sections use 4 vertices each */
   num_st_quads = 4;
   num_ind_st3 = 16;

   st_cindex3 = (int *) G_malloc( num_ind_st3  * sizeof( int ) );
   //st_cindex3 = dyn_sea->st_cindex3 ;

   st_cindex3[0] = start_outer_region + 1;
   st_cindex3[1] = start_outer_region + 4;
   
   st_cindex3[2] = start_corner_index + 1;
   st_cindex3[3] = start_corner_index;

   st_cindex3[4] = start_corner_index + 1;

   st_cindex3[5] = start_outer_region + 7;
   st_cindex3[6] = start_outer_region + 13;

   st_cindex3[7] = start_corner_index + 2;   /* Careful. */
      /* For some reason, the corners go SW, SE, NE, NW, unlike others */

   st_cindex3[8]  = start_corner_index + 3;   /* Careful. */
      /* For some reason, the corners go SW, SE, NE, NW, unlike others */
   st_cindex3[9]  = start_corner_index + 2;   /* Careful. */
      /* For some reason, the corners go SW, SE, NE, NW, unlike others */

   st_cindex3[10] = start_outer_region + 14;
   st_cindex3[11] = start_outer_region + 11;

   st_cindex3[12] = start_outer_region + 2;

   st_cindex3[13] = start_corner_index;
   st_cindex3[14] = start_corner_index + 3;   /* Careful. For some reason, the corners go SW, SE, NE, NW, unlike others */

   st_cindex3[15] = start_outer_region + 8;

 

 //#if USE_NORMALS
   normal[0][0] = 0.0;
   normal[0][1] = 0.0;
   normal[0][2] = 1.0;
                                     //����������

   norm_index0 = (int *) G_calloc(1,  num_strips * sizeof(int) );

   for (i = 0; i < num_strips; i++)
   {
      norm_index0[i] = 0;
   }


 //#if FULL_SEA

   st_norm_index2 = (int *) G_calloc(1,num_st_strips * sizeof(int) );

   for (i = 0; i < num_st_strips; i++)
   {
      st_norm_index2[i] = 0;
   }

   st_norm_index3 = (int *) G_calloc(1,num_st_quads * sizeof(int) );

   for (i = 0; i < num_st_quads; i++)
   {
      st_norm_index3[i] = 0;
   }

   //#if FADE1_LAYER
   st_norm_index4 = (int *) G_calloc(1,num_fade_tri * sizeof(int) );
   //st_norm_index4 = dyn_sea->st_norm_index4 ;

   for (i = 0; i < num_fade_tri; i++)
   {
      st_norm_index4[i] = 0;
   }
   //#endif

  //#endif    //Of FULL_SEA 

 //#endif   /* Of USE_NORMALS */

   /* Type vec4 (defined as an array of 4 floats) */

   col_table[0][0] = surface_col[0];
   col_table[0][1] = surface_col[1];
   col_table[0][2] = surface_col[2];
   col_table[0][3] = sea_surface_alpha;

   col_index0 = (int *) G_calloc(1,num_strips * sizeof(int) );
   for (i = 0; i < num_strips; i++)
   {
      col_index0[i] = 0;
   }

 //#if FULL_SEA
   st_col_index2 = (int *) G_calloc(1,num_st_strips *sizeof(int) );
   //st_col_index2 = dyn_sea->st_col_index2 ;

   for (i = 0; i < num_st_strips; i++)
   {
      st_col_index2[i] = 0;
   }

   st_col_index3 = (int *) G_calloc(1,num_st_quads * sizeof(int) );
   //st_col_index3 = dyn_sea->st_col_index3 ;

   for (i = 0; i < num_st_quads; i++)
   {
      st_col_index3[i] = 0;
   }

   //#if FADE1_LAYER
   st_col_index4 = (int *) G_calloc(1,num_fade_tri * sizeof(int) );
   //st_col_index4 = dyn_sea->st_col_index4 ;

   for (i = 0; i < num_fade_tri; i++)
   {
      st_col_index4[i] = 0;
   }
   //#endif   /* Of FADE1_LAYER */

 //#endif   /* Of FULL_SEA */

///////////////////////////////////here////////////////////
   /* This is essential for TRISTRIPS type */
   lengths = (int*) G_calloc(1, sizeof(int) * num_strips);
   for (i = 0; i < num_strips; i++)
      lengths[i] = num_vtx_in_strip;

 //#if FULL_SEA
   /* Corners: 2 triangle tristrips */

   st_lengths = (int*) G_calloc(1, sizeof(int)*num_st_strips);
   for (i = 0; i < num_st_strips; i++)
      st_lengths[i] = 4;
 //#endif


//#if USE_MATERIAL
   /* Light for shade effects */
   GV_mtl_create( &(mtl) );   //��������
   DynSea_setup_material ( mtl );
   GV_mtl_define( mtl );
   GV_mtl_set_face( mtl, GL_FRONT );
//#endif

//#if USE_TEXTURE

   use_tex = TRUE;
   GV_txr_inq_state_system( &tstate );
   if( tstate == G_OFF )
           use_tex = FALSE;

   /* Read the texture pattern */
   G_file_base( txt_file, sizeof(name), name, &nbytes );
   GV_txr_inq_by_name( name, &tex );  //�����û�д�������
   if( !tex && use_tex )
   {
       GV_txr_create( &(tex) );
       GV_txr_set_filename( tex, txt_file );

       /* Load (define) the texture file for the sea state */
       if (GV_txr_define( tex ) != G_SUCCESS)
       {
		   ::MessageBox(NULL,"������������0����","ϵͳ����",MB_OK);
       }
       else
       {
          /* We do not manually read the MultiGen attribute file since this is
             taken care of by GV_txr_define.
             However, this does mean we must obtain the pattern size from
             the sea config file instead */
       }
   }

   if(use_tex)
   {
     // #if USE_ATTR_FILE

      /* Now do the texture environment */
      //if ( env_mode == GL_BLEND )
      {
         static float env_colour[4];
         env_colour[0] = blendcol[0];
         env_colour[1] = blendcol[1];
         env_colour[2] = blendcol[2];
         env_colour[3] = blendcol[3];
         GV_txr_set_env_property_v( tex,GL_TEXTURE_ENV_COLOR, 4, env_colour );
      }
     // #endif

      tex_table = (vec2 *) G_calloc( 1, num_coord  * sizeof(vec2) );
      tex_index = (int *) G_calloc( 1, num_ind_dy  * sizeof(int) );

    //#if FULL_SEA
      tex_index2 = (int *) G_calloc( 1, num_ind_st2  * sizeof(int) );
      tex_index3 = (int *) G_calloc( 1, num_ind_st3  * sizeof(int) );
      //#if FADE1_LAYER
      tex_index4 = (int *) G_calloc( 1, num_ind_fade  * sizeof(int) );
      //#endif
    //#endif

	  //������������
      for (i = 0; i < num_coord; i++)
      {
         tex_table[i][0] =  coord_table[i][X_IND] / patt_size_u;
         tex_table[i][1] =  coord_table[i][Y_IND] / patt_size_v;
      }
      
	  //�������������������ζ���֮�������
      for (i = 0; i < num_ind_dy; i++)
      {
         tex_index[i] = dy_cindex[i];
      }

 //#if FULL_SEA

      for (i = 0; i < num_ind_st2; i++)
      {
         tex_index2[i] = st_cindex2[i];
      }

      for (i = 0; i < num_ind_st3; i++)
      {
         tex_index3[i] = st_cindex3[i];
      }

      //#if FADE1_LAYER
      for (i = 0; i < num_ind_fade; i++)
      {
         tex_index4[i] = st_cindex4[i];
      }
      //#endif
 //#endif
   }   // End of use_tex 
   
//#endif   // Of USE_TEXTURE 


 
   //GV_scn_add_object(scene, inst);

   setup = TRUE;

   (void) num_tris;	// Not used anywhere at the moment... 

   //////////////////////////////////////////////////////////
   //static G_Position init_pos = { 0.0, 0.0, -6.0  };
   //m_wake.Initialize(init_pos);

   //return m_Obi;
  
}

int COceanWave::DynSea_gfx_callback(GV_Obi inst, void *data_in)
{
	GV_Bbox bbox = {0., 0., 0., 0., 0., 0.};	/* xmin-xmax, ... zmin-zmax */
   int ntriangles = 0;
   int        row, col;
   int        i, j;
   float      x, y, z;	/* Not OpenGVS coordinates; z is up */
   float      ang;
   float      eye_x, eye_y;
   float      wt[MAX_WAVES], disp[MAX_WAVES];

   vec3       *coord_table;
   int        index;
   float      r, g, b, a;
   float      u, v;
   G_Position pos;
   G_Rotation rot;

   GV_Camera  current_camera;
   GV_Texture current_tex;
   float current_time;

   //GV_Channel chnhdl;
   
   //Dynamic_sea * dyn_sea;

//#if USE_MATERIAL
   int        light_state;
   GV_Material current_mtl;
//#endif

//#if REMAP_TEXTURE
   float      sin_rot;
   float      cos_rot;
   vec2       *tex_table;
   vec2       tex_origin;
//#endif

/*
#if DRAW_AS_LINES
   int        pmode;
#endif
*/

   int        vi = 0;
   if( !data_in )
       return G_FAILURE;

  COceanWave*  pOcean = (COceanWave*)data_in;
  coord_table = pOcean->coord_table;

   /* Typecast generic pointer */
    /*dyn_sea = ((TOceanWave *)data_in)->dyn_sea;
	float *W=((TOceanWave *)data_in)->W;
	float *Kx=((TOceanWave *)data_in)->Kx;
	float *Ky=((TOceanWave *)data_in)->Ky;
	float *Amp=((TOceanWave *)data_in)->Amp;
	float *Phi=((TOceanWave *)data_in)->Phi;
	int Num_waves=((TOceanWave *)data_in)->Num_waves;
  */

   /* Make center of mesh translate in x- and y-axis with eyepoint */
   //GV_chn_inq_input_focus( &chnhdl );

   GV_chn_inq_camera( *(g_InsideGVSApp->m_pMainChannel->GetInsideChannel()), &current_camera );
   GV_cam_inq_pos_rot_world( current_camera, BASE_PLATFORM, &pos, &rot );

   GV_obi_set_position_x( pOcean->m_Obi, pos.x );
   GV_obi_set_position_z( pOcean->m_Obi, pos.z );

   eye_x =  pos.x;   /* Can be thought of as "West" */
   eye_y = -pos.z;   /* Can be thought of as "North" */

   static double dtime;

  /*
  #if DRAW_AS_LINES
      glGetIntegerv(GL_POLYGON_MODE, &pmode);
      glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
   #endif
  */
	 
   if (pOcean->dyn_active == TRUE)
   {
      

      /* Method: We calculate the vertical values of all the
         vertices corresponding to the dynamic area of the sea
         model.
         Then we draw all the sea surfaces, using the modified
         vertex list. This ensures that shared vertices are not
         recalculated more than once and that shared vertices
         really do have the same value */

      {
            G_timer_inq_time( &dtime );
            current_time = dtime;
      }

      wt[0] = pOcean->W[0] * current_time;
      wt[1] = pOcean->W[1] * current_time;
      wt[2] = pOcean->W[2] * current_time;
      wt[3] = pOcean->W[3] * current_time;


      i = 0;
      for ( row=0; row < pOcean->num_coord_y; row++ )
      {
         for ( col = 0; col < pOcean->num_coord_x; col++ )
         {
            x = coord_table[i][DB_WEST_IND] + eye_x;
            y = coord_table[i][DB_NORTH_IND] + eye_y;
            z = 0.0;

            for (j=0; j<pOcean->Num_waves; j++)//Num_wavesΪ���ӵ�����������
            {
               ang = wt[j] - (pOcean->Kx[j] * x) - (pOcean->Ky[j] * y) + pOcean->Phi[j];
               disp[j] = sinf(ang) * pOcean->Amp[j];
               z += disp[j];
            }
            coord_table[i][DB_VERT_IND] = z;
            i++;
         }
      }
   }   /* End of dyn_active */
   
   if( pOcean->m_bRempTexture == true )  //#if REMAP_TEXTURE
   {
	   if (pOcean->use_tex == TRUE )
	   {
		   tex_table = pOcean->tex_table;
		   
		   tex_origin[0] = 0.0;
		   tex_origin[1] = 0.0;
		   
		   /* We make the texture origin the nearest whole pattern units
		   position to eyepoint, in order to keep the u,v coordinates
		   as small as possible */
		   
		   if ( pOcean->rot_tex == FALSE )
		   {
			   int tmpi;
			   tmpi = (int) (eye_x / pOcean->patt_size_u);
			   tex_origin[0] = (float) tmpi * pOcean->patt_size_u;
			   tmpi = (int) (eye_y / pOcean->patt_size_v);
			   tex_origin[1] = (float) tmpi * pOcean->patt_size_v;
		   }
		   else
		   {
			   /* Just until ok */
			   pOcean->rot_tex = FALSE;
		   }
		   
		   if (pOcean->rot_tex)
		   {
			   cos_rot = pOcean->cos_tex_rot;
			   sin_rot = pOcean->sin_tex_rot;
		   }
		   
		   for (i = 0; i < pOcean->total_num_coords; i++)
		   {
			   x = coord_table[i][DB_WEST_IND] + eye_x;
			   y = coord_table[i][DB_NORTH_IND] + eye_y;
			   
			   if (pOcean->rot_tex)
			   {
				   float dx, dy;
				   /* To undo a anticlockwise rot by ang, use
				   (x,y) (cos, -sin)
				   (sin,  cos)
				   */
				   dx = x - tex_origin[0];
				   dy = y - tex_origin[1];
				   x = ( dx * cos_rot) + (y * sin_rot);
				   y = (-dx * sin_rot) + (y * cos_rot);
				   tex_table[i][DB_WEST_IND] = x / pOcean->patt_size_u;
				   tex_table[i][DB_NORTH_IND] = y / pOcean->patt_size_v;
				   
				   (void) dy;	/* Yes, we know we aren't using dy anywhere right now*/
			   }
			   else
			   {
				   tex_table[i][DB_WEST_IND] =  (x - tex_origin[0]) / pOcean->patt_size_u;
				   
				   tex_table[i][DB_NORTH_IND] = (y - tex_origin[1]) / pOcean->patt_size_v;
			   }
		   }
		   
	   }
   }  //#endif

   /* Now draw the sea surfaces */

   //#if USE_TEXTURE
   if ( pOcean->use_tex == TRUE )
   {
      GV_txr_inq_current( &current_tex );
      GV_txr_set_current( pOcean->tex );
   }
   //#endif

   if( pOcean->m_bMeteralState == true ) //#if USE_MATERIAL
   {
     light_state = glIsEnabled(GL_LIGHTING);
     glEnable( GL_LIGHTING );
     GV_mtl_inq_current(&current_mtl);
     GV_mtl_set_current(pOcean->mtl);
   } //#endif

   /* Entire sea has the same colour */
   r = pOcean->col_table[0][0];
   g = pOcean->col_table[0][1];
   b = pOcean->col_table[0][2];
   a = pOcean->col_table[0][3];

   glColor4f(r, g, b, a);

   /* The moving part - triangle strips */
   vi = 0;   /* Vertex index */
   ntriangles += pOcean->num_strips;
   for (i = 0; i < pOcean->num_strips; i++)
   {
      glBegin(GL_TRIANGLE_STRIP); //����һ�������������δ�
      {
         if( pOcean->m_bDiffColours == true ) // #if DIFF_COLOURS
		 {
           index = pOcean->col_index0[i];   /* Colour per strip */
           r = pOcean->col_table[index][0];
           g = pOcean->col_table[index][1];
           b = pOcean->col_table[index][2];
           a = pOcean->col_table[index][3];

          glColor4f(r, g, b, a);

         }  //#endif

         if( pOcean->m_bNormalState == true )//#if USE_NORMALS
         {
			 index = pOcean->norm_index0[i];   /* Normal per strip */
             x = pOcean->normal[index][DB_WEST_IND];
             y = pOcean->normal[index][DB_VERT_IND];
             z = -pOcean->normal[index][DB_NORTH_IND];
             glNormal3f(x, y, z);
         }  //#endif

         for (j = 0; j < pOcean->lengths[i]; j++)
         {
            index = pOcean->dy_cindex[vi++];
	        if( pOcean->m_bTextureState == true )//#if USE_TEXTURE
            {
			  if (pOcean->use_tex)
			  {
                   /* Texture indices match the coordinate ones */
                   u = pOcean->tex_table[index][DB_WEST_IND];
                   v = pOcean->tex_table[index][DB_NORTH_IND];

                   glTexCoord2f(u, v);
			  }
			}// #endif

            x = pOcean->coord_table[index][DB_WEST_IND];
            y = pOcean->coord_table[index][DB_VERT_IND];
            z = -pOcean->coord_table[index][DB_NORTH_IND];

            glVertex3f( x, y, z);
	        update_bbox( x,y,z, &bbox );

         }
      }
      glEnd();
   }   /* Loop through triangular meshes for dynamic sea */

/*
   //#if FULL_SEA
   
   // Corners of outer sea: 2 triangle tristrips 
   vi = 0;   // Vertex index 
   ntriangles += dyn_sea->num_st_strips*2;
   for (i = 0; i < dyn_sea->num_st_strips; i++)
   {
      glBegin(GL_TRIANGLE_STRIP);
      {
      #if DIFF_COLOURS
         index = dyn_sea->st_col_index2[i];   // Colour per strip 
         r = dyn_sea->col_table[index][0];
         g = dyn_sea->col_table[index][1];
         b = dyn_sea->col_table[index][2];
         a = dyn_sea->col_table[index][3];

         glColor4f(r, g, b, a);
      #endif

      #if USE_NORMALS
         index = dyn_sea->st_norm_index2[i];   // Normal per strip 
         x = dyn_sea->normal[index][DB_WEST_IND];
         y = dyn_sea->normal[index][DB_VERT_IND];
         z = -dyn_sea->normal[index][DB_NORTH_IND];
         glNormal3f(x, y, z);
      #endif

         for (j = 0; j < dyn_sea->st_lengths[i]; j++)
         {
            index = dyn_sea->st_cindex2[vi++];
	    #if USE_TEXTURE
            if (dyn_sea->use_tex)
            {
               // Texture indices match the coordinate ones 
               u = dyn_sea->tex_table[index][DB_WEST_IND];
               v = dyn_sea->tex_table[index][DB_NORTH_IND];

               glTexCoord2f(u, v);
            }
	    #endif

            x = dyn_sea->coord_table[index][DB_WEST_IND];
            y = dyn_sea->coord_table[index][DB_VERT_IND];
            z = -dyn_sea->coord_table[index][DB_NORTH_IND];

            glVertex3f( x, y, z);
	    update_bbox( x,y,z, &bbox );
         }
      }
      glEnd();
   }   // Loop through tris for outer sea corners 

   // Sides of outer sea: 4 separate quads 
   vi = 0;   // Vertex index 
   ntriangles += dyn_sea->num_st_quads * 2;
   for (i = 0; i < dyn_sea->num_st_quads; i++)
   {
      glBegin(GL_QUADS);
      {
      #if DIFF_COLOURS
         index = dyn_sea->st_col_index3[i];   // Colour per quad 
         r = dyn_sea->col_table[index][0];
         g = dyn_sea->col_table[index][1];
         b = dyn_sea->col_table[index][2];
         a = dyn_sea->col_table[index][3];

         glColor4f(r, g, b, a);
      #endif

      #if USE_NORMALS
         index = dyn_sea->st_norm_index3[i];   // Normal per quad 
         x = dyn_sea->normal[index][DB_WEST_IND];
         y = dyn_sea->normal[index][DB_VERT_IND];
         z = -dyn_sea->normal[index][DB_NORTH_IND];
         glNormal3f(x, y, z);
      #endif

         for (j = 0; j < 4; j++)
         {
            index = dyn_sea->st_cindex3[vi++];
	    #if USE_TEXTURE
            if (dyn_sea->use_tex)
            {
               // Texture indices match the coordinate ones 
               u = dyn_sea->tex_table[index][DB_WEST_IND];
               v = dyn_sea->tex_table[index][DB_NORTH_IND];

               glTexCoord2f(u, v);
            }
	    #endif

            x = dyn_sea->coord_table[index][DB_WEST_IND];
            y = dyn_sea->coord_table[index][DB_VERT_IND];
            z = -dyn_sea->coord_table[index][DB_NORTH_IND];

            glVertex3f( x, y, z);
	    update_bbox( x,y,z, &bbox );
         }
      }
      glEnd();
   }

   #if FADE1_LAYER
   vi = 0;   // Vertex index 
   ntriangles += dyn_sea->num_fade_tri;
   for (i = 0; i < dyn_sea->num_fade_tri; i++)
   {
      glBegin(GL_TRIANGLES);
      {
      #if DIFF_COLOURS
         index = dyn_sea->st_col_index4[i];   // Colour per tri 
         r = dyn_sea->col_table[index][0];
         g = dyn_sea->col_table[index][1];
         b = dyn_sea->col_table[index][2];
         a = dyn_sea->col_table[index][3];

         glColor4f(r, g, b, a);
      #endif

      #if USE_NORMALS
         index = dyn_sea->st_norm_index4[i];   // Normal per tri 
         x = dyn_sea->normal[index][DB_WEST_IND];
         y = dyn_sea->normal[index][DB_VERT_IND];
         z = -dyn_sea->normal[index][DB_NORTH_IND];
         glNormal3f(x, y, z);
      #endif

         for (j = 0; j < 3; j++)
         {
            index = dyn_sea->st_cindex4[vi++];
            #if USE_TEXTURE
            if (dyn_sea->use_tex)
            {
               // Texture indices match the coordinate ones 
               u = pOcean->tex_table[index][DB_WEST_IND];
               v = pOcean->tex_table[index][DB_NORTH_IND];

               glTexCoord2f(u, v);
            }
	    #endif

            x = pOcean->coord_table[index][DB_WEST_IND];//0
            y = pOcean->coord_table[index][DB_VERT_IND];//2
            z = -pOcean->coord_table[index][DB_NORTH_IND];//1

            glVertex3f( x, y, z);
	    update_bbox( x,y,z, &bbox );
         }
      }
      glEnd();
   }
   #endif   // Of FADE1_LAYER 
 #endif   // Of FULL_SEA 
*/
   if( pOcean->m_bTextureState == true )//#if USE_TEXTURE
   {
    if (pOcean->use_tex)
    {
      // Restore previous texture 
      GV_txr_set_current(current_tex);
    }
   } //#endif

   if( pOcean->m_bMeteralState == true )//#if USE_MATERIAL
   {
     GV_mtl_set_current(current_mtl);
     if (!light_state)
        glDisable(GL_LIGHTING);
   }  //#endif

   /*
   #if DRAW_AS_LINES
   glPolygonMode(GL_FRONT_AND_BACK, pmode);
   #endif
   */
   // Tell OpenGVS how many triangles we just rendered 
   GV_obi_add_count( NULL, GV_OBJ_COUNT_TRIANGLES, ntriangles );

   // Set the bounding box for the object 
   GV_obi_set_bbox_local( inst, &bbox );
   GV_obi_set_bbox_local_status( inst, GV_BBOX_VALID );



	return  G_SUCCESS;
}

void  COceanWave::AddScene( GV_Scene    scene )
{
 if( m_Obd == NULL )
 {
   GV_obd_open_by_name( "DYNAMIC_SEA", &m_Obd );
   GV_obd_close( m_Obd );
 }

 if( m_Obi == NULL )
 {
   GV_obi_instance(m_Obd, &m_Obi);

   GV_obi_set_drawing_order( m_Obi,DYNAMIC_SEA_DRAW_ORDER );

   if( sea_surface_alpha < 1.0 )
       GV_obi_set_transparency_state( m_Obi, G_TRISTATE_ON );

   GV_obi_set_gfx_callback(m_Obi, DynSea_gfx_callback);

   GV_obi_set_gfx_data(m_Obi, sizeof(this), this);
 }
 
 G_Boolean  bex;
 GV_scn_inq_object_exists( scene, m_Obi, &bex);
 if( bex != G_TRUE )
    GV_scn_add_object(scene, m_Obi);

}


void  COceanWave::SetOceanActiveState( bool  sstate )
{
	if( m_Obi == NULL )
		return;
    if( sstate == true )
	{
	  GV_obi_set_state( m_Obi, G_ON );
	  GV_obi_set_gfx_state( m_Obi, G_ON );
	}
	else
	{
       GV_obi_set_gfx_state( m_Obi, G_OFF );
       GV_obi_set_state( m_Obi, G_OFF );
	}
}

int  COceanWave::SetOceanState(int sstate )
{
	int status = G_SUCCESS;
   switch (sstate)
   {
   case 0:
         Sea_state = sstate;
         DynSea_state0();
         break;

   case 1:
         Sea_state = sstate;
         DynSea_state1();
         break;

   case 2:
         Sea_state = sstate;
         DynSea_state2();
         break;

   case 4:
         Sea_state = sstate;
         DynSea_state4();
         break;

   default:
        status = G_FAILURE;
	break;
   }
   return status;
}

int   COceanWave::GetOceanState(void)
{
  return Sea_state; 
}

void COceanWave::DynSea_state4()
{
	Sea_state = 4;

   Num_waves = 4;
   W[0] = 0.5684;
   Kx[0] = 0.0329;
   Ky[0] = 0.0329;
   Amp[0] = 1.0135;
   Phi[0] = 0.1143;

   W[1] = 0.7389;
   Kx[1] = 0.0557;
   Ky[1] = 0.0557;
   Amp[1] = 0.6081;
   Phi[1] = 0.9139;

   W[2] = 0.9606;
   Kx[2] = 0.0941;
   Ky[2] = 0.0941;
   Amp[2] = 0.3649;
   Phi[2] = 0.1958;

   W[3] = 1.2488;
   Kx[3] = 0.1590;
   Ky[3] = 0.1590;
   Amp[3] = 0.2189;
   Phi[3] = 0.7084;

}

void COceanWave::DynSea_state2()
{
	Sea_state = 2;

   Num_waves = 4;
   W[0] = 1.2710;
//   W[0] = 0.5684;
   Kx[0] = 0.1647;
   Ky[0] = 0.1647;
   Amp[0] = 0.2027;
   Phi[0] = 0.1055;

   W[1] = 1.6523;
//   W[1] = 0.7389;
   Kx[1] = 0.2783;
   Ky[1] = 0.2783;
   Amp[1] = 0.1216;
   Phi[1] = 0.4938;

   W[2] = 2.1480;
//   W[2] = 0.9606;
   Kx[2] = 0.4703;
   Ky[2] = 0.4703;
   Amp[2] = 0.0730;
   Phi[2] = 0.8172;

   W[3] = 4.7924;
//   W[3] = 1.2488;
   Kx[3] = 0.7949;
   Ky[3] = 0.7949;
   Amp[3] = 0.0438;
   Phi[3] = 0.1619;
}

void COceanWave::DynSea_state0()
{
	Sea_state = 0;

   Num_waves = 1;
   W[0] = 3.8421;
   Kx[0] = 0.8234;
   Ky[0] = 0.8234;
   Amp[0] = 0.00405;
   Phi[0] = 0.3615;

   W[1] = 4.6947;
   Kx[1] = 1.3915;
   Ky[1] = 1.3915;
   Amp[1] = 0.00243;
   Phi[1] = 0.3834;

   W[2] = 5.8031;
   Kx[2] = 2.3517;
   Ky[2] = 2.3517;
   Amp[2] = 0.00146;
   Phi[2] = 0.5049;

   W[3] = 7.2441;
   Kx[3] = 3.9743;
   Ky[3] = 3.9743;
   Amp[3] = 0.00088;
   Phi[3] = 0.5227;
}

void COceanWave::DynSea_state1()
{
	Sea_state = 1;

   Num_waves = 2;
   W[0] = 1.8421;
   Kx[0] = 0.8234;
   Ky[0] = 0.8234;
   Amp[0] = 0.0405;
   Phi[0] = 0.3615;

   W[1] = 2.5947;
   Kx[1] = 1.3915;
   Ky[1] = 1.3915;
   Amp[1] = 0.0243;
   Phi[1] = 0.3834;

   W[2] = 3.5031;
   Kx[2] = 2.3517;
   Ky[2] = 2.3517;
   Amp[2] = 0.0146;
   Phi[2] = 0.5049;

   W[3] = 5.0441;
   Kx[3] = 3.9743;
   Ky[3] = 3.9743;
   Amp[3] = 0.0088;
   Phi[3] = 0.5227;
}

void COceanWave::DynSea_init(void)
{
	setup = FALSE;

   step_x = 2.0;//��ƽ������Ŀ���
   step_y = 2.0;

   dyn_range_x = 200.0;
   dyn_range_y = 200.0;

   sea_range_x = 2000.0;
   sea_range_y = 2000.0;

   height = 0.0f;//0.0f;//09�޸�
   tfb = TRUE;

   surface_col[0] = 103.0f / 255.0f;  //��ƽ���ʼ����ɫ
   surface_col[1] = 159.0f / 255.0f;
   surface_col[2] = 159.0f / 255.0f;

 
   strcpy (txt_file,"seapat6s.int_e");// "water.int");//"h.rgba" );

 

   patt_size_u = 100.0;
   patt_size_v = 100.0;

   dyn_active = TRUE;

   use_tex = TRUE;
   rot_tex = FALSE;    /* NOT SUPPORTED */
   tex_rot = 0.0;

}

void COceanWave::DynSea_setup_material(GV_Material mtl)
{
   static GV_Rgba amb  = {0.00,0.98,0.984};//{155./256., 233./256., 255./256, 1.0f};
   static GV_Rgba dif  = {0.00,0.98,0.984};//{155./256., 233./256., 255./256, 1.0f};
   static GV_Rgba spec = {0.00,0.98,0.984};//{155./256., 233./256., 255./256, 1.0f};

   static GV_Rgba emis = {0.0f, 0.0f, 0.0f, 1.0f};
   static float shiny = 1.0f;
   /*
   static GV_Rgba amb  = {0./256., 46./256., 60./256, 1.0f};
   static GV_Rgba dif  = {0./256., 46./256., 60./256, 1.0f};
   static GV_Rgba spec = {40./256., 40./256., 60./256, 1.0f};
   static GV_Rgba emis = {0.0f, 0.0f, 0.0f, 1.0f};
   static float shiny = 0.0f;
   */

   if( sea_surface_alpha < 1.0f )
            amb.a = dif.a = sea_surface_alpha;

   GV_mtl_set_ambient( mtl, &amb ); //���ú�ƽ�滷����Ĳ�������
   GV_mtl_set_diffuse( mtl, &dif ); //���ú�ƽ��ɢ���Ĳ�������
   GV_mtl_set_specular( mtl, &spec );//���ú�ƽ�淴�����ɫ����
   GV_mtl_set_shininess( mtl, shiny );//���ú�ƽ�淴������ߴ�С�����ȵ�����

   GV_mtl_set_emission( mtl, &emis );  //���ú�ƽ��ķ����Դ����

}

