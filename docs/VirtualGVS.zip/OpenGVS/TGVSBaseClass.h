// TGVSBaseClass.h: interface for the TGVSBaseClass class.
//
//////////////////////////////////////////////////////////////////////

#ifndef  __TGVSBASECLASS_H__
#define  __TGVSBASECLASS_H__

#include "TTypeInfor.h"

#ifndef  GVSNAME_MAXLENGTH

#define  GVSNAME_MAXLENGTH   32

#endif

class TGVSBaseClass
{
protected:
	char  m_ObjectName[GVSNAME_MAXLENGTH];
public:
	TGVSBaseClass(const char*  name){strcpy(m_ObjectName,name);};
	virtual ~TGVSBaseClass(){};
    
	virtual  int GetPropertyStrCount() = 0;
	virtual  PropertyStr*  GetPropertyStr( int  Index )=0;
	virtual  void    UpDataPropertyValue(void)=0;
	virtual  char*  GetClassName(void)=0;
	char*    GetObjectName(void){return m_ObjectName; };

};

template<class T>
class  TGVSPersistent : public TGVSBaseClass
{
	TGVSPersistent(){};
protected:
     static   char   m_ClassName[GVSNAME_MAXLENGTH];
     static   int    m_ObjectCount;  //����ϵͳ�д���GLight���������
     static	  vector<PropertyStr*>    m_PropertyStr_List;  //������Ҫ�������������ʾ�������б�
	
	 TGVSPersistent(const char* name);

public:
    virtual ~TGVSPersistent();
    

	virtual  int             GetPropertyStrCount();
	virtual  PropertyStr*    GetPropertyStr( int  Index );
	virtual  void            UpDataPropertyValue(void);
	virtual  char*           GetClassName(void){return  m_ClassName; };

};

template<typename ClassType>
inline  ClassType*   CreateObjectInstance(const char*  name)
{
	return  new ClassType(name);
};

template <class T> inline TGVSPersistent<T>::TGVSPersistent(const char* name) : TGVSBaseClass(name)
{
	if( m_ObjectCount == 0 )
	      T::InitializePropertyStr();
	m_ObjectCount++;
}

template <class T>
inline    TGVSPersistent<T>::~TGVSPersistent()
{
  m_ObjectCount--;
  if( m_ObjectCount==0)
  {
	 vector<PropertyStr*>::iterator  pIt = m_PropertyStr_List.begin();
	 while( pIt != m_PropertyStr_List.end() )
	 {
        PropertyStr* p = (*pIt);
        m_PropertyStr_List.erase( pIt );
		delete  p;
		pIt = m_PropertyStr_List.begin();
	 }
  }
  if( m_ObjectCount < 0 )
	  m_ObjectCount = 0;
}

template <class T> inline  int  TGVSPersistent<T>::GetPropertyStrCount()
{
 return m_PropertyStr_List.size();
}

template<class T> inline PropertyStr* TGVSPersistent<T>::GetPropertyStr( int  Index )
{
    if( (Index<0)||(Index>=m_PropertyStr_List.size()))
	       return NULL;
    return  (m_PropertyStr_List[Index]);
}

template<class T>  inline   void  TGVSPersistent<T>::UpDataPropertyValue(void)
{
	vector<PropertyStr*>::iterator  pIt = m_PropertyStr_List.begin();
	while( pIt != m_PropertyStr_List.end() )
	{
        PropertyStr*  pProperty = *pIt;
		if( pProperty->m_PropertyType == tkStruct )
		{
          
		  vector<PropertyStr*>::iterator  pIt1 = pProperty->m_ChildList.begin();
		  while( pIt1 != pProperty->m_ChildList.end() )
		  {
             PropertyStr* pProperty1 = *pIt1;
			 if( pProperty1->m_PropertyType == tkInteger )
			 {
               pProperty1->GetDataCallbackFunction.IntergerGet(this,&(pProperty1->PropertyData.iData));
			 }
			 else  if( pProperty1->m_PropertyType == tkFloat )
			 {
			   pProperty1->GetDataCallbackFunction.FloatGet(this,&(pProperty1->PropertyData.fData));
			 }
			 else  if( pProperty1->m_PropertyType == tkString )
			 {

			 }
			 else  if( pProperty1->m_PropertyType == tkChar )
			 {
                pProperty->GetDataCallbackFunction.ByteGet(this,(unsigned char *)&(pProperty->PropertyData.iData));
			 }
             pIt1++;
		  }
		  
		}
		else  if( pProperty->m_PropertyType == tkObject )
		{

		}
		else  if( pProperty->m_PropertyType == tkEnumeration )
		{
           pProperty->GetDataCallbackFunction.EnumGet(this,&(pProperty->PropertyData.eData));
		}
		else  if( pProperty->m_PropertyType == tkString )
		{

		}
		else  if( pProperty->m_PropertyType == tkChar )
		{
          pProperty->GetDataCallbackFunction.ByteGet(this,(unsigned char *)&(pProperty->PropertyData.iData));
		}
		else  if( pProperty->m_PropertyType == tkInteger )
		{
           pProperty->GetDataCallbackFunction.IntergerGet(this,&(pProperty->PropertyData.iData));
		}
		else  if( pProperty->m_PropertyType == tkFloat )
		{
           pProperty->GetDataCallbackFunction.FloatGet(this,&(pProperty->PropertyData.fData));    
		}

		pIt++;
	}
}


#endif //__TGVSBASECLASS_H__