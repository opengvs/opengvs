// TGVSToolPane.cpp : implementation file
//

#include "stdafx.h"
//#include "testBCG.h"
#include "..\resource.h"       // main symbols
#include "TGVSToolPane.h"

#include "TGVSTree.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// TGVSToolPane dialog


TGVSToolPane::TGVSToolPane(CWnd* pParent /*=NULL*/)
	: CSplitDialog(TGVSToolPane::IDD, pParent)
{
	//{{AFX_DATA_INIT(TGVSToolPane)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_PaneMain = NULL;
	m_TopItem = NULL;
	m_GVSObjectTree = new TGVSTree("VirtualGVS Application");
}

TGVSToolPane::~TGVSToolPane()
{
	delete  m_GVSObjectTree;
}

void TGVSToolPane::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(TGVSToolPane)
	DDX_Control(pDX, IDC_GVSPROPERTYLIST, m_PropertyListView);
	DDX_Control(pDX, IDC_GVSOBJECTTREE, m_GVSObjTree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(TGVSToolPane, CSplitDialog)
	//{{AFX_MSG_MAP(TGVSToolPane)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// TGVSToolPane message handlers

BOOL TGVSToolPane::OnInitDialog() 
{
	CSplitDialog::OnInitDialog();
	

	// TODO: Add extra initialization here
    
	static  bool  hasCreate = false;
	if( hasCreate == false )
	{
		if( !m_ImageListTree.Create( IDB_GVSTREEVIEW, 16, 1, RGB( 255, 255, 255 ) ) )
		     TRACE( _T("Image list creation fault") );
	    m_GVSObjTree.SetImageList( &m_ImageListTree, TVSIL_NORMAL );
        hasCreate = true;
    }
	
	
	//create the panes
    m_PaneMain = CreatePane(CPane::ST_HORIZONTAL);//����ˮƽ�ָ���
	SetPaneWnd(m_PaneMain,&m_GVSObjTree,1);
	SetPaneWnd(m_PaneMain,&m_PropertyListView,2);
    //SetTopOffset(30);
	Initialize();
    
	char  tempStr[] = "VirtualGVS Application";
	{
	  TVINSERTSTRUCT InsertStruct;
	  InsertStruct.hParent		= NULL;	
	  InsertStruct.hInsertAfter	= TVI_LAST;
	  InsertStruct.itemex.mask	= TVIF_IMAGE | TVIF_TEXT | TVIF_CHILDREN | 
								  TVIF_SELECTEDIMAGE | TVIF_PARAM;
	  InsertStruct.itemex.pszText	= tempStr;
	  InsertStruct.itemex.iImage	= 3;
	  InsertStruct.itemex.cChildren= 1;
	  InsertStruct.itemex.lParam	= NULL;
 	  InsertStruct.itemex.iSelectedImage = 2;

	  HTREEITEM  TreeTopItem = m_GVSObjTree.InsertItem( &InsertStruct );

	  //HTREEITEM  TreeTopItem = m_GVSObjTree.InsertItem("VirtualGVS Application");

      m_GVSObjectTree->pHTREEITEM = TreeTopItem;
	  m_GVSObjTree.SetItemData(TreeTopItem,(DWORD)m_GVSObjectTree);
    
	
	  m_TopItem = TreeTopItem;
	}





	m_PropertyListView.InsertColumn(0,"Property",LVCFMT_CENTER,150);
	m_PropertyListView.InsertColumn(1,"Value",LVCFMT_CENTER);
    DWORD ExtStyle = m_PropertyListView.GetExtendedStyle( );
    ExtStyle |= LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT;
    m_PropertyListView.SetExtendedStyle(ExtStyle);

	m_PropertyListView.SetBkColor( ::GetSysColor(COLOR_GRAYTEXT));//::GetSysColor(COLOR_WINDOW));
    m_PropertyListView.SetTextBkColor(::GetSysColor(COLOR_WINDOWFRAME));

    m_PropertyListView.InsertItem(0,"afafsdf");
    m_PropertyListView.InsertItem(1,"afkldsf");

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void TGVSToolPane::OnPaint() 
{
	//CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		//dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CSplitDialog::OnPaint();
	}	
	// Do not call CSplitDialog::OnPaint() for painting messages
}

TGVSListNode* TGVSToolPane::AddGVSListNode( const char*  ListName )
{
  TGVSListNode*  pListNode = m_GVSObjectTree->AddGVSListNode(ListName);

	{
	  TVINSERTSTRUCT InsertStruct;
	  InsertStruct.hParent		= m_TopItem;	
	  InsertStruct.hInsertAfter	= TVI_LAST;
	  InsertStruct.itemex.mask	= TVIF_IMAGE | TVIF_TEXT | TVIF_CHILDREN | 
								  TVIF_SELECTEDIMAGE | TVIF_PARAM;
	  InsertStruct.itemex.pszText	= (char*)ListName;
	  InsertStruct.itemex.iImage	= 1;
	  InsertStruct.itemex.cChildren= 1;
	  InsertStruct.itemex.lParam	= NULL;
 	  InsertStruct.itemex.iSelectedImage = 2;

	  HTREEITEM  TreeItem = m_GVSObjTree.InsertItem( &InsertStruct );

	  m_GVSObjTree.SetItemData(TreeItem,(DWORD)pListNode);
    
	  pListNode->pHTREEITEM = TreeItem;
	}
 // HTREEITEM  TreeItem = m_GVSObjTree.InsertItem( ListName,m_TopItem );
 
  
  
  return  pListNode;
}

TGVSNode*  TGVSToolPane::AddGVSObject(TGVSBaseClass*  pGVSObject,TGVSListNode*  pParentNode/*=NULL*/)
{
  TGVSNode*  pNode = NULL;
  if( pParentNode == NULL )
  {
    pNode =  m_GVSObjectTree->AddGVSObject(pGVSObject);

	char  tempCh[256];
	strcpy( tempCh,pGVSObject->GetObjectName());
	strcat( tempCh," : " );
	strcat( tempCh,pGVSObject->GetClassName());

    HTREEITEM  TreeItem = m_GVSObjTree.InsertItem( tempCh,m_TopItem );
    pNode->pHTREEITEM = TreeItem;
    m_GVSObjTree.SetItemData( TreeItem,(DWORD)pNode);
  }
  else
  {
    pNode =  m_GVSObjectTree->AddGVSObject(pGVSObject,pParentNode);
	char  tempCh[256];
	strcpy( tempCh,pGVSObject->GetObjectName());
	strcat( tempCh," : " );
	strcat( tempCh,pGVSObject->GetClassName());

    HTREEITEM  TreeItem = m_GVSObjTree.InsertItem( tempCh,(HTREEITEM)pParentNode->pHTREEITEM );
    pNode->pHTREEITEM = TreeItem;
	m_GVSObjTree.SetItemData( TreeItem,(DWORD)pNode);
  }
  return pNode; 
}


BOOL TGVSToolPane::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if( pMsg->message == WM_TREESET_ITEMS )
	{
	  TGVSNode*  pNode = (TGVSNode*)(void*)pMsg->lParam;
	  TGVSBaseClass*  pGVSObject =  pNode->pNode;
	  m_PropertyListView.SetCurrentGVSObject( pGVSObject );
	  
	}
	return CSplitDialog::PreTranslateMessage(pMsg);
}
