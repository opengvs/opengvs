#if !defined(AFX_PROPERTYLISTCTRL_H__363FCA32_F8A5_4350_8DEC_4DEBCDBD84B5__INCLUDED_)
#define AFX_PROPERTYLISTCTRL_H__363FCA32_F8A5_4350_8DEC_4DEBCDBD84B5__INCLUDED_

#include <afxtempl.h>
#include "TTypeInfor.h"
#include "TGVSBaseClass.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// PropertyListCtrl.h : header file
//

//the max listCtrl columns
#define MAX_LISTCTRL_COLUMNS  2


class CInPlaceCombo;
class CInPlaceEdit;

// User define message 
// This message is posted to the parent
// The message can be handled to make the necessary validations, if any
#define WM_VALIDATE		WM_USER + 0x7FFD

// User define message 
// This message is posted to the parent
// The message should be handled to spcify the items to the added to the combo
#define WM_SET_ITEMS	WM_USER + 0x7FFC
#define  WM_UPDATA_VALUE   WM_USER + 0x7FFE

//#defines
#define FIRST_COLUMN				0
#define MIN_COLUMN_WIDTH			10
#define MAX_DROP_DOWN_ITEM_COUNT	10

/////////////////////////////////////////////////////////////////////////////
// CPropertyListCtrl window
/*
struct  PropertyItem
{
     PropertyStr*   m_pProperty;
     PropertyItem*   m_Parent;
	 list<PropertyItem*>   m_ChildList;

     bool          m_Enpand;
	 PropertyItem(PropertyStr*   pProperty)
	 {
		 m_Parent = NULL;
         m_pProperty = pProperty;
         m_Enpand = false;
	 };
	 ~PropertyItem()
	 {
		 m_Parent = NULL;
		 m_pProperty = NULL;
         list<PropertyItem*>::iterator  pIt = m_ChildList.begin();
		 while( pIt != m_ChildList.end() )
		 {
             PropertyItem*  pItem = (*pIt);
			 delete  pItem;
             m_ChildList.erase( pIt );
			 pIt = m_ChildList.begin();
		 }
	 };
	 void  AddChildPropertyItem( PropertyItem*  pItem )
	 {
         m_ChildList.push_back( pItem );
	 };

};
*/

class CPropertyListCtrl : public CListCtrl
{
// Construction
public:
	CPropertyListCtrl();

// Attributes
public:
   TGVSBaseClass*   m_pCurrentGVSObject;
   

// Operations
public:
   void  SetCurrentGVSObject(TGVSBaseClass*   pCurrentGVSObject);
   void  DeleteAllItems(void);
   int  InsertPropertyData(PropertyStr*  tPropertyStr);
   bool  HitTestEx(CPoint& rHitPoint, int* pRowIndex, int* pColumnIndex) const;
   
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropertyListCtrl)
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPropertyListCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPropertyListCtrl)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

public:

	//insert column
	int InsertColumn(int nCol,LPCTSTR lpszColumnHeading,int nFormat = LVCFMT_LEFT,int nWidth = -1,int nSubItem = -1);
    void DrawText(int nItem, int nSubItem, CDC *pDC, COLORREF crText, COLORREF crBkgnd, CRect &rect);
	
	// Creates and displays the in place combo box
	CInPlaceCombo* ShowInPlaceList(int iRowIndex, int iColumnIndex, CStringList& rComboItemsList, 
								   CString strCurSelecetion = "", int iSel = -1);

	// Creates and displays the in place edit control
	CInPlaceEdit* ShowInPlaceEdit(int iRowIndex, int iColumnIndex, CString& rstrCurSelection);

	// Calculates the cell rect
	void CalculateCellRect(int iColumnIndex, int iRowIndex, CRect& robCellRect);

	// Checks whether column supports in place combo box
	bool IsCombo(int iRowIndex, int iColumnIndex);
	// Scrolls the list ctrl to bring the in place ctrl to the view
	void ScrollToView(int iColumnIndex, /*int iOffSet, */CRect& obCellRect);

private:

// Attributes
	//list<PropertyStr*>   m_PropertyItemList;
    CInPlaceEdit*    m_InPlaceEdit;
	CInPlaceCombo*   m_InPlaceCombo;

	// Valid characters
	CString    m_strValidEditCtrlChars;

	// The window style of the in place edit ctrl
	DWORD m_dwEditCtrlStyle;

	// The window style of the in place combo ctrl
	DWORD m_dwDropDownCtrlStyle;

	//columnCounts
	int m_iColumnCounts;

	//column 
	CString         m_strValidChars[MAX_LISTCTRL_COLUMNS];

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTYLISTCTRL_H__363FCA32_F8A5_4350_8DEC_4DEBCDBD84B5__INCLUDED_)
