/********************************************************************
FileName:     GLight.cpp
descript:     ���ڶ����Դ��
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/
#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include "GLight.h"
#include "GLightProperty.h"
#include "GCamera.h"


GLight::GLight()
{
  m_InsideLight = NULL;
}

GLight::GLight(GV_Light pLight)
{
  m_InsideLight = pLight;
}

GLight::~GLight()
{
  m_InsideLight = NULL;
}

GLight*  GLight::CreateGLight(char*  name_in )
{
  GLight*   pLight = new GLightImp(name_in);
  GV_lsr_create( &(pLight->m_InsideLight) );
  GV_lsr_set_name( pLight->m_InsideLight, name_in);
  return  pLight;
}

GLight*  GLight::CreateGLight( GV_Light  pLight)
{
  static  int  LightDefault = 0;
  G_Name  name_out;
  GV_lsr_inq_name( pLight, name_out );
  int  str_l =  strlen( name_out );
  if( str_l == 0 )
  {
	char  temp[32];
    _ltoa( LightDefault++, temp, 10 );

	strcpy(name_out,"SystemDefineLight_");
	strcat(name_out,temp);
    //sprintf(name_out,"SystemDefineLight_%d",LightDefault++);
  }

  GLight*   p_Light = new GLightImp(name_out);
  p_Light->m_InsideLight = pLight;
  if( str_l == 0 )
    GV_lsr_set_name( p_Light->m_InsideLight, name_out);

  return p_Light;
}

int GLight::Set_ambient( const GV_Rgba *ambient_in)
{
	return GV_lsr_set_ambient( m_InsideLight, ambient_in);
}

int GLight::Get_ambient( GV_Rgba *ambient_out)
{
	return  GV_lsr_inq_ambient( m_InsideLight, ambient_out);
}

int GLight::Set_diffuse( const GV_Rgba *diffuse_in)
{
	return  GV_lsr_set_diffuse( m_InsideLight, diffuse_in);
}

int GLight::Get_diffuse( GV_Rgba *diffuse_out)
{
	return  GV_lsr_inq_diffuse( m_InsideLight, diffuse_out);
}

int GLight::Set_specular( const GV_Rgba *specular_in)
{
	return  GV_lsr_set_specular( m_InsideLight, specular_in);
}

int GLight::Get_specular( GV_Rgba *specular_out)
{
	return  GV_lsr_inq_specular( m_InsideLight, specular_out);
}

int GLight::Set_direction( const G_Vector3 *dir_in)
{
	return  GV_lsr_set_direction( m_InsideLight, dir_in);
}

int GLight::Get_direction( G_Vector3 *dir_out)
{
	return  GV_lsr_inq_direction( m_InsideLight, dir_out);
}

int GLight::Set_position( const G_Position *pos_in)
{
	return  GV_lsr_set_position( m_InsideLight, pos_in);
}

int GLight::Get_position( G_Position *pos_out)
{
	return  GV_lsr_inq_position( m_InsideLight, pos_out);
}


int GLight::Set_spot_direction(const G_Vector3 *dir_in)
{
	return  GV_lsr_set_spot_direction(m_InsideLight, dir_in);
}

int GLight::Get_spot_direction( G_Vector3 *dir_out)
{
	return  GV_lsr_inq_spot_direction(m_InsideLight, dir_out);
}

int GLight::Set_spot_exponent( float exponent_in )
{
	return  GV_lsr_set_spot_exponent( m_InsideLight, exponent_in );
}

int GLight::Get_spot_exponent( float *exponent_out )
{
	return  GV_lsr_inq_spot_exponent( m_InsideLight, exponent_out );
}

int GLight::Set_spot_cutoff( float angle_in )
{
	return  GV_lsr_set_spot_cutoff( m_InsideLight, angle_in );
}

int GLight::Get_spot_cutoff( float *angle_out )
{
	return  GV_lsr_inq_spot_cutoff( m_InsideLight, angle_out );
}

int GLight::Set_attenuation( GLenum a_type, GLfloat atten_in)
{
	return  GV_lsr_set_attenuation( m_InsideLight, a_type, atten_in);
}

int GLight::Get_attenuation( GLenum a_type, GLfloat *atten_out)
{
	return  GV_lsr_inq_attenuation( m_InsideLight, a_type, atten_out);
}

int GLight::Get_type( GV_Lsr_type * lsr_type )
{
	return  GV_lsr_inq_type( m_InsideLight, lsr_type );
}
