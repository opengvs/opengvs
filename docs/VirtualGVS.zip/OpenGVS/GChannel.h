/********************************************************************
FileName:     GChannel.h
descript:     ���ڶ���GChannel��
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/

#ifndef   __GCHANNEL_H__
#define   __GCHANNEL_H__

class  GCamera;
class  GScene;

#ifdef __cplusplus
extern "C" {
#endif
/*  These handles must be declared before including the other header files. */
typedef struct GV_channel_s * GV_Channel ;
#ifdef __cplusplus
}
#endif


class  GChannel
{
protected:
  GV_Channel      m_pInsideData;
  GCamera*        m_CurrentCamera;

  GChannel();
public:
	virtual ~GChannel();

public:
	static  GChannel*   CreateChannel(const char*  name,HWND  hWnd);
	
	GV_channel_s**  GetInsideChannel(void) { return &m_pInsideData;}; 
    void  SetCurrentCamera(GCamera* pCamera);
	GCamera*  Get_curent_camera(void);
	void  SetScene( GScene*  pScene );
    
};

#endif
