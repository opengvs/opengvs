#ifndef  __TGVSAPP_H_
#define  __TGVSAPP_H_

#include  "TVGVSAppFrame.h"

class   CMaterialSetGialog;

class  TGVSApp : public TGVSAppFrame
{
protected:
	bool  m_bControlCamera;
	CMaterialSetGialog*  m_MtlSetDialog;
public:
	

   TGVSApp();
   virtual ~TGVSApp();

	virtual int GVS_user_pre_import( void);
    virtual int GVS_user_init( void );
    virtual int GVS_user_proc( void );
	virtual int GVS_user_proc_post( void );
    virtual int GVS_user_shutdown( void );
	virtual int EventProcess(UINT   message,WPARAM  wParam,LPARAM  lParam );

private:
	void  ControlCameraEvent(UINT   message,WPARAM  wParam,LPARAM  lParam );
    void  ShowMtlDialog( GV_Material  pMaterial );
};
extern  bool g_GVS_Run;
UINT  GVSThreadRun(void*  pParam );
#endif