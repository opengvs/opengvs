#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */


#include  "GTerrainImp.h"
#include  "GObd.h"

char                    TGVSPersistent<GTerrainImp>::m_ClassName[GVSNAME_MAXLENGTH];
int                     TGVSPersistent<GTerrainImp>::m_ObjectCount = 0;  
vector<PropertyStr*>    TGVSPersistent<GTerrainImp>::m_PropertyStr_List;


GTerrainImp::GTerrainImp(const char*  name):TGVSPersistent<GTerrainImp>(name),GTerrain(name)
{
  GV_Bbox   bbox;
  GV_Bbox_status  bbstat;
  //GV_obi_inq_bbox_local( *(p->Get_obi()->Get_obi()), &bbox,&bbstat);
  GV_Obd  tempObd;

  GV_obd_inq_by_name( "TERRAIN", &tempObd);
  
  GV_obd_recompute_bbox_full( tempObd ) ;

  GV_obd_inq_bbox_full( tempObd, &bbox,&bbstat);
  
  if( bbstat == GV_BBOX_VALID )
  {
    Max_x  =  bbox.xmax;
	Max_y  =  bbox.ymax;
	Max_z  =  bbox.zmax;
	Min_x  = bbox.xmin;
	Min_y  = bbox.ymin;
	Min_z  = bbox.zmin;

  }

}

GTerrainImp::GTerrainImp(const char* name,bool bDef):TGVSPersistent<GTerrainImp>(name),GTerrain()
{
 
}

GTerrainImp::~GTerrainImp()
{

}

void  Set_Max_x(void*  self,int x )
{
  GTerrainImp*  p = dynamic_cast<GTerrainImp*>((TGVSBaseClass*)self);
  //p->Max_x = x;

}
void  Get_Max_x(void*  self,int*  x )
{
  GTerrainImp*  p = dynamic_cast<GTerrainImp*>((TGVSBaseClass*)self);
  
  *x = p->Max_x;
}

void  Set_Max_y(void*  self,int y )
{
  GTerrainImp*  p = dynamic_cast<GTerrainImp*>((TGVSBaseClass*)self);
  p->Max_y = y;
}
void  Get_Max_y(void*  self,int*  y )
{
   GTerrainImp*  p = dynamic_cast<GTerrainImp*>((TGVSBaseClass*)self);
   *y = p->Max_y;
}

void  Set_Max_z(void*  self,int z )
{
  GTerrainImp*  p = dynamic_cast<GTerrainImp*>((TGVSBaseClass*)self);
  p->Max_z = z;
}
void  Get_Max_z(void*  self,int*  z )
{
  GTerrainImp*  p = dynamic_cast<GTerrainImp*>((TGVSBaseClass*)self);
  *z = p->Max_z;
}

void  Set_Min_x(void*  self,int x )
{
  GTerrainImp*  p = dynamic_cast<GTerrainImp*>((TGVSBaseClass*)self);
  p->Min_x = x;

}

void  Get_Min_x(void*  self,int*  x )
{
   GTerrainImp*  p = dynamic_cast<GTerrainImp*>((TGVSBaseClass*)self);

   *x = p->Min_x;
}


void  Set_Min_y(void*  self,int y )
{
  GTerrainImp*  p = dynamic_cast<GTerrainImp*>((TGVSBaseClass*)self);
  p->Min_y = y;
}
void  Get_Min_y(void*  self,int*  y )
{
   GTerrainImp*  p = dynamic_cast<GTerrainImp*>((TGVSBaseClass*)self);
   *y = p->Min_y;
}


void  Set_Min_z(void*  self,int z )
{
  GTerrainImp*  p = dynamic_cast<GTerrainImp*>((TGVSBaseClass*)self);
  p->Min_z = z;
}

void  Get_Min_z(void*  self,int*  z )
{
   GTerrainImp*  p = dynamic_cast<GTerrainImp*>((TGVSBaseClass*)self);
   *z = p->Min_z;
}

void     GTerrainImp::InitializePropertyStr(void)
{
  PropertyStr*  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"Max_x" );
  strcpy(t_PropertyStr->m_TypeName,"int" ); //typeid(float).name;
  t_PropertyStr->m_PropertyType = tkInteger;
  t_PropertyStr->GetDataCallbackFunction.IntergerGet = Get_Max_x;
  t_PropertyStr->SetDataCallbackFunction.IntergerSet = Set_Max_x;
  m_PropertyStr_List.push_back( t_PropertyStr );


  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"Max_y");
  strcpy(t_PropertyStr->m_TypeName,"int");//typeid(float).name;
  t_PropertyStr->m_PropertyType = tkInteger;
  t_PropertyStr->GetDataCallbackFunction.IntergerGet = Get_Max_y;
  t_PropertyStr->SetDataCallbackFunction.IntergerSet = Set_Max_y;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name, "Max_z");
  strcpy(t_PropertyStr->m_TypeName,"int");//typeid(float).name;
  t_PropertyStr->m_PropertyType = tkInteger;
  t_PropertyStr->GetDataCallbackFunction.IntergerGet = Get_Max_z;
  t_PropertyStr->SetDataCallbackFunction.IntergerSet = Set_Max_z;
  m_PropertyStr_List.push_back( t_PropertyStr );


  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name, "Min_x");
  strcpy(t_PropertyStr->m_TypeName,"int");//typeid(float).name;
  t_PropertyStr->m_PropertyType = tkInteger;
  t_PropertyStr->GetDataCallbackFunction.IntergerGet = Get_Min_x;
  t_PropertyStr->SetDataCallbackFunction.IntergerSet = Set_Min_x;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name, "Min_y");
  strcpy(t_PropertyStr->m_TypeName,"int");//typeid(float).name;
  t_PropertyStr->m_PropertyType = tkInteger;
  t_PropertyStr->GetDataCallbackFunction.IntergerGet = Get_Min_y;
  t_PropertyStr->SetDataCallbackFunction.IntergerSet = Set_Min_y;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name, "Min_z");
  strcpy(t_PropertyStr->m_TypeName,"int");//typeid(float).name;
  t_PropertyStr->m_PropertyType = tkInteger;
  t_PropertyStr->GetDataCallbackFunction.IntergerGet = Get_Min_z;
  t_PropertyStr->SetDataCallbackFunction.IntergerSet = Set_Min_z;
  m_PropertyStr_List.push_back( t_PropertyStr );

}
