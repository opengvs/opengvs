// GMaterialImp.cpp: implementation of the GMaterialImp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include "GMaterialImp.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

char                    TGVSPersistent<GMaterialImp>::m_ClassName[GVSNAME_MAXLENGTH];
int                     TGVSPersistent<GMaterialImp>::m_ObjectCount = 0;
vector<PropertyStr*>    TGVSPersistent<GMaterialImp>::m_PropertyStr_List;

GMaterialImp::GMaterialImp(const char* name):TGVSPersistent<GMaterialImp>(name)
{
  
}

GMaterialImp::~GMaterialImp()
{

}

static  GV_Rgba  Ambient_Rgba;
static void __cdecl Get_current_Ambient_R(void*  self, float   *color )
{
  GMaterialImp*  p = dynamic_cast<GMaterialImp*>((TGVSBaseClass*)self);
  p->Get_ambient(  &Ambient_Rgba );

  *color = Ambient_Rgba.r;//p->Ambient_R;
}

static void __cdecl Set_current_Ambient_R(void*  self, float    color )
{
  GMaterialImp*  p = dynamic_cast<GMaterialImp*>((TGVSBaseClass*)self);
  p->Ambient_R = color;
  p->Get_ambient(  &Ambient_Rgba );
  Ambient_Rgba.r = color;
  p->Set_ambient(  &Ambient_Rgba );
  p->Define( );
}

static void __cdecl Get_current_Ambient_G(void*  self, float   *color )
{
  GMaterialImp*  p = dynamic_cast<GMaterialImp*>((TGVSBaseClass*)self);
  p->Get_ambient(  &Ambient_Rgba );

  *color = Ambient_Rgba.g; //p->Ambient_G;
}

static void __cdecl Set_current_Ambient_G(void*  self, float    color )
{
  GMaterialImp*  p = dynamic_cast<GMaterialImp*>((TGVSBaseClass*)self);
  p->Ambient_G = color;
  p->Get_ambient(  &Ambient_Rgba );
  Ambient_Rgba.g = color;
  p->Set_ambient(  &Ambient_Rgba );
  p->Define( ); 
}

static void __cdecl Get_current_Ambient_B(void*  self, float   *color )
{
  GMaterialImp*  p = dynamic_cast<GMaterialImp*>((TGVSBaseClass*)self);
  p->Get_ambient(  &Ambient_Rgba );

  *color = Ambient_Rgba.b;//p->Ambient_R;
}

static void __cdecl Set_current_Ambient_B(void*  self, float    color )
{
  GMaterialImp*  p = dynamic_cast<GMaterialImp*>((TGVSBaseClass*)self);
  p->Ambient_B = color;
  p->Get_ambient(  &Ambient_Rgba );
  Ambient_Rgba.b = color;
  p->Set_ambient(  &Ambient_Rgba );
  p->Define( );
}

static void __cdecl Get_current_Ambient_A(void*  self, float   *color )
{
  GMaterialImp*  p = dynamic_cast<GMaterialImp*>((TGVSBaseClass*)self);
  p->Get_ambient(  &Ambient_Rgba );

  *color = Ambient_Rgba.a;//p->Ambient_R;
}

static void __cdecl Set_current_Ambient_A(void*  self, float    color )
{
  GMaterialImp*  p = dynamic_cast<GMaterialImp*>((TGVSBaseClass*)self);
  p->Ambient_A = color;
  p->Get_ambient(  &Ambient_Rgba );
  Ambient_Rgba.a = color;
  p->Set_ambient(  &Ambient_Rgba );
  p->Define( );
}

void     GMaterialImp::InitializePropertyStr(void)
{
  PropertyStr*  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"Ambient_R" );
  strcpy(t_PropertyStr->m_TypeName,"float" ); 
  t_PropertyStr->m_PropertyType = tkFloat;
  t_PropertyStr->GetDataCallbackFunction.FloatGet = Get_current_Ambient_R;
  t_PropertyStr->SetDataCallbackFunction.FloatSet = Set_current_Ambient_R;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"Ambient_G" );
  strcpy(t_PropertyStr->m_TypeName,"float" ); 
  t_PropertyStr->m_PropertyType = tkFloat;
  t_PropertyStr->GetDataCallbackFunction.FloatGet = Get_current_Ambient_G;
  t_PropertyStr->SetDataCallbackFunction.FloatSet = Set_current_Ambient_G;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"Ambient_B" );
  strcpy(t_PropertyStr->m_TypeName,"float" ); 
  t_PropertyStr->m_PropertyType = tkFloat;
  t_PropertyStr->GetDataCallbackFunction.FloatGet = Get_current_Ambient_B;
  t_PropertyStr->SetDataCallbackFunction.FloatSet = Set_current_Ambient_B;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"Ambient_A" );
  strcpy(t_PropertyStr->m_TypeName,"float" ); 
  t_PropertyStr->m_PropertyType = tkFloat;
  t_PropertyStr->GetDataCallbackFunction.FloatGet = Get_current_Ambient_A;
  t_PropertyStr->SetDataCallbackFunction.FloatSet = Set_current_Ambient_A;
  m_PropertyStr_List.push_back( t_PropertyStr );

 
}
