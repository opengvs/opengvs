/****************************************************************************
�ļ����ƣ�TOceanWave.h   ���ڶ���ģ�⺣�˵���
������class  TOceanWave �����ڶ��嶯̬������Ҫ�����ݽṹ����Ӧ�Ĳ�������
2005.2   ������   ��Ȩ����
****************************************************************************/

#ifndef   __TOCEANWAVE_H__
#define   __TOCEANWAVE_H__
#include "TFont.h"
#include  "GTrigon.h"

/*------------------------*/
/* Defines                */
/*------------------------*/
#define DB_WEST_IND	    0
#define DB_NORTH_IND	1
#define DB_VERT_IND	    2

/*------------------------*/
#ifndef BASE_PLATFORM
#define BASE_PLATFORM	0
#endif

#define DYNSEA_DEBUG	0

/*----------------*/
/* Defines        */
/*----------------*/
//#define USE_MATERIAL	1//1
//#define USE_TEXTURE	1
//#define USE_NORMALS	1

//#define DRAW_AS_LINES	0

#define FULL_SEA	1
#define FADE1_LAYER	1

//#define DIFF_COLOURS	1
//#define USE_ATTR_FILE  1

#define REMAP_TEXTURE	0

#define MAX_WAVES	6

#define X_IND		0
#define Y_IND		1
#define Z_IND		2
/*----------------------*/
#define  DYNAMIC_SEA_DRAW_ORDER    4999-100
#define  DYNAMIC_TANK_WAKE_ORDER   4999-99
/*------------------------*/
/* Typedefs               */
/*------------------------*/

typedef float vec4[4];
typedef float vec3[3];
typedef float vec2[2];

#define  TANK_BACK_HALF_WITH     2
#define  WAKE_MAX_WIDTH          10

#define  DEFAULT_HEIGHT          2 //ÿ���1�����һ������С��ʻ�ٶ�Ϊ8����/Сʱ
#define  WAKE_ACTIVE_LENGTH      100
#define  DEFINE_ANGLE             15  //��
#define  DEFINE_ANGLE_LENGTH       0.535899
#define  ACCELERATION_OF_GRAVITY   9.18

class  TOceanWave;


//���崬��̹����ˮ���н��γɵ�β��
class  TWakes
{
public:
	class TWake
	{
    public:
		G_Position  V[4];

        float   m_Width;
		TWake(G_Position&  pos,G_Rotation& rot);
	    bool  Wake_SimulationCallback( void );
	   void   Wake_gfx_callback(void);
	public:
	   TWake*  pNestWake;
	};

public:
     TWakes();
	 ~TWakes();
	 void Initialize(TOceanWave*  pOcean);
	 void AddWake(G_Position&  pos,G_Rotation&  rot);
     
	 //void  SimulationCallback( G_Position&  pos );
     static  int Wake_sim_callback( GV_Obi inst, void *data_in );
	 static  int Wake_gfx_callback( GV_Obi inst, void *data_in );
	 void GfxCallback(void);
public:
	static GV_Obd   m_Obd;
	static GV_Obi   m_Obi;
    TOceanWave *  m_pOcean;  
    TWake*   m_pWakeList;
public:
	GV_Texture  tex;
    char        txt_file[80];
	GV_Material mtl;
};


//���峤�岨ģ�ͷ�����Ҫ����
class  TDynOceanSim
{
public:
  static  int    m_WindDegree2WaveDegree[13];  //����12�����Ӧ�ĺ��˵ĵȼ�
  static  float  m_WaveDegree2WaveHeight_T[10][2];  //����9�����˶�Ӧ�Ĳ��˸߶Ⱥ�����
  static  float  m_WaveDegree2W[8][10][2];  //�������˵ȼ���Ӧ�Ľ�Ƶ�ʺͲ���
private:
	float  m_H0;//�����߶�

	int  m_Phi[10];  //��λ�� 0~180
    int  m_Angle;//���Ĵ�������0~360
	float  SinAngle;
	float  CosAngle;

	int    m_CurrentWindDegree;
	int    m_CurrentWaveDegree;//�˵ĵȼ�
    float  m_CurrentWaveHeight; //�˸�
    float  m_CurrentWaveCyc;//���˵�����
	float  m_CurrentWaveAngleFrequency[10];//��ɢ��Ƶ��
	float  m_CurrentWaveAmplitude[10];  //��ɢ����
public:
    TDynOceanSim();
	~TDynOceanSim();

	float  dynSimulation( G_Position*  pos,double  t );
	float  dynSimulation( float x,float y,float z,double t );
	void   SetCurrentWindDegree( int  Degree );
	void   SetWindAngle( int  Angle );

};

class  TOceanWave
{
public:
	bool  m_bDrawAsLines; //DRAW_AS_LINES
	bool  m_bUseMaterial;   //USE_MATERIAL

	bool  m_bUseTexture;  //USE_TEXTURE
	bool  m_bUseNormals;  //USE_NORMALS;
	bool  m_bDiffColours;  //DIFF_COLOURS
	bool  m_bUseAttrFile;  //USE_ATTR_FILE
    GV_Material    GetOceanMaterial(void);
public:
	void  SetSurfaceColor(unsigned char  r,unsigned char g,unsigned char b);
public:
	void GVSUserMessageProc(UINT   message,WPARAM  wParam,LPARAM  lParam);
	
	GV_Obi DynSea_add( GV_Scene scene );
	int DynSea_inq_state( int * sstate );
	int DynSea_set_state( int sstate );
	
	typedef struct {
		int         sea_state;   //���庣ƽ��״̬
		GV_Obi      group;       //���庣ƽ���������
		GV_Scene    scene;       //�������ڵĳ���
		GV_Channel  channel;     //��ʾ����Ĵ���

		vec3        *coord_table;  //��ƽ���������ά����
		vec2        *tex_table;    //��ƽ����������Ķ�ά����

		int         *lengths;       /* Dynamic area */
		int         num_strips;     /* Dynamic area */

		int         *st_lengths;    /* Outer still area corners */
		int         num_st_strips;  /* Outer still area corners */
		int         num_st_quads;   /* Outer still area sides */

		int         num_fade_tri;   /* Fade area */
		GV_Material  mtl;

		int         *dy_cindex;     /* Dynamic area */
		int         *st_cindex2;    /* Outer still area corners */
		int         *st_cindex3;    /* Outer still area sides */
		int         *st_cindex4;    /* Fade area */

		int         *tex_index;
		int         *tex_index2;
		int         *tex_index3;
		int         *tex_index4;
		
		vec4        col_table[1];
		int         *col_index;
		int         *st_col_index2;
		int         *st_col_index3;
		int         *st_col_index4;
		
		vec3        normal[1];
		int         *norm_index;
		int         *st_norm_index2;
		int         *st_norm_index3;
		int         *st_norm_index4;
		
		GV_Texture  tex;
		
		float       dyn_range_x;  //��ƽ�涯̬�仯�ķ�Χ
		float       dyn_range_y;

		float       sea_range_x;  //��ƽ������Χ
		float       sea_range_y;

		float       step_x;   //��ƽ������Ŀ���
		float       step_y;

		float       tex_rot;
		float       sin_tex_rot;
		float       cos_tex_rot;
		//int         spare4;
		
		int         total_num_coords;
		//int         spare3;
		int         num_coord_x; /* For dynamic sea area */
		int         num_coord_y;

		int         n;           /* Number of steps from centre along x */
		int         m;           /* Number of steps from centre along y */

		float       patt_size_u;  //��ʼ����ֵΪ100  �ñ���Ŀǰ������ȷ������
		float       patt_size_v;

		vec3        surface_col;
		float       blendcol[4];
		
		//int         spare5;
		float       height;  //��ƽ��ƽ����ʼ���߲�

		char        setup;
		
		char        alpha;
		
		char        dyn_active;
		//char        mat_in_use;
		vec2        torigin;
		char        use_tex;
		//char        spare;
		char        rot_tex;
		char        tfb;
		//char        spare2[4];
		char        txt_file[80];
	} Dynamic_sea;

	TOceanWave();
	virtual ~TOceanWave();

	Dynamic_sea * dyn_sea ;//= NULL;
protected:	

	int Sea_state ;//= 4;
	float sea_surface_alpha ;//= 1.0f;
	float W[MAX_WAVES];
	float Kx[MAX_WAVES];
	float Ky[MAX_WAVES];
	float Amp[MAX_WAVES];
	float Phi[MAX_WAVES];
	int   Num_waves;//���뺣ƽ�����

TDynOceanSim   m_DynOceanSim;
	
public:
	
	static int DynSea_gfx_callback( GV_Obi inst, void *data_in );
	static void update_bbox( float xc, float yc, float zc, GV_Bbox * bbox );

	void DynSea_setup_material ( GV_Material mtl );
	void Dynsea_shutdown(void);
	void DynSea_init( TOceanWave::Dynamic_sea *dyn_sea );
	void DynSea_state4();
	void DynSea_state2();
	void DynSea_state0();
	void DynSea_state1();

	G_Position  m_PrevPos;
	bool  m_firstGfx;
public:
	TWakes   m_wake;
	void  SimulationCallback(G_Position*  p);

    void DynOceanSimUpdate();
};
extern  bool g_DynOceanThreadRun;
UINT  DynOceanSimThread(void*  pParam );



#endif