// GGVSObjectTree.cpp : implementation file
//

#include "stdafx.h"
//#include "testBCG.h"
#include "GGVSObjectTree.h"
#include "TGVSTree.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GGVSObjectTree

GGVSObjectTree::GGVSObjectTree()
{
}

GGVSObjectTree::~GGVSObjectTree()
{
}


BEGIN_MESSAGE_MAP(GGVSObjectTree, CTreeCtrl)
	//{{AFX_MSG_MAP(GGVSObjectTree)
	ON_NOTIFY_REFLECT(TVN_SELCHANGED, OnSelchanged)
	ON_WM_CREATE()
	ON_WM_DRAWITEM()
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GGVSObjectTree message handlers

void GGVSObjectTree::OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	HTREEITEM pItem = this->GetSelectedItem();
	if( pItem != NULL )
	{
		//WM_TREESET_ITEMS
		TTreeNode*  pTreeNode = (TTreeNode*)GetItemData( pItem );
		if( pTreeNode != NULL )
        {
          if( pTreeNode->m_NodeType == ChildNode )
		     ::PostMessage( GetParent()->m_hWnd,WM_TREESET_ITEMS,0,(LPARAM)(void*)pTreeNode);
		}
	}
	*pResult = 0;
}

int GGVSObjectTree::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CTreeCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here

	return 0;
}

void GGVSObjectTree::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your message handler code here and/or call default
	
	CTreeCtrl::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void GGVSObjectTree::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CTreeCtrl::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
}
