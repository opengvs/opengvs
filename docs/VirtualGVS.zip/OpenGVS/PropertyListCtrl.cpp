// PropertyListCtrl.cpp : implementation file
//

#include "stdafx.h"
//#include "testBCG.h"
#include "PropertyListCtrl.h"
#include "InPlaceCombo.h"
#include "InPlaceEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertyListCtrl

CPropertyListCtrl::CPropertyListCtrl()
{
	m_pCurrentGVSObject = NULL;
	m_iColumnCounts = 0;
	m_strValidEditCtrlChars.Empty();
	m_dwEditCtrlStyle = ES_AUTOHSCROLL | ES_AUTOVSCROLL | ES_LEFT | ES_NOHIDESEL;
	m_dwDropDownCtrlStyle = WS_BORDER | WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_AUTOVSCROLL | 
							CBS_DROPDOWNLIST | CBS_DISABLENOSCROLL;
	m_InPlaceEdit = CInPlaceEdit::GetInstance();
	m_InPlaceCombo = CInPlaceCombo::GetInstance();
}

CPropertyListCtrl::~CPropertyListCtrl()
{
   m_InPlaceEdit->DeleteInstance();
   m_InPlaceCombo->DeleteInstance();
   m_pCurrentGVSObject = NULL;
}


BEGIN_MESSAGE_MAP(CPropertyListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CPropertyListCtrl)
	ON_WM_CREATE()
	ON_WM_DRAWITEM()
	ON_NOTIFY_REFLECT(NM_CUSTOMDRAW, OnCustomDraw)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_NOTIFY_REFLECT(LVN_BEGINLABELEDIT, OnBeginlabeledit)
	ON_NOTIFY_REFLECT(LVN_ENDLABELEDIT, OnEndlabeledit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void  CPropertyListCtrl::SetCurrentGVSObject(TGVSBaseClass*   pCurrentGVSObject)
{
	if( pCurrentGVSObject == NULL )
	{
        DeleteAllItems( );
		return;
    }
	
	DeleteAllItems( );
	PropertyStr*  tPropertyStr=NULL;

    pCurrentGVSObject->UpDataPropertyValue();
	int count  = pCurrentGVSObject->GetPropertyStrCount();

	for( int i = 0;i<count;i++)
	{
	   tPropertyStr = pCurrentGVSObject->GetPropertyStr(i);
       InsertPropertyData( tPropertyStr );
	   if( tPropertyStr->IsExpand == true )
	   {
		   vector<PropertyStr*>::iterator  pIt = tPropertyStr->m_ChildList.begin();
		   while( pIt != tPropertyStr->m_ChildList.end() )
		   {
               InsertPropertyData( *pIt );
			   pIt++;
		   }
	   }
    }

	m_pCurrentGVSObject = pCurrentGVSObject;

}



int CPropertyListCtrl::InsertColumn(int nCol,LPCTSTR lpszColumnHeading,int nFormat ,int nWidth,int nSubItem)
{
	return CListCtrl::InsertColumn( nCol, lpszColumnHeading, nFormat, nWidth, nSubItem);
}

/////////////////////////////////////////////////////////////////////////////
// CPropertyListCtrl message handlers


int CPropertyListCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CListCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
	

	return 0;
}

void CPropertyListCtrl::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your message handler code here and/or call default
	
	CListCtrl::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void CPropertyListCtrl::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	//draw each item.set txt color,bkcolor....
	NMLVCUSTOMDRAW* pLVCD = reinterpret_cast<NMLVCUSTOMDRAW*>(pNMHDR);
	
	// Take the default processing unless we set this to something else below.
	*pResult = CDRF_DODEFAULT;
	
	// First thing - check the draw stage. If it's the control's prepaint
	// stage, then tell Windows we want messages for every item.
	
	if (pLVCD->nmcd.dwDrawStage == CDDS_PREPAINT)
	{
		*pResult = CDRF_NOTIFYITEMDRAW;
	}
	else if (pLVCD->nmcd.dwDrawStage == CDDS_ITEMPREPAINT)
	{
		// This is the notification message for an item.  We'll request
		// notifications before each subitem's prepaint stage.
		
		*pResult = CDRF_NOTIFYSUBITEMDRAW;
	}
	else if (pLVCD->nmcd.dwDrawStage == (CDDS_ITEMPREPAINT | CDDS_SUBITEM))
	{
		// This is the prepaint stage for a subitem. Here's where we set the
		// item's text and background colors. Our return value will tell
		// Windows to draw the subitem itself, but it will use the new colors
		// we set here.
		
		int nItem = static_cast<int> (pLVCD->nmcd.dwItemSpec);
		int nSubItem = pLVCD->iSubItem;
		
		CDC* pDC = CDC::FromHandle(pLVCD->nmcd.hdc);
		CRect rect;
		GetSubItemRect(nItem, nSubItem, LVIR_BOUNDS, rect);
		
		COLORREF crText,crBkgnd;

	    crText= ::GetSysColor(COLOR_WINDOWTEXT);
        crBkgnd=::GetSysColor( COLOR_INACTIVEBORDER );

		if (GetItemState(nItem, LVIS_SELECTED))
		{
			if( nSubItem == 0 )
			   DrawText(nItem, nSubItem, pDC, crText, crBkgnd, rect);
			else
			   DrawText(nItem, nSubItem, pDC, ::GetSysColor(COLOR_HIGHLIGHTTEXT), ::GetSysColor(COLOR_HIGHLIGHT) , rect);
		}
		else
			DrawText(nItem, nSubItem, pDC, crText, crBkgnd, rect);
		
		 
		*pResult = CDRF_SKIPDEFAULT;	// We've painted everything.
	}
}

void CPropertyListCtrl::DrawText(int nItem, int nSubItem, CDC *pDC, COLORREF crText, COLORREF crBkgnd, CRect &rect)
{
	ASSERT(pDC);
	
//	GetDrawColors(nItem, nSubItem, crText, crBkgnd);
	
	pDC->FillSolidRect(&rect, crBkgnd);

	PropertyStr*  pData = (PropertyStr*)this->GetItemData(nItem);
	if( pData == NULL )
		return;
	
	CString str;
    if( (pData->IsChild == true)&&(nSubItem==0) )
	{
		str = "    ";
	    str += GetItemText(nItem, nSubItem);
	}
	else
        str = GetItemText(nItem, nSubItem);
	
	if (!str.IsEmpty())
	{
		// get text justification
		HDITEM hditem;
		hditem.mask = HDI_FORMAT;
	//	m_ctlHeader.GetItem(nSubItem, &hditem);
	
//	int nFmt = hditem.fmt & HDF_JUSTIFYMASK;

		UINT nFormat = DT_VCENTER | DT_SINGLELINE;

		nFormat |= DT_LEFT;

		if( nSubItem != 1 )
		      pDC->SetBkMode(TRANSPARENT);

		pDC->SetTextColor(crText);
		pDC->SetBkColor(crBkgnd);

        if( (nSubItem == 0)&&(pData->m_PropertyType == tkStruct) )
		{
           int  x,y;
		   x = rect.TopLeft().x+2;
		   y = rect.TopLeft().y+2;
		   int cx,cy;
		   
		   cy = rect.bottom-3;
           cx = x+(cy-y);

		   pDC->MoveTo(x,y);               //Draw3dRect(x,y,16,16,
		   pDC->LineTo(cx,y);
		   pDC->LineTo(cx,cy);
		   pDC->LineTo(x,cy);
		   pDC->LineTo(x,y);

		   int y1 = (y+cy)/2;
           pDC->MoveTo(x+2,y1);
           pDC->LineTo(cx-1,y1);
           
		   if( pData->IsExpand == false )
		   {
		     x = (x+cx)/2;
             pDC->MoveTo(x,y+2);
             pDC->LineTo(x,cy-2);
           }
           rect.left = cx+3;
           pDC->DrawText(str, &rect, nFormat);
		   

		}
		else  if(  (nSubItem == 1)&&(pData->m_PropertyType == tkObject ) )
		{
          pDC->DrawText(str, &rect, nFormat);
		  pDC->Draw3dRect(CRect(rect.right-16,rect.top,rect.right,rect.bottom-1),RGB(0,0,0),RGB(255,255,255));
		  pDC->FillSolidRect(&CRect(rect.right-14,rect.top+2,rect.right-3,rect.bottom-3), RGB(255,150,0));

		  //HICON hIcon = AfxGetApp()->LoadIcon(IDI_OBJECTICON);
		  //pDC->DrawIcon(rect.right-16,rect.top,hIcon);
		}
		else  if( (nSubItem == 1)&&( (pData->m_PropertyType == tkInteger )||(pData->m_PropertyType == tkFloat) ) )
		{
		  pDC->DrawText(str, &rect, nFormat);	
		}
		else
		   pDC->DrawText(str, &rect, nFormat);
	
	}

}


void CPropertyListCtrl::OnPaint() 
{
	Default();
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	int  tempWidth = this->GetColumnWidth(0)+this->GetColumnWidth(1);
	CRect  rt;
	this->GetClientRect(&rt);
	if( rt.Width() != tempWidth )
	{
		this->SetColumnWidth( 1,rt.Width() - GetColumnWidth(0) ); 
	}
	// Do not call CListCtrl::OnPaint() for painting messages
}

bool CPropertyListCtrl::HitTestEx(CPoint &obPoint, int* pRowIndex, int* pColumnIndex) const
{
	if (!pRowIndex || !pColumnIndex)
	{
		return false;
	}

	// Get the row index
	*pRowIndex = HitTest(obPoint, NULL);

	if (pColumnIndex)
	{
		*pColumnIndex = 0;
	}

	// Make sure that the ListView is in LVS_REPORT
	if ((GetWindowLong(m_hWnd, GWL_STYLE) & LVS_TYPEMASK) != LVS_REPORT)
	{
		return false;
	}

	// Get the number of columns
	CHeaderCtrl* pHeader = (CHeaderCtrl*)GetDlgItem(0);

	int iColumnCount = pHeader->GetItemCount();

	// Get bounding rect of item and check whether obPoint falls in it.
	CRect obCellRect;
	GetItemRect(*pRowIndex, &obCellRect, LVIR_BOUNDS);
	
	if (obCellRect.PtInRect(obPoint))
	{
		// Now find the column
		for (*pColumnIndex = 0; *pColumnIndex < iColumnCount; (*pColumnIndex)++)
		{
			int iColWidth = GetColumnWidth(*pColumnIndex);
			
			if (obPoint.x >= obCellRect.left && obPoint.x <= (obCellRect.left + iColWidth))
			{
				return true;
			}
			obCellRect.left += iColWidth;
		}
	}
	return false;
}

void CPropertyListCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	int iColumnIndex = -1;
	int iRowIndex = -1;

	// Get the current column and row
	if (!HitTestEx(point, &iRowIndex, &iColumnIndex))
	{
		return;
	}

	CListCtrl::OnLButtonDown(nFlags, point);

	PropertyStr*  pData = (PropertyStr*)CListCtrl::GetItemData(iRowIndex);
	if( pData == NULL )
		  return;
	
	// If column is not read only then
	// If the SHIFT or CTRL key is down call the base class
	// Check the high bit of GetKeyState - determine whether SHIFT or CTRL key is down
	if ((GetKeyState(VK_SHIFT) & 0x80) || (GetKeyState(VK_CONTROL) & 0x80))
	{
		return;
	}

	{
		UINT flag = LVIS_FOCUSED;
		if ((GetItemState(iRowIndex, flag ) & flag) == flag)
		{
			if( pData->m_PropertyType == tkStruct )
			{
				CRect   rt;
				CalculateCellRect(iColumnIndex, iRowIndex, rt);
				if( (point.x > rt.TopLeft().x)&&(point.x < (rt.TopLeft().x+16)) )
				{
					if( pData->IsExpand == false )
						pData->IsExpand = true;
					else
						pData->IsExpand = false;
					SetCurrentGVSObject(m_pCurrentGVSObject);
					return;
				}
			}
		}
    }
	
	if( iColumnIndex != 1 )
		return;



	CString strCurSelection = GetItemText(iRowIndex, iColumnIndex);
    UINT flag = LVIS_FOCUSED;
    if ((GetItemState(iRowIndex, flag ) & flag) == flag)
	{
	    if( pData->m_PropertyType == tkObject )
		{
			CRect   rt;
			CalculateCellRect(iColumnIndex, iRowIndex, rt);
			if( (point.x > rt.right-16 )&&(point.x < rt.right) )
			{
                if( pData->SetDataCallbackFunction.ObjectSet != NULL )
                      pData->SetDataCallbackFunction.ObjectSet( m_pCurrentGVSObject,pData);
				
				return;
			}
		}
        else
		{
			    if( (pData->m_PropertyType  == tkInteger)||
					      (pData->m_PropertyType  == tkFloat)||(pData->m_PropertyType  == tkString) )
				{
                     CInPlaceEdit* pInPlaceEdit = ShowInPlaceEdit(iRowIndex, iColumnIndex, strCurSelection);
				}
			    else if( pData->m_PropertyType == tkEnumeration )
				{
                    CStringList    rComboItemsList;
					EnumInforObject*  t_pEnumObject = TRegesterEnum::FindEnum( pData->m_TypeName );
                    if( t_pEnumObject != NULL )
					{
						int  size = t_pEnumObject->GetValueNumber( );
						for( int i = 0; i < size; i++ )
						{
                           CString  tempStr = t_pEnumObject->GetValueName(i);
 						   rComboItemsList.AddTail(tempStr);
						}
					}

                   	CInPlaceCombo*  pInPlaceList = 
						ShowInPlaceList(iRowIndex, iColumnIndex, rComboItemsList,strCurSelection);
					ASSERT( pInPlaceList );

					pInPlaceList->SelectString(-1,strCurSelection);
				}

		}

	}

}

CInPlaceCombo* CPropertyListCtrl::ShowInPlaceList(int iRowIndex, int iColumnIndex, CStringList& rComboItemsList, 
											   CString strCurSelecetion /*= ""*/, int iSel /*= -1*/)
{
	// The returned obPointer should not be saved
	
	// Make sure that the item is visible
	if (!EnsureVisible(iRowIndex, TRUE))
	{
		return NULL;
	}

	// Make sure that iColumnIndex is valid 
	CHeaderCtrl* pHeader = static_cast<CHeaderCtrl*> (GetDlgItem(FIRST_COLUMN));

	int iColumnCount = pHeader->GetItemCount();

	if (iColumnIndex >= iColumnCount || GetColumnWidth(iColumnIndex) < MIN_COLUMN_WIDTH) 
	{
		return NULL;
	}

	// Calculate the rectangle specifications for the combo box
	CRect obCellRect(0, 0, 0, 0);
	CalculateCellRect(iColumnIndex, iRowIndex, obCellRect);

	int iHeight = obCellRect.Height();  
	int iCount = (int )rComboItemsList.GetCount();

	iCount = (iCount < MAX_DROP_DOWN_ITEM_COUNT) ? 
		iCount + MAX_DROP_DOWN_ITEM_COUNT : (MAX_DROP_DOWN_ITEM_COUNT + 1); 

	obCellRect.bottom += iHeight * iCount; 

	// Create the in place combobox
	CInPlaceCombo* pInPlaceCombo = m_InPlaceCombo;//CInPlaceCombo::GetInstance();
	pInPlaceCombo->ShowComboCtrl(m_dwDropDownCtrlStyle, obCellRect, this, 0, iRowIndex, iColumnIndex, &rComboItemsList, 
								 strCurSelecetion, iSel);
	
	return pInPlaceCombo;
}

CInPlaceEdit* CPropertyListCtrl::ShowInPlaceEdit(int iRowIndex, int iColumnIndex, CString& rstrCurSelection)
{
	// Create an in-place edit control
	CInPlaceEdit* pInPlaceEdit = m_InPlaceEdit; //CInPlaceEdit::GetInstance();
		
	CRect obCellRect(0, 0, 0, 0);
	CalculateCellRect(iColumnIndex, iRowIndex, obCellRect);
			
	m_InPlaceEdit->ShowEditCtrl(m_dwEditCtrlStyle, obCellRect, this, 0, 
							   iRowIndex, iColumnIndex,
							   m_strValidChars[iColumnIndex], rstrCurSelection);

	return pInPlaceEdit;
}

void CPropertyListCtrl::CalculateCellRect(int iColumnIndex, int iRowIndex, CRect& robCellRect)
{
	GetItemRect(iRowIndex, &robCellRect, LVIR_BOUNDS);
	
	CRect rcClient;
	GetClientRect(&rcClient);

	if (robCellRect.right > rcClient.right) 
	{
		robCellRect.right = rcClient.right;
	}

	ScrollToView(iColumnIndex, robCellRect); 
}

bool CPropertyListCtrl::IsCombo(int iRowIndex,int iColumnIndex)
{
   PropertyStr*  pData =  (PropertyStr*)GetItemData( iRowIndex );
   if( pData->m_PropertyType == tkEnumeration )
	     return true;

	return false;
}

void CPropertyListCtrl::ScrollToView(int iColumnIndex, /*int iOffSet, */CRect& robCellRect)
{
	// Now scroll if we need to expose the column
	CRect rcClient;
	GetClientRect(&rcClient);

	int iColumnWidth = GetColumnWidth(iColumnIndex);

	// Get the column iOffset
	int iOffSet = 0;
	for (int iIndex_ = 0; iIndex_ < iColumnIndex; iIndex_++)
	{
		iOffSet += GetColumnWidth(iIndex_);
	}

	// If x1 of cell rect is < x1 of ctrl rect or
	// If x1 of cell rect is > x1 of ctrl rect or **Should not ideally happen**
	// If the width of the cell extends beyond x2 of ctrl rect then
	// Scroll

	CSize obScrollSize(0, 0);

	if (((iOffSet + robCellRect.left) < rcClient.left) || 
		((iOffSet + robCellRect.left) > rcClient.right))
	{
		obScrollSize.cx = iOffSet + robCellRect.left;
	}
	else if ((iOffSet + robCellRect.left + iColumnWidth) > rcClient.right)
	{
		obScrollSize.cx = iOffSet + robCellRect.left + iColumnWidth - rcClient.right;
	}

	Scroll(obScrollSize);
	robCellRect.left -= obScrollSize.cx;
	
	// Set the width to the column width
	robCellRect.left += iOffSet;
	robCellRect.right = robCellRect.left + iColumnWidth;
}

void  CPropertyListCtrl::DeleteAllItems(void)
{
	CListCtrl::DeleteAllItems();
}

int  CPropertyListCtrl::InsertPropertyData(PropertyStr*  tPropertyStr)
{
	int ItemCount = CListCtrl::GetItemCount( );
	CListCtrl::InsertItem(ItemCount,tPropertyStr->m_Name);
	CString  tempStr;

	if( tPropertyStr->m_PropertyType == tkFloat )
      tempStr.Format("%.2f", tPropertyStr->PropertyData.fData);
	 else  if( tPropertyStr->m_PropertyType == tkInteger )
      tempStr.Format("%d", tPropertyStr->PropertyData.iData);
	else  if( tPropertyStr->m_PropertyType == tkString )
       tempStr.Format("%s", tPropertyStr->PropertyData.iData);
	else  if( tPropertyStr->m_PropertyType == tkEnumeration )
	{

		EnumInforObject* p = TRegesterEnum::FindEnum( tPropertyStr->m_TypeName );
		if( p != NULL )
		{
			tempStr = p->GetValueName(tPropertyStr->PropertyData.eData );
		}

	}
	else  if( tPropertyStr->m_PropertyType == tkStruct )  //�ṹ�����
	{
		char*  tempChar = GVS_Struct::GetStructString(tPropertyStr->m_TypeName);
       tempStr.Format("%s", tempChar );
	}
	else  if( tPropertyStr->m_PropertyType == tkObject ) 
	{
     tempStr.Format("%s", tPropertyStr->m_TypeName );
	}

    CListCtrl::SetItemText( ItemCount,1, tempStr);
    tPropertyStr->ListCtrlIndex = ItemCount;
	
	//PropertyStr*  pData = &(*(m_PropertyList.insert(m_PropertyList.end(),tPropertyStr)));

    CListCtrl::SetItemData(ItemCount,(DWORD)tPropertyStr);

	return ItemCount;
}

void CPropertyListCtrl::OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CPropertyListCtrl::OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	 char*  tempStr;

	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	// TODO: Add your control notification handler code here
	SetItemText(pDispInfo->item.iItem, pDispInfo->item.iSubItem, pDispInfo->item.pszText);

	GetParent()->SendMessage(WM_VALIDATE, GetDlgCtrlID(), (LPARAM)pDispInfo);

	PropertyStr*  p = (PropertyStr*)GetItemData( pDispInfo->item.iItem );
    //this->SendMessage(WM_UPDATA_VALUE, pDispInfo->item.iItem, (LPARAM)p);
	if( (m_pCurrentGVSObject != NULL)&&(p!=NULL) )
	{
		try {
	          if( p->m_PropertyType == tkFloat )
			  {
		          //char*  tempStr;
	      
		          CString  tString = pDispInfo->item.pszText; 
                  double  tempd = strtod(tString,&tempStr);
		          p->SetDataCallbackFunction.FloatSet( m_pCurrentGVSObject,(float)tempd);
			  }
	          else  if( p->m_PropertyType == tkEnumeration )
			  {
		         //char*  tempStr;
		         CString  tString =  pDispInfo->item.pszText; ;

                 EnumInforObject*  pEnum = TRegesterEnum::FindEnum( p->m_TypeName );
                 if( pEnum != NULL )
				 {
			         int Index =  pEnum->GetValue((char*)(const char*)tString);
		             p->SetDataCallbackFunction.EnumSet(m_pCurrentGVSObject,Index);
				 }
			  }
	          else  if( p->m_PropertyType == tkInteger )
			  {
		           //char*  tempStr;
     
		           CString  tString =  pDispInfo->item.pszText;
                   int  tempd = _tcstol(tString,&tempStr,10);
		           p->SetDataCallbackFunction.IntergerSet( m_pCurrentGVSObject,(int)tempd);
			  }
			  else  if( p->m_PropertyType == tkChar )
			  {
		           CString  tString =  pDispInfo->item.pszText;
                   BYTE  tempd = _tcstol(tString,&tempStr,16);
		           p->SetDataCallbackFunction.ByteSet( m_pCurrentGVSObject,(BYTE)tempd);
			  }

		}
		catch(...)
		{
			::MessageBox(NULL,"��������ʱ����","������Ϣ����",MB_OK);
		}
	}
	
	*pResult = 0;
}
