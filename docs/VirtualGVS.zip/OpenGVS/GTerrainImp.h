
#ifndef  __GTERRAINIMP_H__
#define  __GTERRAINIMP_H__

#include "TGVSBaseClass.h"
#include  "GTerrain.h"

class  GTerrainImp : public GTerrain,public TGVSPersistent<GTerrainImp>
{
public:
   static	void     InitializePropertyStr(void);

   GTerrainImp(const char* name,bool bDef);
   GTerrainImp(const char*  name);
   virtual  ~GTerrainImp();

   int  Max_x;
   int  Max_y;
   int  Max_z;

   int  Min_x;
   int  Min_y;
   int  Min_z;
};

#endif