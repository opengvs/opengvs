// TFont.h: interface for the TFont class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TFONT_H__6ACC3328_7735_44C1_BFFA_6813C584D6EA__INCLUDED_)
#define AFX_TFONT_H__6ACC3328_7735_44C1_BFFA_6813C584D6EA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define GV_OBJ_DRAW_ORDER_FONT            1500000

class TFont  
{
public:
	int GetLineCount();
	void SetLineCount(int cnt);
	typedef struct
	{
		float r;
		float g;
		float b;
		float xPos;
		float yPos;
		CString str;
	}LINE;

	void SetPos(int lineIndex,float yPos,float xPos=-1.0);
	void SetColor(int lineIndex,float r=1,float g=1,float b=0);
	int  Create();
	void SetStr(int lineIndex,const CString& str);
	
	TFont();
	virtual ~TFont();
	operator GV_Obi() const {return m_obi;};
	bool IsObi(){return (m_obi!=NULL);}; 

protected:
	LINE *m_pLine;
	int m_lineCount;
	//float m_yPos;
	//float m_xPos;
	static int FontCallback(GV_Obi,void *pData);
	void FuncByGVSCallback();
	//CString m_str;
	GV_Obi m_obi;
	static GV_Obd m_obd;
	//float m_r,m_g,m_b;
};

#endif // !defined(AFX_TFONT_H__6ACC3328_7735_44C1_BFFA_6813C584D6EA__INCLUDED_)
