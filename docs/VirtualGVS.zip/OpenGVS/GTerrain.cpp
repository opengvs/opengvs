/********************************************************************
FileName:     GTerrain.cpp
descript:     ���ڶ�����������������
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/
#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include "GTerrain.h"
#include "GTerrainImp.h"
#include "GObd.h"
#include  "TVGVSAppFrame.h"

bool GFace::IsWithinFace( float x, float z )
{
  G_Boolean  ret;
  int  hr =  GV_geo_inq_xz_within_face( m_InsideFace,x,z, &ret );
  if( (hr != G_SUCCESS)||(ret == G_FALSE) )
	  return  false;
  else
	  return   true;

}

int  GFace::Get_face_vertices( G_Vector3 vtx[3] )
{
  return   GV_geo_inq_face_vertices( m_InsideFace, vtx );
}

int  GFace::Get_face_normal( G_Vector3 *face_normal )
{
  return  GV_geo_inq_face_normal( m_InsideFace, face_normal );
}

int  GFace::Get_face_elevation( float x, float z, float *y)
{
  return  GV_geo_inq_face_elevation( m_InsideFace, x, z, y);
}

int  GFace::Get_face_orientation(float roty,  float *rotx, float *rotz )
{
  return  GV_geo_inq_face_orientation( m_InsideFace,roty,rotx,rotz );

}

int  GFace::Set_face_composition( GComposition geocom )
{
  return GV_geo_set_face_composition( m_InsideFace, *(geocom.GetInsidecomposition()) ) ;
}

int  GFace::Get_face_composition( GComposition * p_geocom )
{
 return GV_geo_inq_face_composition( m_InsideFace,p_geocom->GetInsidecomposition() ) ;
}

int  GFace::Get_face_object_def( GV_Obd * obdhdl_out )
{
 return  GV_geo_inq_face_object_def( m_InsideFace, obdhdl_out ) ;
}


/////////////////////////////////////////////////////////////////////////
GComposition::GComposition(void)
{
 m_InsideComposition = NULL;
}

GComposition::GComposition(const char*  name)
{
 GV_geo_create_composition( &m_InsideComposition ) ;
 GV_geo_set_composition_name( m_InsideComposition,name ) ;
}

int GComposition::Create_composition( const char*  gname,GComposition*  p_geocom )
{
 int hr = GV_geo_create_composition( p_geocom->GetInsidecomposition() ) ;
 hr = GV_geo_set_composition_name( *(p_geocom->GetInsidecomposition()),gname ) ;
 return  hr;
}

GComposition::~GComposition(void)
{
 GV_geo_free_composition( m_InsideComposition ) ;
}

int GComposition::Set_composition_mask( const G_Mask cmask )
{
  return  GV_geo_set_composition_mask( m_InsideComposition,cmask ) ;
}

int GComposition::Get_composition_mask( G_Mask * p_cmask )
{
  return  GV_geo_inq_composition_mask( m_InsideComposition, p_cmask ) ;
}

int GComposition::Set_composition_name( const G_Name gname )
{
  return GV_geo_set_composition_name( m_InsideComposition, gname ) ;
}

int GComposition::Get_composition_name( G_Name gname )
{
	return  GV_geo_inq_composition_name( m_InsideComposition, gname ) ;
}

int GComposition::Get_composition_by_name( const char* name, GComposition* p_geocom )
{
  return GV_geo_inq_composition_by_name( name,(p_geocom->GetInsidecomposition()) ) ;
}

//////////////////////////////////////////////////////////////////////////////////////
GTerrain::GTerrain()
{
  m_InsideTerrain = NULL;
}

GTerrain::GTerrain(const char*  name)
{
  GV_geo_inq_by_name( name, &m_InsideTerrain  );
}

GTerrain::~GTerrain()
{
 delete m_pObi;
 delete m_pObd;
}

GTerrain*  GTerrain::CreateTerrain(const char* name)
{
  GTerrain*  pTerrain = new  GTerrainImp( name );
  pTerrain->m_pObd = new GObd();
  GV_obd_inq_by_name( name, pTerrain->m_pObd->Get_obd() );
   pTerrain->m_pObi = new GObi();
  GV_obi_instance_by_name( name, pTerrain->m_pObi->Get_obi() );

  return pTerrain;
}
GObi*  GTerrain::Get_obi(void)
{
	 return  m_pObi;
}
GObd*  GTerrain::Get_obd(void)
{
	return  m_pObd;
}

GTerrain*  GTerrain::Defineterrain(const char* name,Terrain_def_callback  callback_function )
{
  GTerrain* pTerrain = new GTerrainImp(name,false);

  GV_geo_open_by_name( name, pTerrain->GetInsideTerrain() );
  
     callback_function(pTerrain);
  
  GV_geo_close( *(pTerrain->GetInsideTerrain()) );
  
  GV_geo_set_name( *(pTerrain->GetInsideTerrain()), name );

  GV_obd_inq_by_name( name, pTerrain->m_pObd->Get_obd() );
  GV_obi_instance( *(pTerrain->m_pObd->Get_obd()), pTerrain->m_pObi->Get_obi() );

  return  pTerrain;
}

int   GTerrain::Obtain_terrain_by_name(const char* name,GTerrain*  terrain_out)
{
  
  return GV_geo_inq_by_name( name, terrain_out->GetInsideTerrain()  );
}


int GTerrain::Get_face( GFace  last_face, float x, float z, GFace *face_out)
{
  return  GV_geo_inq_face( m_InsideTerrain, *(last_face.GetInsideFace()),x,z,face_out->GetInsideFace() );
}

int GTerrain::Get_face_below( const G_Position * pos_in, GFace * face_out )
{
  return GV_geo_inq_face_below( m_InsideTerrain, pos_in,face_out->GetInsideFace());
}

int GTerrain::Set_name( const G_Name gname )
{
  return  GV_geo_set_name( m_InsideTerrain, gname );
}

int GTerrain::Get_name( G_Name gname )
{
  return GV_geo_inq_name( m_InsideTerrain, gname );
}

int GTerrain::Set_rotation( const G_Rotation *rotation )
{
  return  GV_geo_set_rotation( m_InsideTerrain, rotation );
}

int GTerrain::Get_rotation( G_Rotation *rotation )
{
  return  GV_geo_inq_rotation( m_InsideTerrain, rotation );
}

int GTerrain::Set_position( const G_Position *position )
{
  return GV_geo_set_position( m_InsideTerrain, position );
}

int GTerrain::Get_position( G_Position *position )
{
 return  GV_geo_inq_position( m_InsideTerrain, position );
}

int GTerrain::Set_scaling( const G_Vector3 *scaling )
{
 return GV_geo_set_scaling( m_InsideTerrain, scaling );
}

int GTerrain::Get_scaling( G_Vector3 *scaling )
{
 return  GV_geo_inq_scaling( m_InsideTerrain, scaling );
}

void GTerrain::Terrain_face_begin(GTerrain*  pTerrain )
{
 GV_geo_face_begin( *(pTerrain->GetInsideTerrain()) );
}

void GTerrain::Terrain_face_begin_mode(GTerrain*  pTerrain, GLenum mode )
{
 GV_geo_face_begin_mode( *(pTerrain->GetInsideTerrain()), mode );
}
 
void GTerrain::Terrain_face_add_vertex(GTerrain*  pTerrain, const float vtx[3] )
{
	GV_geo_face_add_vertex( *(pTerrain->GetInsideTerrain()), vtx );
}

void GTerrain::Terrain_face_end(GTerrain*  pTerrain )
{
  GV_geo_face_end( *(pTerrain->GetInsideTerrain()) );
}

int GTerrain::Set_composition_current( GComposition geocom )
{
  return  GV_geo_set_composition_current( m_InsideTerrain,*(geocom.GetInsidecomposition()) ) ;
}

int GTerrain::Get_composition_current( GComposition * p_geocom )
{
  return  GV_geo_inq_composition_current( m_InsideTerrain,p_geocom->GetInsidecomposition() ) ;

}

int GTerrain::Set_object_def_cur( GV_Obd obdhdl_in )
{
  return  GV_geo_set_object_def_cur( m_InsideTerrain,obdhdl_in ) ;
}

int GTerrain::Get_object_def_cur( GV_Obd * obdhdl_out )
{
 return  GV_geo_inq_object_def_cur( m_InsideTerrain, obdhdl_out ) ;
}


/////////////////////////////////////////////////////////////////////////////////////
int Obtain_scene_Terrain_face( GScene* scnhdl,
    float x, float z, GFace * face_out ) 
{
 return  GV_geo_inq_scene_face( *(scnhdl->GetGVScene()),x,z,face_out->GetInsideFace() ) ;
}



int Obtain_scene_Terrain_face_below( GScene* scnhdl,
    const G_Position * pos_in, GFace * face_out )
{
  return  GV_geo_inq_scene_face_below( *(scnhdl->GetGVScene()),pos_in, face_out->GetInsideFace() ) ;
}

int Obtain_intersection( GScene* cur_scene, const G_Vector3 *v0,
    const G_Vector3 *v1, GV_Geo_isc_control_mask isc_mask,
    G_Mask exclusion_mask, GV_Geo_isc_data * p_iscdat )
{
 return  GV_geo_inq_intersection( *(cur_scene->GetGVScene()), v0,v1,isc_mask,exclusion_mask,p_iscdat ) ;

}

int Obtain_intersection_d( GScene* cur_scene, const G_Vector3_d *v0,
    const G_Vector3_d *v1, GV_Geo_isc_control_mask isc_mask,
    G_Mask exclusion_mask, GV_Geo_isc_data_d * p_iscdat )
{
 return  GV_geo_inq_intersection_d( *(cur_scene->GetGVScene()), v0,v1,isc_mask,exclusion_mask,p_iscdat ) ;
}

int Obtain_point_in_frustum( const G_Vector3 *v0,
    const GV_Frustum *p_frustum, GV_Geo_isc_result * p_result)
{
  return  GV_geo_inq_point_in_frustum( v0,p_frustum,p_result);
}

int Obtain_line_in_frustum( const G_Vector3 *v0, const G_Vector3 *v1,
    const GV_Frustum *p_frustum, GV_Geo_isc_control_mask isc_mask,
    G_Vector3 *v_out, GV_Geo_isc_result * p_result)
{
 return GV_geo_inq_line_in_frustum( v0, v1,p_frustum,isc_mask,v_out,p_result);
}

int Obtain_geo_inq_line_in_sphere( const G_Vector3 *x0, float r,
    const G_Vector3 *v1, const G_Vector3 *v2, G_Boolean * p_result )
{
 return  GV_geo_inq_line_in_sphere( x0, r,v1,v2,p_result );
}

int Obtain_inq_face( GTerrain* geohdl, GV_Geo_face last_face, 
    float x, float z, GFace *face_out)
{
 return  GV_geo_inq_face( *(geohdl->GetInsideTerrain()),last_face,x,z,face_out->GetInsideFace());
}

int Obtain_inq_face_below( GTerrain* geohdl, const G_Position * pos_in,
    GFace * face_out )
{
 return  GV_geo_inq_face_below( *(geohdl->GetInsideTerrain()), pos_in,face_out->GetInsideFace() );
}

int Obtain_obi_collision( GV_Obi obihdl1, GV_Obi obihdl2,G_Boolean * p_bool)
{
  return  GV_geo_inq_obi_collision( obihdl1, obihdl2,p_bool);
}

int Obtain_group_parent( GV_Geometry geohdl, GV_Geometry * GeoParent )
{
 return  GV_geo_inq_group_parent( geohdl, GeoParent ) ;
}

int Obtain_group_child( GV_Geometry geohdl, GV_Geometry * GeoChild )
{
 return  GV_geo_inq_group_child( geohdl, GeoChild ) ;
}

int Obtain_inq_group_next( GV_Geometry geohdl, GV_Geometry * GeoNext )
{
 return GV_geo_inq_group_next( geohdl, GeoNext ) ;
}

int Terrain_group_prev( GV_Geometry geohdl, GV_Geometry * GeoPrev )
{
  return  GV_geo_inq_group_prev( geohdl, GeoPrev ) ;
}

int Terrain_group_detach( GV_Geometry GeoParent, GV_Geometry GeoChild )
{
  return  GV_geo_group_detach( GeoParent, GeoChild ) ;
}

int Terrain_group_attach( GV_Geometry GeoParent, GV_Geometry GeoChild )
{
  return  GV_geo_group_attach( GeoParent, GeoChild ) ;
}


void      AddTerrain2GVSPanel(GTerrain* pTerrain,TGVSListNode*  pParentNode)
{
  TGVSBaseClass*  pGVSObi = dynamic_cast<GTerrainImp*>(pTerrain);
  if( g_InsideGVSApp != NULL )
  {
	  g_InsideGVSApp->AddGVSObiNode(pGVSObi,pParentNode);
  }

}

