// GMaterialImp.h: interface for the GMaterialImp class.
//
//////////////////////////////////////////////////////////////////////

#ifndef  __GMATERIALIMP_HPP_
#define  __GMATERIALIMP_HPP_

#include "TGVSBaseClass.h"
#include "GMaterial.h"

class GMaterialImp : public  GMaterial,public TGVSPersistent<GMaterialImp>  
{
public:
   static void     InitializePropertyStr(void);
public:
	GMaterialImp(const char* name);
	virtual ~GMaterialImp();

public:
    float  Ambient_R;
	float  Ambient_G;
	float  Ambient_B;
    float  Ambient_A;

	float  Diffuse_R;
    float  Diffuse_G;
    float  Diffuse_B;
	float  Diffuse_A;

	float  Specular_R;
    float  Specular_G;
    float  Specular_B;
	float  Specular_A;

};

#endif 
