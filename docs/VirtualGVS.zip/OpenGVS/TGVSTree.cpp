// TGVSTree.cpp: implementation of the TGVSTree class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "testBCG.h"
//#include "GLightProperty.h"
#include "TGVSTree.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
TTreeNode::~TTreeNode()
{
  pHTREEITEM = NULL;
}

TGVSListNode::~TGVSListNode()
{
 list<TGVSNode*>::iterator  pIt = m_pGVSObjectList.begin();
 if( pIt != m_pGVSObjectList.end() )
 {
    TGVSNode* pNode = *pIt;
    m_pGVSObjectList.erase(pIt);
	delete pNode;
    pIt = m_pGVSObjectList.begin();
 }
}


TGVSTree::TGVSTree(const char* pNodeName):TTreeNode(TopNode)
{
  strcpy(m_NodeName,pNodeName);
}

TGVSTree::~TGVSTree()
{
	{
		list<TGVSNode*>::iterator  pIt = m_pGVSObjectList.begin();
		while( pIt != m_pGVSObjectList.end() )
		{
			TGVSNode*  pGVSNode = *pIt;
			delete  pGVSNode;
			m_pGVSObjectList.erase( pIt );
			pIt = m_pGVSObjectList.begin();
		}
	}
    {
		list<TGVSListNode*>::iterator  pIt = m_GVSListNode.begin();
		while( pIt != m_GVSListNode.end() )
		{
			TGVSListNode*  pNode = *pIt;
			m_GVSListNode.erase( pIt );
			delete  pNode;
			pIt = m_GVSListNode.begin();
		}
	}
}

TGVSListNode*  TGVSTree::AddGVSListNode( const char*  ListName )
{
	TGVSListNode*  pListNode = new  TGVSListNode(ListName);
	pListNode->m_NodeType = ListNode;
	m_GVSListNode.push_back( pListNode );
    return pListNode;
}

TGVSNode*   TGVSTree::AddGVSObject(const char*  ParentName,TGVSBaseClass*  pGVSObject)
{
  TGVSNode*  pGVSNode = NULL;
  list<TGVSListNode*>::iterator pIt =  m_GVSListNode.begin();
  while( pIt != m_GVSListNode.end() )
  {
      TGVSListNode*  pNode = *pIt;
	  if( pNode->m_NodeName == ParentName )
	  {
         pGVSNode = new TGVSNode(pGVSObject->GetObjectName() );
         pGVSNode->pNode = pGVSObject;
         pGVSNode->m_NodeType = ChildNode;
         pNode->m_pGVSObjectList.push_back(pGVSNode);
         break;
	  }

	  pIt++;
  }

  return pGVSNode;
}

TGVSNode*    TGVSTree::AddGVSObject(TGVSBaseClass*  pGVSObject,TGVSListNode*  pParentNode /*=NULL*/)
{
  
  TGVSNode*  pGVSNode = new TGVSNode(pGVSObject->GetObjectName() );
  pGVSNode->pNode = pGVSObject;
  pGVSNode->m_NodeType = ChildNode;

  if( pParentNode != NULL )
      pParentNode->m_pGVSObjectList.push_back(pGVSNode);
  else
	  m_pGVSObjectList.push_back(pGVSNode);
  return pGVSNode;
}
