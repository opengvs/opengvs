/********************************************************************
FileName:     GCameraImp.h
descript:     ���ڶ����������
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/

#ifndef  __GCAMERAIMP_HPP__
#define  __GCAMERAIMP_HPP__

#include  "GCamera.h"
#include "TGVSBaseClass.h"

#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

class  GCameraImp : public TGVSPersistent<GCameraImp>, public  GCamera
{
   
public:
	static void     InitializePropertyStr(void);
public:
   GCameraImp(const char* name);
   virtual  ~GCameraImp();
public:
	int    m_CurrentPlatForm;
	
	float  pos_x;
	float  pos_y;
	float  pos_z;
    GV_Cam_projection_mode   m_Prj_Mode;
	G_Rotation   cam_rot;

};



#endif