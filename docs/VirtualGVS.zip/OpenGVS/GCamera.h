/********************************************************************
FileName:     GCamera.h
descript:     ���ڶ����������
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/

#ifndef   __GCAMERA_h__
#define   __GCAMERA_h__

struct GV_camera_s;
struct  TGVSListNode;
class  GCamera
{
protected:
	GV_camera_s*   m_InsideCamera;

	GCamera(){ m_InsideCamera = NULL;};
public:
    virtual ~GCamera();
public:
	static  GCamera*  CreateCamera(char* name);
	void      AddCamera2GVSPanel( TGVSListNode*  pParentNode = NULL );
    GV_camera_s**  Get_camera(){return &m_InsideCamera; };
    
	int  Get_position( int platform,G_Position*  position );
	int  Set_position( int platform,G_Position*  position );
	int  Get_position_x(int platform,float* x);
	int  Set_position_x(int platform,float  x);
	int  Get_position_y(int platform,float* y);
	int  Set_position_y(int platform,float  y);
	int  Get_position_z(int platform,float* z);
	int  Set_position_z(int platform,float  z);

	int  Get_rotation(  int platform,G_Rotation*  rotation );
	int  Set_rotation(  int platform,G_Rotation*  rotation );
	int  Get_rotation_x(int platform,float* x);
	int  Set_rotation_x(int platform,float  x);
	int  Get_rotation_y(int platform,float* y);
	int  Set_rotation_y(int platform,float  y);
	int  Get_rotation_z(int platform,float* z);
	int  Set_rotation_z(int platform,float  z);

    int  Set_aov( float aov_in );
    int  Get_aov( float * aov_out );

    int Set_aov_maximum( float aovmax_in );
    int Get_aov_maximum( float * aovmax_out );

    int Set_aov_minimum( float aovmin_in );
    int Get_aov_minimum( float * aovmin_out );

    int Set_aov_nominal( float aovnom_in );
    int Get_aov_nominal( float * aovnom_out );

};

#endif