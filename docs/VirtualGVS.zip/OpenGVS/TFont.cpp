// TFont.cpp: implementation of the TFont class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>

#include "TFont.h"
#include  "TVGVSAppFrame.h"
#include  "GChannel.h"
#include  "GChannelImp.h"
#include  "GScene.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
GV_Obd TFont::m_obd = NULL;

TFont::TFont()//:m_str("PROGRAM BY TOP,2004-08-14,ChangChun City,China!")
{
	
	//m_xPos=-1.0f;
	//m_yPos=0.8f;
	m_obi=NULL;
	//m_r=1.0;
	//m_g=1.0;
	//m_b=0.0;
	//----------
	m_pLine=NULL;
	m_lineCount=0;

}

TFont::~TFont()
{
	if(m_pLine)
	{
		delete []m_pLine;
		m_pLine=NULL;
	}
	
	if(m_obi)
	{
		GV_scn_remove_object_from_all( m_obi );
		GV_obi_free( m_obi );
		m_obi=NULL;
	}
}

int TFont::FontCallback(GV_Obi, void *pData)
{
	TFont *p=(TFont *)pData;
	if(p)
		p->FuncByGVSCallback();
	return G_SUCCESS;

}

void TFont::SetStr(int lineIndex,const CString &str)
{
	if(lineIndex>=0&&lineIndex<m_lineCount)
	{
		if(m_pLine)
		{
			(m_pLine+lineIndex)->str=str;						
		}
	}
}

void TFont::FuncByGVSCallback()
{
	if(!m_obi) return;
	for(int i=0;i<m_lineCount;i++)
	{
		if(m_pLine)
		{
			glColor3f( (m_pLine+i)->r,  (m_pLine+i)->g,  (m_pLine+i)->b );
			glRasterPos2f( (m_pLine+i)->xPos, (m_pLine+i)->yPos );
			GV_fnt_string_std( (LPTSTR)(LPCTSTR)((m_pLine+i)->str));
		}
	}
	
}

int TFont::Create()
{
	if(!m_obd)
	{
		GV_obd_open_by_name( "FONT", &m_obd);
		GV_obd_close( m_obd );
		GV_obd_set_gfx_callback( m_obd, FontCallback);
		GV_obd_set_coordinate_system( m_obd, GV_COORD_SYS_NORMALIZED_2D );		
	}
	GV_obi_instance( m_obd, &m_obi );
	GV_obi_set_gfx_data(m_obi,sizeof(TFont),(void *)this);
    /* Add our new instance to the caller specified scene */
	GV_obi_set_drawing_order(m_obi,GV_OBJ_DRAW_ORDER_FONT);

    GV_scn_add_object( *(g_InsideGVSApp->m_pMainScene->GetGVScene()), m_obi );
	
	return G_SUCCESS;

}

void TFont::SetColor(int lineIndex,float r, float g, float b)
{
	if(lineIndex>=0&&lineIndex<m_lineCount)
	{
		if(m_pLine)
		{
			(m_pLine+lineIndex)->r=r;
			(m_pLine+lineIndex)->g=g;
			(m_pLine+lineIndex)->b=b;			
		}
	}
	
}

void TFont::SetPos(int lineIndex,float yPos, float xPos)
{
	if(lineIndex>=0&&lineIndex<m_lineCount)
	{
		if(m_pLine)
		{
			(m_pLine+lineIndex)->yPos=yPos;
			(m_pLine+lineIndex)->xPos=xPos;		
			
		}
	}
	
}

void TFont::SetLineCount(int cnt)
{
	ASSERT(cnt>0);
	
	LINE *p=m_pLine;
	m_pLine=new LINE[cnt];
	if(m_pLine)
	{
		for(int i=0;i<cnt;i++)
		{
			(m_pLine+i)->r=1.f;
			(m_pLine+i)->g=1.f;
			(m_pLine+i)->b=0.f;
			(m_pLine+i)->xPos=-1.f;
			(m_pLine+i)->yPos=0.8f;
			(m_pLine+i)->str="PROGRAM BY TOP,2004-08-17,ChangChun City,China!";
		}
		m_lineCount=cnt;
		if(p)
			delete []p;
	}
}

int TFont::GetLineCount()
{
	return m_lineCount;
}
