#if !defined(AFX_TGVSTOOLPANE_H__F1868136_AA63_42D5_957C_1485F3670280__INCLUDED_)
#define AFX_TGVSTOOLPANE_H__F1868136_AA63_42D5_957C_1485F3670280__INCLUDED_

#include "SplitDialog.h"
#include "PropertyListCtrl.h"
#include "GGVSObjectTree.h"

//#include  "TGVSTree.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TGVSToolPane.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// TGVSToolPane dialog
class  TGVSTree;
struct  TGVSListNode;
struct  TGVSNode;
class TGVSToolPane : public CSplitDialog
{
// Construction
public:
	TGVSToolPane(CWnd* pParent = NULL);   // standard constructor
    ~TGVSToolPane();
// Dialog Data
	//{{AFX_DATA(TGVSToolPane)
	enum { IDD = IDD_GVSTOOLPANE };
	CPropertyListCtrl	m_PropertyListView;
	GGVSObjectTree	    m_GVSObjTree;
	//}}AFX_DATA
   CPane *m_PaneMain;
   TGVSTree*           m_GVSObjectTree;
    CImageList	m_ImageListTree;
   HTREEITEM           m_TopItem;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(TGVSToolPane)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
public:
   TGVSListNode*     AddGVSListNode( const char*  ListName );
   TGVSNode*         AddGVSObject(TGVSBaseClass*  pGVSObject,TGVSListNode*  pParentNode=NULL);
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(TGVSToolPane)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TGVSTOOLPANE_H__F1868136_AA63_42D5_957C_1485F3670280__INCLUDED_)
