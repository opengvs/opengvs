/********************************************************************
FileName:     GCamera.cpp
descript:     ���ڶ����������
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/
#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include "GCamera.h"
#include  "GCameraImp.h"
#include  "TVGVSAppFrame.h"

GCamera::~GCamera()
{
 m_InsideCamera = NULL;
}

GCamera*  GCamera::CreateCamera(char* name)
{
  GCamera*  pCamera = new  GCameraImp(name);
  GV_cam_create( &(pCamera->m_InsideCamera) );
  GV_cam_set_name( pCamera->m_InsideCamera, name );
  return  pCamera;
}

void  GCamera::AddCamera2GVSPanel( TGVSListNode*  pParentNode )
{
  TGVSBaseClass*  pGVSObi = dynamic_cast<GCameraImp*>(this);
  if( g_InsideGVSApp != NULL )
  {
	  g_InsideGVSApp->AddGVSObiNode(pGVSObi,pParentNode);
  }
}

int  GCamera::Get_position( int platform,G_Position*  position )
{
 return GV_cam_inq_position( m_InsideCamera, platform, position);
}

int  GCamera::Set_position( int platform,G_Position*  position )
{
  return  GV_cam_set_position( m_InsideCamera, platform, position );
}

int  GCamera::Get_position_x(int platform,float* x)
{
	return  GV_cam_inq_position_x( m_InsideCamera, platform, x);
}

int  GCamera::Set_position_x(int platform,float  x)
{
	return  GV_cam_set_position_x( m_InsideCamera, platform, x);
}

int  GCamera::Get_position_y(int platform,float* y)
{
	return  GV_cam_inq_position_y( m_InsideCamera, platform, y);
}

int  GCamera::Set_position_y(int platform,float  y)
{
	return  GV_cam_set_position_y( m_InsideCamera, platform, y);
}

int  GCamera::Get_position_z(int platform,float* z)
{
	return  GV_cam_inq_position_z( m_InsideCamera, platform, z);
}

int  GCamera::Set_position_z(int platform,float  z)
{
	return  GV_cam_set_position_x( m_InsideCamera, platform, z);
}

int  GCamera::Get_rotation( int platform, G_Rotation*  rotation )
{
	return  GV_cam_inq_rotation( m_InsideCamera, platform, rotation );
}

int  GCamera::Set_rotation( int platform, G_Rotation*  rotation )
{
	return  GV_cam_set_rotation( m_InsideCamera, platform, rotation );
}

int  GCamera::Get_rotation_x(int platform,float* x)
{
   return  GV_cam_inq_rotation_x( m_InsideCamera, platform, x );
}

int  GCamera::Set_rotation_x(int platform,float  x)
{
   return  GV_cam_set_rotation_x( m_InsideCamera, platform, x );
}

int  GCamera::Get_rotation_y(int platform,float* y)
{
  return  GV_cam_inq_rotation_y( m_InsideCamera, platform, y );
}

int  GCamera::Set_rotation_y(int platform,float  y)
{
  return  GV_cam_set_rotation_y( m_InsideCamera, platform, y );
}

int  GCamera::Get_rotation_z(int platform,float* z)
{
  return  GV_cam_inq_rotation_z( m_InsideCamera, platform, z );
}

int  GCamera::Set_rotation_z(int platform,float  z)
{
  return  GV_cam_set_rotation_z( m_InsideCamera, platform, z );
}

int  GCamera::Set_aov( float aov_in )
{
  return  GV_cam_set_aov( m_InsideCamera, aov_in );
}

int  GCamera::Get_aov( float * aov_out )
{
  return  GV_cam_inq_aov( m_InsideCamera, aov_out );
}

int GCamera::Set_aov_maximum( float aovmax_in )
{
  return  GV_cam_set_aov_maximum( m_InsideCamera, aovmax_in );
}

int GCamera::Get_aov_maximum( float * aovmax_out )
{
  return  GV_cam_inq_aov_maximum( m_InsideCamera, aovmax_out );
}

int GCamera::Set_aov_minimum( float aovmin_in )
{
  return  GV_cam_set_aov_minimum( m_InsideCamera, aovmin_in );
}

int GCamera::Get_aov_minimum( float * aovmin_out )
{
  return  GV_cam_inq_aov_minimum( m_InsideCamera, aovmin_out );
}

int GCamera::Set_aov_nominal( float aovnom_in )
{
  return  GV_cam_set_aov_nominal( m_InsideCamera, aovnom_in );
}

int GCamera::Get_aov_nominal( float * aovnom_out )
{
  return  GV_cam_inq_aov_nominal( m_InsideCamera, aovnom_out );
}
