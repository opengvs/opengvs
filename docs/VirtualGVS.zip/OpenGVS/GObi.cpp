/********************************************************************
FileName:     GObi.cpp
descript:     ���ڶ�����������
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/
#include "stdafx.h"

#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include  "GObiImp.h"
#include  "TVGVSAppFrame.h"

GObi::GObi(const G_Name  name )
{
  GV_obi_instance_by_name( name, &m_insideObi );
  GV_obi_set_name( m_insideObi, name);
}

GObi*  GObi::CreateObi(char* name)
{
  GObi*  pObi = new GObiImp(name);
  GV_obi_instance_by_name( name, pObi->Get_obi());
  GV_obi_set_name( *(pObi->Get_obi()), name);
  return pObi;
}

void      GObi::AddObi2GVSPanel( TGVSListNode*  pParentNode /*= NULL*/ )
{
  TGVSBaseClass*  pGVSObi = dynamic_cast<GObiImp*>(this);
  if( g_InsideGVSApp != NULL )
  {
	  g_InsideGVSApp->AddGVSObiNode(pGVSObi,pParentNode);
  }
}