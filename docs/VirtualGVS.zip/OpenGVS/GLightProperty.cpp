#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include "GLightProperty.h"

static void SetLightPosition_x( void*  pLight, float  x )
{

}
static void GetLightPosition_x( void*  pLight, float*  x )
{

}
static void SetLightPosition_y( void*  pLight, float  x )
{

}
static void GetLightPosition_y( void*  pLight, float* y )
{

}
static void SetLightPosition_z( void*  pLight, float  x )
{

}
static void GetLightPosition_z( void*  pLight, float* z )
{

}

char                    TGVSPersistent<GLightImp>::m_ClassName[GVSNAME_MAXLENGTH];
int                     TGVSPersistent<GLightImp>::m_ObjectCount = 0;
vector<PropertyStr*>    TGVSPersistent<GLightImp>::m_PropertyStr_List;


GLightImp::GLightImp(const char* name):TGVSPersistent<GLightImp>(name)
{
  
}

GLightImp::~GLightImp()
{
}

void     GLightImp::InitializePropertyStr(void)
{
  
}

