#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include  "GObiImp.h"



char                    TGVSPersistent<GObiImp>::m_ClassName[GVSNAME_MAXLENGTH];
int                     TGVSPersistent<GObiImp>::m_ObjectCount = 0;  
vector<PropertyStr*>    TGVSPersistent<GObiImp>::m_PropertyStr_List;


GObiImp::GObiImp(const char* name):TGVSPersistent<GObiImp>(name)
{

}

GObiImp::~GObiImp()
{

}

static void  Get_current_platform(void*  self, int   *platform )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);
  *platform = p->m_CurrentPlatForm;
}

static void  Set_current_platform(void*  self, int    platform )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);
  p->m_CurrentPlatForm = platform;  
}

static void  Get_position_x(void*  self, float* x )
{
 
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);

  GV_obi_inq_position_x( *(p->Get_obi()),&(p->pos_x) );
  *x = p->pos_x;
}

static void  Set_position_x(void*  self, float  x )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);
  p->pos_x = x;
  GV_obi_set_position_x( *(p->Get_obi()),x );  
}

static void  Get_position_y(void*  self, float* y )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);

  GV_obi_inq_position_y( *(p->Get_obi()),&(p->pos_y) );
  *y = p->pos_y;
}

static void  Set_position_y(void*  self, float  y )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);
  p->pos_y = y;
  GV_obi_set_position_y( *(p->Get_obi()),y );  
}

static void  Get_position_z(void*  self, float* z )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);

  GV_obi_inq_position_z( *(p->Get_obi()),&(p->pos_z) );
  *z = p->pos_z;
}

static void  Set_position_z(void*  self, float  z )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);
  p->pos_z = z;
  GV_obi_set_position_z( *(p->Get_obi()),z );  
}

static  void  GetPrjMode(void* self,int*  mode )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);

  *mode = (int)p->m_Prj_Mode;
}

static  void  SetPriMode(void*  self,int mode)
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);
  p->m_Prj_Mode = (GV_Cam_projection_mode)mode;
}


static void  Get_rotation_x(void*  self, float* x )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);
  GV_obi_inq_rotation_x( *(p->Get_obi()),&(p->obi_rot.x) );
  *x = p->obi_rot.x;
}

static void  Set_rotation_x(void*  self, float  x )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);
  p->obi_rot.x = x;
  GV_obi_set_rotation_x( *(p->Get_obi()), x );
}

static void  Get_rotation_y(void*  self, float* y )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);
  GV_obi_inq_rotation_y( *(p->Get_obi()),&(p->obi_rot.y) );
  *y = p->obi_rot.y;
}

static void  Set_rotation_y(void*  self, float  y )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);
  p->obi_rot.y = y;
  GV_obi_set_rotation_y( *(p->Get_obi()), y );
}

static void  Get_rotation_z(void*  self, float* z )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);
  GV_obi_inq_rotation_y( *(p->Get_obi()),&(p->obi_rot.z) );
  *z = p->obi_rot.z;
}

static void  Set_rotation_z(void*  self, float  z )
{
  GObiImp*  p = dynamic_cast<GObiImp*>((TGVSBaseClass*)self);
  p->obi_rot.z = z;
  GV_obi_set_rotation_z( *(p->Get_obi()), z );
}

static  void Get_cam_color(void*  self,void* color)
{

}

static void Set_cam_color(void* self,void* color)
{
  CColorDialog   colorDlg;
  colorDlg.DoModal();
}

void     GObiImp::InitializePropertyStr(void)
{
  PropertyStr*  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"Platform" );
  strcpy(t_PropertyStr->m_TypeName,"int" ); //typeid(float).name;
  t_PropertyStr->m_PropertyType = tkInteger;
  t_PropertyStr->GetDataCallbackFunction.IntergerGet = Get_current_platform;
  t_PropertyStr->SetDataCallbackFunction.IntergerSet = Set_current_platform;
  m_PropertyStr_List.push_back( t_PropertyStr );


  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"pos_x");
  strcpy(t_PropertyStr->m_TypeName,"float");//typeid(float).name;
  t_PropertyStr->m_PropertyType = tkFloat;
  t_PropertyStr->GetDataCallbackFunction.FloatGet = Get_position_x;
  t_PropertyStr->SetDataCallbackFunction.FloatSet = Set_position_x;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name, "pos_y");
  strcpy(t_PropertyStr->m_TypeName,"float");//typeid(float).name;
  t_PropertyStr->m_PropertyType = tkFloat;
  t_PropertyStr->GetDataCallbackFunction.FloatGet = Get_position_y;
  t_PropertyStr->SetDataCallbackFunction.FloatSet = Set_position_y;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"pos_z");
  strcpy(t_PropertyStr->m_TypeName,"float");//typeid(float).name;
  t_PropertyStr->m_PropertyType = tkFloat;
  t_PropertyStr->GetDataCallbackFunction.FloatGet = Get_position_z;
  t_PropertyStr->SetDataCallbackFunction.FloatSet = Set_position_z;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"m_Prj_Mode");
  strcpy(t_PropertyStr->m_TypeName,"GV_Cam_projection_mode");
  t_PropertyStr->m_PropertyType = tkEnumeration;
  t_PropertyStr->GetDataCallbackFunction.EnumGet = GetPrjMode;
  t_PropertyStr->SetDataCallbackFunction.EnumSet = SetPriMode;
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"m_Rotation");
  strcpy(t_PropertyStr->m_TypeName,"G_Rotation");
  t_PropertyStr->m_PropertyType = tkStruct;
  t_PropertyStr->GetDataCallbackFunction.StringGet = NULL;
  t_PropertyStr->SetDataCallbackFunction.StringSet = NULL;
  //t_PropertyStr->PropertyData.sData = GVS_Struct::GetStructString("G_Position");
  t_PropertyStr->IsExpand = false;
  {
     PropertyStr* t_PropertyStr1 = new PropertyStr();
     strcpy(t_PropertyStr1->m_Name,"rotation_x");
     strcpy(t_PropertyStr1->m_TypeName,"float");
     t_PropertyStr1->m_PropertyType = tkFloat;
     t_PropertyStr1->GetDataCallbackFunction.FloatGet = Get_rotation_x;
     t_PropertyStr1->SetDataCallbackFunction.FloatSet = Set_rotation_x;
     t_PropertyStr->AddChildProperty(t_PropertyStr1);

     t_PropertyStr1 = new PropertyStr();
     strcpy(t_PropertyStr1->m_Name,"rotation_y");
     strcpy(t_PropertyStr1->m_TypeName,"float");
     t_PropertyStr1->m_PropertyType = tkFloat;
     t_PropertyStr1->GetDataCallbackFunction.FloatGet = Get_rotation_y;
     t_PropertyStr1->SetDataCallbackFunction.FloatSet = Set_rotation_y;
     t_PropertyStr->AddChildProperty(t_PropertyStr1);
	 
     t_PropertyStr1 = new PropertyStr();
     strcpy(t_PropertyStr1->m_Name,"rotation_z");
     strcpy(t_PropertyStr1->m_TypeName,"float");
     t_PropertyStr1->m_PropertyType = tkFloat;
     t_PropertyStr1->GetDataCallbackFunction.FloatGet = Get_rotation_z;
     t_PropertyStr1->SetDataCallbackFunction.FloatSet = Set_rotation_z;
     t_PropertyStr->AddChildProperty(t_PropertyStr1);
  }
  m_PropertyStr_List.push_back( t_PropertyStr );

  t_PropertyStr = new PropertyStr();
  strcpy(t_PropertyStr->m_Name,"m_cam_color");
  strcpy(t_PropertyStr->m_TypeName,"CColor");
  t_PropertyStr->m_PropertyType = tkObject;
  t_PropertyStr->GetDataCallbackFunction.ObjectGet = Get_cam_color;
  t_PropertyStr->SetDataCallbackFunction.ObjectSet = Set_cam_color;
  m_PropertyStr_List.push_back( t_PropertyStr );

}
