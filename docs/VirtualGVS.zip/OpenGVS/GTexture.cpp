/********************************************************************
FileName:     GTexture.cpp
descript:     ���ڶ���GTexture��
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/

#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include  "GTexture.h"

GTexture::GTexture( const char*  name)
{
  int  hr = GV_txr_inq_by_name( name, &m_pInsideTxr );
  if( hr != G_SUCCESS )
  {
	  GV_txr_free( m_pInsideTxr );
      GV_txr_create( &m_pInsideTxr );
  }
  GV_txr_set_name(m_pInsideTxr, name );

}

GTexture::GTexture(const char* name,const char*  filename)
{
	GV_txr_create( &m_pInsideTxr );
    GV_txr_set_filename(m_pInsideTxr, filename);
    GV_txr_set_name(m_pInsideTxr, name );
}

GTexture::~GTexture()
{
  if( m_pInsideTxr != NULL )
	  GV_txr_free( m_pInsideTxr );
  m_pInsideTxr = NULL;
}


int GTexture::Texture_define( )
{
  return GV_txr_define( m_pInsideTxr );
}


int GTexture::Texture_undefine( void )
{
  return  GV_txr_undefine( m_pInsideTxr );
}

int GTexture::Set_env( GLfloat env_mode_in )
{
	return  GV_txr_set_env( m_pInsideTxr, env_mode_in );
}

int GTexture::Get_env( GLfloat *env_mode_out )
{
  return  GV_txr_inq_env( m_pInsideTxr, env_mode_out );
}

/*  GV_txr_set_format -- Set the internal format to be used
    for a particular texture.
    The format_in may be anything that is legal as the "components"
    parameter of function glTexImage2D, such as:  1, 2, 3, 4,
    GL_RGB4_EXT, GL_RGBA4_EXT, etc.

    A no-operation unless OpenGL extension "GL_EXT_texture" is present.
    */
int GTexture::Set_format( int format_in )
{
  return  GV_txr_set_format( m_pInsideTxr, format_in ) ;
}

int GTexture::Get_format( int * format_out )
{
  return  GV_txr_inq_format( m_pInsideTxr, format_out ) ;
}


int GTexture::Remove_property(GLenum pname )
{
  return  GV_txr_remove_property( m_pInsideTxr, pname ) ;
}

int GTexture::Reset_properties(void)
{
  return  GV_txr_reset_properties( m_pInsideTxr );
}

int GTexture::Set_property( GLenum pname, GLfloat param )
{
  return  GV_txr_set_property( m_pInsideTxr, pname, param );
}

int GTexture::Set_property_v( GLenum pname,int nparams, const GLfloat parray[] )
{
  return  GV_txr_set_property_v( m_pInsideTxr, pname,nparams,parray ) ;
}

int GTexture::Get_property_v( GLenum pname,int attr_dim, int *attr_count, GLfloat parray_out[] )
{
  return  GV_txr_inq_property_v( m_pInsideTxr, pname,attr_dim,attr_count,parray_out) ;
}

int GTexture::Get_property(  GLenum pname, GLfloat * pvalue )
{
  return  GV_txr_inq_property( m_pInsideTxr, pname, pvalue ) ;
}

int GTexture::Remove_env_property( GLenum pname )
{
  return  GV_txr_remove_env_property( m_pInsideTxr, pname ) ;
}

int GTexture::Reset_env_properties(void)
{
  return  GV_txr_reset_env_properties( m_pInsideTxr );
}

int GTexture::Set_env_property(  GLenum pname, GLfloat param )
{
  return  GV_txr_set_env_property( m_pInsideTxr, pname, param );
}

int GTexture::Set_env_property_v(  GLenum pname,int nparams, const GLfloat parray[] )
{
  return  GV_txr_set_env_property_v( m_pInsideTxr, pname,nparams,parray ) ;
}

int GTexture::Get_env_property_v( GLenum pname,int attr_dim, int *attr_count, GLfloat parray_out[] )
{
	return  GV_txr_inq_env_property_v( m_pInsideTxr, pname,attr_dim,attr_count,parray_out) ;
}

int GTexture::Get_env_property( GLenum pname, GLfloat * pvalue)
{
  return  GV_txr_inq_env_property( m_pInsideTxr, pname,pvalue);
}


    //int GV_txr_free( GV_Texture txrhdl);

    //int GV_txr_free_all(void);

int GTexture::Get_bind_name(  GLuint * txr_bind_name_out )
{
  return  GV_txr_inq_bind_name( m_pInsideTxr, txr_bind_name_out ) ;
}

int GTexture::Set_filename( const char *filename_in)
{
  return  GV_txr_set_filename(m_pInsideTxr,filename_in);
}

int GTexture::Get_filename(  char *filename_out)
{
  return  GV_txr_inq_filename( m_pInsideTxr, filename_out);
}

int GTexture::Get_filename_full(  char *filename_out)
{
  return  GV_txr_inq_filename_full( m_pInsideTxr, filename_out);
}

int GTexture::Set_name( const G_Name name_in)
{
  return  GV_txr_set_name(m_pInsideTxr, name_in);
}

int GTexture::Get_name(  G_Name name_out)
{
  return  GV_txr_inq_name( m_pInsideTxr, name_out);
}

int GTexture::Set_components( int num_comps_in)
{
  return  GV_txr_set_components( m_pInsideTxr, num_comps_in);
}

int GTexture::Get_components(  int * num_comps_out)
{
  return  GV_txr_inq_components( m_pInsideTxr, num_comps_out);
}

int GTexture::Set_retain_state(  G_State rstate_in )
{
  return  GV_txr_set_retain_state( m_pInsideTxr,rstate_in );
}

int GTexture::Get_retain_state(  G_State *rstate_out )
{
  return  GV_txr_inq_retain_state( m_pInsideTxr, rstate_out );
}

int GTexture::Set_state(  G_State state_in )
{
  return  GV_txr_set_state( m_pInsideTxr, state_in );
}

int GTexture::Get_state(  G_State * state_out )
{
  return  GV_txr_inq_state( m_pInsideTxr, state_out );
}

int GTexture::Get_transparency(  G_Boolean *mode_out )
{
  return  GV_txr_inq_transparency( m_pInsideTxr, mode_out );
}

int GTexture::Get_gl_list(  GLuint * gl_list)
{
  return  GV_txr_inq_gl_list( m_pInsideTxr, gl_list);
}


int GTexture::Set_attribute( GV_Txr_attr attr, int value_in )
{
  return  GV_txr_set_attribute( m_pInsideTxr, attr, value_in);
}

int GTexture::Get_attribute(  GV_Txr_attr attr, int * value_out)
{
  return  GV_txr_inq_attribute( m_pInsideTxr,attr,value_out);
}

int GTexture::Set_attribute_fv(  GV_Txr_attr_f attrfa,int nfloats_in, const float * values_in ) 
{
  return  GV_txr_set_attribute_fv( m_pInsideTxr, attrfa, nfloats_in, values_in ) ;
}

int  GTexture::Get_attribute_fv(  GV_Txr_attr_f attrfa, int vdim, int * nfloats_out, float * values_out )
{
  return  GV_txr_inq_attribute_fv( m_pInsideTxr, attrfa,vdim,nfloats_out,values_out ) ;
}

int GTexture::Set_detail( GTexture*    dtxhdl )
{
  return  GV_txr_set_detail( m_pInsideTxr, *(dtxhdl->Get_txr()) ) ;
}

int GTexture::Get_detail( GTexture* p_dtxhdl )
{
	return  GV_txr_inq_detail( m_pInsideTxr, p_dtxhdl->Get_txr() ) ;
}


int GTexture::Set_current_with_detail( GTexture*  dtxhdl )
{
	return  GV_txr_set_current_with_detail( m_pInsideTxr, *(dtxhdl->Get_txr()) ) ;
}

/*  GV_txr_set_image_data -- Allow specification of an in-memory
    image to be used as the texture.  The image is described by the
    same structure as is returned by standard image importers.
    When this function is called, OpenGVS copies all of the
    specified image data so that as far as OpenGVS is concerned,
    the caller does not need to retain data itself.

    OpenGVS's copy of the image data may be freed by OpenGVS after the
    texture has been defined.  (However, see GV_txr_set_retain_state).
    */
int GTexture::Set_image_data( const GV_Imp_img_data_out * imgdat_in )
{
  return  GV_txr_set_image_data( m_pInsideTxr,imgdat_in ) ;
}

/*  GV_txr_inq_image_data -- Returns current image info.
    If image memory has been released, then pointers will be
    returned as NULL.
    */
int GTexture::Get_image_data( GV_Imp_img_data_out * imgdat_out )
{
  return  GV_txr_inq_image_data( m_pInsideTxr,imgdat_out ) ;
}

int GTexture::Set_opacity_map_file( const char* filename_in )
{
  return  GV_txr_set_opacity_map_file( m_pInsideTxr, filename_in );
}

int GTexture::Get_opacity_map_file(  char *filename_out )
{
 return GV_txr_inq_opacity_map_file( m_pInsideTxr, filename_out );
}

/*  Begin -- Functions intentionally not documented in man pages: */

/*  GV_txr_inq_dimension -- Return the x and y sizes of a texture and
    the number of bits per component.
    This function is subject to change.
    Deficiencies:
    --  nbits_per_component is always returned as 8.
    --  no information is returned about mipmaps levels.
    */
int GTexture::Get_dimension( int * size_x, int * size_y, int * nbits_per_component )
{
 return  GV_txr_inq_dimension( m_pInsideTxr,size_x,size_y,nbits_per_component );

}

/*  GV_txr_inq_size_bytes -- Return the total memory required
    to store a texture image in the hardware.
    This function is subject to change.
    Deficiencies:
    --  Uses GV_txr_inq_dimension, so has all of its weaknesses.
    */
int GTexture::Get_size_bytes(  int * nbytes )
{
  return  GV_txr_inq_size_bytes( m_pInsideTxr, nbytes );
}

/* prototype function- adding support for cube map processing */
int GTexture::Set_cube_map_image_data(  GLenum cube_face, const GV_Imp_img_data_out * imgdat_in )
{
  return  GV_txr_set_cube_map_image_data( m_pInsideTxr,cube_face,imgdat_in ) ;
}

int GTexture::Set_auxiliary_call_list(  GLuint call_list_in )
{
  return  GV_txr_set_auxiliary_call_list( m_pInsideTxr, call_list_in );
}

int GTexture::Get_auxiliary_call_list(  GLuint *call_list_out )
{
  return  GV_txr_inq_auxiliary_call_list( m_pInsideTxr, call_list_out );
}

/*  End -- Functions intentionally not documented */

int GVS_txr_set_state_system( G_State state_sys_in )
{
  return  GV_txr_set_state_system( state_sys_in );
}

int GVS_txr_inq_state_system( G_State * state_sys_out )
{
  return  GV_txr_inq_state_system( state_sys_out );
}

int GVS_txr_define_pending( void )
{
	return  GV_txr_define_pending();
}


/*  GV_txr_set_format_default -- Set the default internal format
    to be used for a texture with a given number of components.
    The format_in may be anything that is legal as the "components"
    parameter of function glTexImage2D, such as:  1, 2, 3, 4,
    GL_RGB4_EXT, GL_RGBA4_EXT, etc.
    A no-operation unless OpenGL extension "GL_EXT_texture" is present.
    Parameters:
	ncomps -- Ranges from 1 to 4.  Number of components of textures
	    whose default is set by this function.
	format_in -- The internal format to be used by default for a
	    texture with the specified number of components.
    The built-in defaults are:
	GV_txr_set_format_default( 1, 1 ) ;
	GV_txr_set_format_default( 2, 2 ) ;
	GV_txr_set_format_default( 3, 3 ) ;
	GV_txr_set_format_default( 4, 4 ) ;
    This sequence of calls would set defaults for textures with 1, 2, 3,
    or 4 components, respectively:
	GV_txr_set_format_default( 1, GL_LUMINANCE16_EXT ) ;
	GV_txr_set_format_default( 2, GL_LUMINANCE12_ALPHA12_EXT ) ;
	GV_txr_set_format_default( 3, GL_RGB5_EXT ) ;
	GV_txr_set_format_default( 4, GL_RGB5_A1_EXT ) ;
    At one time, OpenGVS used the following defaults:
	GV_txr_set_format_default( 1, GL_LUMINANCE4_EXT ) ;
	GV_txr_set_format_default( 2, GL_LUMINANCE4_ALPHA4_EXT ) ;
	GV_txr_set_format_default( 3, GL_RGB5_EXT ) ;
	GV_txr_set_format_default( 4, GL_RGBA8_EXT ) ;
    */
int GVS_txr_set_format_default( int ncomps, int format_in )
{
   return  GV_txr_set_format_default(ncomps,format_in );
}

int GVS_txr_inq_format_default( int ncomps, int * format_out )
{
  return  GVS_txr_inq_format_default( ncomps,format_out );
}

int GVS_txr_set_current( GTexture* txrhdl )
{
  return  GV_txr_set_current( *(txrhdl->Get_txr()) );
}

int GVS_txr_inq_current( GTexture * p_txrhdl )
{
  return  GV_txr_inq_current( p_txrhdl->Get_txr() );
}

