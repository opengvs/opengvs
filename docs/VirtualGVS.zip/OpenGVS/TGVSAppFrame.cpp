
#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv_sys.h>
#include <gv.h>                    /* Entire OpenGVS kernel         */
#include <gvu_sge.h>

//#include "testBCG.h"
#include "..\resource.h"       // main symbols
#include  "TVGVSAppFrame.h"
#include  "GChannel.h"
#include  "GChannelImp.h"
#include  "GScene.h"
#include  "GObi.h"
#include  "GCamera.h"
#include  "GLight.h"
#include  "TGVSTree.h"
#include  "TGVSToolPane.h"
#include  "GTerrain.h"
#include  <math.h>

TGVSAppFrame*   g_InsideGVSApp = NULL;


//static GV_Obi	    object = NULL;	/* A GVS object instance*/


TGVSAppFrame::TGVSAppFrame()
{
  m_pGVSToolPane = NULL;
  m_pMainChannel = NULL;
  m_pFrameBuffer = NULL;
  m_pMainScene  = NULL;
  m_pSunLight = NULL;
  m_pMainCamera = NULL;

  system_mode = GV_SYS_MODE_INIT;
  m_hWnd = NULL;
  g_InsideGVSApp = this;

}

TGVSAppFrame::~TGVSAppFrame()
{
  if( m_pGVSToolPane != NULL )
  {
	 m_pGVSToolPane->DestroyWindow();
	 delete m_pGVSToolPane; 
     m_pGVSToolPane = NULL;
  }

  if( m_pMainChannel != NULL )
  {
	  delete  m_pMainChannel;
	  m_pMainChannel = NULL;
  }

  if( m_pMainScene  != NULL )
  {
	  delete m_pMainScene;
	  m_pMainScene = NULL;
  }


  if( m_pSunLight != NULL )
  {
     delete m_pSunLight;
	 m_pSunLight = NULL;
  }

  if( m_pMainCamera != NULL )
  {
	  delete  m_pMainCamera;
      m_pMainCamera = NULL;
  }

}

TGVSAppFrame*   TGVSAppFrame::GVSGetApp(void)
{
	return g_InsideGVSApp;
}


//--------------------------------------------------------
static int GV_user_pre_import( void)
{
  return g_InsideGVSApp->GVS_user_pre_import();
}

static int GV_user_init( void )
{
 	static GV_Viewport normalized_viewport = {-0.5, 0.5, -0.5, 0.5};
    static G_Vector3 direction = { 0.0, 0.8, -1.0 };

    // Create essential graphics resources 
    GV_fbf_create( &(g_InsideGVSApp->m_pFrameBuffer) );      // Frame buffer within OS window   
	g_InsideGVSApp->m_pMainChannel =  GChannel::CreateChannel("MainChannel",g_InsideGVSApp->m_hWnd );// 3D drawing surface   
    g_InsideGVSApp->m_pMainCamera = GCamera::CreateCamera("MainCamera");  // Primary view control
    g_InsideGVSApp->m_pMainScene =  GScene::CreateScene("MainScene");   // Includes zero or more objects         
	g_InsideGVSApp->m_pSunLight = GLight::CreateGLight( "SunLight" ); // Default-infinite light source           
    GV_lsr_set_direction( *(g_InsideGVSApp->m_pSunLight->Get_light()), &direction );
    
	// Give channel a name (which will be used on the window border) and setup channel viewport  
    GV_chn_set_viewport( *(g_InsideGVSApp->m_pMainChannel->GetInsideChannel()), &normalized_viewport );

	//GVW_chn_set_window_id( *(g_InsideGVSApp->m_pMainChannel->GetInsideChannel()), GV_CHN_WL_NORMAL, g_InsideGVSApp->m_hwnd );
	//GV_chn_set_message_bypass( G_ON );

    // Make other necessary resource connections 
    g_InsideGVSApp->m_pMainScene->AddLight( g_InsideGVSApp->m_pSunLight );
    g_InsideGVSApp->m_pMainChannel->SetCurrentCamera(g_InsideGVSApp->m_pMainCamera);
    g_InsideGVSApp->m_pMainChannel->SetScene( g_InsideGVSApp->m_pMainScene );

    



    GV_fbf_add_channel( g_InsideGVSApp->m_pFrameBuffer, *(g_InsideGVSApp->m_pMainChannel->GetInsideChannel()) );

    static  G_Position  camposition;
	GV_cam_inq_position( *(g_InsideGVSApp->m_pMainCamera->Get_camera()),
		0,&camposition);
	camposition.y += 2;
	GV_cam_set_position( *(g_InsideGVSApp->m_pMainCamera->Get_camera()),
		0,&camposition);



    g_InsideGVSApp->GVS_user_init();

    return  G_SUCCESS;
}
    
static int GV_user_proc( void )
{
  return  g_InsideGVSApp->GVS_user_proc();
}

static int GV_user_proc_post( void )
{
 return g_InsideGVSApp->GVS_user_proc_post();
}
    
static int GV_user_shutdown( void )
{
 return g_InsideGVSApp->GVS_user_shutdown();
}


void TGVSAppFrame::Initialize( HWND tHwnd)
{
    GV_sys_set_mode( GV_SYS_MODE_INIT );


    m_hWnd = tHwnd;
	m_pGVSToolPane = new  TGVSToolPane();
    m_pGVSToolPane->Create(IDD_GVSTOOLPANE);
    
	/* Establish project specific callbacks */
    GV_sys_set_callback_init( GV_user_init );
    GV_sys_set_callback_pre_import( GV_user_pre_import );
    GV_sys_set_callback_proc( GV_user_proc );
    GV_sys_set_callback_proc_post( GV_user_proc_post );
    GV_sys_set_callback_shutdown( GV_user_shutdown );

	/* Initialize OpenGVS */
    GV_sys_init();

    GV_sys_inq_mode( &system_mode) ;
    if (system_mode != GV_SYS_MODE_SHUTDOWN)
    {
	  GV_sys_set_mode( GV_SYS_MODE_RUNTIME );
	  GV_sys_inq_mode( &system_mode) ;
    }

    m_pMainCamera->AddCamera2GVSPanel();

    //HTREEITEM  pTreeItrem = m_pGVSToolPane->m_GVSObjTree.InsertItem("GVSMainChannel");
	//TGVSBaseClass*  pBase = dynamic_cast<GChannelImp*>(m_pMainChannel);
    
}

void TGVSAppFrame::GVSRun(void)
{
    //while (system_mode == GV_SYS_MODE_RUNTIME)
    {
	  /* Loop here "forever" */
	  GV_sys_proc();
	  GV_sys_inq_mode( &system_mode) ;
    }

}

void TGVSAppFrame::GVSShutdown(void)
{
    //if (system_mode == GV_SYS_MODE_SHUTDOWN)
       system_mode = GV_SYS_MODE_SHUTDOWN;
        GV_sys_shutdown();
       system_mode = GV_SYS_MODE_SHUTDOWN;
}

bool  TGVSAppFrame::IsRun()
{
  GV_sys_inq_mode( &system_mode) ;
  if( system_mode == GV_SYS_MODE_RUNTIME )
	  return  true;
  else
	  return  false;
}



void TGVSAppFrame::ProcessMessage(UINT   message,WPARAM  wParam,LPARAM  lParam )
{
  if( message == WM_SIZE )
  {
    if( IsRun() == true )
	   GV_chn_determine_size( *(m_pMainChannel->GetInsideChannel()) ) ;
  }
  EventProcess(message,wParam,lParam );
}

int TGVSAppFrame::EventProcess(UINT   message,WPARAM  wParam,LPARAM  lParam )
{
  return  G_SUCCESS;
}

void  TGVSAppFrame::ShowToolPane(void)
{
  static  bool  firstShow = true;
  if(m_pGVSToolPane != NULL)
  {
	if( firstShow == true )
	{
		firstShow = false;
		CRect  rt;
        m_pGVSToolPane->GetWindowRect(&rt);
        CRect  drt;
		::GetWindowRect( ::GetDesktopWindow(),&drt);
        //rt.left = drt.right - rt.Width();
		//rt.top = drt.top + 100;
	
		CRect  rRt( drt.Width()-rt.Width(),drt.top+100,drt.Width(),drt.Height() );

        m_pGVSToolPane->MoveWindow(rRt);

	}
    m_pGVSToolPane->ShowWindow(SW_SHOWNORMAL);
  }
}

void  TGVSAppFrame::HideToolPane(void)
{
   m_pGVSToolPane->ShowWindow(SW_HIDE);
}

TTreeNode*  TGVSAppFrame::GetGVSAppNode(void)
{
	return  m_pGVSToolPane->m_GVSObjectTree;
}

TTreeNode*  TGVSAppFrame::AddGVSListNode(const char*  NodeName)
{
  TGVSListNode*  pNode =  m_pGVSToolPane->AddGVSListNode( NodeName );
   return  pNode;
}


TTreeNode*  TGVSAppFrame::AddGVSObiNode(TGVSBaseClass*  pGVSObject,TGVSListNode*   pParentNode/*=NULL*/)
{
  TTreeNode*  pNode = NULL;
  if( pParentNode == NULL )
  {
    pNode = m_pGVSToolPane->AddGVSObject(pGVSObject);
  }
  else
  {
    pNode = m_pGVSToolPane->AddGVSObject(pGVSObject,pParentNode);
  }
  return  pNode;
}
