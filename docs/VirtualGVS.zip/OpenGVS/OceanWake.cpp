#include "stdafx.h"
#include <math.h>
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>
                    /* Entire OpenGVS kernel         */
#include  "TOceanWave.h"
#include  "TVGVSAppFrame.h"
#include  "GChannel.h"
#include  "GScene.h"
#include  "GCamera.h"


GV_Obd   TWakes::m_Obd=NULL;
GV_Obi   TWakes::m_Obi = NULL;


TWakes::TWake::TWake(G_Position&  pos,G_Rotation& rot)
{
   m_Width = TANK_BACK_HALF_WITH;
   float  siny = -sinf(rot.y);
   float  cosy = cosf(rot.y);
   
   float  x,z;
   x = (-1*TANK_BACK_HALF_WITH - DEFINE_ANGLE_LENGTH);
   z = DEFAULT_HEIGHT;
   V[0].x = x*cosy-z*siny+pos.x;
   V[0].y = 0.0;
   V[0].z = x*siny+z*cosy+pos.z;

   x = TANK_BACK_HALF_WITH + DEFINE_ANGLE_LENGTH;
   z = DEFAULT_HEIGHT;
   V[1].x = x*cosy-z*siny+pos.x;
   V[1].y = 0.0;
   V[1].z = x*siny+z*cosy+pos.z;

   x = -1* TANK_BACK_HALF_WITH;
   z = 0.0f;
   V[2].x = x*cosy-z*siny+pos.x;
   V[2].y = 0.0;
   V[2].z = x*siny+z*cosy+pos.z;

   x = TANK_BACK_HALF_WITH;
   z = 0.0f;
   V[3].x = x*cosy-z*siny+pos.x;
   V[3].y = 0.0;
   V[3].z = x*siny+z*cosy+pos.z;


  pNestWake = NULL;
}

/*
bool  TWakes::TWake::SimulationCallback( G_Position&  pos )
{

}
*/
void  TWakes::TWake::Wake_gfx_callback(void)
{
 glDisable( GL_DEPTH_TEST );
  //int  gj = TRUE;
 //glLightModeliv(GL_LIGHT_MODEL_TWO_SIDE,&gj );

    //glPolygonMode( GL_FRONT_AND_BACK,GL_LINE );

	glBegin( GL_TRIANGLE_STRIP );

       glColor3ub(255,255,255);
       glNormal3f(0.0f, 1.0f, 0.0f); 
	   glTexCoord2f(0, 0);
	   glVertex3f( V[0].x, V[0].y, V[0].z);

	   glTexCoord2f(1, 0);
	   glVertex3f( V[1].x, V[1].y, V[1].z);

	   glTexCoord2f(0, 1); 
	   glVertex3f( V[2].x, V[2].y, V[2].z);

	   glTexCoord2f(1, 1);
	   glVertex3f( V[3].x, V[3].y, V[3].z);

	   glEnd();


  glEnable( GL_DEPTH_TEST );
   
	   // gj = FALSE;
   // glLightModeliv(GL_LIGHT_MODEL_TWO_SIDE,&gj );

}
////////////////////////////////////////////////////////////
TWakes::TWakes()
{
  m_pWakeList = NULL;
  m_pOcean = NULL;
  tex = NULL;
}

TWakes::~TWakes()
{
  if( m_pWakeList != NULL )
  {
	  while( m_pWakeList->pNestWake != NULL )
	  {
         TWake   *pWake = m_pWakeList;
         m_pWakeList = m_pWakeList->pNestWake;
		 delete  pWake;
	  }
	  delete  m_pWakeList;
  }
  m_pOcean = NULL;
}

void TWakes::Initialize(TOceanWave*  pOcean)
{
	//G_Position  pos = {0.0,0.0,0.0};
	//G_Rotation  rot;
	//AddWake( pos,rot);
     //tex;
    //char        txt_file[80];

    strcpy (txt_file,"wake.rgba");//"wake.rgba");
    G_Name  name;
	int   nbytes;

	G_file_base( txt_file, sizeof(name), name, &nbytes );
    GV_txr_inq_by_name( name, &tex );
    if( !tex  )
    {
       GV_txr_create( &(tex) );
       GV_txr_set_filename( tex, txt_file );

       /* Load (define) the texture file for the sea state */
       if (GV_txr_define( tex ) != G_SUCCESS)
       {
		   ::MessageBox(NULL,"��ʼ������ʱ���ִ���","OpenGVS����",MB_OK);
       }
       else
       {
          /* We do not manually read the MultiGen attribute file since this is
             taken care of by GV_txr_define.
             However, this does mean we must obtain the pattern size from
             the sea config file instead */
       }
   }

  static GV_Rgba amb  = {0.13,0.315,1.294,0.0};
   static GV_Rgba dif  = {0.1, 0.715, 0.614, 1.0f};
   static GV_Rgba spec = {0.06, 0.95, 0.915, 1.0f};
   static GV_Rgba emis = {0.0f, 0.0f, 0.0f, 1.0f};
   static float shiny = 0.0f;

   //if( sea_surface_alpha < 1.0f )
     //  amb.a = dif.a = 1.0f;
   GV_mtl_create( &(mtl) );
  


   GV_mtl_set_ambient( mtl, &amb ); //���ú�ƽ�滷����Ĳ�������
   GV_mtl_set_diffuse( mtl, &dif ); //���ú�ƽ��ɢ���Ĳ�������
   GV_mtl_set_specular( mtl, &spec );//���ú�ƽ�淴�����ɫ����
   GV_mtl_set_shininess( mtl, shiny );//���ú�ƽ�淴������ߴ�С�����ȵ�����

   GV_mtl_set_emission( mtl, &emis );  //���ú�ƽ��ķ����Դ����

   GV_mtl_define( mtl );
   GV_mtl_set_face( mtl, GL_FRONT_AND_BACK );


	m_pOcean = pOcean;

   GV_obd_open_by_name( "TANKWAVES", &m_Obd );
   GV_obd_close( m_Obd );

   GV_obd_set_transparency_state( m_Obd, G_TRISTATE_ON );

   GV_obi_instance(m_Obd, &m_Obi);

   GV_obi_set_sim_callback(m_Obi, Wake_sim_callback );
   GV_obi_set_sim_data(m_Obi, sizeof(this), this);

   GV_obi_set_gfx_callback(m_Obi, Wake_gfx_callback);
   GV_obi_set_gfx_data(m_Obi, sizeof(this), this);

   GV_obi_set_drawing_order( m_Obi,DYNAMIC_TANK_WAKE_ORDER );
   
   GV_scn_add_object(*(g_InsideGVSApp->m_pMainScene->GetGVScene()), m_Obi);
}


void TWakes::GfxCallback(void)
{
  TWake*  pWake = m_pWakeList;
  
   int        light_state;
   GV_Material current_mtl;

  /* 
  light_state = glIsEnabled(GL_LIGHTING);
  
  glEnable(GL_LIGHTING);
  
  GV_mtl_inq_current(&current_mtl);

  GV_mtl_set_current(mtl);
  */

  GV_Texture  current_tex;
  GV_txr_inq_current(&current_tex);
  GV_txr_set_current(tex);

  GV_txr_set_env( tex, GL_MODULATE );//GL_MODULATE);//GL_BLEND ); 

  while( pWake != NULL )
  {
	  pWake->Wake_gfx_callback();
      pWake = pWake->pNestWake;
  }

  GV_txr_set_current(current_tex);
 
 /*
    GV_mtl_set_current(current_mtl);
    if (!light_state)
      glDisable(GL_LIGHTING);
  */
}


int TWakes::Wake_gfx_callback( GV_Obi inst, void *data_in )
{
    TWakes*  p = (TWakes*)data_in;
	p->GfxCallback();

  return  G_SUCCESS;
}

void TWakes::AddWake(G_Position&  pos,G_Rotation&  rot)
{
  TWakes::TWake*  pWake = new TWakes::TWake(pos,rot);

  if( m_pWakeList == NULL )
	  m_pWakeList = pWake;
  else
  {
      pWake->pNestWake = m_pWakeList;

      //pWake->V[0] = m_pWakeList->V[2];
      //pWake->V[1] = m_pWakeList->V[3];
      m_pWakeList->V[2] = pWake->V[0];
      m_pWakeList->V[3] = pWake->V[1];

      m_pWakeList = pWake;
  }
}

int TWakes::Wake_sim_callback( GV_Obi inst, void *data_in )
{
  TWakes*  p = (TWakes*)data_in;
  TWake* pWake = p->m_pWakeList;
  TWake* tpWake = pWake;
  while( pWake != NULL )
  {
    if( pWake->Wake_SimulationCallback() == false )
	{
		if( pWake == p->m_pWakeList )
		{
          p->m_pWakeList = pWake->pNestWake;
		  tpWake = pWake->pNestWake;
		  delete  pWake;
          pWake = tpWake;
		}
		else
		{
			tpWake->pNestWake = pWake->pNestWake;
			delete pWake;
			pWake = tpWake->pNestWake;
		}
	}
	else
	{
     
		for( int i = 0; i<4; i++ )
	       p->m_pOcean->SimulationCallback( &( pWake->V[i] ) );
        

	  tpWake = pWake;
	  pWake = pWake->pNestWake;
	}
   
  }
  return  G_SUCCESS;
}

bool  TWakes::TWake::Wake_SimulationCallback( void )
{
  m_Width += 0.01;
  if( m_Width > 2*TANK_BACK_HALF_WITH )
  {
	  return  false;
  }
  else
  {
    V[2].x -=  0.01;
	V[3].x +=  0.01;

    V[0].x -=  0.01;
	V[1].x +=  0.01;


  }
  return  true;
}