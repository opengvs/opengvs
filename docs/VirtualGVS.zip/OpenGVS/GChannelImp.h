/********************************************************************
FileName:     GChannelImp.h
descript:     ���ڶ���GChannelImp��
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/
#ifndef  __GCHANNLEIMP_H__
#define  __GCHANNLEIMP_H__

#include "GChannel.h"
#include "TGVSBaseClass.h"

class  GChannelImp : public TGVSPersistent<GChannelImp>,public GChannel
{
public:
     static void     InitializePropertyStr(void);

public:
  GChannelImp(const char* name);
  virtual ~GChannelImp();
private:
  int  x;

};

#endif

