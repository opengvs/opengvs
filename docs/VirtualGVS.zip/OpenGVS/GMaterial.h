//GMaterial.h
#ifndef  __MATERIAL_H__
#define  __MATERIAL_H__

typedef struct GV_material_s * GV_Material ;

typedef unsigned int GV_Mtl_attr_mask ;

#ifdef __cplusplus
extern "C" {
#endif


/*  GV_Mtl_attr_mask and GV_MTL_ATTR_MASK_* -- type and bit mask
    definitions to allow specification of particular material attributes.
    */

#define GV_MTL_ATTR_MASK_AMBIENT      0x1
#define GV_MTL_ATTR_MASK_DIFFUSE      0x2
#define GV_MTL_ATTR_MASK_EMISSION     0x4
#define GV_MTL_ATTR_MASK_SPECULAR     0x8
#define GV_MTL_ATTR_MASK_SHININESS   0x10

#define GV_MTL_ATTR_MASK_NONE         0x0

#define GV_MTL_ATTR_MASK_ALL (GV_MTL_ATTR_MASK_AMBIENT | GV_MTL_ATTR_MASK_DIFFUSE | GV_MTL_ATTR_MASK_EMISSION | GV_MTL_ATTR_MASK_SPECULAR | GV_MTL_ATTR_MASK_SHININESS)


#ifdef __cplusplus
}
#endif

class  GMaterial
{
protected:
    GV_Material   m_InsideMaterial;
public:
	GMaterial(){ m_InsideMaterial = NULL;};
	GMaterial( GV_Material  pMaterial );
	virtual ~GMaterial();
    
    GV_Material*  Get_material(void){return  &m_InsideMaterial;};
    static GMaterial*  CreateMaterial(const char* name);
	static GMaterial*  CreateMaterial( GV_Material  pMaterial );

    int Define( void );
	int Free( void );


    int Set_name(  const G_Name name_in );
    int Get_name(  G_Name name_out );

    int Set_ambient(  const GV_Rgba *ambient );
    int Get_ambient(  GV_Rgba *ambient );

    int Set_diffuse(  const GV_Rgba *diffuse );
    int Get_diffuse(  GV_Rgba *diffuse );

    int Set_emission(  const GV_Rgba *emission );
    int Get_emission(  GV_Rgba *emission );

    int Set_specular(  const GV_Rgba *specular );
    int Get_specular(  GV_Rgba *specular );

    int Set_shininess(  float shininess );
    int Get_shininess(  float *shininess );

    int Set_face(  GLenum face );
    int Get_face(  GLenum *face );

    int Set_attribute_mask(  GV_Mtl_attr_mask amask_in ) ;
    int Get_attribute_mask(  GV_Mtl_attr_mask * amask_out ) ;

     /* PROTOTYPE */
    int Set_auxiliary_call_list(  GLuint call_list_in ) ;
    int Get_auxiliary_call_list(  GLuint *call_list_out ) ;


};

int GVS_mtl_define_pending( void );
int GVS_mtl_set_current( GMaterial*  mtlhdl ) ;
int GVS_mtl_inq_current( GMaterial * mtlhdl ) ;


#endif