#include "stdafx.h"
#include <math.h>
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>
                    /* Entire OpenGVS kernel         */
#include  "TOceanWave.h"
#include  "TVGVSAppFrame.h"
#include  "GChannel.h"
#include  "GScene.h"
#include  "GCamera.h"
#include  "GTrigon.h"

                                                  //0 1 2 3 4 5 6 7 8 9 10 11 12
int    TDynOceanSim::m_WindDegree2WaveDegree[13] = {0,1,2,2,3,4,5,5,6,7,7, 8, 9 };

float  TDynOceanSim::m_WaveDegree2WaveHeight_T[10][2] = {
	{0,0,},{0.1,0.1},{0.5,1.8},{1.25,3.5},
	{2.5,4.5},{4.0,6.5},{6.0,8.2},{9.0,9.7},{14.0,11.0},{16.0,13}};

float  TDynOceanSim::m_WaveDegree2W[8][10][2] = { //0,1��Ϊ�����
		{ {1.05,0.0493},{1.1375,0.056},{1.3125,0.0626},{1.4,0.0632},{1.605,0.0926},{2.015,0.0741},{2.425,0.0562},{2.835,0.0425},{3.245,0.0326},{3.45,0.0287} },
		{{0.71,0.1205},{0.7525,0.1289},{0.8375,0.1375},{0.88,0.1385},{0.982,0.2090},{1.186,0.1793},{1.39,0.1456},{1.594,0.1167},{1.798,0.0937},{1.9,0.0843}},
		{{0.42,0.2118},{0.47,0.2791},{0.57,0.3494},{0.62,0.3573},{0.757,0.5452},{1.031,0.3729},{1.305,0.2458},{1.579,0.1671},{1.853,0.1182},{1.99,0.1008}},
		{{0.3,0.2570},{0.3475,0.4217},{0.4425,0.6066},{0.49,0.6266},{0.643,0.9709},{0.949,0.5468},{1.255,0.3143},{1.561,0.1950},{1.867,0.1295},{2.02,0.1077}},
		{{0.23,0.2997},{0.2725,0.5923},{0.3575,0.9461},{0.4,0.9839},{0.564,1.5394},{0.892,0.7181},{1.22,0.3697},{1.548,0.2147},{1.876,0.1364},{2.04,0.116}},
		{{0.18,0.3699},{0.2175,0.8609},{0.2925,1.4773},{0.33,1.5344},{0.502,2.3341},{0.846,0.8969},{1.19,0.4197},{1.534,0.2311},{1.878,0.1421},{2.05,0.1148}},
		{{0.14,0.4771},{0.17,1.2273},{0.23,2.2630},{0.26,2.3829},{0.44,3.6243},{0.8,1.1129},{1.16,0.4721},{1.52,0.2468},{1.88,0.1470},{2.06,0.1174}},
		{{0.13,0.5376},{0.16,1.4817},{0.22,2.7175},{0.25,2.8163},{0.43,3.9818},{0.793,1.1579},{1.155,0.4822},{1.517,0.2498},{1.879,0.1480},{2.06,0.1180}} };

TDynOceanSim::TDynOceanSim()
{
	int i;
	m_H0 = 0.0f;//�����߶�
	for( i=0;i<10;i++)
		m_Phi[i] = 0;  //��λ�� 0~180
    m_Angle = 0;//���Ĵ�������0~360
	SinAngle = 0.0f;
	CosAngle = 1.0f;

	m_CurrentWindDegree = 4;
	m_CurrentWaveDegree = 3;
    m_CurrentWaveHeight = 1.25;
	m_CurrentWaveCyc = 3.5;
    for( i = 0; i<10;i++ )
	{
       m_CurrentWaveAngleFrequency[i] = m_WaveDegree2W[m_CurrentWaveDegree-2][i][0];
	   m_CurrentWaveAmplitude[i] = m_WaveDegree2W[m_CurrentWaveDegree-2][i][1];
	}


}

TDynOceanSim::~TDynOceanSim()
{

}

void TDynOceanSim::SetCurrentWindDegree( int  Degree )
{
  m_CurrentWindDegree = Degree;
  if( Degree <= 1 )
  {
     m_CurrentWindDegree = 0;
     m_CurrentWaveDegree = Degree;
     m_CurrentWaveHeight = 0.0f;
     m_CurrentWaveCyc = 0;
     for( int i = 0; i<10;i++ )
	 {
       m_CurrentWaveAngleFrequency[i] = 0.0f;
       m_CurrentWaveAmplitude[i] = 0.0f;
     }
	 return;
  }
  else  if( Degree > 12 )
               Degree = 12;

  {
     m_CurrentWindDegree = 0;
     m_CurrentWaveDegree = m_WindDegree2WaveDegree[Degree];
     m_CurrentWaveHeight = m_WaveDegree2WaveHeight_T[m_CurrentWaveDegree][0];
     m_CurrentWaveCyc = m_WaveDegree2WaveHeight_T[m_CurrentWaveDegree][1];
     for( int i = 0; i<10;i++ )
	 {
       m_CurrentWaveAngleFrequency[i] = m_WaveDegree2W[m_CurrentWaveDegree-2][i][0];
	   m_CurrentWaveAmplitude[i] = m_WaveDegree2W[m_CurrentWaveDegree-2][i][1];
	 }
  }

}

float  TDynOceanSim::dynSimulation( G_Position*  pos,double  t )
{
  static  float x,y,z,DynHeight;
  //static  double dtime;
  static  float   tAngle;
  static  float   k;
  //G_timer_inq_time( &dtime );
  
  x = pos->x;
  y = pos->z;
  z = pos->y;
  DynHeight = m_H0;
  for( int i = 0;i < 10;i++ )
  {
	k = m_CurrentWaveAngleFrequency[i]*m_CurrentWaveAngleFrequency[i]/ACCELERATION_OF_GRAVITY;
    tAngle = k*(x*GTrigon::Sin(m_Angle)+y*GTrigon::Cos(m_Angle)) + m_CurrentWaveAngleFrequency[i]*t+m_Phi[i];

    DynHeight += m_CurrentWaveAmplitude[i] * GTrigon::Cos( (int) (tAngle*G_RAD_TO_DEG) ); 

  }
  pos->y = DynHeight;

  return DynHeight;
}

float  TDynOceanSim::dynSimulation( float x,float y,float z,double t )
{
  float DynHeight;
  //static  double dtime;
  float   tAngle;
  float   k;
  //G_timer_inq_time( &dtime );
  
  //x = pos->x;
  //y = pos->z;
  //z = pos->y;

  DynHeight = m_H0;
  for( int i = 0;i < 10 ;i++ )
  {
	k = m_CurrentWaveAngleFrequency[i]*m_CurrentWaveAngleFrequency[i]/ACCELERATION_OF_GRAVITY;
    //tAngle = k*(x*g_Trigon.Sin( m_Angle)+y*g_Trigon.Cos(m_Angle) ) + m_CurrentWaveAngleFrequency[i]*t+m_Phi[i];
    tAngle = k*( x * SinAngle +y*CosAngle )+ m_CurrentWaveAngleFrequency[i]*t+m_Phi[i];
	//tAngle = k*(x*sinf( m_Angle)+y*cosf(m_Angle) ) + m_CurrentWaveAngleFrequency[i]*t+m_Phi[i];
    DynHeight += m_CurrentWaveAmplitude[i] *cosf( tAngle );// g_Trigon.Cos( (int) (tAngle) ); // //

  }
  //pos->y = DynHeight;

  return DynHeight;

}

void   TDynOceanSim::SetWindAngle( int  Angle )
{
	SinAngle = sinf( Angle*G_DEG_TO_RAD);
	CosAngle = cosf( Angle*G_DEG_TO_RAD);
}