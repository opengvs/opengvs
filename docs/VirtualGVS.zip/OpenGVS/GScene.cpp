/********************************************************************
FileName:     GScene.cpp
descript:     ���ڶ���Virtual  GVSϵͳ��Ҫ�ĳ�����
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/

#include "stdafx.h"

#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include "GLight.h"
#include "GScene.h"
#include "GSceneImp.h"
#include "GObi.h"
#include "GTerrain.h"



GScene*  GScene::CreateScene(const char*  name)
{
  GScene*  pScene  = new GSceneImp(name);
  GV_scn_create( &(pScene->m_pInsideData) );
  
  GV_scn_set_name( pScene->m_pInsideData, name);

  return  pScene;
}

void  GScene::AddLight(GLight*  pLight)
{
  GV_scn_add_light( m_pInsideData, *(pLight->Get_light()) );
}

int  GScene::Add_obi( GObi*  pObi )
{
 if(pObi)
	return  GV_scn_add_object( m_pInsideData, *(pObi->Get_obi()) ) ;
 else
	return G_FAILURE;
}

int  GScene::Add_terrain( GTerrain*  pTerrain)
{
  if( pTerrain )
	  return Add_obi( pTerrain->Get_obi() ) ; 
  else
	  return G_FAILURE;
}

int  GScene::Remove_object( GObi*  pObi )
{
  if( pObi )
	  return  GV_scn_remove_object(m_pInsideData,*(pObi->Get_obi()) );
  else
	  return  G_FAILURE;
}

int  GScene::Remove_terrain(GTerrain*  pTerrain)
{
	if(pTerrain)
		return Remove_object( pTerrain->Get_obi() ) ;
	else
		return  G_FAILURE;
}

int  GScene::Remove_all_objects( void )
{
   return  GV_scn_remove_objects( m_pInsideData ) ;
}

int  Remove_object_from_all_scene( GObi*  pObi )
{
	return  GV_scn_remove_object_from_all( *(pObi->Get_obi()) );
}