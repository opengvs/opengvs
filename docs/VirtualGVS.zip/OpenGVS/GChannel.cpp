/********************************************************************
FileName:     GChannel.cpp
descript:     ���ڶ���GChannel��
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/
#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include "GChannel.h"
#include "GChannelImp.h"
#include "GCamera.h"
#include "GScene.h"

GChannel::GChannel()
{
  m_pInsideData = NULL;
  m_CurrentCamera = NULL;
}

GChannel::~GChannel()
{
  m_pInsideData = NULL;
  m_CurrentCamera = NULL;
}

GChannel*   GChannel::CreateChannel(const char*  name,HWND  hWnd)
{
  static GV_Viewport normalized_viewport = {-0.5, 0.5, -0.5, 0.5};
  static GV_Rgba  erase_color = {0.1,0.4,0.8,0.0};

  GChannel*  pChannel = new  GChannelImp(name);
  GV_chn_create( &pChannel->m_pInsideData );  // 3D drawing surface              
  GV_chn_set_name( pChannel->m_pInsideData, name );
  GV_chn_set_erase_color( pChannel->m_pInsideData,&erase_color);
  GV_chn_set_viewport( pChannel->m_pInsideData, &normalized_viewport );
  
  GVW_chn_set_window_id( pChannel->m_pInsideData, GV_CHN_WL_NORMAL, hWnd );
  	
  return  pChannel;
}

void  GChannel::SetCurrentCamera(GCamera* pCamera)
{	
  if( pCamera != NULL )
  {
    GV_chn_set_camera( m_pInsideData, *(pCamera->Get_camera()) );
    m_CurrentCamera = pCamera;
  }
}

GCamera*  GChannel::Get_curent_camera(void)
{
  return  m_CurrentCamera;
}

void  GChannel::SetScene( GScene*  pScene )
{
  if( pScene != NULL )
      GV_chn_set_scene( m_pInsideData, *(pScene->GetGVScene()) );
}

