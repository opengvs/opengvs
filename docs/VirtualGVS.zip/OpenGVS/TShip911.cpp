#include "stdafx.h"
#include <math.h>
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>
                    /* Entire OpenGVS kernel         */
#include "TOceanWave.h"
#include  "TVGVSAppFrame.h"
#include  "GChannel.h"
#include  "GScene.h"
#include  "GCamera.h"
#include  "TShip911.h"
#include  "mmsystem.h"
#include  <gl\glext.h>
//#include  <gl\glprocs.h>

extern TWakes*   g_pWakes;

//_GLextensionProcs extensionProcs;

//PFNGLPOINTPARAMETERFEXTPROC    glPointParameterfEXT1;
//PFNGLPOINTPARAMETERFVEXTPROC   glPointParameterfvEXT1;

int isExtensionSupported(const char *extstring)
{
    char *s = (char*) glGetString(GL_EXTENSIONS); //Get our extension-string
    char *temp = strstr(s, extstring);            //Is our extension a string?
    return temp != NULL;                          //Return false.
}


TShip911::TShip911() : GObi("MOVING_OBJECT")
{
  m_current_speed = 0.0f;
  m_current_acceleration = 0.0f;
  m_last_time = 0.0;

  m_Move_Destance = 0.0f;

  static G_Position init_pos = { 0.0, 0.0, 0.0  };
  static G_Rotation init_rot = { 0.0, 0.0, 0.0  };
  GV_obi_set_position( m_insideObi, &init_pos );
  GV_obi_set_rotation( m_insideObi, &init_rot );
  GV_obi_set_sim_callback(m_insideObi, Simulation_callback );
  GV_obi_set_sim_data(m_insideObi, sizeof(this), this);

  GV_scn_add_object( *(g_InsideGVSApp->m_pMainScene->GetGVScene()), m_insideObi );
  m_last_time = timeGetTime();

/*
   _InitExtensionProcs (&extensionProcs);

  // Check if the extension is there.
int hasPointParams = isExtensionSupported("GL_EXT_point_parameters");

// Initialize the extension-functions.
#ifdef _WIN32    // for windows only

if (hasPointParams)
{
    glPointParameterfEXT1 = (PFNGLPOINTPARAMETERFEXTPROC) wglGetProcAddress("glPointParameterfEXT");
    glPointParameterfvEXT1 = (PFNGLPOINTPARAMETERFVEXTPROC) wglGetProcAddress("glPointParameterfvEXT");
}

#endif

if (hasPointParams) // If the extension is available
{
    static float quadratic[3] = { 0.25, 0.0, 1/60.0 };
    glPointParameterfvEXT1(GL_DISTANCE_ATTENUATION_EXT, quadratic);
    glPointParameterfEXT1(GL_POINT_FADE_THRESHOLD_SIZE_EXT, 1.0);
}
*/
//RenderScene();

}

TShip911::~TShip911()
{
  GV_obi_set_state( m_insideObi, G_OFF );
  m_insideObi = NULL;
}

void   TShip911::Inside_Simulation_Callback(void)
{
  static  DWORD  current_time;
  float   D;
  static  G_Position  pos;
  static  G_Rotation  rot;

  current_time = timeGetTime();
  DWORD  Alter = current_time - m_last_time;

  if( Alter > 28 )
  {
    m_last_time =  current_time;
	D = m_current_speed*Alter;
	GV_obi_inq_position( m_insideObi,&pos );
	GV_obi_inq_rotation( m_insideObi,&rot );
    
	pos.z -= D*cos(rot.y);
	pos.x -= D*sin(rot.y);
    
	GV_obi_set_position( m_insideObi,&pos );
	GV_obi_set_rotation( m_insideObi,&rot );
    
	m_Move_Destance += D;
	if( m_Move_Destance >= DEFAULT_HEIGHT )
	{
       if( g_pWakes )
		   g_pWakes->AddWake(pos,rot);

       m_Move_Destance = 0.0f; 
	}
  }
}

int   TShip911::Simulation_callback( GV_Obi inst, void *data_in )
{
  TShip911*  pShip = (TShip911*)data_in;

  if( pShip == NULL )
	  return  G_SUCCESS;

  pShip->Inside_Simulation_Callback();

  return  G_SUCCESS;
}

void  TShip911::GVSUserMessageProc(UINT   message,WPARAM  wParam,LPARAM  lParam)
{
  G_Rotation  rot;
  bool fShift = GetKeyState(VK_RSHIFT) & 0x8000 ? TRUE : FALSE;
  if( fShift == FALSE )
	  return;

  if( message == WM_KEYDOWN )
  {
	  if( wParam == 'U' )
	  {
        m_current_speed += 0.005;
		if( m_current_speed > 0.0111 )
			m_current_speed = 0.0111;
	  }
	  else  if( wParam == 'J' )
	  {
        m_current_speed -= 0.005;
		if( m_current_speed < 0.0 )
			m_current_speed = 0.0;
	  }
	  else  if( wParam == 'K' )
	  {
        GV_obi_inq_rotation( m_insideObi,&rot );
        rot.y += 0.017;
        GV_obi_set_rotation( m_insideObi,&rot );
	  }
	  else  if( wParam == 'L' )
	  {
        GV_obi_inq_rotation( m_insideObi,&rot );
        rot.y -= 0.017;
        GV_obi_set_rotation( m_insideObi,&rot );
	  }
  }
}