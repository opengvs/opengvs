
#include "stdafx.h"
#include "TTypeInfor.h"
#include "RegEnum.h"


list<EnumInforObject*>  g_RegesterEnumList;

TRegesterEnum::Initialise(void)
{
    //GCamera  ���ö�����͵�ע��
	{
		{//GV_Cam_projection_mode
          EnumInfor<GV_Cam_projection_mode>*  pEnumInfor = new EnumInfor<GV_Cam_projection_mode>("GV_Cam_projection_mode");
  		  pEnumInfor->insert( GV_CAM_PROJECTION_MODE_PERSP,"GV_CAM_PROJECTION_MODE_PERSP");
		  pEnumInfor->insert( GV_CAM_PROJECTION_MODE_ORTHO,"GV_CAM_PROJECTION_MODE_ORTHO");
		  pEnumInfor->insert( GV_CAM_PROJECTION_MODE_IDENTITY,"GV_CAM_PROJECTION_MODE_IDENTITY");
          g_RegesterEnumList.push_back(pEnumInfor);
		}
        {//GV_Cam_stability_mode
          EnumInfor<GV_Cam_stability_mode>*  pEnumInfor = new EnumInfor<GV_Cam_stability_mode>("GV_Cam_stability_mode");
  		  pEnumInfor->insert( GV_CAM_STABILITY_MODE_OFF,"GV_CAM_STABILITY_MODE_OFF");
		  pEnumInfor->insert( GV_CAM_STABILITY_MODE_WORLD,"GV_CAM_STABILITY_MODE_WORLD");
		  pEnumInfor->insert( GV_CAM_STABILITY_MODE_OBJECT,"GV_CAM_STABILITY_MODE_OBJECT");
		  pEnumInfor->insert( GV_CAM_STABILITY_MODE_PITCH,"GV_CAM_STABILITY_MODE_PITCH");
          g_RegesterEnumList.push_back(pEnumInfor);
		}
		{//GV_Cam_track_mode
          EnumInfor<GV_Cam_track_mode>*  pEnumInfor = new EnumInfor<GV_Cam_track_mode>("GV_Cam_track_mode");
  		  pEnumInfor->insert( GV_CAM_TRACK_MODE_OFF,"GV_CAM_TRACK_MODE_OFF");
		  pEnumInfor->insert( GV_CAM_TRACK_MODE_OBI_SINGLE,"GV_CAM_TRACK_MODE_OBI_SINGLE");
		  pEnumInfor->insert( GV_CAM_TRACK_MODE_OBI_MULTIPLE,"GV_CAM_TRACK_MODE_OBI_MULTIPLE");
		  pEnumInfor->insert( GV_CAM_TRACK_MODE_POSITION,"GV_CAM_TRACK_MODE_POSITION");
          g_RegesterEnumList.push_back(pEnumInfor);
		}
		{//GV_Cam_zoom_mode
          EnumInfor<GV_Cam_zoom_mode>*  pEnumInfor = new EnumInfor<GV_Cam_zoom_mode>("GV_Cam_zoom_mode");
  		  pEnumInfor->insert( GV_CAM_ZOOM_MODE_OFF,"GV_CAM_ZOOM_MODE_OFF");
		  pEnumInfor->insert( GV_CAM_ZOOM_MODE_MANUAL,"GV_CAM_ZOOM_MODE_MANUAL");
		  pEnumInfor->insert( GV_CAM_ZOOM_MODE_AUTO,"GV_CAM_ZOOM_MODE_AUTO");
          g_RegesterEnumList.push_back(pEnumInfor);
		}
	}

	{//GLight
          EnumInfor<GV_Lsr_type>*  pEnumInfor = new EnumInfor<GV_Lsr_type>("GV_Lsr_type");
  		  pEnumInfor->insert( GV_LSR_TYPE_INFINITE,"GV_LSR_TYPE_INFINITE");
		  pEnumInfor->insert( GV_LSR_TYPE_LOCAL,"GV_LSR_TYPE_LOCAL");
          g_RegesterEnumList.push_back(pEnumInfor);
	}
}

TRegesterEnum::Destroy(void)
{
	list<EnumInforObject*>::iterator  pIt = g_RegesterEnumList.begin();
	while( pIt != g_RegesterEnumList.end() )
	{
	   EnumInforObject* pData = (EnumInforObject*)(*pIt);
       g_RegesterEnumList.erase(pIt);
	   delete pData;

       pIt = g_RegesterEnumList.begin();
	}
}

EnumInforObject*  TRegesterEnum::FindEnum( char* eNum )
{
  EnumInforObject*    tObject = NULL;
    
    list<EnumInforObject*>::iterator  pIt = g_RegesterEnumList.begin();
	while( pIt != g_RegesterEnumList.end() )
	{
	   EnumInforObject* pData = (*pIt);
       if( strcmp(pData->name,eNum)==0 )
		   break;
	   pIt++;
	}
	if( pIt != g_RegesterEnumList.end() )
       tObject = (*pIt);
    return  tObject;
} 

//////////////////////////////////////////////////////////////////////////////
int  g_EnumPrepare = 0;
PropertyStr::PropertyStr()
{
    if( g_EnumPrepare == 0 )
	{
		TRegesterEnum::Initialise();
		GVS_Struct::Initialize();
	}
    g_EnumPrepare++;

	ListCtrlIndex = -1;
	IsExpand = false;
	SetDataCallbackFunction.FloatSet = NULL;
	GetDataCallbackFunction.FloatGet=NULL;
    IsChild = false;
}

PropertyStr::~PropertyStr()
{
	vector<PropertyStr*>::iterator  pIt = m_ChildList.begin();
	while( pIt != m_ChildList.end() )
	{
        PropertyStr*  p = *pIt;
		delete p;
        m_ChildList.erase(pIt);
		pIt = m_ChildList.begin();
	}

	g_EnumPrepare--;
   if( g_EnumPrepare == 0 )
   {
	  TRegesterEnum::Destroy();
   }
   if( g_EnumPrepare < 0 )
	  g_EnumPrepare=0;

}


list<GVS_StructInfor>    GVS_Struct::m_GVSStructInfor_List;

void   GVS_Struct::Initialize(void)
{
  m_GVSStructInfor_List.push_back(GVS_StructInfor("G_Position","[x,y,z]") );
  m_GVSStructInfor_List.push_back(GVS_StructInfor("G_Rotation","[x,y,z]") );
}

char*  GVS_Struct::GetStructString(const char*  typeName)
{
	list<GVS_StructInfor>::iterator  pIt = m_GVSStructInfor_List.begin();
	while( pIt != m_GVSStructInfor_List.end() )
	{
		if( strcmp(pIt->m_TypeName,typeName)== 0 )
			return  pIt->m_MemberStr;
		pIt++;
	}
	return  NULL;
}
