/********************************************************************
FileName:     GObi.h
descript:     ���ڶ�����������
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/

#ifndef  __GOBI_H__
#define  __GOBI_H__

#ifdef __cplusplus
extern "C" {
#endif

/*  These handles must be declared before including the other header files. */
typedef struct GV_obd_s * GV_Obd;
typedef struct GV_obi_s * GV_Obi;

#ifdef __cplusplus
}
#endif

struct  TGVSListNode;

class  GObi
{
protected:
	GV_Obi   m_insideObi;

	
public:
	GObi(){m_insideObi=NULL;};
    GObi(const G_Name  name );
	static  GObi*  CreateObi(char* name);
	virtual ~GObi(){};
    
    GV_Obi*  Get_obi(void){ return  &m_insideObi;};

	void      AddObi2GVSPanel( TGVSListNode*  pParentNode = NULL );

};

#endif