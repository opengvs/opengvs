/**********************************************************************************
FileName:  RegEnum.h
Descript:  ���ڶ���ϵͳ���Ѿ�ע���ÿ�����ͣ����ļ�ֻ��TTypeInfor.cpp ��Ӧ��
CopyRight: ������    3005��1��  ��Ȩ����
***********************************************************************************/

#ifndef  __REGENUM_HPP__
#define  __REGENUM_HPP__

//GCamera  ʹ��
typedef enum {
    GV_CAM_PROJECTION_MODE_PERSP,
    GV_CAM_PROJECTION_MODE_ORTHO,
    GV_CAM_PROJECTION_MODE_IDENTITY
} GV_Cam_projection_mode;

typedef enum {
    GV_CAM_STABILITY_MODE_OFF,
    GV_CAM_STABILITY_MODE_WORLD,
    GV_CAM_STABILITY_MODE_OBJECT,
    GV_CAM_STABILITY_MODE_PITCH
} GV_Cam_stability_mode;

typedef enum {
    GV_CAM_TRACK_MODE_OFF,
    GV_CAM_TRACK_MODE_OBI_SINGLE,
    GV_CAM_TRACK_MODE_OBI_MULTIPLE,
    GV_CAM_TRACK_MODE_POSITION
} GV_Cam_track_mode;

typedef enum {
    GV_CAM_ZOOM_MODE_OFF,
    GV_CAM_ZOOM_MODE_MANUAL,
    GV_CAM_ZOOM_MODE_AUTO
} GV_Cam_zoom_mode;

typedef enum {
    GV_LSR_TYPE_INFINITE = 0,
    GV_LSR_TYPE_LOCAL = 1
} GV_Lsr_type ;


#endif