#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv_sys.h>
#include <gv.h>                    /* Entire OpenGVS kernel         */
#include <gvu_sge.h>

#include "..\resource.h"       // main symbols
#include  "TVGVSAppFrame.h"
#include  "TGVSApp.h"
#include  "GChannel.h"
#include  "GChannelImp.h"
#include  "GScene.h"
#include  "GObi.h"
#include  "GCamera.h"
#include  "GLight.h"
#include  "TGVSTree.h"
#include  "TGVSToolPane.h"
#include  "GTerrain.h"
#include  "TShip911.h"
#include  "TFont.h"
#include  <math.h>
#include "TOceanWave.h"
#include  "GMaterial.h"
#include "GMaterialImp.h"
#include "..\MaterialSetGialog.h"
#include "..\VirtualGVS.h"
#include "..\MainFrm.h"
#include "..\VirtualGVSDoc.h"
#include "..\VirtualGVSView.h"

extern  TGVSAppFrame*    g_GVSApp;
GObi*         g_obi = NULL;
GTerrain*    g_terrain = NULL;
TOceanWave   g_oceanWave;
//COceanWave*   g_pOcean= NULL;;
GVU_Sge  sgehdl=NULL;
int g_Camera_Height = 15;
TFont        *g_pFont = NULL;
TShip911*    g_pShip911 = NULL;
GMaterial*   g_pWaveMaterial = NULL;

TGVSApp::TGVSApp()
{
  m_bControlCamera = true;
}

TGVSApp::~TGVSApp()
{

}

int TGVSApp::GVS_user_pre_import( void)
{
  return  G_SUCCESS;
}

static int MainCamera_Callback( GV_Camera camera, void *pData )
{
   static  G_Position  pos;
   static   GV_Geo_face  geo_face1=NULL,geo_face2=NULL;

   TGVSApp*  pGVSApp = (TGVSApp*)pData; 

   GV_cam_inq_position(camera,0,&pos);
   pos.y+=1000;
   //GV_geo_inq_face( *(g_terrain->GetInsideTerrain()),geo_face1, pos.x,pos.z, &geo_face2 );
   GV_geo_inq_scene_face( *(pGVSApp->m_pMainScene->GetGVScene()) , pos.x,pos.z, &geo_face2 );
   if( geo_face2 != NULL )
   {
	   GV_geo_inq_face_elevation(geo_face2, pos.x,pos.z, &(pos.y));
       //GV_geo_inq_scene_face( GV_Scene scnhdl,    float x, float z, GV_Geo_face * face_out ) ;
	   pos.y += g_Camera_Height;
	   GV_cam_set_position(camera,0,&pos);
   }
   else
     pos.y = 5;
   
   GV_cam_set_position(camera,0,&pos);
   //geo_face1 = geo_face2;
   return  G_SUCCESS;
}

int TGVSApp::GVS_user_init( void )
{
	m_MtlSetDialog = new CMaterialSetGialog();
    m_MtlSetDialog->Create(IDD_MATERIALDIALOG);

	/*static G_Position init_pos = { 0.0, 0.0, -6.0  };
	g_obi = GObi::CreateObi("MOVING_OBJECT");
    GV_obi_set_position( *(g_obi->Get_obi()), &init_pos );
    GV_scn_add_object( *(m_pMainScene->GetGVScene()), *(g_obi->Get_obi()) );

    g_obi->AddObi2GVSPanel();
   */

    /*
   g_terrain = GTerrain::CreateTerrain("TERRAIN");
	m_pMainScene->Add_terrain(g_terrain);
	AddTerrain2GVSPanel(g_terrain,NULL);
    */
	g_pShip911 = new TShip911();

	static  GV_Obi  skydome = NULL;
    GV_obi_instance_by_name( "SKYDOME", &skydome );
    GV_obi_set_state( skydome, G_ON );
    GV_scn_add_object( *(m_pMainScene->GetGVScene()), skydome );
    

	GVU_sge_create( &sgehdl );
	GVU_sge_set_name( sgehdl, "TUTOR_GVU_SGE" );
	GVU_sge_set_light( sgehdl, *(g_InsideGVSApp->m_pSunLight->Get_light()) );
	GVU_sge_set_lens_flare_state( sgehdl, G_ON );
	GVU_sge_add_to_scene( sgehdl, *(g_InsideGVSApp->m_pMainScene->GetGVScene()) );
    

	g_oceanWave.DynSea_add( *(m_pMainScene->GetGVScene()) );

	g_pWaveMaterial =  GMaterial::CreateMaterial( g_oceanWave.GetOceanMaterial() );

    //AddTerrain2GVSPanel(g_pWaveMaterial,NULL);

    AddGVSObiNode( dynamic_cast<GMaterialImp*>(g_pWaveMaterial),NULL);

	//����������ص�����
	//GV_cam_set_sim_callback( *(m_pMainCamera->Get_camera()), MainCamera_Callback );
	//GV_cam_set_sim_data( *(m_pMainCamera->Get_camera()), sizeof(this), this );

	//������Ļ��ʾ����
	g_pFont = new  TFont();
	g_pFont->Create();
	g_pFont->SetLineCount(6);
	g_pFont->SetPos(0,0.8);
	g_pFont->SetPos(1,0.7);
	g_pFont->SetPos(2,0.6);
	g_pFont->SetPos(3,0.5);
	g_pFont->SetPos(4,0.4);
	g_pFont->SetPos(5,0.3);

	g_pFont->SetStr(0,"OpenGVS  4.5 Programer");


 return  G_SUCCESS;

}

int TGVSApp::GVS_user_proc( void )
{
  /*  static G_Rotation current_angles;
    // Get the current rotation angles for this object 
    GV_obi_inq_rotation( *(g_obi->Get_obi()), &current_angles );

    // Continuously tumble the object in all three axis 
	//by the some arbitrary "delta" values 
    current_angles.x -= 0.50 * G_DEG_TO_RAD;
    current_angles.y += 0.085 * G_DEG_TO_RAD;
    current_angles.z += 0.065 * G_DEG_TO_RAD;
    GV_obi_set_rotation( *(g_obi->Get_obi()), &current_angles );
*/
    G_Vector3  v_mg,v_gvs;
    v_mg.x = 10;v_mg.y=-10;v_mg.z=0;

	G_vec_multigen_to_gvs( &v_mg, &v_gvs);

 return  G_SUCCESS;

}

int TGVSApp::GVS_user_proc_post( void )
{
 return  G_SUCCESS;
}

int TGVSApp::GVS_user_shutdown( void )
{
  
  m_MtlSetDialog->DestroyWindow();
  delete m_MtlSetDialog;

  g_oceanWave.Dynsea_shutdown();

  if( g_pShip911 != NULL )
  {
	  delete  g_pShip911;
  }

  if( g_obi )
  {
     delete  g_obi;
     g_obi = NULL;
  }
 if( g_terrain )
	 delete  g_terrain;

 if( g_pFont ) 
      delete  g_pFont;

 return  G_SUCCESS;
}

int TGVSApp::EventProcess(UINT   message,WPARAM  wParam,LPARAM  lParam )
{
   g_oceanWave.GVSUserMessageProc(message,wParam,lParam);
   
   //if( g_pShip911 != NULL )
   //	   g_pShip911->GVSUserMessageProc(message,wParam,lParam);

  static RECT rc;
  static POINT ptTmp;
  static POINT pt;
  static int dx,dy;
  static bool m_isCaptureMouse = false;
  static G_Vector3   Sun_direction;

   bool fShift = GetKeyState(VK_SHIFT) & 0x8000 ? TRUE : FALSE;

  if( message == WM_KEYDOWN )
  {
        if( m_bControlCamera == true )  //��ǰ����Ϊ�����
		{
          ControlCameraEvent(message, wParam,lParam );
		}
        //else
		{
		  if( wParam == 'M' )
		  {
            GV_lsr_inq_direction( *(m_pSunLight->Get_light()) , &Sun_direction );
			   if( fShift  == TRUE )
			        Sun_direction.y += 0.5*G_DEG_TO_RAD;
			   else
                    Sun_direction.y -= 0.5*G_DEG_TO_RAD;

            GV_lsr_set_direction( *(m_pSunLight->Get_light()) , &Sun_direction );
		  }
		  if( wParam == 'N' )
		  {
			  ShowMtlDialog( g_oceanWave.GetOceanMaterial() );
		  }
		}
  }
  else  if( message == WM_KEYUP )
  {
	  
	  if(wParam == VK_TAB )
	  {
        if(m_bControlCamera==true)
		   m_bControlCamera	= false;
		else
			m_bControlCamera=true;
	  }
	  
  }
  else  if( message == WM_LBUTTONDOWN )
  {
	if( m_bControlCamera == true )  //��ǰ����Ϊ�����
	{
 	 ::GetClientRect(m_hWnd,&rc);
	 ::GetCursorPos(&pt);
	 ::ScreenToClient(m_hWnd,&pt);
	 if(!m_isCaptureMouse)
	 {
		if( ::GetCapture() != m_hWnd )
			  ::SetCapture(m_hWnd);
		ptTmp.x=rc.left;
		ptTmp.y=rc.top;
		::ClientToScreen(m_hWnd,&ptTmp);
		rc.left=ptTmp.x;
		rc.top=ptTmp.y;

		ptTmp.x=rc.right;
		ptTmp.y=rc.bottom;
		
		::ClientToScreen(m_hWnd,&ptTmp);
		rc.right=ptTmp.x;
		rc.bottom=ptTmp.y;

		::ClipCursor(&rc);
		::ShowCursor(FALSE);
		m_isCaptureMouse=true;
		ptTmp = pt;
		//m_point=pt;
	 }
	}
  }
  else  if( message == WM_LBUTTONUP )
  {
   if( m_bControlCamera == true )  //��ǰ����Ϊ�����
   {
	 if(m_isCaptureMouse)
	 {
		if(::GetCapture()==m_hWnd)
				::ReleaseCapture();
		::ClipCursor(NULL);
		m_isCaptureMouse=false;
		ShowCursor(TRUE);
	 }
   }

  }
  else  if( message == WM_MOUSEMOVE )
  {
	if( m_bControlCamera == true )  //��ǰ����Ϊ�����
	{
	 ::GetClientRect(m_hWnd,&rc);
	 ::GetCursorPos(&pt);
	 ::ScreenToClient(m_hWnd,&pt);
 	 if(m_isCaptureMouse)
	 {			
		dx = pt.x-ptTmp.x;
		dy = pt.y-ptTmp.y;
		

		{
	       static   float   step=1.5;
	       static   float   deltay,deltax;
		   static   G_Rotation  m_rot;

	       GV_cam_inq_rotation(*(m_pMainCamera->Get_camera()),0,&m_rot);
	       //------------------------------
	       deltay=step*(float)dx/(rc.right-rc.left)*360.0;
	       //-----------------------------
	        deltax=step*(float)dy/(rc.bottom-rc.top)*90.0;
	
			{
		       if(deltay>1.5)
		           deltay=1.5;
		       if(deltay<-1.5)
		           deltay=-1.5;
		       deltay*=G_DEG_TO_RAD;
		       m_rot.y-=deltay;
			}

			{
		       if(deltax>1.5)
		         deltax=1.5;
		       if(deltax<-1.5)
		         deltax=-1.5;
		       deltax*=G_DEG_TO_RAD;
		       m_rot.x-=deltax;
			}
	
	       GV_cam_set_rotation(*(m_pMainCamera->Get_camera()),0,&m_rot);

		}
		ptTmp = pt;
		if((rc.right-pt.x<3)||(pt.x-rc.left<3)||(rc.bottom-pt.y<3)||(pt.y-rc.top<3))
		{
			ptTmp.x=(rc.right-rc.left)/2;
			ptTmp.y=(rc.bottom-rc.top)/2;
			::SetCursorPos(ptTmp.x,ptTmp.y);
						
		}
	 }				
	}
  }

  return  G_SUCCESS;
}

void  TGVSApp::ControlCameraEvent(UINT   message, WPARAM  wParam,LPARAM  lParam )
{
  GCamera*  pCamera = m_pMainChannel->Get_curent_camera();
  static  G_Position  pos;
  static  G_Rotation  rot;
  static  float   MoveDestance = 1.0f;
  static  float  camera_aov;
 
  bool fShift = GetKeyState(VK_SHIFT) & 0x8000 ? TRUE : FALSE;

  pCamera->Get_position(0,&pos);
  pCamera->Get_rotation(0,&rot);

  if( wParam == 'W' )
  {
	if( fShift == TRUE )
	{
      rot.x += 0.25*G_DEG_TO_RAD;
	}
	else
	{
      pos.x -= MoveDestance*sin(rot.y);
	  pos.z -= MoveDestance*cos(rot.y);
	}
  }
  else  if( wParam == 'S' )
  {
	if( fShift == TRUE )
	{
      rot.x -= 0.25*G_DEG_TO_RAD;
	}
	else
	{
      pos.x += MoveDestance*sin(rot.y);
	  pos.z += MoveDestance*cos(rot.y);
	}
  }
  else  if( wParam == 'A' )
  {
    rot.y += 1.0*G_DEG_TO_RAD;
  }
  else  if( wParam == 'D' )
  {
    rot.y -= 1.0*G_DEG_TO_RAD;
  }
  else  if( wParam =='Q' )
  {
    
	if( fShift == TRUE )
	{
      MoveDestance += 0.1;   
	}
	else
	{
        pCamera->Get_aov(&camera_aov);
        camera_aov += 0.25*G_DEG_TO_RAD;
        pCamera->Set_aov(camera_aov);
	}
  }
  else  if( wParam == 'E' )
  {
  	if( fShift == TRUE )
	{
      MoveDestance -= 0.1;   
	}
	else
	{
        pCamera->Get_aov(&camera_aov);
        camera_aov -= 0.25*G_DEG_TO_RAD;
        pCamera->Set_aov(camera_aov);
	}

  }
  else  if( wParam == 'H' )
  {
  	if( fShift == TRUE )
	{
      g_Camera_Height -= 1;
	  pos.y += 1.0f;
	}
	else
	{
		g_Camera_Height += 1;
		pos.y -= 1.0f;
	}
  }

  pCamera->Set_rotation(0,&rot);
  pCamera->Set_position(0,&pos);
}
bool g_GVS_Run = false;
UINT  GVSThreadRun(void*  pParam )
{
	g_GVS_Run = true;
   
	g_GVSApp = new TGVSApp();
    CMainFrame*  pMainFrm = (CMainFrame*)AfxGetApp()->GetMainWnd();
    CVirtualGVSView*  pView = (CVirtualGVSView*)pMainFrm->GetActiveView( );
	g_GVSApp->Initialize( pView->m_hWnd );

	while( g_GVS_Run == true )
	{
		g_InsideGVSApp->GVSRun();
	}

	g_GVSApp->GVSShutdown();
    delete g_GVSApp;

	AfxEndThread(0);
	return 0;
}

void  TGVSApp::ShowMtlDialog( GV_Material  pMaterial )
{
  m_MtlSetDialog->m_pMaterial = pMaterial;
  m_MtlSetDialog->ShowWindow(SW_SHOWNORMAL);
}