#ifndef  __TSHIP911_H__
#define  __TSHIP911_H__

#include "GObi.h"

#define  SHIP_MAX_SPEED           0.0111  //��λ����/���룩
#define  SHIP_MAX_ACCELERATION    1.833E-8  //��λ(��/����2)

class  TShip911 : public GObi
{
private:
	float  m_current_speed;
	float  m_current_acceleration;
	float  m_Move_Destance;
	DWORD  m_last_time;
public:
    TShip911();
	~TShip911();

	static int Simulation_callback( GV_Obi inst, void *data_in );
	void   Inside_Simulation_Callback(void);
	void GVSUserMessageProc(UINT   message,WPARAM  wParam,LPARAM  lParam);
};

#endif