#if !defined(AFX_GGVSOBJECTTREE_H__5E4B4F01_6BDC_46CC_AA5C_61B33D7E87B0__INCLUDED_)
#define AFX_GGVSOBJECTTREE_H__5E4B4F01_6BDC_46CC_AA5C_61B33D7E87B0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GGVSObjectTree.h : header file
//

#define WM_TREESET_ITEMS	WM_USER + 0x6E01

/////////////////////////////////////////////////////////////////////////////
// GGVSObjectTree window

class GGVSObjectTree : public CTreeCtrl
{
// Construction
public:
	GGVSObjectTree();

// Attributes
public:
  
// Operations
public:
  
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(GGVSObjectTree)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~GGVSObjectTree();

	// Generated message map functions
protected:
	//{{AFX_MSG(GGVSObjectTree)
	afx_msg void OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GGVSOBJECTTREE_H__5E4B4F01_6BDC_46CC_AA5C_61B33D7E87B0__INCLUDED_)
