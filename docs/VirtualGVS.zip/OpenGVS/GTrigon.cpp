
#include "stdafx.h"
#include <stdlib.h>
#include <math.h>
#include  "GTrigon.h"

float    GTrigon::SinValue[90];
float    GTrigon::CosValue[90];
float    GTrigon::TanValue[90];
float    GTrigon::CtanValue[90];

div_t  MyDIV(int x,int y)
{
   div_t  temp;
   temp.quot = x/y;
   temp.rem = x - temp.quot*y;
   return  temp;
};

 
GTrigon::GTrigon()
{
  static  int  TrigonInit = 0;
  if( TrigonInit == 0 )
  {
	  TrigonInit = 1;
	  for( int i = 0;i<90;i++)
	  {
        SinValue[i] = sinf( (float)i );
		CosValue[i] = cosf( (float)i );
        TanValue[i] = tanf( (float)i );
        CtanValue[i] = atanf( (float)i );
	  }
  }
}

float GTrigon::Sin( int x )
{
	div_t   div_result = MyDIV( x, 360 );

	if( div_result.rem < 90 )
    {
        div_result.quot = 1;
	}
	else  if( div_result.rem < 180 )
    {
		x = x - 90;
        div_result.quot = 1;
	}
	else  if(  div_result.rem < 270 )
	{
		x = x - 180;
        div_result.quot = -1;
	}
	else
	{
		x = x - 270;
        div_result.quot = -1;
	}
	return  SinValue[x];
}

float GTrigon::Cos( int x )
{
	div_t   div_result = MyDIV( x, 360 );
	if( div_result.rem < 90 )
    {
        div_result.quot = 1;
	}
	else  if( div_result.rem < 180 )
    {
		x = x - 90;
        div_result.quot = -1;
	}
	else  if(  div_result.rem < 270 )
	{
		x = x - 180;
        div_result.quot = -1;
	}
	else
	{
		x = x - 270;
        div_result.quot = 1;
	}
	return  CosValue[x];

}

float GTrigon::tan( int x )
{
	div_t   div_result = MyDIV( x, 360 );
	if( div_result.rem < 90 )
    {
        div_result.quot = 1;
	}
	else  if( div_result.rem < 180 )
    {
		x = x - 90;
        div_result.quot = -1;
	}
	else  if(  div_result.rem < 270 )
	{
		x = x - 180;
        div_result.quot = 1;
	}
	else
	{
		x = x - 270;
        div_result.quot = -1;
	}
	return  TanValue[x];
}

float GTrigon::Ctan( int x )
{
	div_t   div_result = MyDIV( x, 360 );

	if( div_result.rem < 90 )
    {
        div_result.quot = 1;
	}
	else  if( div_result.rem < 180 )
    {
		x = x - 90;
        div_result.quot = -1;
	}
	else  if(  div_result.rem < 270 )
	{
		x = x - 180;
        div_result.quot = 1;
	}
	else
	{
		x = x - 270;
        div_result.quot = -1;
	}
	return  TanValue[x];
}

GTrigon  g_Trigon;