/****************************************************************************
�ļ����ƣ�TOceanWave.h   ���ڶ���ģ�⺣�˵���
������class  TOceanWave �����ڶ��嶯̬������Ҫ�����ݽṹ����Ӧ�Ĳ�������
2005.2   ������   ��Ȩ����
****************************************************************************/


#include "stdafx.h"
#include <afxmt.h>
#include <math.h>
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>
                    /* Entire OpenGVS kernel         */
#include "TOceanWave.h"
#include  "TVGVSAppFrame.h"
#include  "GChannel.h"
#include  "GScene.h"
#include  "GCamera.h"
#include  "mmsystem.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

extern TFont        *g_pFont;
TWakes*   g_pWakes = NULL;

CCriticalSection   DynOceanCriticalSection;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

TOceanWave::TOceanWave()
{
	Sea_state = 4;

	//Num_waves;
	sea_surface_alpha = 1.0f;//1.0f
	dyn_sea = NULL;
	g_pWakes = new TWakes();

	m_bDrawAsLines = false;
	m_bUseMaterial = true;   //USE_MATERIAL
	m_bUseTexture = true;
	m_bUseNormals = true;  //USE_NORMALS;
	m_bDiffColours = true;  //DIFF_COLOURS
	m_bUseAttrFile = true;  //USE_ATTR_FILE
}

TOceanWave::~TOceanWave()
{
	if( g_pWakes != NULL )
		delete g_pWakes;
	g_pWakes = NULL;
	//Dynsea_shutdown();
}

void TOceanWave::DynSea_state0()
{
	Sea_state = 0;

   Num_waves = 4;
   W[0] = 3.8421;
   Kx[0] = 0.8234;
   Ky[0] = 0.8234;
   Amp[0] = 0.00405;
   Phi[0] = 0.3615;

   W[1] = 4.6947;
   Kx[1] = 1.3915;
   Ky[1] = 1.3915;
   Amp[1] = 0.00243;
   Phi[1] = 0.3834;

   W[2] = 5.8031;
   Kx[2] = 2.3517;
   Ky[2] = 2.3517;
   Amp[2] = 0.00146;
   Phi[2] = 0.5049;

   W[3] = 7.2441;
   Kx[3] = 3.9743;
   Ky[3] = 3.9743;
   Amp[3] = 0.00088;
   Phi[3] = 0.5227;

}
void TOceanWave::DynSea_state1()
{
	Sea_state = 1;

   Num_waves = 4;
   W[0] = 1.8421;
   Kx[0] = 0.8234;
   Ky[0] = 0.8234;
   Amp[0] = 0.0405;
   Phi[0] = 0.3615;

   W[1] = 2.5947;
   Kx[1] = 1.3915;
   Ky[1] = 1.3915;
   Amp[1] = 0.0243;
   Phi[1] = 0.3834;

   W[2] = 3.5031;
   Kx[2] = 2.3517;
   Ky[2] = 2.3517;
   Amp[2] = 0.0146;
   Phi[2] = 0.5049;

   W[3] = 5.0441;
   Kx[3] = 3.9743;
   Ky[3] = 3.9743;
   Amp[3] = 0.0088;
   Phi[3] = 0.5227;

}


void TOceanWave::DynSea_state2()
{
	Sea_state = 2;

   Num_waves = 4;
   W[0] = 1.2710;
//   W[0] = 0.5684;
   Kx[0] = 0.1647;
   Ky[0] = 0.1647;
   Amp[0] = 0.2027;
   Phi[0] = 0.1055;

   W[1] = 1.6523;
//   W[1] = 0.7389;
   Kx[1] = 0.2783;
   Ky[1] = 0.2783;
   Amp[1] = 0.1216;
   Phi[1] = 0.4938;

   W[2] = 2.1480;
//   W[2] = 0.9606;
   Kx[2] = 0.4703;
   Ky[2] = 0.4703;
   Amp[2] = 0.0730;
   Phi[2] = 0.8172;

   W[3] = 4.7924;
//   W[3] = 1.2488;
   Kx[3] = 0.7949;
   Ky[3] = 0.7949;
   Amp[3] = 0.0438;
   Phi[3] = 0.1619;

}

void TOceanWave::DynSea_state4()
{
	Sea_state = 4;

   Num_waves = 4;
   W[0] = 0.5684;
   Kx[0] = 0.0329;
   Ky[0] = 0.0329;
   Amp[0] = 1.0135;
   Phi[0] = 0.1143;

   W[1] = 0.7389;
   Kx[1] = 0.0557;
   Ky[1] = 0.0557;
   Amp[1] = 0.6081;
   Phi[1] = 0.9139;

   W[2] = 0.9606;
   Kx[2] = 0.0941;
   Ky[2] = 0.0941;
   Amp[2] = 0.3649;
   Phi[2] = 0.1958;

   W[3] = 1.2488;
   Kx[3] = 0.1590;
   Ky[3] = 0.1590;
   Amp[3] = 0.2189;
   Phi[3] = 0.7084;

}

void TOceanWave::update_bbox(float xc, float yc, float zc, GV_Bbox *bbox)
{
	if( xc < bbox->xmin )
	    bbox->xmin = xc;
    else if( xc > bbox->xmax )
	     bbox->xmax = xc;

    if( yc < bbox->ymin )
	     bbox->ymin = yc;
    else if( yc > bbox->ymax )
	     bbox->ymax = yc;

    if( zc < bbox->zmin )
	     bbox->zmin = zc;
    else if( zc > bbox->zmax )
	     bbox->zmax = zc;

}

void TOceanWave::DynSea_init(TOceanWave::Dynamic_sea *dyn_sea1)
{
	dyn_sea1->setup = FALSE;

   dyn_sea1->step_x = 4.0;//��ƽ������Ŀ���
   dyn_sea1->step_y = 4.0;

   dyn_sea1->dyn_range_x = 200.0;
   dyn_sea1->dyn_range_y = 200.0;

   dyn_sea1->sea_range_x = 1000.0;
   dyn_sea1->sea_range_y = 1000.0;

   dyn_sea1->height = 0.0f;//0.0f;//09�޸�
   dyn_sea1->tfb = TRUE;

   dyn_sea1->surface_col[0] = 103.0f / 255.0f;  //��ƽ���ʼ����ɫ
   dyn_sea1->surface_col[1] = 159.0f / 255.0f;
   dyn_sea1->surface_col[2] = 159.0f / 255.0f;

   strcpy (dyn_sea1->txt_file,"seapat6s.int_e");//"seapat6s.int_e");// "water.int");//"h.rgba" );

   dyn_sea1->patt_size_u = 100.0;
   dyn_sea1->patt_size_v = 100.0;

   dyn_sea1->dyn_active = TRUE;

   dyn_sea1->use_tex = TRUE;
   dyn_sea1->rot_tex = FALSE;    /* NOT SUPPORTED */
   dyn_sea1->tex_rot = 0.0;

}

int TOceanWave::DynSea_set_state(int sstate)
{
	int status = G_SUCCESS;
   switch (sstate)
   {
   case 0:
         Sea_state = sstate;
         DynSea_state0();
         break;

   case 1:
         Sea_state = sstate;
         DynSea_state1();
         break;

   case 2:
         Sea_state = sstate;
         DynSea_state2();
         break;

   case 4:
         Sea_state = sstate;
         DynSea_state4();
         break;

   default:
        status = G_FAILURE;
	break;
   }
   return status;

}

int TOceanWave::DynSea_inq_state(int *sstate)
{
	* sstate = Sea_state;
    return G_SUCCESS;

}

GV_Obi TOceanWave::DynSea_add(GV_Scene scene)
{

   int   env_mode;

   G_State tstate;
   GV_Obi inst;
   int   n;
   int   m;
   int   dy_num_coord, num_coord;
   int   i, j;
   int   nbytes;
   int   num_tris, num_quads, num_ind_dy, num_vtx_in_strip;
   int   row, col;
   int   this_row_index, next_row_index;
   float y, x;
   int   num_ind_st2, num_ind_st3, num_ind_fade;
   int   *st_cindex2, *st_cindex3, *st_cindex4;
   int   *st_col_index2, *st_col_index3, *st_col_index4;
   int   *st_norm_index2, *st_norm_index3, *st_norm_index4;
   int   start_fade_index;
   float join_x, join_y;
   int   start_corner_index;
   int   start_outer_region;
   int   this_row_end_ind;
   int   next_row_end_ind;
   int   next_next_row_end_ind;
   int   top_row_ind;
   int   this_row_start_ind;
   int   next_row_start_ind;
   int   next_next_row_start_ind;
   float tex_rot;
   G_Name name;
   vec3  *coord_table;
   GV_Obd sea_def;

   /* SeaState */
   DynSea_set_state( 4 );//Sea_state  //���ú��˵ȼ�
   dyn_sea = (Dynamic_sea *) G_calloc( 1, sizeof( Dynamic_sea) );

   //GV_cmd_service("setenv TXTPATH ./txr");
   if( !dyn_sea )
       return NULL;

   /* Initialize the sea state model */
   DynSea_init( dyn_sea );
   m_PrevPos.x = m_PrevPos.y = m_PrevPos.z = 0.0f;
   m_firstGfx = false;

   dyn_sea->sea_state = Sea_state;
   dyn_sea->scene = scene;

   if (dyn_sea->rot_tex)//������ת�ĽǶ���
   {
      tex_rot = dyn_sea->tex_rot * G_DEG_TO_RAD;
      dyn_sea->cos_tex_rot = cosf(tex_rot);
      dyn_sea->sin_tex_rot = sinf(tex_rot);
   }

   //���㶯̬�����x,y�������������
   dyn_sea->n = n = (int) ((dyn_sea->dyn_range_x / dyn_sea->step_x) + 0.5);
   dyn_sea->m = m = (int) ((dyn_sea->dyn_range_y / dyn_sea->step_y) + 0.5);


   dyn_sea->num_coord_x = 2*n + 1;
   dyn_sea->num_coord_y = 2*m + 1;

   dy_num_coord = dyn_sea->num_coord_x * dyn_sea->num_coord_y;

 #if FULL_SEA
   /* Need extra 16 vertices to extend sea surface (this will
      NOT give continuity of heights but is just a starting point)
      (only need 12 if we share the points that join the moving section) */

   num_coord = dy_num_coord + 16;

   #if FADE1_LAYER
   num_coord += (2*n + 2*m + 4 + 4);
   #endif

 #else
   num_coord = dy_num_coord;
 #endif

   //���������ζ���������ڴ�
   dyn_sea->total_num_coords = num_coord;
   dyn_sea->coord_table = (vec3 *) G_calloc(1, num_coord * sizeof(vec3) );
   

/********************************************************************** 
Row 2m      ---------------------
            |  . |  . |  . |  . |
            |.   |.   |.   |.   |
            ---------------------
            |  . |  . |  . |  . |
            |.   |.   |.   |.   |
            ---------------------
            |  . |  . |  . |  . |
            |.   |.   |.   |.   |
Row 1   2n+1----2n+2------------2n + 2n+1
            |  . |  . |  . |  . |
            |.   |.   |.   |.   |
Row 0       ---------------------
           0     1              2n
*************************************************************************/

   /* Type vec3 (defined as array of 3 floats), in order xyz in db coordinates*/
   /* The coordinates of the sea mesh centered about a local
      origin are set up and stored in the coord_table */

   i = 0;
   coord_table = dyn_sea->coord_table;

   //��̬������̬�仯�ĺ�ƽ��
   for (row = -m; row <= m; row++)
   {
      y = row * dyn_sea->step_y;
      for (col = -n; col <= n; col++)
      {
         coord_table[i][X_IND] = col * dyn_sea->step_x;
         coord_table[i][Y_IND] = y;
         coord_table[i][Z_IND] = 0.0;
         i++;
      }

   }
   
   #if FULL_SEA
   /* Index of next coordinate is dy_num_coord */

   #if FADE1_LAYER
   start_fade_index = dy_num_coord;
   
   /* Fade layer at bottom: number of these coordinates is n+1 */
   y = -(m + 2) * dyn_sea->step_y;
   for (col = -n; col <= n; col += 2)
   {
      coord_table[i][X_IND] = col * dyn_sea->step_x;
      coord_table[i][Y_IND] = y;
      coord_table[i][Z_IND] = 0.0;
      i++;
   }

   /* Fade layer at right: number of these coordinates is m+1 */
   x = (n + 2) * dyn_sea->step_x;
   join_x = x;
   for (row = -m; row <= m; row += 2)
   {
      coord_table[i][X_IND] = x;
      coord_table[i][Y_IND] = row * dyn_sea->step_y;
      coord_table[i][Z_IND] = 0.0;
      i++;
   }

   /* Fade layer at top: number of these coordinates is n+1 */
   y = (m + 2) * dyn_sea->step_y;
   join_y = y;
   for (col = -n; col <= n; col += 2)
   {
      coord_table[i][X_IND] = col * dyn_sea->step_x;
      coord_table[i][Y_IND] = y;
      coord_table[i][Z_IND] = 0.0;
      i++;
   }

   /* Fade layer at left: number of these coordinates is m+1 */
   x = -(n + 2) * dyn_sea->step_x;
   for (row = -m; row <= m; row += 2)
   {
      coord_table[i][X_IND] = x;
      coord_table[i][Y_IND] = row * dyn_sea->step_y;
      coord_table[i][Z_IND] = 0.0;
      i++;
   }
   /* So total number of level 1 fade coordinates is 2m + 2n + 4 */

   /* Need 4 extra coordinates to fill in the corners */
   start_corner_index = i;
   
   /* SW */
   coord_table[i][X_IND] = -join_x;
   coord_table[i][Y_IND] = -join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* SE */
   coord_table[i][X_IND] = join_x;
   coord_table[i][Y_IND] = -join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* NE */
   coord_table[i][X_IND] = join_x;
   coord_table[i][Y_IND] = join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* NW */
   coord_table[i][X_IND] = -join_x;
   coord_table[i][Y_IND] = join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

 #else 
   join_x = dyn_sea->dyn_range_x;
   join_y = dyn_sea->dyn_range_y;
 #endif /* #if FADE1_LAYER */

   start_outer_region = i;
   /* South west corner */
   /* k0 */
   coord_table[i][X_IND] = -dyn_sea->sea_range_x;
   coord_table[i][Y_IND] = -dyn_sea->sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* k1 */
   coord_table[i][X_IND] = -join_x;
   coord_table[i][Y_IND] = -dyn_sea->sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k2 */
   coord_table[i][X_IND] = -dyn_sea->sea_range_x;
   coord_table[i][Y_IND] = -join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k3 */
   coord_table[i][X_IND] = -join_x;    /* Same as coord[0], 
                                          or coord[start_corner_index] */
   coord_table[i][Y_IND] = -join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* South east corner */
   /* k4 */
   coord_table[i][X_IND] = join_x;
   coord_table[i][Y_IND] = -dyn_sea->sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* k5 */
   coord_table[i][X_IND] = dyn_sea->sea_range_x;
   coord_table[i][Y_IND] = -dyn_sea->sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k6 */
   coord_table[i][X_IND] = join_x;     /* Same as coord[2n], 
   					   or coord[start_corner_index+1] */
   coord_table[i][Y_IND] = -join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k7 */
   coord_table[i][X_IND] = dyn_sea->sea_range_x;
   coord_table[i][Y_IND] = -join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* North west corner */
   /* k8 */
   coord_table[i][X_IND] = -dyn_sea->sea_range_x;
   coord_table[i][Y_IND] = join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* k9 */
   coord_table[i][X_IND] = -join_x;   /* Same as coord[2m * (2n+1)], or 
                                           coord[start_corner_index+2] */
   coord_table[i][Y_IND] = join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k10 */
   coord_table[i][X_IND] = -dyn_sea->sea_range_x;
   coord_table[i][Y_IND] = dyn_sea->sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k11 */
   coord_table[i][X_IND] = -join_x;
   coord_table[i][Y_IND] = dyn_sea->sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* North east corner */
   /* k12 */
   coord_table[i][X_IND] = join_x;   /* Same as coord[2m * (2n+1) + 2n], 
                                          or coord[start_corner_index+3] */
   coord_table[i][Y_IND] = join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;

   /* k13 */
   coord_table[i][X_IND] = dyn_sea->sea_range_x;
   coord_table[i][Y_IND] = join_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k14 */
   coord_table[i][X_IND] = join_x;
   coord_table[i][Y_IND] = dyn_sea->sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
   /* k15 */
   coord_table[i][X_IND] = dyn_sea->sea_range_x;
   coord_table[i][Y_IND] = dyn_sea->sea_range_y;
   coord_table[i][Z_IND] = 0.0;
   i++;
   
 #endif /* #if FULL_SEA */

   /* Now that all the different coordinates have been set up, need to
      set up indices into this coord_table to control which coordinates
      form part of which drawing primitive */
      
   num_quads = 2*n * 2*m;
   num_tris = num_quads * 2;

   /* Each row becomes a single tristrip.
      For each row, num_indices = 2 + num_tris in row */

   dyn_sea->num_strips = 2*m;   /* = number of rows */
   num_vtx_in_strip = 2 + 2*n*2;
   num_ind_dy = num_vtx_in_strip * dyn_sea->num_strips;

   dyn_sea->dy_cindex = (int *) G_malloc( num_ind_dy  * sizeof( int ) );

   /* Order for tristips */
   i = 0;
   this_row_index = 0;
   for (row = 0; row < 2*m; row++)   /* Do NOT go to last row */
   {
      next_row_index = (row+1) * (2*n + 1);//very Good!--Added by TOP----2004-08-04
      
      for (col = 0; col <= 2*n; col++)   /* DO go to last column */
      {
         dyn_sea->dy_cindex[i++] = next_row_index + col;
         dyn_sea->dy_cindex[i++] = this_row_index + col;
      }
      this_row_index = next_row_index;
   }

 #if FULL_SEA

   #if FADE1_LAYER
   dyn_sea->num_fade_tri = 2 * ( (3 * n) + (3 * m) ) + 8;
   num_ind_fade = 3 * dyn_sea->num_fade_tri;

   dyn_sea->st_cindex4 = (int *) G_malloc( num_ind_fade  * sizeof( int ) );
   st_cindex4 = dyn_sea->st_cindex4 ;

   /* Unconnected triangles */
   j = 0;   /* Index in to new coordinates created for the fade regions */
   i = 0;
   
   /* Base */
   for (col = 0; col < 2*n; col += 2)
   {
      /* Three triangles per column pair */
      
      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = col + 1;
      st_cindex4[i++] = col;

      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = start_fade_index + j + 1;
      st_cindex4[i++] = col + 1;

      st_cindex4[i++] = start_fade_index + j + 1;
      st_cindex4[i++] = col + 2;
      st_cindex4[i++] = col + 1;
      j++;
   }

   /* Right */
   j++;   /* Skip last fade coordinate along base */
   for (row = 0; row < 2*m; row += 2)
   {
      /* Three triangles per row pair */

      this_row_end_ind = row * (2*n + 1) + 2*n;
      next_row_end_ind = this_row_end_ind + (2*n + 1);
      next_next_row_end_ind = next_row_end_ind + (2*n + 1);
      
      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = next_row_end_ind;
      st_cindex4[i++] = this_row_end_ind;

      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = start_fade_index + j + 1;
      st_cindex4[i++] = next_row_end_ind;

      st_cindex4[i++] = start_fade_index + j + 1;
      st_cindex4[i++] = next_next_row_end_ind;
      st_cindex4[i++] = next_row_end_ind;
      j++;
   }
   
   /* Top. NB. Order changed compared with base */
   j++;   /* Skip last fade coordinate along right */
   top_row_ind = 2*m * (2*n + 1);
   for (col = 0; col < 2*n; col += 2)
   {
      /* Three triangles per column pair */
      
      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = top_row_ind + col;
      st_cindex4[i++] = top_row_ind + col + 1;

      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = top_row_ind + col + 1;
      st_cindex4[i++] = start_fade_index + j + 1;

      st_cindex4[i++] = start_fade_index + j + 1;
      st_cindex4[i++] = top_row_ind + col + 1;
      st_cindex4[i++] = top_row_ind + col + 2;
      j++;
   }

   /* Left. NB. Order changed compared with right */
   j++;   /* Skip last fade coordinate on top */
   for (row = 0; row < 2*m; row += 2)
   {
      /* Three triangles per row pair */

      this_row_start_ind = row * (2*n + 1);
      next_row_start_ind = this_row_start_ind + (2*n + 1);
      next_next_row_start_ind = next_row_start_ind + (2*n + 1);
      
      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = this_row_start_ind;
      st_cindex4[i++] = next_row_start_ind;

      st_cindex4[i++] = start_fade_index + j;
      st_cindex4[i++] = next_row_start_ind;
      st_cindex4[i++] = start_fade_index + j + 1;

      st_cindex4[i++] = start_fade_index + j + 1;
      st_cindex4[i++] = next_row_start_ind;
      st_cindex4[i++] = next_next_row_start_ind;
      j++;
   }

   /* Now do the corners. Could make these 2 triangle tristrips but
      that would mean making them a separate geoset, so stick to
      isolated triangles. */
      
   /* SW corner */
   st_cindex4[i++] = start_corner_index;
   st_cindex4[i++] = start_fade_index;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1 + n + 1;

   st_cindex4[i++] = 0;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1 + n + 1;
   st_cindex4[i++] = start_fade_index;
   
   /* SE corner */
   st_cindex4[i++] = start_corner_index + 1;
   st_cindex4[i++] = start_fade_index + n + 1;
   st_cindex4[i++] = start_fade_index + n;

   st_cindex4[i++] = 2 * n;
   st_cindex4[i++] = start_fade_index + n;
   st_cindex4[i++] = start_fade_index + n + 1;
   
   /* NE corner */
   st_cindex4[i++] = start_corner_index + 2;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1 + n;
   st_cindex4[i++] = start_fade_index + n + 1 + m;

   st_cindex4[i++] = 2*m * (2*n + 1) + 2*n;
   st_cindex4[i++] = start_fade_index + n + 1 + m;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1 + n;
   
   /* NW corner */
   st_cindex4[i++] = start_corner_index + 3;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1 + n + 1 + m;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1;

   st_cindex4[i++] = 2*m * (2*n + 1);
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1;
   st_cindex4[i++] = start_fade_index + n + 1 + m + 1 + n + 1 + m;
   
  #endif   /* Of FADE */

   /* The 4 corners use 4 vertices each */
   dyn_sea->num_st_strips = 4;
   num_ind_st2 = 16;
   
   dyn_sea->st_cindex2 = (int *) G_malloc( num_ind_st2  * sizeof( int ) );
   st_cindex2 = dyn_sea->st_cindex2 ;

   /* Order for tristips for the corners*/

   /* If FADE1_LAYER,
      SW, k3 =  start_corner_index,
      SE, k6 =  start_corner_index + 1,
      NW, k9 =  start_corner_index + 2,
      NE, k12 = start_corner_index + 3 */
      
   st_cindex2[0] = start_outer_region;
   st_cindex2[1] = start_outer_region + 1;
   st_cindex2[2] = start_outer_region + 2;
   #if FADE1_LAYER
   st_cindex2[3] = start_corner_index;
   #else
   st_cindex2[3] = 0;                        /* Also start_outer_region + 3 */
   #endif

   st_cindex2[4] = start_outer_region + 4;
   st_cindex2[5] = start_outer_region + 5;
   #if FADE1_LAYER
   st_cindex2[6] = start_corner_index + 1;
   #else
   st_cindex2[6] = 2 * n;                    /* Also start_outer_region + 6 */
   #endif
   st_cindex2[7] = start_outer_region + 7;

   st_cindex2[8] = start_outer_region + 8;
   #if FADE1_LAYER
   st_cindex2[9] = start_corner_index + 3;   /* Careful. */
   /* For some reason, the corners go SW, SE, NE, NW, unlike others */
   #else
   st_cindex2[9] = 2*m * (2*n + 1);          /* Also start_outer_region + 9 */
   #endif
   st_cindex2[10] = start_outer_region + 10;
   st_cindex2[11] = start_outer_region + 11;

   #if FADE1_LAYER
   st_cindex2[12] = start_corner_index + 2;   /* Careful. */
      /* For some reason, the corners go SW, SE, NE, NW, unlike others */
   #else
   st_cindex2[12] = 2*m * (2*n + 1) + 2*n;   /* Also start_outer_region + 12 */
   #endif
   st_cindex2[13] = start_outer_region + 13;
   st_cindex2[14] = start_outer_region + 14;
   st_cindex2[15] = start_outer_region + 15;

   /* The 4 side sections use 4 vertices each */
   dyn_sea->num_st_quads = 4;
   num_ind_st3 = 16;

   dyn_sea->st_cindex3 = (int *) G_malloc( num_ind_st3  * sizeof( int ) );
   st_cindex3 = dyn_sea->st_cindex3 ;

   st_cindex3[0] = start_outer_region + 1;
   st_cindex3[1] = start_outer_region + 4;
   #if FADE1_LAYER
   st_cindex3[2] = start_corner_index + 1;
   st_cindex3[3] = start_corner_index;
   #else
   st_cindex3[2] = 2 * n;                    /* Also start_outer_region + 6 */
   st_cindex3[3] = 0;                        /* Also start_outer_region + 3 */
   #endif

   #if FADE1_LAYER
   st_cindex3[4] = start_corner_index + 1;
   #else
   st_cindex3[4] = 2 * n;                    /* Also start_outer_region + 6 */
   #endif
   st_cindex3[5] = start_outer_region + 7;
   st_cindex3[6] = start_outer_region + 13;
   #if FADE1_LAYER
   st_cindex3[7] = start_corner_index + 2;   /* Careful. */
      /* For some reason, the corners go SW, SE, NE, NW, unlike others */
   #else
   st_cindex3[7] = 2*m * (2*n + 1) + 2*n;    /* Also start_outer_region + 12 */
   #endif

   #if FADE1_LAYER
   st_cindex3[8]  = start_corner_index + 3;   /* Careful. */
      /* For some reason, the corners go SW, SE, NE, NW, unlike others */
   st_cindex3[9]  = start_corner_index + 2;   /* Careful. */
      /* For some reason, the corners go SW, SE, NE, NW, unlike others */
   #else
   st_cindex3[8]  = 2*m * (2*n + 1);         /* Also start_outer_region + 9 */
   st_cindex3[9]  = 2*m * (2*n + 1) + 2*n;   /* Also start_outer_region + 12 */
   #endif
   st_cindex3[10] = start_outer_region + 14;
   st_cindex3[11] = start_outer_region + 11;

   st_cindex3[12] = start_outer_region + 2;
   #if FADE1_LAYER
   st_cindex3[13] = start_corner_index;
   st_cindex3[14] = start_corner_index + 3;   /* Careful. For some reason, the corners go SW, SE, NE, NW, unlike others */
   #else
   st_cindex3[13] = 0;                        /* Also start_outer_region + 3 */
   st_cindex3[14] = 2*m * (2*n + 1);          /* Also start_outer_region + 9 */
   #endif
   st_cindex3[15] = start_outer_region + 8;

 #endif   /* Of FULL_SEA */


 //#if USE_NORMALS
   dyn_sea->normal[0][0] = 0.0;
   dyn_sea->normal[0][1] = 0.0;
   dyn_sea->normal[0][2] = 1.0;

   dyn_sea->norm_index = (int *) G_calloc(
      1, dyn_sea->num_strips * sizeof(int) );

   for (i = 0; i < dyn_sea->num_strips; i++)
   {
      dyn_sea->norm_index[i] = 0;
   }

 #if FULL_SEA
   dyn_sea->st_norm_index2 = (int *) G_calloc(
      1,dyn_sea->num_st_strips * sizeof(int) );
   st_norm_index2 = dyn_sea->st_norm_index2 ;

   for (i = 0; i < dyn_sea->num_st_strips; i++)
   {
      st_norm_index2[i] = 0;
   }

   dyn_sea->st_norm_index3 = (int *) G_calloc(
      1,dyn_sea->num_st_quads * sizeof(int) );
   st_norm_index3 = dyn_sea->st_norm_index3 ;

   for (i = 0; i < dyn_sea->num_st_quads; i++)
   {
      st_norm_index3[i] = 0;
   }
   #if FADE1_LAYER
   dyn_sea->st_norm_index4 = (int *) G_calloc(
      1,dyn_sea->num_fade_tri * sizeof(int) );
   st_norm_index4 = dyn_sea->st_norm_index4 ;

   for (i = 0; i < dyn_sea->num_fade_tri; i++)
   {
      st_norm_index4[i] = 0;
   }
   #endif

  #endif   /* Of FULL_SEA */

 //#endif   /* Of USE_NORMALS */

   /* Type vec4 (defined as an array of 4 floats) */

   dyn_sea->col_table[0][0] = dyn_sea->surface_col[0];
   dyn_sea->col_table[0][1] = dyn_sea->surface_col[1];
   dyn_sea->col_table[0][2] = dyn_sea->surface_col[2];
   dyn_sea->col_table[0][3] = sea_surface_alpha;

   dyn_sea->col_index = (int *) G_calloc(
      1,dyn_sea->num_strips * sizeof(int) );

   for (i = 0; i < dyn_sea->num_strips; i++)
   {
      dyn_sea->col_index[i] = 0;
   }

 #if FULL_SEA
   dyn_sea->st_col_index2 = (int *) G_calloc(
      1,dyn_sea->num_st_strips * sizeof(int) );
   st_col_index2 = dyn_sea->st_col_index2 ;

   for (i = 0; i < dyn_sea->num_st_strips; i++)
   {
      st_col_index2[i] = 0;
   }

   dyn_sea->st_col_index3 = (int *) G_calloc(
      1,dyn_sea->num_st_quads * sizeof(int) );
   st_col_index3 = dyn_sea->st_col_index3 ;

   for (i = 0; i < dyn_sea->num_st_quads; i++)
   {
      st_col_index3[i] = 0;
   }
   #if FADE1_LAYER
   dyn_sea->st_col_index4 = (int *) G_calloc(
      1,dyn_sea->num_fade_tri * sizeof(int) );
   st_col_index4 = dyn_sea->st_col_index4 ;

   for (i = 0; i < dyn_sea->num_fade_tri; i++)
   {
      st_col_index4[i] = 0;
   }
   #endif   /* Of FADE1_LAYER */

 #endif   /* Of FULL_SEA */


   /* This is essential for TRISTRIPS type */
   dyn_sea->lengths = (int*) G_calloc(1, sizeof(int) * dyn_sea->num_strips);
   for (i = 0; i < dyn_sea->num_strips; i++)
      dyn_sea->lengths[i] = num_vtx_in_strip;

 #if FULL_SEA
   /* Corners: 2 triangle tristrips */

   dyn_sea->st_lengths = (int*) G_calloc(1, sizeof(int)*dyn_sea->num_st_strips);
   for (i = 0; i < dyn_sea->num_st_strips; i++)
      dyn_sea->st_lengths[i] = 4;
 #endif

 if( m_bUseMaterial == true )   //#if USE_MATERIAL
 {
   /* Light for shade effects */
   GV_mtl_create( &(dyn_sea->mtl) );
   GV_mtl_set_name( dyn_sea->mtl,"Ocean_Wave");
   DynSea_setup_material ( dyn_sea->mtl );
   GV_mtl_define( dyn_sea->mtl );
   GV_mtl_set_face( dyn_sea->mtl, GL_FRONT );
 }  //#endif

//if( m_bUseTexture == true ) //#if USE_TEXTURE
{
   dyn_sea->use_tex = TRUE;
   GV_txr_inq_state_system( &tstate );
   if( tstate == G_OFF )
       dyn_sea->use_tex = FALSE;

   /* Read the texture pattern */
   G_file_base( dyn_sea->txt_file, sizeof(name), name, &nbytes );
   GV_txr_inq_by_name( name, &dyn_sea->tex );
   if( !dyn_sea->tex && dyn_sea->use_tex )
   {
       GV_txr_create( &(dyn_sea->tex) );
       GV_txr_set_filename( dyn_sea->tex, dyn_sea->txt_file );

       /* Load (define) the texture file for the sea state */
       if (GV_txr_define( dyn_sea->tex ) != G_SUCCESS)
       {
          //fprintf( stderr, "DynSea_add: "     "could not find default texture file %s\n", dyn_sea->txt_file);
          //fflush ( stderr );
		   ::MessageBox(NULL,"��ʼ������ʱ���ִ���","OpenGVS����",MB_OK);
       }
       else
       {
          /* We do not manually read the MultiGen attribute file since this is
             taken care of by GV_txr_define.
             However, this does mean we must obtain the pattern size from
             the sea config file instead */
       }
   }

   if (dyn_sea->use_tex)
   {
      if( m_bUseAttrFile == true ) //#if USE_ATTR_FILE
      { 
        /* Now do the texture environment */
        //if ( env_mode == GL_BLEND )
		{
         static float env_colour[4];
         env_colour[0] = dyn_sea->blendcol[0];
         env_colour[1] = dyn_sea->blendcol[1];
         env_colour[2] = dyn_sea->blendcol[2];
         env_colour[3] = dyn_sea->blendcol[3];
		 GV_txr_set_env( dyn_sea->tex, GL_MODULATE);//GL_BLEND ); 
         GV_txr_set_env_property_v(dyn_sea->tex,GL_TEXTURE_ENV_COLOR, 4, env_colour );
		}
	  }  //#endif

      dyn_sea->tex_table = (vec2 *) G_calloc( 1, num_coord  * sizeof(vec2) );
      dyn_sea->tex_index = (int *) G_calloc( 1, num_ind_dy  * sizeof(int) );
    #if FULL_SEA
      dyn_sea->tex_index2 = (int *) G_calloc( 1, num_ind_st2  * sizeof(int) );
      dyn_sea->tex_index3 = (int *) G_calloc( 1, num_ind_st3  * sizeof(int) );
      #if FADE1_LAYER
      dyn_sea->tex_index4 = (int *) G_calloc( 1, num_ind_fade  * sizeof(int) );
      #endif
    #endif

      for (i = 0; i < num_coord; i++)
      {
         dyn_sea->tex_table[i][0] =  dyn_sea->coord_table[i][X_IND] / dyn_sea->patt_size_u;
         dyn_sea->tex_table[i][1] =  dyn_sea->coord_table[i][Y_IND] / dyn_sea->patt_size_v;
      }

      for (i = 0; i < num_ind_dy; i++)
      {
         dyn_sea->tex_index[i] = dyn_sea->dy_cindex[i];
      }

 #if FULL_SEA

      for (i = 0; i < num_ind_st2; i++)
      {
         dyn_sea->tex_index2[i] = st_cindex2[i];
      }

      for (i = 0; i < num_ind_st3; i++)
      {
         dyn_sea->tex_index3[i] = st_cindex3[i];
      }

      #if FADE1_LAYER
      for (i = 0; i < num_ind_fade; i++)
      {
         dyn_sea->tex_index4[i] = st_cindex4[i];
      }
      #endif
 #endif
   }   /* End of use_tex */
   
} //#endif   // Of USE_TEXTURE 
   

   GV_obd_open_by_name( "DYNAMIC_SEA", &sea_def );
   GV_obd_close( sea_def );

   GV_obi_instance(sea_def, &inst);

   GV_obi_set_drawing_order( inst,DYNAMIC_SEA_DRAW_ORDER );

   if( sea_surface_alpha < 1.0 )
       GV_obi_set_transparency_state( inst, G_TRISTATE_ON );

   GV_obi_set_gfx_callback(inst, DynSea_gfx_callback);
   //GV_obi_set_gfx_data(inst, sizeof(Dynamic_sea), dyn_sea);
   GV_obi_set_gfx_data(inst, sizeof(this), this);
   GV_scn_add_object(scene, inst);

   m_DynOceanSim.SetCurrentWindDegree(5);

   dyn_sea->setup = TRUE;

   (void) num_tris;	/* Not used anywhere at the moment... */

   //////////////////////////////////////////////////////////
   g_pWakes->Initialize(this);

   /*
   static G_Position init_pos = { 0.0, 0.0, -6.0  };
   m_wake.Initialize(init_pos);
   */
   //CWinThread*  pThread = AfxBeginThread(DynOceanSimThread,this); //,THREAD_PRIORITY_BELOW_NORMAL);
  // pThread->m_bAutoDelete = TRUE;

   return inst;

}

void TOceanWave::Dynsea_shutdown()
{
	//	 DynOceanCriticalSection.Lock( );
   //      g_DynOceanThreadRun = false;
	//	 DynOceanCriticalSection.Unlock( );
	
	//::Sleep(500);

	if(!dyn_sea)
		return;
	if (dyn_sea->coord_table)
    {
	G_free( dyn_sea->coord_table ) ;
	dyn_sea->coord_table = NULL ;
    }

    if (dyn_sea->dy_cindex)
    {
	G_free( dyn_sea->dy_cindex ) ;
	dyn_sea->dy_cindex = NULL ;
    }

    if (dyn_sea->st_cindex4)
    {
	G_free( dyn_sea->st_cindex4 ) ;
	dyn_sea->st_cindex4 = NULL ;
    }

    if (dyn_sea->st_cindex2)
    {
	G_free( dyn_sea->st_cindex2 ) ;
	dyn_sea->st_cindex2 = NULL ;
    }

    if (dyn_sea->st_cindex3)
    {
	G_free( dyn_sea->st_cindex3 ) ;
	dyn_sea->st_cindex3 = NULL ;
    }

    if (dyn_sea->norm_index)
    {
	G_free( dyn_sea->norm_index ) ;
	dyn_sea->norm_index = NULL ;
    }

    if (dyn_sea->st_norm_index2)
    {
	G_free( dyn_sea->st_norm_index2 ) ;
	dyn_sea->st_norm_index2 = NULL ;
    }

    if (dyn_sea->st_norm_index3)
    {
	G_free( dyn_sea->st_norm_index3 ) ;
	dyn_sea->st_norm_index3 = NULL ;
    }

    if (dyn_sea->st_norm_index4)
    {
	G_free( dyn_sea->st_norm_index4 ) ;
	dyn_sea->st_norm_index4 = NULL ;
    }

    if (dyn_sea->col_index)
    {
	G_free( dyn_sea->col_index ) ;
	dyn_sea->col_index = NULL ;
    }

    if (dyn_sea->st_col_index2)
    {
	G_free( dyn_sea->st_col_index2 ) ;
	dyn_sea->st_col_index2 = NULL ;
    }

    if (dyn_sea->st_col_index3)
    {
	G_free( dyn_sea->st_col_index3 ) ;
	dyn_sea->st_col_index3 = NULL ;
    }

    if (dyn_sea->st_col_index4)
    {
	G_free( dyn_sea->st_col_index4 ) ;
	dyn_sea->st_col_index4 = NULL ;
    }

    if (dyn_sea->lengths)
    {
	G_free( dyn_sea->lengths ) ;
	dyn_sea->lengths = NULL ;
    }

    if (dyn_sea->st_lengths)
    {
	G_free( dyn_sea->st_lengths ) ;
	dyn_sea->st_lengths = NULL ;
    }

    if (dyn_sea->tex_table)
    {
	G_free( dyn_sea->tex_table ) ;
	dyn_sea->tex_table = NULL ;
    }

    if (dyn_sea->tex_index)
    {
	G_free( dyn_sea->tex_index ) ;
	dyn_sea->tex_index = NULL ;
    }

    if (dyn_sea->tex_index2)
    {
	G_free( dyn_sea->tex_index2 ) ;
	dyn_sea->tex_index2 = NULL ;
    }

    if (dyn_sea->tex_index3)
    {
	G_free( dyn_sea->tex_index3 ) ;
	dyn_sea->tex_index3 = NULL ;
    }

    if (dyn_sea->tex_index4)
    {
	G_free( dyn_sea->tex_index4 ) ;
	dyn_sea->tex_index4 = NULL ;
    }

    if (dyn_sea)
    {
	G_free( dyn_sea ) ;
	dyn_sea = NULL ;
    }

    return ;

}

int TOceanWave::DynSea_gfx_callback(GV_Obi inst, void *data_in)
{
	GV_Bbox bbox = {0., 0., 0., 0., 0., 0.};	/* xmin-xmax, ... zmin-zmax */
   int ntriangles = 0;
   int        row, col;
   int        i, j;
   float      x, y, z;	/* Not OpenGVS coordinates; z is up */
   float      ang;
   float      eye_x, eye_y;
   float      wt[MAX_WAVES], disp[MAX_WAVES];
   vec3       *coord_table;
   int        index;
   float      r, g, b, a;
   float      u, v;
   G_Position pos;
   G_Rotation rot;
   GV_Camera  current_camera;
   GV_Texture current_tex;
   float current_time;

   GV_Channel chnhdl;
   Dynamic_sea * dyn_sea = NULL;
   TOceanWave*  pOcean=NULL;

//#if USE_MATERIAL
   int        light_state;
   GV_Material current_mtl;
//#endif

#if REMAP_TEXTURE
   float      sin_rot;
   float      cos_rot;
   vec2       *tex_table;
   vec2       tex_origin;
#endif

//#if DRAW_AS_LINES
   int        pmode;
//#endif

   int        vi = 0;
   if( !data_in )
       return G_FAILURE;

 

   /* Typecast generic pointer */
   pOcean = (TOceanWave *)data_in;
   dyn_sea = pOcean->dyn_sea;
	float *W= pOcean->W;
	float *Kx=pOcean->Kx;
	float *Ky=pOcean->Ky;
	float *Amp=pOcean->Amp;
	float *Phi=pOcean->Phi;
	int Num_waves=pOcean->Num_waves;

   /* Make center of mesh translate in x- and y-axis with eyepoint */
   //GV_chn_inq_input_focus( &chnhdl );
   GV_chn_inq_camera( *(g_InsideGVSApp->m_pMainChannel->GetInsideChannel()), &current_camera );
   GV_cam_inq_pos_rot_world( current_camera, BASE_PLATFORM, &pos, &rot );
   
   //GV_obi_set_position_x( inst, pos.x );
   //GV_obi_set_position_z( inst, pos.z );


   eye_x =  pos.x;   /* Can be thought of as "West" */
   eye_y = -pos.z;   /* Can be thought of as "North" */

    coord_table = dyn_sea->coord_table;
    
	static double dtime;

    /*  if( pOcean->m_firstGfx == false )
	  {
        pOcean->m_PrevPos = pos;
        pOcean->m_firstGfx = true;
	  }
     else
	 {
       G_Position  *p = &pOcean->m_PrevPos;
	   
	   if( ((p->x - pos.x)*(p->x - pos.x) + (p->z + eye_y)*(p->z + eye_y) ) > 10000 )
	   {
          pOcean->m_firstGfx = false;

            GV_obi_set_position_x( inst, pos.x );
             GV_obi_set_position_z( inst, pos.z );

	   }

	}
*/

   if( pOcean->m_bDrawAsLines == true ) //#if DRAW_AS_LINES
   {
      glGetIntegerv(GL_POLYGON_MODE, &pmode);
      glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
   }//#endif
 

   #if REMAP_TEXTURE
   if (dyn_sea->use_tex)
   {
      tex_table = dyn_sea->tex_table;

      tex_origin[0] = 0.0;
      tex_origin[1] = 0.0;

      /* We make the texture origin the nearest whole pattern units
         position to eyepoint, in order to keep the u,v coordinates
         as small as possible */

      if (!dyn_sea->rot_tex)
      {
   	     int tmpi;
         tmpi = (int) (eye_x / dyn_sea->patt_size_u);
         tex_origin[0] = (float) tmpi * dyn_sea->patt_size_u;
         tmpi = (int) (eye_y / dyn_sea->patt_size_v);
         tex_origin[1] = (float) tmpi * dyn_sea->patt_size_v;
      }
      else
      {
         /* Just until ok */
         dyn_sea->rot_tex = FALSE;
      }

      if (dyn_sea->rot_tex)
      {
         cos_rot = dyn_sea->cos_tex_rot;
         sin_rot = dyn_sea->sin_tex_rot;
      }

      for (i = 0; i < dyn_sea->total_num_coords; i++)
      {
         x = coord_table[i][DB_WEST_IND] + eye_x;
         y = coord_table[i][DB_NORTH_IND] + eye_y;

         if (dyn_sea->rot_tex)
         {
   	        float dx, dy;
            /* To undo a anticlockwise rot by ang, use
               (x,y) (cos, -sin)
                     (sin,  cos)
            */
            dx = x - tex_origin[0];
            dy = y - tex_origin[1];
            x = ( dx * cos_rot) + (y * sin_rot);
            y = (-dx * sin_rot) + (y * cos_rot);
            tex_table[i][DB_WEST_IND] = x / dyn_sea->patt_size_u;
            tex_table[i][DB_NORTH_IND] = y / dyn_sea->patt_size_v;

	        (void) dy;	/* Yes, we know we aren't using dy anywhere right now*/
         }
         else
         {
            tex_table[i][DB_WEST_IND] = 
	    	(x - tex_origin[0]) / dyn_sea->patt_size_u;

            tex_table[i][DB_NORTH_IND] = 
	    	(y - tex_origin[1]) / dyn_sea->patt_size_v;
         }
      }

   }
   #endif

   /* Now draw the sea surfaces */

   if( pOcean->m_bUseTexture == true )  //#if USE_TEXTURE
   {
     if (dyn_sea->use_tex)
	 {
       GV_txr_inq_current(&current_tex);
       GV_txr_set_current(dyn_sea->tex);
	 }
   }//#endif

   if( pOcean->m_bUseMaterial == true )  //#if USE_MATERIAL
   {
     light_state = glIsEnabled(GL_LIGHTING);
     glEnable(GL_LIGHTING);
     GV_mtl_inq_current(&current_mtl);
     GV_mtl_set_current(dyn_sea->mtl);
   }  //#endif

   /* Entire sea has the same colour */
   r = dyn_sea->col_table[0][0];
   g = dyn_sea->col_table[0][1];
   b = dyn_sea->col_table[0][2];
   a = dyn_sea->col_table[0][3];

   glColor4f(r, g, b, a);

   static float env_colour[4];
   env_colour[0] = dyn_sea->blendcol[0];
   env_colour[1] = dyn_sea->blendcol[1];
   env_colour[2] = dyn_sea->blendcol[2];
   env_colour[3] = dyn_sea->blendcol[3];
   GV_txr_set_env_property_v(dyn_sea->tex,GL_TEXTURE_ENV_COLOR, 4, env_colour );

   /* The moving part - triangle strips */
   vi = 0;   /* Vertex index */
   ntriangles += dyn_sea->num_strips;
   for (i = 0; i < dyn_sea->num_strips; i++)
   {
      glBegin(GL_TRIANGLE_STRIP); //����һ�������������δ�
      {
         if( pOcean->m_bDiffColours == true )  //#if DIFF_COLOURS
		 {
           index = dyn_sea->col_index[i];   /* Colour per strip */
           r = dyn_sea->col_table[index][0];
           g = dyn_sea->col_table[index][1];
           b = dyn_sea->col_table[index][2];
           a = dyn_sea->col_table[index][3];

           glColor4f(r, g, b, a);
         } //#endif

         if( pOcean->m_bUseNormals == true )//#if USE_NORMALS
		 {
           index = dyn_sea->norm_index[i];   /* Normal per strip */
           x = dyn_sea->normal[index][DB_WEST_IND];
           y = dyn_sea->normal[index][DB_VERT_IND];
           z = -dyn_sea->normal[index][DB_NORTH_IND];
           glNormal3f(x, y, z);
         }//#endif

         for (j = 0; j < dyn_sea->lengths[i]; j++)
         {
            index = dyn_sea->dy_cindex[vi++];

	        if( pOcean->m_bUseTexture == true ) //#if USE_TEXTURE
			{
              if (dyn_sea->use_tex)
			  {
                   /* Texture indices match the coordinate ones */
                   u = dyn_sea->tex_table[index][DB_WEST_IND];
                   v = dyn_sea->tex_table[index][DB_NORTH_IND];

                   glTexCoord2f(u, v);
			  }
			}//#endif

            x = dyn_sea->coord_table[index][DB_WEST_IND];
            y = dyn_sea->coord_table[index][DB_VERT_IND];
            z = -dyn_sea->coord_table[index][DB_NORTH_IND];

            glVertex3f( x, y, z);
	        update_bbox( x,y,z, &bbox );

         }
      }
      glEnd();
   }   /* Loop through triangular meshes for dynamic sea */


 #if FULL_SEA
   /* Corners of outer sea: 2 triangle tristrips */
   vi = 0;   /* Vertex index */
   ntriangles += dyn_sea->num_st_strips*2;
   for (i = 0; i < dyn_sea->num_st_strips; i++)
   {
      glBegin(GL_TRIANGLE_STRIP);
      {
        if( pOcean->m_bDiffColours == true ) //#if DIFF_COLOURS
		{
         index = dyn_sea->st_col_index2[i];   /* Colour per strip */
         r = dyn_sea->col_table[index][0];
         g = dyn_sea->col_table[index][1];
         b = dyn_sea->col_table[index][2];
         a = dyn_sea->col_table[index][3];

         glColor4f(r, g, b, a);
		} //#endif

      if( pOcean->m_bUseNormals == true ) //#if USE_NORMALS
	  {
         index = dyn_sea->st_norm_index2[i];   /* Normal per strip */
         x = dyn_sea->normal[index][DB_WEST_IND];
         y = dyn_sea->normal[index][DB_VERT_IND];
         z = -dyn_sea->normal[index][DB_NORTH_IND];
         glNormal3f(x, y, z);
      }  //#endif

         for (j = 0; j < dyn_sea->st_lengths[i]; j++)
         {
            index = dyn_sea->st_cindex2[vi++];
	    
            if( pOcean->m_bUseTexture == true ) //#if USE_TEXTURE
			{
              if (dyn_sea->use_tex)
			  {
               /* Texture indices match the coordinate ones */
               u = dyn_sea->tex_table[index][DB_WEST_IND];
               v = dyn_sea->tex_table[index][DB_NORTH_IND];

               glTexCoord2f(u, v);
			  }
			}// #endif

            x = dyn_sea->coord_table[index][DB_WEST_IND];
            y = dyn_sea->coord_table[index][DB_VERT_IND];
            z = -dyn_sea->coord_table[index][DB_NORTH_IND];

            glVertex3f( x, y, z);
	    update_bbox( x,y,z, &bbox );
         }
      }
      glEnd();
   }   /* Loop through tris for outer sea corners */

   /* Sides of outer sea: 4 separate quads */
   vi = 0;   /* Vertex index */
   ntriangles += dyn_sea->num_st_quads * 2;
   for (i = 0; i < dyn_sea->num_st_quads; i++)
   {
      glBegin(GL_QUADS);
      {
        if( pOcean->m_bDiffColours == true ) //#if DIFF_COLOURS
		{
         index = dyn_sea->st_col_index3[i];   /* Colour per quad */
         r = dyn_sea->col_table[index][0];
         g = dyn_sea->col_table[index][1];
         b = dyn_sea->col_table[index][2];
         a = dyn_sea->col_table[index][3];

         glColor4f(r, g, b, a);
        }//#endif

      if( pOcean->m_bUseNormals == true ) //#if USE_NORMALS
	  {
         index = dyn_sea->st_norm_index3[i];   /* Normal per quad */
         x = dyn_sea->normal[index][DB_WEST_IND];
         y = dyn_sea->normal[index][DB_VERT_IND];
         z = -dyn_sea->normal[index][DB_NORTH_IND];
         glNormal3f(x, y, z);
      }//#endif

         for (j = 0; j < 4; j++)
         {
            index = dyn_sea->st_cindex3[vi++];
	    
            if( pOcean->m_bUseTexture == true ) //#if USE_TEXTURE
			{
             if (dyn_sea->use_tex)
             {
               /* Texture indices match the coordinate ones */
               u = dyn_sea->tex_table[index][DB_WEST_IND];
               v = dyn_sea->tex_table[index][DB_NORTH_IND];

               glTexCoord2f(u, v);
             }
			} //#endif

            x = dyn_sea->coord_table[index][DB_WEST_IND];
            y = dyn_sea->coord_table[index][DB_VERT_IND];
            z = -dyn_sea->coord_table[index][DB_NORTH_IND];

            glVertex3f( x, y, z);
	    update_bbox( x,y,z, &bbox );
         }
      }
      glEnd();
   }

   #if FADE1_LAYER
   vi = 0;   /* Vertex index */
   ntriangles += dyn_sea->num_fade_tri;
   for (i = 0; i < dyn_sea->num_fade_tri; i++)
   {
      glBegin(GL_TRIANGLES);
      {
        if( pOcean->m_bDiffColours == true ) //#if DIFF_COLOURS
		{
         index = dyn_sea->st_col_index4[i];   /* Colour per tri */
         r = dyn_sea->col_table[index][0];
         g = dyn_sea->col_table[index][1];
         b = dyn_sea->col_table[index][2];
         a = dyn_sea->col_table[index][3];

         glColor4f(r, g, b, a);
        }//#endif

      if( pOcean->m_bUseNormals == true ) //#if USE_NORMALS
	  {
         index = dyn_sea->st_norm_index4[i];   /* Normal per tri */
         x = dyn_sea->normal[index][DB_WEST_IND];
         y = dyn_sea->normal[index][DB_VERT_IND];
         z = -dyn_sea->normal[index][DB_NORTH_IND];
         glNormal3f(x, y, z);
      }//#endif

         for (j = 0; j < 3; j++)
         {
            index = dyn_sea->st_cindex4[vi++];
            if( pOcean->m_bUseTexture == true ) //#if USE_TEXTURE
			{
             if (dyn_sea->use_tex)
             {
               /* Texture indices match the coordinate ones */
               u = dyn_sea->tex_table[index][DB_WEST_IND];
               v = dyn_sea->tex_table[index][DB_NORTH_IND];

               glTexCoord2f(u, v);
             }
			}// #endif

            x = dyn_sea->coord_table[index][DB_WEST_IND];//0
            y = dyn_sea->coord_table[index][DB_VERT_IND];//2
            z = -dyn_sea->coord_table[index][DB_NORTH_IND];//1

            glVertex3f( x, y, z);
	         update_bbox( x,y,z, &bbox );
         }
      }
      glEnd();
   }
   #endif   /* Of FADE1_LAYER */
 #endif   /* Of FULL_SEA */

   if( pOcean->m_bUseTexture == true )  //#if USE_TEXTURE
   {
     if (dyn_sea->use_tex)
	 {
      /* Restore previous texture */
      GV_txr_set_current(current_tex);
	 }
   }//   #endif

   if( pOcean->m_bUseMaterial == true ) //#if USE_MATERIAL
   {
    GV_mtl_set_current(current_mtl);
    if (!light_state)
      glDisable(GL_LIGHTING);
   }//#endif

   if( pOcean->m_bDrawAsLines == true ) //#if DRAW_AS_LINES
   {
      glPolygonMode(GL_FRONT_AND_BACK, pmode);
   }//#endif

   /* Tell OpenGVS how many triangles we just rendered */
   GV_obi_add_count( NULL, GV_OBJ_COUNT_TRIANGLES, ntriangles );

   /* Set the bounding box for the object */
   GV_obi_set_bbox_local( inst, &bbox );
   GV_obi_set_bbox_local_status( inst, GV_BBOX_VALID );


   //pWake->GfxCallback();

   return G_SUCCESS;

}

void TOceanWave::DynSea_setup_material(GV_Material mtl)
{
  /* static GV_Rgba amb  = {0.00,0.98,0.984};//{155./256., 233./256., 255./256, 1.0f};
   static GV_Rgba dif  = {0.00,0.98,0.984};//{155./256., 233./256., 255./256, 1.0f};
   static GV_Rgba spec = {0.00,0.98,0.984};//{155./256., 233./256., 255./256, 1.0f};

   static GV_Rgba emis = {0.0f, 0.0f, 0.0f, 1.0f};
   static float shiny = 1.0f;
  */
   
 /*  static GV_Rgba amb  = {0./256., 46./256., 60./256, 1.0f};
   static GV_Rgba dif  = {0./256., 46./256., 60./256, 1.0f};
   static GV_Rgba spec = {40./256., 40./256., 60./256, 1.0f};
   static GV_Rgba emis = {0.0f, 0.0f, 0.0f, 1.0f};
   static float shiny = 0.0f;
 */
 /*  static GV_Rgba amb  = {0.13,0.375,0.714};
   static GV_Rgba dif  = {0.1, 0.705, 0.784, 1.0f};
   static GV_Rgba spec = {0.116, 0.805, 2.064, 1.0f};
   static GV_Rgba emis = {0.0f, 0.0f, 0.0f, 1.0f};
   static float shiny = 0.0f;
*/
/*	   static GV_Rgba amb  = {0.13,0.315,1.149,0.0};
   static GV_Rgba dif  = {0.1, 0.715, 0.949, 1.0f};
   static GV_Rgba spec = {0.06, 0.605, 1.164, 1.0f};
   static GV_Rgba emis = {0.0f, 0.0f, 0.0f, 1.0f};
   static float shiny = 0.0f;
*/
   static GV_Rgba amb  = {0.13,0.315,1.294,0.0};
   static GV_Rgba dif  = {0.1, 0.715, 0.614, 1.0f};
   static GV_Rgba spec = {0.06, 0.95, 0.915, 1.0f};
   static GV_Rgba emis = {0.0f, 0.0f, 0.0f, 1.0f};
   static float shiny = 0.0f;

   if( sea_surface_alpha < 1.0f )
       amb.a = dif.a = sea_surface_alpha;
   GV_mtl_set_ambient( mtl, &amb ); //���ú�ƽ�滷����Ĳ�������
   GV_mtl_set_diffuse( mtl, &dif ); //���ú�ƽ��ɢ���Ĳ�������
   GV_mtl_set_specular( mtl, &spec );//���ú�ƽ�淴�����ɫ����
   GV_mtl_set_shininess( mtl, shiny );//���ú�ƽ�淴������ߴ�С�����ȵ�����

   GV_mtl_set_emission( mtl, &emis );  //���ú�ƽ��ķ����Դ����

}

void TOceanWave::GVSUserMessageProc(UINT   message,WPARAM  wParam,LPARAM  lParam)
{//-------------debug-------------

	GV_Material  mtl=NULL;
	if(dyn_sea)
	mtl = dyn_sea->mtl;	
	//mtl = g_pWakes->mtl;
  /*
   static GV_Rgba amb  = {0.13,0.375,0.714};
   static GV_Rgba dif  = {0.1, 0.705, 0.784, 1.0f};
   static GV_Rgba spec = {0.116, 0.805, 2.064, 1.0f};
   static GV_Rgba emis = {0.0f, 0.0f, 0.0f, 1.0f};
   static float shiny = 0.0f;
*/
	/*
   static GV_Rgba amb  = {0.13,0.315,1.149,0.0};
   static GV_Rgba dif  = {0.1, 0.715, 0.949, 1.0f};
   static GV_Rgba spec = {0.06, 0.605, 1.164, 1.0f};
   static GV_Rgba emis = {0.0f, 0.0f, 0.0f, 1.0f};
   static float shiny = 0.0f;
*/
   static GV_Rgba amb  = {0.13,0.315,1.294,0.0};
   static GV_Rgba dif  = {0.1, 0.715, 0.614, 0.0f};
   static GV_Rgba spec = {0.06, 0.95, 0.915, 0.0f};
   static GV_Rgba emis = {0.0f, 0.0f, 0.0f, 1.0f};
   static float shiny = 0.0f;
   
   if(dyn_sea)
       GV_mtl_set_ambient(dyn_sea->mtl,&amb);

   bool fShift = GetKeyState(VK_SHIFT) & 0x8000 ? TRUE : FALSE;

	if(message==WM_KEYDOWN)
	{
		static G_Position pos={0,0,0};
		static float step=0.005;
        if( fShift == FALSE )
		{
		  if(wParam=='1')
		  {
			amb.r += step;
            if( amb.r > 10.0 )
				amb.r = 10.0;
		  }
		  if(wParam=='2')
		  {
			amb.g += step;
			if( amb.g > 10.0 )
				amb.g = 10.0;
		  }
		  if(wParam=='3')
		  {
			amb.b += step;
			if( amb.b > 10.0 )
				amb.b = 10.0;
		  }
		
		  if(wParam=='4')
		  {
			dif.r += step;
            if(dif.r > 10.0 )
				dif.r = 10.0;
		  }
		  if(wParam=='5')
		  {
			dif.g +=step;
			if( dif.g > 10.0 )
				dif.g = 10.0;
		  }
		  if(wParam=='6')
          {
			dif.b+=step;
			if( dif.b > 10.0 )
				dif.b = 10.0;
          } 
		  if(wParam=='7')
		  {
			spec.r+=step;
			if( spec.r > 10.0 )
				spec.r = 10.0;
		  }
		  if(wParam=='8')
		  {
			spec.g+=step;
			if( spec.g > 10.0 )
				spec.g = 10.0;
		  }
		  if(wParam=='9')
		  {
			spec.b+=step;
			if( spec.b > 10.0 )
				spec.b = 10.0;
		  }

		  if(wParam=='0')
		  {
			step +=0.01;
			if( step > 10.0 )
				step = 10.0;
		  }
		  if(wParam=='R')
		  {
            dyn_sea->col_table[0][0] += step;
			if( dyn_sea->col_table[0][0] > 10.0 )
				dyn_sea->col_table[0][0] = 10.0;
		  }
		  if(wParam=='G')
		  {
            dyn_sea->col_table[0][1] += step;
			if( dyn_sea->col_table[0][1] > 10.0 )
				dyn_sea->col_table[0][1] = 10.0;
		  }
		  if(wParam=='B')
		  {
            dyn_sea->col_table[0][2] += step;
			if( dyn_sea->col_table[0][2] > 10.0 )
				dyn_sea->col_table[0][2] = 10.0;
		  }

          if( wParam=='P')
		  {
            dyn_sea->blendcol[0] += step;
				if( dyn_sea->blendcol[0] > 1.0 )
					dyn_sea->blendcol[0]  = 1.0f;
		  }
          if( wParam=='O')
		  {
            dyn_sea->blendcol[1] += step;
				if( dyn_sea->blendcol[1] > 1.0 )
					dyn_sea->blendcol[1]  = 1.0f;
		  }
          if( wParam=='I')
		  {
            dyn_sea->blendcol[2] += step;
				if( dyn_sea->blendcol[2] > 1.0 )
					dyn_sea->blendcol[2]  = 1.0f;
		  }

          if( wParam=='L')
		  {
            dyn_sea->blendcol[3] += step;
				if( dyn_sea->blendcol[3] > 1.0 )
					dyn_sea->blendcol[3]  = 1.0f;
		  }


        }
		else
		{
		  if(wParam=='1')
		  {
			amb.r -= step;
            if( amb.r < 0.0 )
				amb.r = 0.0;
		  }
		  if(wParam=='2')
		  {
			amb.g -= step;
			if( amb.g < 0.0 )
				amb.g = 0.0;
		  }
		  if(wParam=='3')
		  {
			amb.b -= step;
			if( amb.b < 0.0 )
				amb.b = 0.0;
		  }
		
		  if(wParam=='4')
		  {
			dif.r -= step;
            if( dif.r < 0.0 )
				dif.r = 0.0;
		  }
		  if(wParam=='5')
		  {
			dif.g -=step;
			if( dif.g < 0.0 )
				dif.g = 0.0;
		  }
		  if(wParam=='6')
          {
			dif.b -= step;
			if( dif.b < 0.0 )
				dif.b = 0.0;
          } 
		  if(wParam=='7')
		  {
			spec.r -= step;
			if( spec.r < 0.0 )
				spec.r = 0.0;
		  }
		  if(wParam=='8')
		  {
			spec.g -= step;
			if( spec.g < 0.0 )
				spec.g = 0.0;
		  }
		  if(wParam=='9')
		  {
			spec.b -= step;
			if( spec.b < 0.0 )
				spec.b = 0.0;
		  }

		  if(wParam=='0')
		  {
			step -=0.01;
			if( step < 0.0 )
				step = 0.0;
		  }
		  if(wParam=='R')
		  {
            dyn_sea->col_table[0][0] -= step;
			if( dyn_sea->col_table[0][0] < 0.0 )
				dyn_sea->col_table[0][0] = 0.0;
		  }
		  if(wParam=='G')
		  {
            dyn_sea->col_table[0][1] -= step;
			if( dyn_sea->col_table[0][1] < 0.0 )
				dyn_sea->col_table[0][1] = 0.0;
		  }
		  if(wParam=='B')
		  {
            dyn_sea->col_table[0][2] -= step;
			if( dyn_sea->col_table[0][2] < 0.0 )
				dyn_sea->col_table[0][2] = 0.0;
		  }

          if( wParam=='P')
		  {
            dyn_sea->blendcol[0] -= step;
				if( dyn_sea->blendcol[0] < 0.0 )
					dyn_sea->blendcol[0]  = 0.0f;
		  }
          if( wParam=='O')
		  {
            dyn_sea->blendcol[1] -= step;
				if( dyn_sea->blendcol[1] < 0.0 )
					dyn_sea->blendcol[1]  = 0.0f;
		  }
          if( wParam=='I')
		  {
            dyn_sea->blendcol[2] -= step;
				if( dyn_sea->blendcol[2] < 0.0 )
					dyn_sea->blendcol[2]  = 0.0f;
		  }

          if( wParam=='L')
		  {
            dyn_sea->blendcol[3] -= step;
				if( dyn_sea->blendcol[3] < 0.0 )
					dyn_sea->blendcol[3]  = 0.0f;
		  }
		  if( wParam=='J')
		  {
			  static  G_Position  t_Pos = {0.0,0.0,0.0 };
			  static  G_Rotation   t_Rot = {0.0f,0.0f,0.0f};

              
              //t_Rot.y = 30*G_DEG_TO_RAD;
              t_Rot.y  += 1*G_DEG_TO_RAD;
              
			  t_Pos.z -= 2*cosf(t_Rot.y); 
              t_Pos.x += 2*sinf(t_Rot.y); 

              g_pWakes->AddWake( t_Pos,t_Rot);
		  }
		}
///////////////////////////////////
   //r = dyn_sea->col_table[0][0];
   //g = dyn_sea->col_table[0][1];
   //b = dyn_sea->col_table[0][2];
   //a = dyn_sea->col_table[0][3];

 // env_colour[0] = dyn_sea->blendcol[0];
  // env_colour[1] = dyn_sea->blendcol[1];
  // env_colour[2] = dyn_sea->blendcol[2];
  // env_colour[3] = dyn_sea->blendcol[3];
///////////////////////////////////
		
		CString str;
        str.Format("MTL:r=%1.3f***g=%1.3f***b=%1.3f***a=%1.3f",amb.r,amb.g,amb.b,amb.a);
        g_pFont->SetStr(1,str);
        str.Format("MTL:r=%1.3f***g=%1.3f***b=%1.3f***a=%1.3f",dif.r,dif.g,dif.b,dif.a);
        g_pFont->SetStr(2,str);
        str.Format("MTL:r=%1.3f***g=%1.3f***b=%1.3f***a=%1.3f",spec.r,spec.g,spec.b,spec.a);
        g_pFont->SetStr(3,str);
        str.Format("MTL:r=%1.3f***g=%1.3f***b=%1.3f***a=%1.3f",	dyn_sea->col_table[0][0],	dyn_sea->col_table[0][1],	dyn_sea->col_table[0][2],spec.a);
        g_pFont->SetStr(4,str);
        str.Format("MTL:r=%1.3f***g=%1.3f***b=%1.3f***a=%1.3f",	dyn_sea->blendcol[0],dyn_sea->blendcol[1],dyn_sea->blendcol[2],dyn_sea->blendcol[3]);
        g_pFont->SetStr(5,str);



   if( sea_surface_alpha < 1.0f )
       amb.a = dif.a = sea_surface_alpha;

   GV_mtl_set_ambient( mtl, &amb );
   GV_mtl_set_diffuse( mtl, &dif );
   GV_mtl_set_specular( mtl, &spec );

   //GV_mtl_set_emission( mtl, &emis );
   //GV_mtl_set_shininess( mtl, shiny );

   GV_mtl_define(mtl);
		
	}

}

void  TOceanWave::SimulationCallback(G_Position*  p)
{
	static  float x,y,z;
	static float ang;
    static  float   wt[MAX_WAVES];
    static  float   disp[MAX_WAVES];

    x = p->x;
    y = -1*p->z;
    z = 0.0;
    for (int j=0; j<Num_waves; j++)//Num_wavesΪ���ӵ�����������
    {
               ang = wt[j] - (Kx[j] * x) - (Ky[j] * y) + Phi[j];
               disp[j] = sinf(ang) * Amp[j];
               z += disp[j];
    }
    p->y = z;

}

void  TOceanWave::SetSurfaceColor(unsigned char  r,unsigned char g,unsigned char b)
{
  if( dyn_sea == NULL )
	  return;
  dyn_sea->surface_col[0] = r;
  dyn_sea->surface_col[1] = g;
  dyn_sea->surface_col[2] = b;
}
///////////////////////////////////////////////////////////////////////
GV_Material    TOceanWave::GetOceanMaterial(void)
{
 if( dyn_sea == NULL )
	 return  NULL;
 else
    return dyn_sea->mtl; 
}
//-----------------------------------------------------------------------
bool g_DynOceanThreadRun = false;
UINT  DynOceanSimThread(void*  pParam )
{
  TOceanWave*  p = (TOceanWave*)pParam;
  g_DynOceanThreadRun = true;
  if( p != NULL )
  {
     while( g_DynOceanThreadRun == true )
		 p->DynOceanSimUpdate();
  }
  AfxEndThread(0);
  return 0;
}
//-------------------------------------------------------------------------
void  TOceanWave::DynOceanSimUpdate()
{

  static  double current_time,dtime;
  int        row, col;
   int        i, j;
   float      x, y, z;	/* Not OpenGVS coordinates; z is up */
   static vec3       *coord_table = dyn_sea->coord_table;
   static  DWORD  OldTime = timeGetTime();

   if (dyn_sea->dyn_active)
   {
      

      /* Method: We calculate the vertical values of all the
         vertices corresponding to the dynamic area of the sea
         model.
         Then we draw all the sea surfaces, using the modified
         vertex list. This ensures that shared vertices are not
         recalculated more than once and that shared vertices
         really do have the same value */
      static char  tempStr[256];

      
       // static double dtime;
	        G_timer_inq_time( &dtime );
            current_time = dtime;
			//sprintf(tempStr,"Current time %f",current_time);
            //g_pFont->SetStr(1,tempStr);

			DWORD  tempD = timeGetTime();

      
      
	  if( (tempD - OldTime) >= 100 )
	  {
		  DynOceanCriticalSection.Lock( );

         i = 0;
         for (row=0; row<dyn_sea->num_coord_y; row++)
		 {
            for (col=0; col<dyn_sea->num_coord_x; col++)
			{
              x = coord_table[i][DB_WEST_IND];// + eye_x;
              y = coord_table[i][DB_NORTH_IND];// + eye_y;
              z = 0.0;
 
			  z = 0.0;//m_DynOceanSim.dynSimulation( x,y,z,current_time );
           
              coord_table[i][DB_VERT_IND] = z;
		
              i++;
			}
		 }

		 DynOceanCriticalSection.Unlock( );

         OldTime = tempD;
	  }


   }   /* End of dyn_active */

}
//------------------------------------------------------------------------