/********************************************************************
FileName:     GMaterial.cpp
descript:     ���ڶ��������
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/
#include "stdafx.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include  "GMaterial.h"
#include  "GMaterialImp.h"

GMaterial::GMaterial( GV_Material  pMaterial )
{
  m_InsideMaterial = pMaterial;
}

GMaterial::~GMaterial()
{

}


GMaterial*  GMaterial::CreateMaterial(const char* name)
{

   GMaterialImp* p = new GMaterialImp(name);
   int hr = GV_mtl_inq_by_name( name, &(p->m_InsideMaterial) );
   if( (hr != G_SUCCESS)||(p->m_InsideMaterial == NULL ) )
   {
              GV_mtl_create( &(p->m_InsideMaterial)  );
			  GV_mtl_set_name( p->m_InsideMaterial,name );
   }

   GV_Rgba   Color_RGBA;

   p->Get_ambient(  &Color_RGBA );
   p->Ambient_R = Color_RGBA.r; 	
   p->Ambient_G = Color_RGBA.g; 	
   p->Ambient_B = Color_RGBA.b; 	
   p->Ambient_A = Color_RGBA.a;
   
   p->Get_diffuse(  &Color_RGBA  );
   p->Diffuse_R =  Color_RGBA.r;
   p->Diffuse_G =  Color_RGBA.g;
   p->Diffuse_B =  Color_RGBA.b;
   p->Diffuse_A =  Color_RGBA.a;
   
   p->Get_specular(  &Color_RGBA  );
   p->Specular_R = Color_RGBA.r;
   p->Specular_G = Color_RGBA.g;
   p->Specular_B = Color_RGBA.b;
   p->Specular_A = Color_RGBA.a;



   return  p;
}

GMaterial*  GMaterial::CreateMaterial( GV_Material  pMaterial )
{
   G_Name  t_name;
   GV_mtl_inq_name( pMaterial,t_name );
   strcpy( t_name,"WAVE_MTL");
   GMaterialImp* p = new GMaterialImp(t_name);

   
   p->m_InsideMaterial = pMaterial;

   GV_Rgba   Color_RGBA;

   p->Get_ambient(  &Color_RGBA );
   p->Ambient_R = Color_RGBA.r; 	
   p->Ambient_G = Color_RGBA.g; 	
   p->Ambient_B = Color_RGBA.b; 	
   p->Ambient_A = Color_RGBA.a;
   
   p->Get_diffuse(  &Color_RGBA  );
   p->Diffuse_R =  Color_RGBA.r;
   p->Diffuse_G =  Color_RGBA.g;
   p->Diffuse_B =  Color_RGBA.b;
   p->Diffuse_A =  Color_RGBA.a;
   
   p->Get_specular(  &Color_RGBA  );
   p->Specular_R = Color_RGBA.r;
   p->Specular_G = Color_RGBA.g;
   p->Specular_B = Color_RGBA.b;
   p->Specular_A = Color_RGBA.a;



   return  p;
  
}

int GMaterial::Define( void )
{
	return GV_mtl_define( m_InsideMaterial );
}

int GMaterial::Free( void )
{
	return  GV_mtl_free( m_InsideMaterial );
}

int GMaterial::Set_name(  const G_Name name_in )
{
  return  GV_mtl_set_name( m_InsideMaterial, name_in );
}

int GMaterial::Get_name(  G_Name name_out )
{
  return  GV_mtl_inq_name( m_InsideMaterial, name_out );
}

int GMaterial::Set_ambient(  const GV_Rgba *ambient )
{
  return  GV_mtl_set_ambient( m_InsideMaterial, ambient );
}

int GMaterial::Get_ambient(  GV_Rgba *ambient )
{
  return  GV_mtl_inq_ambient( m_InsideMaterial, ambient );
}

int GMaterial::Set_diffuse(  const GV_Rgba *diffuse )
{
  return  GV_mtl_set_diffuse( m_InsideMaterial, diffuse );
}

int GMaterial::Get_diffuse(  GV_Rgba *diffuse )
{
  return  GV_mtl_inq_diffuse( m_InsideMaterial, diffuse );
}

int GMaterial::Set_emission(  const GV_Rgba *emission )
{
  return  GV_mtl_set_emission( m_InsideMaterial, emission );
}

int GMaterial::Get_emission(  GV_Rgba *emission )
{
  return GV_mtl_inq_emission( m_InsideMaterial, emission );
}

int GMaterial::Set_specular(  const GV_Rgba *specular )
{
  return  GV_mtl_set_specular( m_InsideMaterial, specular );
}

int GMaterial::Get_specular(  GV_Rgba *specular )
{
  return  GV_mtl_inq_specular( m_InsideMaterial, specular );
}

int GMaterial::Set_shininess(  float shininess )
{
  return  GV_mtl_set_shininess( m_InsideMaterial, shininess );
}

int GMaterial::Get_shininess(  float *shininess )
{
  return  GV_mtl_inq_shininess( m_InsideMaterial, shininess );
}

int GMaterial::Set_face(  GLenum face )
{
  return  GV_mtl_set_face( m_InsideMaterial, face );
}

int GMaterial::Get_face(  GLenum *face )
{
  return  GV_mtl_inq_face( m_InsideMaterial, face );
}

int GMaterial::Set_attribute_mask(  GV_Mtl_attr_mask amask_in )
{
  return  GV_mtl_set_attribute_mask( m_InsideMaterial, amask_in ) ;
}

int GMaterial::Get_attribute_mask(  GV_Mtl_attr_mask * amask_out )
{
  return  GV_mtl_inq_attribute_mask( m_InsideMaterial, amask_out ) ;
}

     /* PROTOTYPE */
int GMaterial::Set_auxiliary_call_list(  GLuint call_list_in )
{
  return  GV_mtl_set_auxiliary_call_list( m_InsideMaterial, call_list_in ) ;
}

int GMaterial::Get_auxiliary_call_list(  GLuint *call_list_out )
{
  return  GV_mtl_inq_auxiliary_call_list( m_InsideMaterial, call_list_out ) ;
}

int GVS_mtl_define_pending( void )
{
  return GV_mtl_define_pending();
}

int GVS_mtl_set_current( GMaterial*  mtlhdl )
{
  return GV_mtl_set_current( *(mtlhdl->Get_material()) );
}

int GVS_mtl_Get_current( GMaterial * mtlhdl )
{
  return  GV_mtl_inq_current( mtlhdl->Get_material() );
}
