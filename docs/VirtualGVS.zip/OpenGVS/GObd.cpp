/********************************************************************
FileName:     GObd.cpp
descript:     ���ڶ������嶨����
Copy Right:   ���ļ��������춨�壬δ�����ɲ��ÿ���
********************************************************************/
#include "stdafx.h"

#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include "GObd.h"
#include "GObdImp.h"

GObd::GObd()
{
  m_InsideObd = NULL;
}


GObd::~GObd()
{
 m_InsideObd = NULL;
}

GObd*  GObd::CreateObd_by_name(const char* name)
{
  GObd* p = new GObdImp(name);
  GV_obd_inq_by_name( name, &p->m_InsideObd );
  GV_obd_set_name( p->m_InsideObd, name);
  return  p;
}

GObd*  GObd::CreateObd_by_import(const char* name,const char* importStr)
{
 GObd* p = new GObdImp(name);
 GV_cmd_service( importStr );
 GV_obd_inq_by_name( name, &p->m_InsideObd );
 GV_obd_set_name( p->m_InsideObd, name);
 return  p;
}

GObd*  GObd::DirectDefineObd(const char*  name,GVS_Obd_define_callback  define_callback)
{
    GObd* p = new GObdImp(name);
	if( name == NULL )
	   GV_obd_open( &p->m_InsideObd );
	else
		GV_obd_open_by_name( name,&p->m_InsideObd );

   if( define_callback != NULL )
       define_callback(p);
   
   GV_obd_close( p->m_InsideObd );
   return  p;
}

int  GObd::Get_path( int namdim, char * fname, int * length)
{
	return  GV_obd_inq_path( m_InsideObd, namdim, fname, length);
}

int  GObd::Get_position_granularity( G_Position * g_out )
{
	return  GV_obd_inq_position_granularity( m_InsideObd, g_out ) ;
}

int  GObd::Set_position_granularity( const G_Position * g_in ) 
{
  return  GV_obd_set_position_granularity( m_InsideObd, g_in ) ;
}

int  GObd::Get_rotation_granularity( G_Rotation * g_out )
{
  return  GV_obd_inq_rotation_granularity( m_InsideObd, g_out ) ;
}

int  GObd::Set_rotation_granularity( const G_Rotation * g_in )
{
  return  GV_obd_set_rotation_granularity( m_InsideObd, g_in ) ;
}

int  GObd::Get_scaling_granularity( G_Vector3 * g_out )
{
 return  GV_obd_inq_scaling_granularity( m_InsideObd,g_out ) ;
}

int  GObd::Set_scaling_granularity( const G_Vector3 * g_in )
{
 return  GV_obd_set_scaling_granularity( m_InsideObd, g_in ) ;
}

int  GObd::Set_text_string( const char * ptext )
{
  return  GV_obd_set_text_string( m_InsideObd, ptext );
}

int  GObd::Get_text_string( char** p_text )
{
  return  GV_obd_inq_text_string( m_InsideObd, p_text );
}

int  GObd::Set_template_type( GV_Obj_template_type ttype)
{
 return  GV_obd_set_template_type( m_InsideObd, ttype);
}

int  GObd::Get_template_type( GV_Obj_template_type * p_ttype)
{
 return  GV_obd_inq_template_type( m_InsideObd, p_ttype);
}


int  GObd::Set_template_axis( const G_Vector3 *axis)
{
 return  GV_obd_set_template_axis( m_InsideObd,axis);
}

int  GObd::Get_template_axis( G_Vector3 *axis)
{
 return  GV_obd_inq_template_axis( m_InsideObd,axis);
}


int  GObd::Set_template_point( const G_Position *point)
{
 return  GV_obd_set_template_point( m_InsideObd, point);
}

int  GObd::Get_template_point( G_Position *point)
{
 return  GV_obd_inq_template_point( m_InsideObd, point);
}


int  GObd::Set_lod_transition_range( float transition_in )
{
 return  GV_obd_set_lod_transition_range( m_InsideObd, transition_in ) ;
}

int  GObd::Get_lod_transition_range( float * transition_out )
{
  return  GV_obd_inq_lod_transition_range( m_InsideObd, transition_out ) ;
}


int  GObd::Set_name( const G_Name name)
{
 return  GV_obd_set_name( m_InsideObd, name);
}

int  GObd::Get_name( G_Name name)
{
 return  GV_obd_inq_name(m_InsideObd,name);
}


/*
int  GObd::Get_by_name_relative( const char * rel_name, GV_Obd * p_obdhdl )
{
 return  
}
*/

int  GObd::Attach_child( GV_Obd child_obdhdl)
{
 return  GV_obd_attach_child( m_InsideObd, child_obdhdl);
}

int  GObd::Detach_child( GV_Obd obdhdl)
{
 return  GV_obd_detach_child( m_InsideObd );
}

    //int  GV_obd_free( GV_Obd obdhdl);
    //int  GV_obd_free_all( void );

int  GObd::Get_attribute_float( GV_Obj_attr oattr, float * aval)
{
  return  GV_obd_inq_attribute_float( m_InsideObd, oattr, aval);
}

int  GObd::Set_attribute_float( GV_Obj_attr oattr, float aval )
{
 return  GV_obd_set_attribute_float( m_InsideObd, oattr, aval );
}

int  GObd::Get_attribute( GV_Obj_attr oattr,     int  * aval )
{
 return  GV_obd_inq_attribute( m_InsideObd, oattr, aval );
}

int  GObd::Set_attribute( GV_Obj_attr oattr,     int  aval )
{
 return  GV_obd_set_attribute( m_InsideObd, oattr, aval );
}



    //int  Get_root_first( GV_Obd * p_obdhdl );
    //int  Get_root_last( GV_Obd * p_obdhdl );
    //int  Get_root_next( GV_Obd obdhdl, GV_Obd * p_obdhdl );
    //int  Get_root_previous( GV_Obd obdhdl, GV_Obd * p_obdhdl );

    //int  Get_root( GV_Obd obdhdl, GV_Obd * p_obdhdl );
    //int  Get_child( GV_Obd obdhdl, GV_Obd * p_obdhdl );
    //int  Get_next( GV_Obd obdhdl, GV_Obd * p_obdhdl );
    //int  Get_parent( GV_Obd obdhdl, GV_Obd * p_obdhdl );
    //int  Get_previous( GV_Obd obdhdl, GV_Obd * p_obdhdl );

int  GObd::Get_valid(  G_Boolean * p_gstate )
{
 return  GV_obd_inq_valid( m_InsideObd, p_gstate );
}

int  GObd::Set_origin_offset( const G_Position *voffset)
{
 return  GV_obd_set_origin_offset( m_InsideObd, voffset);
}

int  GObd::Get_origin_offset(  G_Position *offset)
{
 return  GV_obd_inq_origin_offset( m_InsideObd, offset);
}

int  GObd::Set_gfx_offset_state(  G_State ostate_in )
{
 return  GV_obd_set_gfx_offset_state( m_InsideObd, ostate_in );
}

int  GObd::Get_gfx_offset_state(  G_State * ostate_out )
{
 return  GV_obd_inq_gfx_offset_state( m_InsideObd, ostate_out );
}

int  GObd::Set_lod_scaling_mode( GV_Obj_lod_scaling_mode lsmode_in )
{
 return  GV_obd_set_lod_scaling_mode( m_InsideObd, lsmode_in ) ;

}

int  GObd::Get_lod_scaling_mode( GV_Obj_lod_scaling_mode * lsmode_out )
{
 return  GV_obd_inq_lod_scaling_mode( m_InsideObd, lsmode_out ) ;
}

int  GObd::Set_position(  const G_Position *vpos)
{
 return  GV_obd_set_position( m_InsideObd,vpos);
}

int  GObd::Get_position(  G_Position *position)
{
  return  GV_obd_inq_position( m_InsideObd, position);
}

int  GObd::Set_position_x(  float position)
{
  return  GV_obd_set_position_x( m_InsideObd, position);
}

int  GObd::Get_position_x(  float * p_posx)
{
 return GV_obd_inq_position_x( m_InsideObd, p_posx);
}

int  GObd::Set_position_y(  float position)
{
 return  GV_obd_set_position_y( m_InsideObd, position);
}

int  GObd::Get_position_y( float * p_posy)
{
 return  GV_obd_inq_position_y( m_InsideObd, p_posy);
}

int  GObd::Set_position_z(  float position)
{
 return  GV_obd_set_position_z( m_InsideObd, position);
}

int  GObd::Get_position_z( float * p_posz)
{
 return  GV_obd_inq_position_z( m_InsideObd, p_posz);
}

int  GObd::Set_rotation( const G_Rotation *angles)
{
 return  GV_obd_set_rotation( m_InsideObd, angles);
}

int  GObd::Get_rotation(  G_Rotation *rotation)
{
 return  GV_obd_inq_rotation( m_InsideObd, rotation);
}

int  GObd::Set_rotation_x( float angle)
{
 return  GV_obd_set_rotation_x( m_InsideObd, angle);
}

int  GObd::Get_rotation_x(  float * p_rotx)
{
 return  GV_obd_inq_rotation_x( m_InsideObd, p_rotx);
}

int  GObd::Set_rotation_y(  float angle)
{
 return  GV_obd_set_rotation_y( m_InsideObd, angle);
}

int  GObd::Get_rotation_y(  float * p_roty)
{
 return  GV_obd_inq_rotation_y( m_InsideObd, p_roty );
}

int  GObd::Set_rotation_z(  float angle)
{
 return  GV_obd_set_rotation_z( m_InsideObd,angle);
}

int  GObd::Get_rotation_z( float * p_rotz)
{
  return  GV_obd_inq_rotation_z( m_InsideObd, p_rotz);
}

int  GObd::Set_pos_rot( const G_Position *pos, const G_Rotation *rots)
{
 return  GV_obd_set_pos_rot( m_InsideObd, pos, rots);

}


int  GObd::Get_pos_rot_world( G_Position *opos, G_Rotation *orot)
{
  return  GV_obd_inq_pos_rot_world( m_InsideObd, opos, orot);
}

int  GObd::Get_SRT_world( G_Scaling * scaling_out,G_Rotation * rotation_out, G_Position * position_out )
{
  return  GV_obd_inq_SRT_world( m_InsideObd,scaling_out,rotation_out,position_out ) ;
}

int  GObd::Set_scaling( const G_Vector3 *scales)
{
 return  GV_obd_set_scaling( m_InsideObd, scales);
}

int  GObd::Get_scaling( G_Vector3 *scales)
{
 return  GV_obd_inq_scaling( m_InsideObd, scales);
}

int  GObd::Get_radius( float * radius_out )
{
  return  GV_obd_inq_radius( m_InsideObd, radius_out ) ;
}

int  GObd::Get_bbox_local( GV_Bbox *bbox,GV_Bbox_status * p_bbstat)
{
  return  GV_obd_inq_bbox_local( m_InsideObd, bbox,p_bbstat);

}

int  GObd::Set_bbox_local( const GV_Bbox *bbox)
{
  return  GV_obd_set_bbox_local( m_InsideObd, bbox);
}

int  GObd::Get_bbox_local_status( GV_Bbox_status * p_bbstat)
{
  return  GV_obd_inq_bbox_local_status( m_InsideObd, p_bbstat);

}

int  GObd::Set_bbox_local_status( GV_Bbox_status bbstat )
{
  return  GV_obd_set_bbox_local_status( m_InsideObd, bbstat );
}

int  GObd::Get_bbox_full( GV_Bbox *bbox,GV_Bbox_status * p_bbstat)
{
	return  GV_obd_inq_bbox_full( m_InsideObd, bbox,p_bbstat);
}

int  GObd::Set_bbox_full( const GV_Bbox *bbox)
{
  return  GV_obd_set_bbox_full( m_InsideObd, bbox);
}


int  GObd::Get_bbox_full_status( GV_Bbox_status * p_bbstat)
{
  return  GV_obd_inq_bbox_full_status( m_InsideObd, p_bbstat);
}

int  GObd::Set_bbox_full_status( GV_Bbox_status bbstat )
{
  return  GV_obd_set_bbox_full_status( m_InsideObd, bbstat );
}

int  GObd::Set_coordinate_system( GV_Coord_sys csys)
{
  return  GV_obd_set_coordinate_system( m_InsideObd, csys);
}

int  GObd::Get_coordinate_system( GV_Coord_sys * p_csys)
{
  return  GV_obd_inq_coordinate_system( m_InsideObd, p_csys);
}


int  GObd::Set_gfx_state( G_State gstate_in)
{
  return  GV_obd_set_gfx_state( m_InsideObd, gstate_in); 
}

int  GObd::Get_gfx_state( G_State * gstate_out)
{
  return  GV_obd_inq_gfx_state( m_InsideObd, gstate_out);
}

int  GObd::Set_drawing_order( int  drawing_order_in)
{
  return  GV_obd_set_drawing_order( m_InsideObd, drawing_order_in);
}

int  GObd::Get_drawing_order( int  * drawing_order_out)
{
  return  GV_obd_inq_drawing_order( m_InsideObd, drawing_order_out);
}

int  GObd::Set_traversal_type( GV_Obj_traversal_type ttype)
{
  return  GV_obd_set_traversal_type( m_InsideObd, ttype);
}

int  GObd::Get_traversal_type( GV_Obj_traversal_type * p_ttype)
{
  return  GV_obd_inq_traversal_type( m_InsideObd, p_ttype);
}

int  GObd::Set_lod_range( float fnear, float ffar)
{
  return  GV_obd_set_lod_range(m_InsideObd,fnear,ffar);
}

int  GObd::Get_lod_range( float *fnear, float *ffar )
{
  return  GV_obd_inq_lod_range( m_InsideObd,fnear,ffar );
}

int  GObd::Set_lod_state( G_State lod_state )
{
  return  GV_obd_set_lod_state( m_InsideObd, lod_state );
}

int  GObd::Get_lod_state( G_State * p_lod_state )
{
  return  GV_obd_inq_lod_state( m_InsideObd, p_lod_state );
}

int  GObd::Set_culling_mode( GV_Obj_culling_mode cmode_in)
{
  return  GV_obd_set_culling_mode( m_InsideObd, cmode_in);
}

int  GObd::Get_culling_mode( GV_Obj_culling_mode * cmode_out)
{
  return  GV_obd_inq_culling_mode( m_InsideObd, cmode_out);
}

int  GObd::Set_culling_state( G_State cstate_in)
{
  return  GV_obd_set_culling_state( m_InsideObd, cstate_in);
}

int  GObd::Get_culling_state( G_State * cstate_out)
{
  return  GV_obd_inq_culling_state( m_InsideObd, cstate_out);
}

int  GObd::Get_transparency_state( G_Tristate * p_tstate)
{
  return  GV_obd_inq_transparency_state( m_InsideObd, p_tstate);
}

int  GObd::Set_transparency_state( G_Tristate mode)
{
  return  GV_obd_set_transparency_state( m_InsideObd, mode);
}

int  GObd::Get_alpha_method( GV_Obj_alpha_method * AlphaMethodOut )
{
  return  GV_obd_inq_alpha_method( m_InsideObd, AlphaMethodOut );
}

int  GObd::Set_alpha_method( GV_Obj_alpha_method AlphaMethodIn)
{
  return  GV_obd_set_alpha_method( m_InsideObd, AlphaMethodIn);
}

int  GObd::Set_gfx_data( int  nbytes, void * pdata )
{
  return  GV_obd_set_gfx_data( m_InsideObd, nbytes,pdata );
}

int  GObd::Get_gfx_data( int  * nbytes, void ** pdata )
{
  return GV_obd_inq_gfx_data( m_InsideObd, nbytes, pdata );
}

int  GObd::Set_gfx_callback( GV_Obi_callback gfunc)
{
  return  GV_obd_set_gfx_callback( m_InsideObd, gfunc);
}

int  GObd::Get_gfx_callback( GV_Obi_callback * p_gfunc)
{
  return  GV_obd_inq_gfx_callback( m_InsideObd, p_gfunc);
}

int  GObd::Set_gfx_post_callback( GV_Obi_callback gfunc)
{
  return  GV_obd_set_gfx_post_callback( m_InsideObd, gfunc);
}

int  GObd::Get_gfx_post_callback( GV_Obi_callback * p_gfunc)
{
  return  GV_obd_inq_gfx_post_callback( m_InsideObd, p_gfunc);
}

int  GObd::Set_sim_data( int  nbytes, void * pdata )
{
  return  GV_obd_set_sim_data( m_InsideObd, nbytes,pdata );
}

int  GObd::Get_sim_data( int  * nbytes, void ** pdata )
{
  return  GV_obd_inq_sim_data( m_InsideObd, nbytes, pdata );
}

int  GObd::Set_sim_callback( GV_Obi_callback sfunc)
{
  return  GV_obd_set_sim_callback( m_InsideObd, sfunc);
}

int  GObd::Get_sim_callback( GV_Obi_callback * p_sfunc)
{
  return  GV_obd_inq_sim_callback( m_InsideObd, p_sfunc);
}


int  GObd::Add_count( GV_Obj_count gltype_in, int count_in )
{
  return  GV_obd_add_count( m_InsideObd, gltype_in,count_in );
}

int  GObd::Set_count( GV_Obj_count gltype_in, int count_in )
{
  return  GV_obd_set_count( m_InsideObd, gltype_in, count_in );
}

int  GObd::Get_count_local( GV_Obj_count gltype_in, int *count_out )
{
  return  GV_obd_inq_count_local( m_InsideObd,gltype_in,count_out );
}

int  GObd::Get_count_global( GV_Obj_count gltype_in, int *count_out )
{
  return GV_obd_inq_count_global( m_InsideObd,gltype_in,count_out );
}

int  GObd::Set_composition_mask( G_Mask cmask)
{
  return  GV_obd_set_composition_mask( m_InsideObd, cmask);
}

int  GObd::Get_composition_mask( G_Mask * cmask)
{
  return  GV_obd_inq_composition_mask( m_InsideObd, cmask);
}

int  GObd::Set_lod_scale( float lod_scale_factor )
{
  return  GV_obd_set_lod_scale( m_InsideObd, lod_scale_factor );
}

int  GObd::Get_lod_scale( float * p_lod_scale_factor )
{
  return  GV_obd_inq_lod_scale( m_InsideObd, p_lod_scale_factor );
}

int  GObd::Set_position_limit_min( const G_Position *vecmin )
{
  return  GV_obd_set_position_limit_min( m_InsideObd, vecmin );
}

int  GObd::Get_position_limit_min( G_Position *vecmin )
{
  return  GV_obd_inq_position_limit_min( m_InsideObd, vecmin );
}

int  GObd::Get_rotation_limit_min( G_Rotation *vecmin )
{
  return  GV_obd_inq_rotation_limit_min( m_InsideObd, vecmin );
}

int  GObd::Set_rotation_limit_min( const G_Rotation *vecmin )
{
  return  GV_obd_set_rotation_limit_min( m_InsideObd, vecmin );
}

int  GObd::Get_scaling_limit_min( G_Vector3 *vecmin )
{
  return  GV_obd_inq_scaling_limit_min( m_InsideObd, vecmin );
}

int  GObd::Set_scaling_limit_min( const G_Vector3 *vecmin )
{
  return  GV_obd_set_scaling_limit_min( m_InsideObd, vecmin );
}

int  GObd::Set_position_limit_max( const G_Position *vecmax )
{
  return  GV_obd_set_position_limit_max( m_InsideObd, vecmax );
}

int  GObd::Get_position_limit_max( G_Position *vecmax)
{
  return  GV_obd_inq_position_limit_max( m_InsideObd, vecmax);
}

int  GObd::Get_rotation_limit_max( G_Rotation *vecmax )
{
  return  GV_obd_inq_rotation_limit_max( m_InsideObd, vecmax );
}

int  GObd::Set_rotation_limit_max( const G_Rotation *vecmax )
{
  return  GV_obd_set_rotation_limit_max( m_InsideObd, vecmax );
}

int  GObd::Get_scaling_limit_max( G_Vector3 *vecmax )
{
  return  GV_obd_inq_scaling_limit_max( m_InsideObd,vecmax );
}

int  GObd::Set_scaling_limit_max( const G_Vector3 *vecmax )
{
  return  GV_obd_set_scaling_limit_max( m_InsideObd, vecmax );
}


int  GObd::Set_geo( const GV_Geometry geo_db)
{
  return  GV_obd_set_geo( m_InsideObd, geo_db);
}

int  GObd::Get_geo( GV_Geometry *geo_db)
{
  return  GV_obd_inq_geo( m_InsideObd, geo_db);
}


int  GObd::Set_centroid( const G_Position * centroid_in )
{
	return  GV_obd_set_centroid( m_InsideObd, centroid_in ) ;
}

int  GObd::Get_centroid( G_Position * centroid_out )
{
  return  GV_obd_inq_centroid( m_InsideObd, centroid_out ) ;
}


int  GObd::Get_comment_count( int * num_comments_out )
{
  return  GV_obd_inq_comment_count( m_InsideObd, num_comments_out ) ;
}

int  GObd::Get_comment( int comment_index_in, int buf_dim, char * buf_out, int * num_bytes_out )
{
  return  GV_obd_inq_comment( m_InsideObd,comment_index_in,buf_dim,buf_out,num_bytes_out ) ;
}

int  GObd::Set_comment( int comment_index_in, int buf_dim, const char * buf_in )
{
  return  GV_obd_set_comment( m_InsideObd,comment_index_in,buf_dim,buf_in ) ;
}

int  GObd::Add_comment( int buf_dim, const char * buf_in, int * comment_index_out )
{
  return  GV_obd_add_comment( m_InsideObd,buf_dim,buf_in,comment_index_out ) ;
}

int  GObd::Free_comment( int comment_index_in)
{
  return  GV_obd_free_comment(m_InsideObd, comment_index_in) ;
}

int  GObd::Free_comments_all()
{
  return  GV_obd_free_comments_all( m_InsideObd ) ;
}



int  GObd::Set_switch_table( int nmasks_in,int  Words_per_mask_in, const GV_Obj_switch_mask * mask_in )
{
  return  GV_obd_set_switch_table( m_InsideObd, nmasks_in,Words_per_mask_in, mask_in ) ;
}

/*  Get_switch_table -- Returns the number of switch
    masks for this object.  Also, if mask_out is not NULL:
    1.  returns the masks (up to min(tdim_in,nmasks_out)).
    2.  Gives failure return if tdim_in < nmasks_out.
    Parameters, input:
	obdhdl -- object handle
	tdim_in -- dimension of mask_out.  If all is well, this will
	    be the product (nmasks_out * words_per_mask_out).
	nmasks_out -- receives number of masks for the object.
	words_per_mask_out -- Number of 32-bit words for each mask.
	mask_out -- Pointer to table of dimension tdim_in
    */
int  GObd::Get_switch_table( int tdim_in, int * nmasks_out,int * words_per_mask_out, GV_Obj_switch_mask * mask_out )
{
  return GV_obd_inq_switch_table( m_InsideObd, tdim_in,nmasks_out,words_per_mask_out,mask_out ) ;
}


/*  GV_obi_inq_switch_table -- Returns the number of switch
    masks for this object.  Also, if mask_out is not NULL:
    1.  returns the masks (up to min(tdim_in,nmasks_out)).
    2.  Gives failure return if tdim_in < nmasks_out.
    Parameters, input:
	obihdl --
	tdim_in -- dimension of mask_out
	nmasks_out -- receives number of masks for the object.
	mask_out -- Pointer to table of dimension tdim_in
    */


int  GObd::Set_switch_current( int switch_cur_in )
{
  return  GV_obd_set_switch_current( m_InsideObd, switch_cur_in ) ;
}

int  GObd::Get_switch_current( int * switch_cur_out )
{
  return  GV_obd_inq_switch_current( m_InsideObd, switch_cur_out ) ;
}

int  GObd::Recompute_bbox_full(  )
{
  return  GV_obd_recompute_bbox_full( m_InsideObd ) ;
}

int  GObd::Set_bbox_full_recompute_state( G_State rcs_in )
{
  return  GV_obd_set_bbox_full_recompute_state( m_InsideObd, rcs_in ) ;
}

int  GObd::Get_bbox_full_recompute_state( G_State * rcs_out )
{
  return  GV_obd_inq_bbox_full_recompute_state( m_InsideObd, rcs_out ) ;
}


int  GVS_obj_free_lookaside_lists(void)
{
  return GV_obj_free_lookaside_lists() ;
}

int  GVS_obj_inq_alpha_method_default( GV_Obj_alpha_method * AlphaMethodOut )
{
 return  GV_obj_inq_alpha_method_default( AlphaMethodOut );
}

int  GVS_obj_set_alpha_method_default( GV_Obj_alpha_method AlphaMethodIn )
{
 return  GV_obj_set_alpha_method_default( AlphaMethodIn );
}
