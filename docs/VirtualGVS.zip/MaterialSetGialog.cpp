// MaterialSetGialog.cpp : implementation file
//

#include "stdafx.h"
#include "VirtualGVS.h"
#include <g_sys.h>                 /* Target system information     */
#include <g_consts.h>              /* Some universal constants      */
#include <gv_sys.h>
#include <gv.h>                    /* Entire OpenGVS kernel         */

#include "OpenGVS\GMaterial.h"
#include "MaterialSetGialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMaterialSetGialog dialog


CMaterialSetGialog::CMaterialSetGialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMaterialSetGialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMaterialSetGialog)
	m_CheckRadio = -1;
	//}}AFX_DATA_INIT
	m_pMaterial = NULL;

}


void CMaterialSetGialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMaterialSetGialog)
	DDX_Control(pDX, IDC_RGBA_RSLIDER, m_RSlider);
	DDX_Control(pDX, IDC_RGBA_GSLIDER, m_GSlider);
	DDX_Control(pDX, IDC_RGBA_BSLIDER, m_BSlider);
	DDX_Control(pDX, IDC_RGBA_ASLIDER, m_ASlider);
	DDX_Radio(pDX, IDC_ANBIENTRADIO, m_CheckRadio);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMaterialSetGialog, CDialog)
	//{{AFX_MSG_MAP(CMaterialSetGialog)
	ON_WM_SHOWWINDOW()
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_RGBA_RSLIDER, OnCustomdrawRgbaRslider)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_RGBA_GSLIDER, OnCustomdrawRgbaGslider)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_RGBA_BSLIDER, OnCustomdrawRgbaBslider)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_RGBA_ASLIDER, OnCustomdrawRgbaAslider)
	ON_BN_CLICKED(IDC_ANBIENTRADIO, OnAnbientradio)
	ON_BN_CLICKED(IDC_DIFFUSERADIO, OnDiffuseradio)
	ON_BN_CLICKED(IDC_SPECULARRADIO, OnSpecularradio)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMaterialSetGialog message handlers

void CMaterialSetGialog::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

void CMaterialSetGialog::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
    if( m_pMaterial == NULL )
		return;

	GV_Rgba  Ambient_Rgba;
	GV_mtl_inq_ambient(m_pMaterial,&Ambient_Rgba );

	m_RSlider.SetPos( Ambient_Rgba.r*10 );
	m_GSlider.SetPos( Ambient_Rgba.g*10 );
	m_BSlider.SetPos( Ambient_Rgba.b*10 );
	m_ASlider.SetPos( Ambient_Rgba.a*10 );

}

BOOL CMaterialSetGialog::OnInitDialog() 
{
	

	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_RSlider.SetRangeMin( 0 );
    m_RSlider.SetRangeMax(100);
	
	m_GSlider.SetRangeMin( 0 );
    m_GSlider.SetRangeMax(100);
	
	m_BSlider.SetRangeMin( 0 );
    m_BSlider.SetRangeMax(100);

	m_ASlider.SetRangeMin( 0 );
    m_ASlider.SetRangeMax(100);
     
    	this->m_CheckRadio = 0;
		this->UpdateData(FALSE);
    
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
float  Noise(int x)
{
	x = (x<<13) ^ x;
    return  ( 1.0 - ( (x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0);    
}

void CMaterialSetGialog::OnCustomdrawRgbaRslider(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int  Range = m_RSlider.GetPos( );
	GV_Rgba  Ambient_Rgba;
	GV_mtl_inq_ambient(m_pMaterial,&Ambient_Rgba );
    Ambient_Rgba.r = ((float)Range)/10;
    GV_mtl_set_ambient(m_pMaterial,&Ambient_Rgba );
    GV_mtl_define( m_pMaterial );
    *pResult = 0;
}

void CMaterialSetGialog::OnCustomdrawRgbaGslider(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int  Range = m_GSlider.GetPos( );
	GV_Rgba  Ambient_Rgba;
	GV_mtl_inq_ambient(m_pMaterial,&Ambient_Rgba );
    Ambient_Rgba.g = ((float)Range)/10;
    GV_mtl_set_ambient(m_pMaterial,&Ambient_Rgba );
    GV_mtl_define( m_pMaterial );
	
	*pResult = 0;
}

void CMaterialSetGialog::OnCustomdrawRgbaBslider(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int  Range = m_BSlider.GetPos( );
	GV_Rgba  Ambient_Rgba;
	GV_mtl_inq_ambient(m_pMaterial,&Ambient_Rgba );
    Ambient_Rgba.b = ((float)Range)/10;
    GV_mtl_set_ambient(m_pMaterial,&Ambient_Rgba );
    GV_mtl_define( m_pMaterial );
	
	*pResult = 0;
}

void CMaterialSetGialog::OnCustomdrawRgbaAslider(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
		int  Range = m_ASlider.GetPos( );
	GV_Rgba  Ambient_Rgba;
	GV_mtl_inq_ambient(m_pMaterial,&Ambient_Rgba );
    Ambient_Rgba.a = ((float)Range)/10;
    GV_mtl_set_ambient(m_pMaterial,&Ambient_Rgba );
    GV_mtl_define( m_pMaterial );

	*pResult = 0;
}

void CMaterialSetGialog::OnAnbientradio() 
{
	// TODO: Add your control notification handler code here
	
}

void CMaterialSetGialog::OnDiffuseradio() 
{
	// TODO: Add your control notification handler code here
	
}

void CMaterialSetGialog::OnSpecularradio() 
{
	// TODO: Add your control notification handler code here
	
}
