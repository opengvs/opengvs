//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VirtualGVS.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_VIRTUATYPE                  129
#define IDD_GVSTOOLPANE                 130
#define IDB_GVSTREEVIEW                 131
#define IDD_MATERIALDIALOG              132
#define IDC_GVSOBJECTTREE               1000
#define IDC_GVSPROPERTYLIST             1001
#define IDC_RGBA_RSLIDER                1003
#define IDC_RGBA_GSLIDER                1004
#define IDC_SPIN1                       1004
#define IDC_RGBA_BSLIDER                1005
#define IDC_EDIT1                       1005
#define IDC_RGBA_ASLIDER                1006
#define IDC_ANBIENTRADIO                1007
#define IDC_DIFFUSERADIO                1008
#define IDC_SPECULARRADIO               1009
#define IDC_EDIT2                       1010
#define IDC_EDIT3                       1011
#define IDC_EDIT4                       1012
#define IDC_EDIT5                       1013
#define ID_GVSPANESHOW                  32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
