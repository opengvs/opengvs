﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenGLObject;
using OpenTK.Mathematics;
using OpenTK;
using OpenTK.Graphics;
using OpenTK.Graphics.OpenGL4;

namespace CsharpeOpenGL_LightAndMaterial
{
    public class SphereUseMaterial : Transform
    {
        // 将球横纵划分成50X50的网格
        const int Y_SEGMENTS = 50;
        const int X_SEGMENTS = 50;
        List<float> _sphere_vertices = new List<float>();
        List<float> _sphere_mNormals = new List<float>();
        List<float> _sphere_mTexCoords = new List<float>();
        List<int> _sphere_indices = new List<int>();
        public Vector3 viewPosition;
        public Material useMaterial;
        public VertexArrayObject m_vao;

        public ParallelLight  directLight;
        public DotLight       pointLight;
        public SpotLight       spotLight;
        public int useLightType = 0;//0代表使用平行光光源，1表示使用点光源，

        public bool useBlinn = false;

        public SphereUseMaterial(Material _useMaterial) : base()
        {
            useMaterial = _useMaterial;

            float radius = 2.0f;

            // 生成球的顶点
            for (int j = 0; j <= Y_SEGMENTS; j++)
            {
                for (int i = 0; i <= X_SEGMENTS; i++)
                {

                    float iSegment = (float)i / (float)X_SEGMENTS;
                    float jSegment = (float)j / (float)Y_SEGMENTS;
                    float xPos =
                       (float)(Math.Cos(iSegment * 2.0f * MathHelper.Pi) * Math.Sin(jSegment * MathHelper.Pi) * radius);
                    float yPos = (float)Math.Cos(jSegment * MathHelper.Pi) * radius;
                    float zPos =
                       (float)(Math.Sin(iSegment * 2.0f * MathHelper.Pi) * Math.Sin(jSegment * MathHelper.Pi) * radius);

                    _sphere_vertices.Add(xPos);
                    _sphere_vertices.Add(yPos);
                    _sphere_vertices.Add(zPos);

                    //这里应该使用一个临时变量
                    Vector3 v3 = new Vector3(xPos, yPos, zPos);
                    //然后对v3进行矢量归一化
                    v3.X = xPos;
                    v3.Y = yPos;
                    v3.Z = zPos;
                    v3.Normalize();

                    _sphere_mNormals.Add(v3.X);
                    _sphere_mNormals.Add(v3.Y);
                    _sphere_mNormals.Add(v3.Z);

                    //这个位置花费了我3天时间，开始没想到计算结果为0的问题，总是不显示纹理
                    //试了很多中办法，在将该代码改为EathSphereobject后放入TextureCube工程发现还是不显示，
                    //才意识到计算的纹理坐标可能为0
                    float tempU = (float)i / (float)X_SEGMENTS;
                    float tempV = (float)j / (float)X_SEGMENTS;

                    _sphere_mTexCoords.Add(tempU);
                    _sphere_mTexCoords.Add(tempV);

                }
            }

            // 生成球的Indices
            for (int i = 0; i < Y_SEGMENTS; i++)
            {
                for (int j = 0; j < X_SEGMENTS; j++)
                {
                    _sphere_indices.Add(i * (X_SEGMENTS + 1) + j);
                    _sphere_indices.Add((i + 1) * (X_SEGMENTS + 1) + j);
                    _sphere_indices.Add((i + 1) * (X_SEGMENTS + 1) + j + 1);

                    _sphere_indices.Add(i * (X_SEGMENTS + 1) + j);
                    _sphere_indices.Add((i + 1) * (X_SEGMENTS + 1) + j + 1);
                    _sphere_indices.Add(i * (X_SEGMENTS + 1) + j + 1);
                }
            }
            m_vao = new VertexArrayObject();
            m_vao.Bind();
            m_vao.AddVertexBufferObjectFloat(_sphere_vertices.ToArray(), sizeof(float) * _sphere_vertices.Count, 3, BufferUsageHint.StaticDraw, 0);
            // shader expects: location 1 = aTexCoord, location 2 = aNormal
            m_vao.AddVertexBufferObjectFloat(_sphere_mTexCoords.ToArray(), sizeof(float) * _sphere_mTexCoords.Count, 2, BufferUsageHint.StaticDraw, 1);
            m_vao.AddVertexBufferObjectFloat(_sphere_mNormals.ToArray(), sizeof(float) * _sphere_mNormals.Count, 3, BufferUsageHint.StaticDraw, 2);

            m_vao.SetElementBufferObject<int>(_sphere_indices.ToArray(), sizeof(int) * _sphere_indices.Count, BufferUsageHint.StaticDraw);
        }
        public void Draw(Shader? _shader)
        {
            _shader?.Bind();

            //在这里传入灯光个材质属性
            if (useLightType == 0)
            {
                //平行光属性
                _shader?.SetVector3("directLight.direction", directLight.direction);

                _shader?.SetVector3("directLight.ambient", directLight.ambient);
                _shader?.SetVector3("directLight.diffuse", directLight.diffuse);
                _shader?.SetVector3("directLight.specular", directLight.specular);
            }
            else if (useLightType == 1)
            {
                _shader?.SetVector3("pointLight.position", pointLight.position);

                _shader?.SetVector3("pointLight.ambient", pointLight.ambient);
                _shader?.SetVector3("pointLight.diffuse", pointLight.diffuse);
                _shader?.SetVector3("pointLight.specular", pointLight.specular);
            }
            else if (useLightType == 2)
            {
                _shader?.SetVector3("spotLight.position", spotLight.position);
                _shader?.SetVector3("spotLight.direction", spotLight.direction);
                _shader?.SetVector3("spotLight.ambient", spotLight.ambient);
                _shader?.SetVector3("spotLight.diffuse", spotLight.diffuse);
                _shader?.SetVector3("spotLight.specular", spotLight.specular);

                _shader?.SetFloat("spotLight.cutOff", spotLight.cutOff);
                _shader?.SetFloat("spotLight.outerCutOff", spotLight.outerCutOff);
            }

            _shader?.SetVector3("viewPos", viewPosition);

            _shader?.SetVector3("material.ambient", useMaterial.ambient);
            _shader?.SetVector3("material.diffuse", useMaterial.diffuse);
            _shader?.SetVector3("material.specular", useMaterial.specular);
            _shader?.SetFloat("material.shininess", useMaterial.shininess);
            if (useBlinn == true)
            {
                _shader?.SetInt("blinn", 1);
            }
            else
            {
                _shader?.SetInt("blinn", 0);
            }

            // 使用内部的 VAO 对象来进行绘制
            m_vao.Draw(_shader);
        }

        // C# 版本：从原始 C++ 函数移植并适配到当前类型签名
        public void Draw(Camera _camera, Shader _shader, Material _material, LightBase _light, bool isBlin)
        {
            if (_shader == null || _camera == null || _material == null || _light == null)
                return;

            _shader.Bind();
            _shader.SetVector3("viewPos", _camera.Position);
            _shader.SetInt("blinn", isBlin ? 1 : 0);

            // 材质属性
            _shader.SetVector3("material.ambient", _material.ambient);
            _shader.SetVector3("material.diffuse", _material.diffuse);
            _shader.SetVector3("material.specular", _material.specular);
            _shader.SetFloat("material.shininess", _material.shininess);

            // 灯光属性，根据具体子类设置对应 uniform 名称
            if (_light is ParallelLight p)
            {
                _shader.SetVector3("directLight.ambient", p.ambient);
                _shader.SetVector3("directLight.diffuse", p.diffuse);
                _shader.SetVector3("directLight.specular", p.specular);
                _shader.SetVector3("directLight.direction", p.direction);
            }
            else if (_light is DotLight d)
            {
                _shader.SetVector3("pointLight.ambient", d.ambient);
                _shader.SetVector3("pointLight.diffuse", d.diffuse);
                _shader.SetVector3("pointLight.specular", d.specular);
                _shader.SetVector3("pointLight.position", d.position);
            }
            else if (_light is SpotLight s)
            {
                _shader.SetVector3("spotLight.ambient", s.ambient);
                _shader.SetVector3("spotLight.diffuse", s.diffuse);
                _shader.SetVector3("spotLight.specular", s.specular);
                _shader.SetVector3("spotLight.position", s.position);
                _shader.SetVector3("spotLight.direction", s.direction);
                _shader.SetFloat("spotLight.cutOff", s.cutOff);
                _shader.SetFloat("spotLight.outerCutOff", s.outerCutOff);
            }

            // 设置矩阵
            _shader.SetMatrix4("projection", _camera.GetProjectionMatrix());
            _shader.SetMatrix4("view", _camera.GetViewMatrix());
            _shader.SetMatrix4("model", GetMatrix4());

            // 绘制
            m_vao.Draw(_shader);

            _shader.Unbind();
        }

    }
}
