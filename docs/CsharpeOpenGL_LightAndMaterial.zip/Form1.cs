using DotLiquid.Util;
using OpenGLObject;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using System.CodeDom;
using System.Reflection;
using System.Windows.Forms;

namespace CsharpeOpenGL_LightAndMaterial
{
    public partial class OpenTKMainForm : Form
    {
        public OpenTKMainForm()
        {
            InitializeComponent();
        }
        private void OpenTKMainForm_Load(object sender, EventArgs e)
        {

            openglView.Resize += openglView_Resize;
            openglView.Paint += openglView_Paint;

            int w = this.openglView.Width;
            int h = this.openglView.Height;
            float _Fov = 120;
            float _aspect = (float)h / (float)w;
            float _Near = 0.1f;
            float _Far = 1000.0f;

            GL.Viewport(0, 0, w, h);  //����ߴ�����

            // ��������Ʋ���С�ӽ��Լ����Ե͸�ӻ��䣬ʹ�������������ɼ�
            m_MainCamera = new Camera(new Vector3(0f, 1f, 13f), // eye (�����Զ����΢Сһ��)
                                       new Vector3(0, 0, 0),  // center
                                       new Vector3(0, 1, 0),  // up
                                       60,                    // FOV ��С�� 60 ��
                                       (float)w / (float)h,
                                       0.1f,
                                       1000.0f);
            Vector3 angleV = m_MainCamera.getRotation();


            m_ParallelLightShader = new Shader(m_vsShader, fs_ParallelLightShader);
            m_DotLightShader = new Shader(m_vsShader, fs_PointLightShader);
            m_SpotLightShader = new Shader(m_vsShader, fs_SpotLightShader);



            m_ParallelLight = new ParallelLight();
            m_DotLight = new DotLight();
            m_SpotLight = new SpotLight();

            // Ĭ�Ϲ��ղ�����C++ ԭ��Ŀ��ͨ�������þ�����ɫ/λ�ã�
            m_ParallelLight.direction = new Vector3(-0.2f, -1.0f, -0.3f);
            m_ParallelLight.ambient = new Vector3(0.05f, 0.05f, 0.05f);
            m_ParallelLight.diffuse = new Vector3(0.4f, 0.4f, 0.4f);
            m_ParallelLight.specular = new Vector3(0.5f, 0.5f, 0.5f);

            m_DotLight.position = new Vector3(2.0f, 4.0f, 2.0f);
            m_DotLight.ambient = new Vector3(0.05f, 0.05f, 0.05f);
            m_DotLight.diffuse = new Vector3(1.0f, 1.0f, 1.0f);
            m_DotLight.specular = new Vector3(1.0f, 1.0f, 1.0f);

            m_SpotLight.position = m_MainCamera != null ? m_MainCamera.Position : new Vector3(0f, 0f, 0f);
            m_SpotLight.direction = m_MainCamera != null ? m_MainCamera.Front : new Vector3(0f, 0f, -1f);
            m_SpotLight.ambient = new Vector3(0.0f, 0.0f, 0.0f);
            m_SpotLight.diffuse = new Vector3(1.0f, 1.0f, 1.0f);
            m_SpotLight.specular = new Vector3(1.0f, 1.0f, 1.0f);
            m_SpotLight.cutOff = 12.5f; // ��� shader ʹ�� cos �Ƚϣ�������Ҫ���� cos(angle)
            m_SpotLight.outerCutOff = 17.5f;

            g_Material_1 = new Material();
            g_Material_1.ambient = new Vector3(0.0f, 0.0f, 0.0f);
            g_Material_1.diffuse = new Vector3(0.8f, 0.8f, 0.8f);
            g_Material_1.specular = new Vector3(0.0f, 0.0f, 0.0f);
            g_Material_1.shininess = 0.0f;

            g_EmeraldMaterial = Materials.GetEmeraldMaterial();//���
            g_JadeMaterial = Materials.GetJadeMaterial();//��
            g_ObsidianMaterial = Materials.GetObsidianMaterial();//����ʯ
            g_PearlMaterial = Materials.GetPearlMaterial();//����
            g_RubyMaterial = Materials.GetRubyMaterial();//�챦ʯ
            g_TurquoiseMaterial = Materials.GetTurquoiseMaterial();//����ʯ
            g_BrassMaterial = Materials.GetBrassMaterial();//��ͭ
            g_BronzeMaterial = Materials.GetBronzeMaterial();//��ͭ
            g_ChromeMaterial = Materials.GetChromeMaterial();//��
            g_CopperMaterial = Materials.GetCopperMaterial();//ͭ
            g_GoldMaterial = Materials.GetGoldMaterial();//�ƽ�
            g_SilverMaterial = Materials.GetSilverMaterial();//��
            g_GreenPlastic = Materials.GetGreenPlasticMaterial();//��ɫ����
            g_CyanRubber = Materials.GetCyanRubberMaterial();//��ɫ��


            m_SphereUseMaterial = new SphereUseMaterial(Materials.GetEmeraldMaterial());
           
            
            // �趨�����Ļ����Ļ��ʾ�ı���ɫ������������ɫ
            GL.ClearColor(0.2f, 0.3f, 0.3f, 1.0f);

            timer1.Enabled = true;


        }

        private void OpenTKMainForm_FormClosed(object sender, FormClosedEventArgs e)
        {

            m_ParallelLightShader?.Dispose();
            m_DotLightShader?.Dispose();
            m_SpotLightShader?.Dispose();

            


        }
        static float time = 0.0f;

        private void openglView_Paint(object sender, PaintEventArgs e)
        {
            // ����
            GL.Viewport(0, 0, openglView.Width, openglView.Height);
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            GL.Enable(EnableCap.DepthTest);

            // ʹ����������񲼾ֻ������壬�����������ص�
            Material[] mats = new Material[] {
                g_Material_1, g_EmeraldMaterial, g_JadeMaterial, g_ObsidianMaterial, g_PearlMaterial,
                g_RubyMaterial, g_TurquoiseMaterial, g_BrassMaterial, g_BronzeMaterial, g_ChromeMaterial,
                g_CopperMaterial, g_GoldMaterial, g_SilverMaterial, g_GreenPlastic, g_CyanRubber
            };

            int rows = 3;
            int cols = 5;
            float spacingX = 4.5f; // ˮƽ��ࣨ��С�Ա��ⳬ�����ڣ�
            float spacingY = 4.5f; // ��ֱ���
            float startX = -((cols - 1) / 2.0f) * spacingX;
            float startY = ((rows - 1) / 2.0f) * spacingY;

            int idx = 0;
            for (int r = 0; r < rows; r++)
            {
                for (int c = 0; c < cols; c++)
                {
                    if (idx >= mats.Length) break;
                    float x = startX + c * spacingX;
                    float y = startY - r * spacingY;
                    m_SphereUseMaterial.SetPosition(x, y, 0.0f);
                    // ��С�����Լ��ٱ�Ե����
                    m_SphereUseMaterial.SetScale(0.85f, 0.85f, 0.85f);
                    m_SphereUseMaterial.Draw(m_MainCamera, m_DotLightShader, mats[idx], m_DotLight, true);
                    idx++;
                }
            }

            // ����������
            openglView.SwapBuffers();
        }

        private void openglView_Resize(object sender, EventArgs e)
        {
            int w = this.openglView.Width;
            int h = this.openglView.Height;
            GL.Viewport(0, 0, w, h);  //����ߴ�����
            // �趨�����Ļ����Ļ��ʾ�ı���ɫ������������ɫ
            GL.ClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Refresh();
        }

        Shader? m_ParallelLightShader;
        Shader? m_DotLightShader;
        Shader? m_SpotLightShader;

        Camera? m_MainCamera;
 

        ParallelLight    m_ParallelLight;
        DotLight         m_DotLight;
        SpotLight        m_SpotLight;

        SphereUseMaterial m_SphereUseMaterial;

        Material g_Material_1;
        Material g_EmeraldMaterial;//���
        Material g_JadeMaterial;//��
        Material g_ObsidianMaterial;//����ʯ
        Material g_PearlMaterial;//����
        Material g_RubyMaterial;//�챦ʯ
        Material g_TurquoiseMaterial;//����ʯ
        Material g_BrassMaterial;//��ͭ
        Material g_BronzeMaterial;//��ͭ
        Material g_ChromeMaterial;//��
        Material g_CopperMaterial;//ͭ
        Material g_GoldMaterial;//�ƽ�
        Material g_SilverMaterial;//��
        Material g_GreenPlastic;//��ɫ����
        Material g_CyanRubber;//��ɫ��


        static public string m_vsShader = "#version 460 core                    \n" +
              "   layout(location = 0) in   vec3 aPos;                          \n" +
              "   layout(location = 1) in   vec2 aTexCoord;                     \n" +
              "   layout(location = 2) in   vec3 aNormal;                       \n" +
              "   out  vec3 FragPos;                                             \n" +
              "   out  vec2 TexCoord;                                            \n" +
              "   out  vec3 Normal;                                              \n" +
              "   uniform mat4 model;                                            \n" +
              "   uniform mat4 view;                                             \n" +
              "   uniform mat4 projection;                                       \n" +
              "   void main()                                                    \n" +
              "   {                                                              \n" +
              "      gl_Position = projection * view * model * vec4(aPos, 1.0f); \n" +
              "      FragPos = vec3(model * vec4(aPos, 1.0));                    \n" +
              "      TexCoord = vec2(aTexCoord.x, aTexCoord.y);                  \n" +
              "      Normal = vec3(aNormal.x, aNormal.y, aNormal.z);             \n" +
              "   }\n";

        string fs_ParallelLightShader = "# version 460 core                      \n" +
                 "   struct Material                                             \n" +
                 "   {                                                           \n" +
                 "      vec3 ambient;                                            \n" +  
                 "      vec3 diffuse;                                            \n" +
                 "      vec3 specular;                                           \n" +
                 "      float shininess;                                         \n" +
                 "   };                                                          \n" +
                 "   struct DirectLight                                          \n" +
                 "   {                                                           \n" +
                 "      vec3 direction;                                          \n" +
                 "      vec3 ambient;                                            \n" +
                 "      vec3 diffuse;                                            \n" +
                 "      vec3 specular;                                           \n" +
                 "   };                                                          \n" +                                                                                                        
                 "   out vec4 FragColor;                                         \n" +                                                                                        
                 "   in  vec3 FragPos;                                           \n" +
                 "   in  vec2 TexCoord;                                          \n" +                                                                                          
                 "   in  vec3 Normal;                                            \n" +
                 "   uniform bool blinn;                                         \n" +
                 "   uniform vec3 viewPos;                                       \n" +                                                                                    
                 "   uniform Material material;                                  \n" +                                                                               
                 "   uniform DirectLight  directLight;                           \n" +                                                                           
                 "   void main()                                                 \n" +
                 "   {                                                           \n" +
                        // ��������--������ļ���ܼ򵥣����ǿ��*����ǿ��*������ɫ(����������ɫĬ��Ϊ1) 
                 "       vec3 ambient = directLight.ambient * material.ambient;  \n" +
                        // ������---                                           
                 "       vec3 norm = normalize(Normal);                          \n" +
                 "       vec3 lightDir = normalize(-directLight.direction);      \n" +
                 "       float diff = max(dot(norm, lightDir), 0.0);             \n" +
                 "       vec3 diffuse = directLight.diffuse * (diff * material.diffuse); \n" +
                        // �������                                             
                 "       vec3 viewDir = normalize(viewPos - FragPos);            \n" +
                 "       float spec = 0;                                         \n" +
                 "       if (blinn)                                              \n" +
                 "       {                                                       \n" +
                 "          vec3 halfwayDir = normalize(lightDir + viewDir);     \n" +
                 "          spec = pow(max(dot(norm, halfwayDir), 0.0), material.shininess);   \n" +
                 "       }                                                                     \n" +
                 "       else                                                                  \n" +
                 "       {                                                                     \n" +
                 "          vec3 reflectDir = reflect(-lightDir, norm);                        \n" +
                 "          spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);\n" +
                 "       }                                                                     \n" +
                 "       vec3 specular = directLight.specular * (spec * material.specular);    \n" +
                 "       vec3 result = ambient + diffuse + specular;                           \n" +
                 "       FragColor = vec4(result, 1.0);                                        \n" +
                 "   }";

	      string fs_PointLightShader = "# version 460 core                                     \n" +                                            
                 "   struct Material                                                           \n" +        
                 "   {                                                                         \n" +
                 "      vec3 ambient;                                                          \n" +
                 "      vec3 diffuse;                                                          \n" +
                 "      vec3 specular;                                                         \n" +
                 "      float shininess;                                                       \n" +
                 "   };                                                                        \n" +
                 "   struct PointLight                                                         \n" +
                 "   {                                                                         \n" +
                 "      vec3 position;                                                         \n" +
                 "      vec3 ambient;                                                          \n" +
                 "      vec3 diffuse;                                                          \n" +
                 "      vec3 specular;                                                         \n" +
                 "   };                                                                        \n" +                                                                                                        
                 "   out vec4 FragColor;                                                       \n" +                                                                                      
        
                 "   in vec3 FragPos;                                                          \n" +
                 "   in  vec2 TexCoord;                                                        \n" +                                                                                            
                 "   in vec3 Normal;                                                               \n" +
                    //�ڹ���ģ�ͼ�������в���Ҫ�����������ɫ����ʵMaterial����ֵ�൱���������ɫ
                    //   uniform vec3 objectColor;       ���㱾������ɫ                                                                      

                 "   uniform int blinn;                                                            \n" +
                 "   uniform vec3 viewPos;                                                         \n" +                                                                                      
                 "   uniform Material material;                                                    \n" +                                                                                

                 "   uniform PointLight pointLight;                                                \n" +                                                                                
                 "   void main()                                                                   \n" +
                 "   {                                                                             \n" +
                       // ��������--������ļ���ܼ򵥣����ǿ��*����ǿ��*������ɫ(����������ɫĬ��Ϊ1)
                 "      vec3 ambient = pointLight.ambient * material.ambient;                           \n" +

                       // ������---                                                                    
                 "      vec3 norm = normalize(Normal);                                                  \n" +
                 "      vec3 lightDir = normalize(pointLight.position - FragPos);                       \n" +
                 "      float diff = max(dot(norm, lightDir), 0.0);                                     \n" +
                 "      vec3 diffuse = pointLight.diffuse * (diff * material.diffuse);                  \n" +

                       // �������                                                          
                 "      vec3 viewDir = normalize(viewPos - FragPos);                         \n" +
                 "      float spec = 0;                                                      \n" +
                 "      if (blinn == 1)                                                      \n" +
                 "      {                                                                    \n" +
                 "          vec3 halfwayDir = normalize(lightDir + viewDir);                 \n" +
                 "          spec = pow(max(dot(norm, halfwayDir), 0.0), material.shininess); \n" +
                 "      }                                                                    \n" +
                 "      else                                                                 \n" +
                 "      {                                                                    \n" +
                 "          vec3 reflectDir = reflect(-lightDir, norm);                      \n" +
                 "          spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);\n" +
                 "      }                                                                      \n" +
                 "      vec3 specular = pointLight.specular * (spec * material.specular);      \n" +
                 "      vec3 result = ambient + diffuse + specular;                            \n" +
                 "      FragColor = vec4(result, 1.0);                                         \n" +
                 "   }\n";

          string fs_SpotLightShader = "# version 330 core                                      \n" +                    
                 "   struct Material                                                           \n" +
                 "   {                                                                         \n" +
                 "       vec3 ambient;                                                         \n" +
                 "       vec3 diffuse;                                                         \n" +
                 "       vec3 specular;                                                        \n" +
                 "       float shininess;                                                      \n" +
                 "   };                                                                        \n" +
                 "   struct SpotLight                                                          \n" +
                 "    {                                                                        \n" +
                 "       vec3 position;                                                        \n" +
                 "       vec3 direction;                                                       \n" +
                 "       float cutOff;                                                         \n" +
                 "       float outerCutOff;                                                    \n" +

                 "       vec3 ambient;                                                         \n" +
                 "       vec3 diffuse;                                                         \n" +
                 "       vec3 specular;                                                        \n" +
                 "   };                                                                        \n" +                                                                  
                 "   out vec4 FragColor;                                                       \n" +                                                                      
                 "   in vec3 FragPos;                                                          \n" +                                                                       
                 "   in vec3 Normal;                                                           \n" +

                    //�ڹ���ģ�ͼ�������в���Ҫ�����������ɫ����ʵMaterial����ֵ�൱���������ɫ  
                    //   uniform vec3 objectColor;      // ���㱾������ɫ                                                                      
                 "   uniform int blinn;                                                         \n" +
                 "   uniform vec3 viewPos;                                                      \n" +                                                                   
                 "   uniform Material material;                                                 \n" +                                                               
                 "   uniform SpotLight  spotLight;                                              \n" +   
                 "   float constant = 1.0;                                                      \n" +
                 "   float linear = 0.0;                                                        \n" +
                 "   float quadratic = 0.0;                                                     \n" +
                 "   void CalculateAttenuation(float distance)                                  \n" +
                 "   {                                                                   \n" +
                 "       if (distance < 7.0)                                             \n" +
                 "       {                                                               \n" +
                 "             linear = 0.7;                                             \n" +
                 "             quadratic = 1.8;                                          \n" +
                 "       }                                                               \n" +
                 "       else if (distance < 13.0)                                       \n" +
                 "       {                                                               \n" +
                 "            linear = 0.35;                                             \n" +
                 "            quadratic = 0.44;                                          \n" +
                 "       }                                                               \n" +
                 "       else if (distance < 20.0)                                       \n" +
                 "       {                                                               \n" +
                 "           linear = 0.22;                                              \n" +
                 "           quadratic = 0.20;                                           \n" +
                 "       }                                                               \n" +
                 "       else if (distance < 32.0)                                       \n" +
                 "       {                                                               \n" +
                 "           linear = 0.14;                                              \n" +
                 "           quadratic = 0.07;                                           \n" +
                 "       }                                                               \n" +
                 "       else if (distance < 50.0)                                       \n" +
                 "       {                                                               \n" +
                 "           linear = 0.09;                                              \n" +
                 "           quadratic = 0.032;                                          \n" +
                 "       }                                                               \n" +
                 "       else if (distance < 65.0)                                       \n" +
                 "       {                                                               \n" +
                 "           linear = 0.07;                                              \n" +
                 "           quadratic = 0.017;                                          \n" +
                 "       }                                                               \n" +
                 "       else if (distance < 100.0)                                      \n" +
                 "       {                                                               \n" +
                 "           linear = 0.045;                                             \n" +
                 "           quadratic = 0.0075;                                         \n" +
                 "       }                                                               \n" +
                 "       else if (distance < 160.0)                                      \n" +
                 "       {                                                               \n" +
                 "           linear = 0.027;                                             \n" +
                 "           quadratic = 0.0028;                                         \n" +
                 "       }                                                               \n" +
                 "       else if (distance < 200.0)                                      \n" +
                 "       {                                                               \n" +
                 "           linear = 0.022;                                             \n" +
                 "           quadratic = 0.0019;                                         \n" +
                 "      }                                                                \n" +
                 "       else if (distance < 325.0)                                      \n" +
                 "       {                                                               \n" +
                 "           linear = 0.014;                                             \n" +
                 "           quadratic = 0.0007;                                         \n" +
                 "       }                                                               \n" +
                 "       else if (distance < 600.0)                                      \n" +
                 "       {                                                               \n" +
                 "           linear = 0.007;                                             \n" +
                 "           quadratic = 0.0002;                                         \n" +
                 "       }                                                               \n" +
                 "       else if (distance < 3250.0)                                     \n" +
                 "       {                                                               \n" +
                 "           linear = 0.0014;                                            \n" +
                 "           quadratic = 0.000007;                                       \n" +
                 "       }                                                               \n" +
                "   }                                                                    \n" +
                "   void main()                                                          \n" +
                "   {                                                                    \n" +
                       // ����������շ�����                                          
                "       vec3 ambient = spotLight.ambient * material.ambient;             \n" +

                       // ��������--������ļ���ܼ򵥣����ǿ��*����ǿ��*������ɫ(����������ɫĬ��Ϊ1)  
                "      vec3 lightDir = normalize(spotLight.position - FragPos);                           \n" +

                       // ����������ϵ��                                                  
                "      float diff = max(dot(Normal, lightDir), 0.0);                       \n" +
                "      vec3 diffuse = spotLight.diffuse * diff * material.diffuse;         \n" +

                      // ���淴��ϵ��                                                      
                "      vec3 viewDir = normalize(viewPos - FragPos);                         \n" +
                "      vec3 specular;                                                       \n" +
                "      if (blinn == 1)                                                      \n" +
                "      {                                                                    \n" +
                "         vec3 halfwayDir = normalize(lightDir + viewDir);                  \n" +
                "         float spec = pow(max(dot(Normal, halfwayDir), 0.0), material.shininess);\n" +
                "         specular = spotLight.specular * (spec * material.specular);       \n" +
                "      }                                                                    \n" +
                "      else                                                                 \n" +
                "      {                                                                    \n" +
                "         vec3 reflectDir = reflect(-lightDir, Normal);                     \n" +
                "         float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);\n" +
                "         specular = spotLight.specular * (spec * material.specular);         \n" +
                "      }                                                                      \n" +
                      // ����˥��                                                            
                "      float distance = length(spotLight.position - FragPos);                 \n" +
                "      CalculateAttenuation(distance);                                        \n" +
                "      float attenuation = 1.0f / (constant + linear * distance + quadratic * (distance * distance));\n" +

                      //������۹��spotDir�н�����ֵ                                        
                "     float theta = dot(lightDir, normalize(-spotLight.direction));           \n" +
                "     float inCutOff = cos(spotLight.cutOff);                                 \n" +
                "     float outCutOff = cos(spotLight.outerCutOff);                           \n" +

                "     float epsilon = inCutOff - outCutOff;                                   \n" +
                "     float intensity = clamp((theta - outCutOff) / epsilon, 0.0, 1.0);       \n" +

                    // ����۹�ϵ��                                                           
                "     //     float theta = dot(lightDir, normalize(-spotLight.direction));     \n" +                   
                "     //    float epsilon = spotLight.cutOff - spotLight.outerCutOff;          \n" +                           
                "     //     float intensity = clamp((theta - spotLight.outerCutOff) / epsilon, 0.0, 1.0); \n" +  

                   //��ÿ�����շ�������˥��ϵ���;۹�ϵ��                                      
                   //     ambient *= attenuation * intensity;                                                                                  
                "    diffuse *= attenuation * intensity;                                        \n" +
                "    specular *= attenuation * intensity;                                       \n" +
                "    if (theta < inCutOff)                                                      \n" +
                "    {                                                                          \n" +
                "        vec3 result = ambient * attenuation * intensity + diffuse + specular;  \n" +
                "        FragColor = vec4(result, 1.0);                                          \n" +
                "    }                                                                           \n" +
                "    else                                                                         \n" +
                "    {                                                                            \n" +
                "        FragColor = vec4(ambient, 1.0);                                          \n" +
                "    }                                                                            \n" +
                "   }";




 
 

    }

}

