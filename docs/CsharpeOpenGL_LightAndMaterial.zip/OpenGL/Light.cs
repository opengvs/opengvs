﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Mathematics;

namespace OpenGLObject
{
    public enum LightType
    {
        Parallel_Light = 1,//平行光
        Dot_Light,  //点光源
        Spot_Light,  //聚光灯
    }
    public class LightBase
    {
        LightType lightType; //光源类型

        public Vector3 ambient = Vector3.Zero; //环境光颜色
        public Vector3 diffuse = Vector3.Zero; //漫射光颜色
        public Vector3 specular = Vector3.Zero; //镜面光颜色

        public LightBase() { }
        protected LightBase(LightType _lightType = LightType.Parallel_Light)
	    {
            lightType = _lightType;
	    }

        void SendAmbientData(ref readonly Shader pShader, ref readonly string _AmbientName)
	    {
		   pShader.SetVector3(_AmbientName, ambient);
	    }
	    void SendDiffuseData(ref readonly Shader pShader, ref readonly string _DiffuseName)
        {
            pShader.SetVector3(_DiffuseName, diffuse);
        }
        void SendSpecularData(ref readonly Shader pShader, ref readonly string _SpecularName)
        {
            pShader.SetVector3(_SpecularName, specular);
        }
    }

    public class ParallelLight :  LightBase
    {
        public Vector3 direction = Vector3.Zero;   //平行光照射方向                                                                                       \n" +


        public  ParallelLight():base(LightType.Parallel_Light)
        {

        }
        public  ParallelLight(Vector3 _direction) : base(LightType.Parallel_Light)
        {
            direction = _direction;
        }

        public  void SendDirectionData(ref readonly Shader pShader, ref readonly string _DirectionName)
        {
           pShader.SetVector3(_DirectionName, direction);
        }
    };

    public class DotLight :  LightBase
    {
        public Vector3 position = Vector3.Zero;
        //Vector3      direction = Vector3.Zero;

        public DotLight() :base(LightType.Dot_Light)
        {

        }

        public void SendPositionData( Shader pShader, string _positionName)
        {
           pShader.SetVector3(_positionName, position);
        }
    };

    public class SpotLight : LightBase
    {
        public Vector3 position = Vector3.Zero; //光源位置
        public Vector3 direction = Vector3.Zero;//光的方向，即上图的SpotDir
        public float cutOff = 0.0f;            //内圆锥切角
        public float outerCutOff = 0.0f;          //外圆锥切角

        //一下三个参数在Shader中根据位置远近自动进行调整，不需要传入Shader
        //public float _constant_attenuation; //常量衰减
        //public float _linear_attenuation; //线性衰减
        //public float _quadratic_attenuatin;//二次方衰减
        public SpotLight() : base(LightType.Spot_Light)
        {
        }

        public SpotLight(Vector3 _position, Vector3 _direction, float _cutOff, float _outerCutOff) : base(LightType.Spot_Light)
        {
            position = _position;
            direction = _direction;
            cutOff = _cutOff;
            outerCutOff = _outerCutOff;
        }
        public void SendPositionData(ref readonly Shader pShader, ref readonly string _positionName)
        {
            pShader.SetVector3(_positionName, position);
        }
        public void SendDirectionData(ref readonly Shader pShader, ref readonly string _directionName)
        {
            pShader.SetVector3(_directionName, direction);
        }
        public void SendCutOffData(ref readonly Shader pShader, ref readonly string _cutOffName)
        {
            pShader.SetFloat(_cutOffName, cutOff);
        }
        public void SendOuterCutOffData(ref readonly Shader pShader, ref readonly string _outerCutOffName)
        {
            pShader.SetFloat(_outerCutOffName, outerCutOff);
        }
    };

}
