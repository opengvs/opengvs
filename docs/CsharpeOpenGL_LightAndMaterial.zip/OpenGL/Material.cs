﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Mathematics;

namespace OpenGLObject
{
    public class Material
    {

        public string? Name;
        //环境光材质参数            默认值为GL_ambient
        public Vector3 ambient = new Vector3(0.2f, 0.2f, 0.2f);//表示材质对环境光反射的RGBA值，前后表面的缺省值都是 (0.2, 0.2, 0.2, 1.0)。
        //漫射光材质参数         默认值为GL_diffuse和GL_ambient_AND_diffuse
        public Vector3 diffuse = new Vector3(0.8f, 0.8f, 0.8f);//表示材质对漫射光的反射RGBA值，前后表面的缺省值都是 (0.8, 0.8, 0.8, 1.0)。
        ////镜面反射材质参数     默认值为GL_specular 
        public Vector3 specular = new Vector3(0.0f, 0.0f, 0.0f);//表示材质对镜面光的反射RGBA值，前后表面的缺省值都是 (0.0, 0.0, 0.0, 1.0)。
        //镜面指数光亮度
        public float shininess = 0.0f;//表示材质的镜面指数，取值范围是[0,128]，当取值为128时，则表示该材质是一完全镜面。缺省值为0。

        //材料是自发光物体
        public Vector3 emissive = new Vector3(0.0f, 0.0f, 0.0f); //表示材质辐射光RGBA值，前后表面的缺省值都是 (0.0, 0.0, 0.0, 1.0)。

        public Vector3 reflective = new Vector3(0.0f, 0.0f, 0.0f);//反射，光影,

        public Vector3 transparent = new Vector3(1.0f, 1.0f, 1.0f);//透明度材质

        public Vector4 t = new Vector4(0.0f, 0.0f, 0.0f, 0.0f);

        public int index = 0;



        public static readonly Material Default = new Material
        {
            Name = "Default"
        };

        public bool IsDefault => this == Default;



        public int CompareTo(object obj)
        {
            if (obj is Material)
            {
                if (obj.Equals(this))
                {
                    return 0;
                }

                Material gLMaterial = (Material)obj;
                if (index > gLMaterial.index)
                {
                    return 1;
                }

                return -1;
            }

            return 1;
        }

        private bool EqualFloatArray(float[] left, float[] right)
        {
            if (left == null)
            {
                return right == null;
            }

            if (right == null)
            {
                return false;
            }

            if (left.Length != right.Length)
            {
                return false;
            }

            int num = left.Length;
            for (int i = 0; i < num; i++)
            {
                if (left[i] == right[i])
                {
                    return false;
                }
            }

            return true;
        }

        void SendAmbientData(ref readonly Shader pShader, ref readonly string _ambientName)
        {
            pShader.SetVector3(_ambientName, ambient);
        }

        void SendDiffuseData(ref readonly Shader pShader, ref readonly string _DiffuseName )
        {
            pShader.SetVector3(_DiffuseName, diffuse);
        }

        void SendSpecularData(ref readonly Shader pShader, ref readonly string _SpecularName, ref readonly string _ShininessName)
        {
            pShader.SetVector3(_SpecularName, specular);
            pShader.SetFloat(_ShininessName, shininess);
        }

        void SendEmissiveData(Shader pShader, string _EmissiveName)
        {
            pShader.SetVector3(_EmissiveName, emissive);
        }

        void SendReflectiveData(Shader  pShader, string _ReflectiveName)
        {
            pShader.SetVector3(_ReflectiveName, reflective);
        }

        void SendTransparentData(Shader  pShader, string _TransparentName)
        {
            pShader.SetVector3(_TransparentName, transparent);
        }
    }
    public class Materials
    {
        public static Material GetEmeraldMaterial()
        {
            Material material = new Material();
            material.Name = "Emerald";//翡翠
            material.ambient.X = 0.0215f;
            material.ambient.Y = 0.1745f;
            material.ambient.Z = 0.0215f;
            material.diffuse.X = 0.07568f;
            material.diffuse.Y = 0.61424f;
            material.diffuse.Z = 0.07568f;
            material.specular.X = 0.07568f;
            material.specular.Y = 0.61424f;
            material.specular.Z = 0.07568f;
            material.shininess = 0.6f;
            return material;
        }

        public static Material GetJadeMaterial()
        {
            Material material = new Material();
            material.Name = "Jade";//玉
            material.ambient.X = 0.135f;
            material.ambient.Y = 0.2225f;
            material.ambient.Z = 0.1575f;
            material.diffuse.X = 0.54f;
            material.diffuse.Y = 0.89f;
            material.diffuse.Z = 0.63f;
            material.specular.X = 0.316228f;
            material.specular.Y = 0.316228f;
            material.specular.Z = 0.316228f;
            material.shininess = 0.1f;
            return material;
        }

        public static Material GetObsidianMaterial()
        {
            Material material = new Material();
            material.Name = "Obsidian";//黑曜石
            material.ambient.X = 0.05375f;
            material.ambient.Y = 0.05f;
            material.ambient.Z = 0.06f;
            material.diffuse.X = 0.18275f;
            material.diffuse.Y = 0.17f;
            material.diffuse.Z = 0.22525f;
            material.specular.X = 0.332741f;
            material.specular.Y = 0.328634f;
            material.specular.Z = 0.346435f;
            material.shininess = 0.3f;
            return material;
        }
        public static Material GetPearlMaterial()
        {
            Material material = new Material();
            material.Name = "Pearl";//珍珠
            material.ambient.X = 0.25f;
            material.ambient.Y = 0.20725f;
            material.ambient.Z = 0.20725f;
            material.diffuse.X = 1.0f;
            material.diffuse.Y = 0.829f;
            material.diffuse.Z = 0.829f;
            material.specular.X = 0.296648f;
            material.specular.Y = 0.296648f;
            material.specular.Z = 0.296648f;
            material.shininess = 0.088f;
            return material;
        }
        public static Material GetRubyMaterial()
        {
            Material material = new Material();
            material.Name = "Ruby";//红宝石
            material.ambient.X = 0.1745f;
            material.ambient.Y = 0.01175f;
            material.ambient.Z = 0.01175f;
            material.diffuse.X = 0.61424f;
            material.diffuse.Y = 0.04136f;
            material.diffuse.Z = 0.04136f;
            material.specular.X = 0.727811f;
            material.specular.Y = 0.626959f;
            material.specular.Z = 0.626959f;
            material.shininess = 0.6f;
            return material;
        }
        public static Material GetTurquoiseMaterial()
        {
            Material material = new Material();
            material.Name = "Turquoise";//绿松石
            material.ambient.X = 0.1f;
            material.ambient.Y = 0.18725f;
            material.ambient.Z = 0.1745f;
            material.diffuse.X = 0.396f;
            material.diffuse.Y = 0.74151f;
            material.diffuse.Z = 0.69102f;
            material.specular.X = 0.297254f;
            material.specular.Y = 0.30829f;
            material.specular.Z = 0.306678f;
            material.shininess = 0.1f;
            return material;
        }
        public static Material GetBrassMaterial()
        {
            Material material = new Material();
            material.Name = "Brass";//黄铜
            material.ambient.X = 0.329412f;
            material.ambient.Y = 0.223529f;
            material.ambient.Z = 0.027451f;
            material.diffuse.X = 0.780392f;
            material.diffuse.Y = 0.568627f;
            material.diffuse.Z = 0.113725f;
            material.specular.X = 0.992157f;
            material.specular.Y = 0.941176f;
            material.specular.Z = 0.807843f;
            material.shininess = 0.21794872f;
            return material;
        }
        public static Material GetBronzeMaterial()
        {
            Material material = new Material();
            material.Name = "Bronze";//青铜
            material.ambient.X = 0.2125f;
            material.ambient.Y = 0.1275f;
            material.ambient.Z = 0.054f;
            material.diffuse.X = 0.714f;
            material.diffuse.Y = 0.4284f;
            material.diffuse.Z = 0.18144f;
            material.specular.X = 0.393548f;
            material.specular.Y = 0.271906f;
            material.specular.Z = 0.166721f;
            material.shininess = 0.2f;
            return material;
        }
        public static Material GetChromeMaterial()
        {
            Material material = new Material();
            material.Name = "Chrome";//铬
            material.ambient.X = 0.25f;
            material.ambient.Y = 0.25f;
            material.ambient.Z = 0.25f;
            material.diffuse.X = 0.4f;
            material.diffuse.Y = 0.4f;
            material.diffuse.Z = 0.4f;
            material.specular.X = 0.774597f;
            material.specular.Y = 0.774597f;
            material.specular.Z = 0.774597f;
            material.shininess = 0.6f;
            return material;
        }
        public static Material GetCopperMaterial()
        {
            Material material = new Material();
            material.Name = "Copper";//铜
            material.ambient.X = 0.19125f;
            material.ambient.Y = 0.0735f;
            material.ambient.Z = 0.0225f;
            material.diffuse.X = 0.7038f;
            material.diffuse.Y = 0.27048f;
            material.diffuse.Z = 0.0828f;
            material.specular.X = 0.256777f;
            material.specular.Y = 0.137622f;
            material.specular.Z = 0.086014f;
            material.shininess = 0.1f;
            return material;
        }
        public static Material GetGoldMaterial()
        {
            Material material = new Material();
            material.Name = "Gold";//黄金
            material.ambient.X = 0.24725f;
            material.ambient.Y = 0.1995f;
            material.ambient.Z = 0.0745f;
            material.diffuse.X = 0.75164f;
            material.diffuse.Y = 0.60648f;
            material.diffuse.Z = 0.22648f;
            material.specular.X = 0.638281f;
            material.specular.Y = 0.555802f;
            material.specular.Z = 0.366065f;
            material.shininess = 0.4f;
            return material;
        }
        public static Material GetSilverMaterial()
        {
            Material material = new Material();
            material.Name = "Silver";//银
            material.ambient.X = 0.19225f;
            material.ambient.Y = 0.19225f;
            material.ambient.Z = 0.19225f;
            material.diffuse.X = 0.50754f;
            material.diffuse.Y = 0.50754f;
            material.diffuse.Z = 0.50754f;
            material.specular.X = 0.508273f;
            material.specular.Y = 0.508273f;
            material.specular.Z = 0.508273f;
            material.shininess = 0.4f;
            return material;
        }
        public static Material GetBlackPlasticMaterial()
        {
            Material material = new Material();
            material.Name = "BlackPlastic";//黑色塑料
            material.ambient.X = 0.0f;
            material.ambient.Y = 0.0f;
            material.ambient.Z = 0.0f;
            material.diffuse.X = 0.1f;
            material.diffuse.Y = 0.1f;
            material.diffuse.Z = 0.1f;
            material.specular.X = 0.5f;
            material.specular.Y = 0.5f;
            material.specular.Z = 0.5f;
            material.shininess = 0.25f;
            return material;
        }
        public static Material GetCyanPlasticMaterial()
        {
            Material material = new Material();
            material.Name = "CyanPlastic";//青色塑料
            material.ambient.X = 0.0f;
            material.ambient.Y = 0.0f;
            material.ambient.Z = 0.06f;
            material.diffuse.X = 0.0f;
            material.diffuse.Y = 0.50980392f;
            material.diffuse.Z = 0.50980392f;
            material.specular.X = 0.50196078f;
            material.specular.Y = 0.50196078f;
            material.specular.Z = 0.50196078f;
            material.shininess = 0.25f;
            return material;
        }
        public static Material GetGreenPlasticMaterial()
        {
            Material material = new Material();
            material.Name = "GreenPlastic";//黑色塑料
            material.ambient.X = 0.0f;
            material.ambient.Y = 0.0f;
            material.ambient.Z = 0.0f;
            material.diffuse.X = 0.1f;
            material.diffuse.Y = 0.35f;
            material.diffuse.Z = 0.1f;
            material.specular.X = 0.45f;
            material.specular.Y = 0.55f;
            material.specular.Z = 0.45f;
            material.shininess = 0.25f;
            return material;
        }
        public static Material GetRedPlasticMaterial()
        {
            Material material = new Material();
            material.Name = "RedPlastic";//黑色塑料
            material.ambient.X = 0.0f;
            material.ambient.Y = 0.0f;
            material.ambient.Z = 0.0f;
            material.diffuse.X = 0.5f;
            material.diffuse.Y = 0.0f;
            material.diffuse.Z = 0.0f;
            material.specular.X = 0.7f;
            material.specular.Y = 0.6f;
            material.specular.Z = 0.6f;
            material.shininess = 0.25f;
            return material;
        }
        public static Material GetWhitePlasticMaterial()
        {
            Material material = new Material();
            material.Name = "WhitePlastic";//白色塑料
            material.ambient.X = 0.0f;
            material.ambient.Y = 0.0f;
            material.ambient.Z = 0.0f;
            material.diffuse.X = 0.55f;
            material.diffuse.Y = 0.55f;
            material.diffuse.Z = 0.55f;
            material.specular.X = 0.7f;
            material.specular.Y = 0.7f;
            material.specular.Z = 0.7f;
            material.shininess = 0.25f;
            return material;
        }
        public static Material GetYellowPlasticMaterial()
        {
            Material material = new Material();
            material.Name = "YellowPlastic";//黄色塑料
            material.ambient.X = 0.0f;
            material.ambient.Y = 0.0f;
            material.ambient.Z = 0.0f;
            material.diffuse.X = 0.5f;
            material.diffuse.Y = 0.5f;
            material.diffuse.Z = 0.0f;
            material.specular.X = 0.6f;
            material.specular.Y = 0.6f;
            material.specular.Z = 0.5f;
            material.shininess = 0.25f;
            return material;
        }
        public static Material GetBlackRubberMaterial()
        {
            Material material = new Material();
            material.Name = "BlackRubber";//黑色橡胶
            material.ambient.X = 0.02f;
            material.ambient.Y = 0.02f;
            material.ambient.Z = 0.02f;
            material.diffuse.X = 0.01f;
            material.diffuse.Y = 0.01f;
            material.diffuse.Z = 0.01f;
            material.specular.X = 0.4f;
            material.specular.Y = 0.4f;
            material.specular.Z = 0.4f;
            material.shininess = 0.78125f;
            return material;
        }
        public static Material GetCyanRubberMaterial()
        {
            Material material = new Material();
            material.Name = "CyanRubber";//青色橡胶
            material.ambient.X = 0.0f;
            material.ambient.Y = 0.05f;
            material.ambient.Z = 0.05f;
            material.diffuse.X = 0.4f;
            material.diffuse.Y = 0.5f;
            material.diffuse.Z = 0.5f;
            material.specular.X = 0.04f;
            material.specular.Y = 0.7f;
            material.specular.Z = 0.7f;
            material.shininess = 0.78125f;
            return material;
        }
        public static Material GetGreenRubberMaterial()
        {
            Material material = new Material();
            material.Name = "GreenRubber";//绿色橡胶
            material.ambient.X = 0.0f;
            material.ambient.Y = 0.05f;
            material.ambient.Z = 0.0f;
            material.diffuse.X = 0.4f;
            material.diffuse.Y = 0.5f;
            material.diffuse.Z = 0.4f;
            material.specular.X = 0.04f;
            material.specular.Y = 0.7f;
            material.specular.Z = 0.04f;
            material.shininess = 0.78125f;
            return material;
        }
        public static Material GetRedRubberMaterial()
        {
            Material material = new Material();
            material.Name = "RedRubber";//红色橡胶
            material.ambient.X = 0.05f;
            material.ambient.Y = 0.0f;
            material.ambient.Z = 0.0f;
            material.diffuse.X = 0.5f;
            material.diffuse.Y = 0.4f;
            material.diffuse.Z = 0.4f;
            material.specular.X = 0.7f;
            material.specular.Y = 0.04f;
            material.specular.Z = 0.04f;
            material.shininess = 0.78125f;
            return material;
        }
        public static Material GetWhiteRubberMaterial()
        {
            Material material = new Material();
            material.Name = "WhiteRubber";//黑色橡胶
            material.ambient.X = 0.05f;
            material.ambient.Y = 0.05f;
            material.ambient.Z = 0.05f;
            material.diffuse.X = 0.5f;
            material.diffuse.Y = 0.5f;
            material.diffuse.Z = 0.5f;
            material.specular.X = 0.7f;
            material.specular.Y = 0.7f;
            material.specular.Z = 0.7f;
            material.shininess = 0.78125f;
            return material;
        }
        public static Material GetYellowRubberMaterial()
        {
            Material material = new Material();
            material.Name = "YellowRubber";//黄色橡胶
            material.ambient.X = 0.05f;
            material.ambient.Y = 0.05f;
            material.ambient.Z = 0.00f;
            material.diffuse.X = 0.5f;
            material.diffuse.Y = 0.5f;
            material.diffuse.Z = 0.4f;
            material.specular.X = 0.7f;
            material.specular.Y = 0.7f;
            material.specular.Z = 0.04f;
            material.shininess = 0.78125f;
            return material;
        }
    }
}
