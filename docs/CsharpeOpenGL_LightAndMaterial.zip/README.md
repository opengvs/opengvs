# CsharpeOpenGL_LightAndMaterial

这是一个基于 OpenTK 的 .NET 8（Windows Forms）示例工程，用于演示 OpenGL 光照与材质（Phong/Blinn）效果，原始项目改编自一个 C++ 的练习工程。

主要特性

- 使用 OpenTK (4.9.3) 进行 OpenGL 渲染
- 演示多种材质（预置一组常见材质）和光照类型（平行光 / 点光 / 聚光）
- 网格化绘制多个球体以便比较不同材质的视觉效果
- Shader 直接内嵌在 `Form1.cs` 中，顶点/片段着色器实现了 Blinn-Phong 高光选项

主要文件

- `Form1.cs` - 程序入口与 UI、着色器源码、主绘制循环（包含 shader 字符串、球体布局、相机与灯光初始化）
- `SphereUseMaterial.cs` - 球体对象，封装顶点数据、法线、纹理坐标、内部 VAO（VertexArrayObject）和 Draw 接口
- `OpenGL/VertexArrayObject.cs` - VAO 和 VBO 封装
- `OpenGL/VertexBufferObject.cs` - VBO 封装
- `OpenGL/Shader.cs` - Shader 程序封装（编译、链接、uniform 操作）
- `OpenGL/Camera.cs` - 简单相机（视图/投影矩阵）
- `OpenGL/Light.cs`, `OpenGL/Material.cs` - 光源与材质数据结构

依赖

- .NET 8 SDK
- NuGet 包：OpenTK (4.9.3), DotLiquid
- Visual Studio（建议 2022+，已在 Visual Studio Community 2026 上测试）

快速构建与运行

1. 在机器上安装 .NET 8 SDK。
2. 使用 Visual Studio 打开解决方案 `CsharpeOpenGL_LightAndMaterial.sln`。
3. 还原 NuGet 包（Visual Studio 会自动还原）并生成解决方案。
4. 运行（F5）程序。

常见问题与排查

- 看不到光照效果：
  - 确认 shader 的 uniform 名称与代码中 SetVector3/SetFloat 调用一致。
  - 确认顶点属性绑定顺序和 shader 的 layout(location=...) 一致（位置/纹理坐标/法线）。
  - 确认材质 specular/shininess 与光源颜色非零。

- 球体显示堆叠或超出窗口：
  - 可在 UI 中调整相机位置/旋转/FOV；项目中已提供相机参数控件。
  - 可在 `Form1.cs` 中调整网格 spacing 或球体缩放（spacingX/spacingY、SetScale）。

本仓库中已做的关键修复（移植自 C++ 时）

- 修正了 SphereUseMaterial 中顶点属性绑定顺序：location0 = position，location1 = texcoord，location2 = normal，确保法线正确传递给 shader。
- 将 SphereUseMaterial 从继承 VAO 改为继承 Transform，并在内部持有 `VertexArrayObject m_vao`，把绘制职责分离。
- 添加并移植了一个 C++ 风格的 Draw 函数为 C# 版本：public void Draw(Camera, Shader, Material, LightBase, bool)，用于上传材质与光照 uniform 并绘制。
- 在 Form1 初始化处设置了默认光源参数（direction/position/ambient/diffuse/specular），以便运行时能立即看到光照效果。
- 调整了相机初始位置与 FOV，使演示时球体布局更易观察；同时将球体布局改为可配置的网格并缩小边缘球体以减轻透视畸变。

建议改进项（可选）

- 将着色器文本抽出为独立 GLSL 文件，便于编辑与复用。
- 支持多个 VAO 实例而不是复用单个 SphereUseMaterial 对象绘制所有球体（可更灵活地为每个球体设置不同模型矩阵/缩放）。
- 添加 UI 控件以动态切换光源类型、开关 Blinn 模式、调整光源强度/位置等。

许可证

本项目为学习/练习用途；若基于其它开源代码转换，请遵守其原始许可。 

如果需要，我可以：
- 把 README 翻译为英文版本；
- 进一步整理工程结构或把 shader 提取为文件；
- 添加运行截图或 GIF 到 README 中。

---

作者: 项目移植与调试由 GitHub Copilot 辅助（输出为中文 README）。
